import assert from 'node:assert/strict';
import { createHash, generateKeyPairSync, randomBytes, sign, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const base = dirname(fileURLToPath(import.meta.url));
const require = createRequire(root + '/package.json');
const { Miniflare } = require('miniflare');
const { privateKey, publicKey } = generateKeyPairSync('ml-dsa-65');
const token = randomBytes(32).toString('hex');
const source = await readFile(base + '/load-worker.mjs', 'utf8');
const calls = [];
const attempts = new Map();
const knownKey = JSON.parse(await readFile(base + '/load-driver-key.json', 'utf8'));
const report = {
  qualification: 'Local load-driver validation with real durable alarms, simulated Router backpressure, and ordinary Node ML-DSA signatures. No threshold performance claim.',
  sourceSha256: createHash('sha256').update(source).digest('hex'),
  publicKeyDerHex: publicKey.export({ format: 'der', type: 'spki' }).toString('hex'),
  startedAtMs: Date.now(),
  cases: [],
  passed: false,
};

async function backend(request) {
  assert.equal(request.headers.get('x-router-ab-internal-service-auth'), token);
  const operation = await request.json();
  const identity = Buffer.from(operation.request.operation).toString('hex');
  const count = (attempts.get(identity) ?? 0) + 1;
  attempts.set(identity, count);
  calls.push({ atMs: Date.now(), identity, count });
  if (count === 1) return Response.json({ status: 'unavailable', reason: 'empty_pool', retry_at_ms: Date.now() + 1000 });
  if (count === 2) return Response.json({ status: 'existing', operation: { state: 'running' } });
  assert.equal(count, 3, 'A completed operation should not execute again');
  const signature = sign(null, Buffer.from(operation.message), privateKey);
  return Response.json({ status: 'existing', operation: { state: 'succeeded', signature: Array.from(signature) } });
}

const runtime = new Miniflare({
  compatibilityDate: '2026-06-12',
  compatibilityFlags: ['nodejs_compat'],
  modules: [
    { type: 'ESModule', path: 'entry.mjs', contents: "import { routeLoadRequest } from './load-worker.mjs'; export { LoadWallet } from './load-worker.mjs'; export default { fetch: routeLoadRequest };" },
    { type: 'ESModule', path: 'load-worker.mjs', contents: source },
  ],
  durableObjects: { TEST_WALLET: { className: 'LoadWallet', useSQLite: true } },
  bindings: { ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET: token },
  serviceBindings: { TEST_FRONT: backend },
});

async function call(name, input) {
  const response = await runtime.dispatchFetch('http://load/__benchmark/wallet/' + name, {
    method: input === null ? 'GET' : 'POST',
    headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token },
    body: input === null ? undefined : JSON.stringify(input),
  });
  assert.equal(response.status, 200);
  return response.json();
}

function sameOperation(row) {
  return Buffer.from(row.operation).toString('hex');
}

try {
  await runtime.ready;
  const startAtMs = Date.now() + 2000;
  const endAtMs = startAtMs + 65000;
  for (const intervalMs of [45000, 60000]) {
    const name = 'cadence-' + intervalMs;
    const result = await call(name, { index: intervalMs === 45000 ? 0 : 1, key: knownKey, startAtMs, endAtMs, intervalMs });
    assert.equal(result.started, true);
    const status = await call(name, null);
    assert.equal(status.state.config.intervalMs, intervalMs);
    report.cases.push({ name, intervalMs, startAtMs, endAtMs });
  }
  const deadline = Date.now() + 80000;
  while (true) {
    let complete = true;
    for (const entry of report.cases) {
      entry.snapshot = await call(entry.name, null);
      if (entry.snapshot.state.state !== 'complete') complete = false;
      assert.notEqual(entry.snapshot.state.state, 'failed', JSON.stringify(entry.snapshot.state));
    }
    if (complete) break;
    assert.ok(Date.now() < deadline, 'Durable drivers did not complete the bounded window');
    await delay(1000);
  }
  for (const entry of report.cases) {
    const snapshot = entry.snapshot;
    assert.equal(snapshot.state.successes, 2);
    assert.equal(snapshot.state.demands, 2);
    assert.equal(snapshot.requests.length, 6);
    const successful = snapshot.requests.filter(succeeded);
    assert.equal(successful.length, 2);
    for (const row of successful) {
      const message = Buffer.from(row.messageHex, 'hex');
      const signature = Buffer.from(row.signatureHex, 'hex');
      assert.equal(verify(null, message, publicKey, signature), true);
      message[0] ^= 1;
      assert.equal(verify(null, message, publicKey, signature), false);
    }
    const first = snapshot.requests.filter(firstDemand);
    assert.equal(new Set(first.map(sameOperation)).size, 1, 'Backpressure must reuse the operation ID');
    assert.deepEqual(first.map(requestState), ['empty_pool', 'running', 'succeeded']);
    const delta = snapshot.demands[1].startAtMs - snapshot.demands[0].startAtMs;
    assert.ok(delta >= entry.intervalMs && delta < entry.intervalMs + 5000, 'The next demand must use the configured cadence');
    assert.notEqual(sameOperation(successful[0]), sameOperation(successful[1]));
    entry.observedDemandSpacingMs = delta;
    entry.independentlyVerifiedSignatures = successful.length;
  }
  report.calls = calls;
  report.passed = true;
} finally {
  report.endedAtMs = Date.now();
  await writeFile(base + '/load-driver-validation.json', JSON.stringify(report, null, 2) + '\n');
  await runtime.dispose();
}

function succeeded(row) {
  return row.state === 'succeeded';
}
function firstDemand(row) {
  return row.demand === 1;
}
function requestState(row) {
  return row.reason ?? row.state;
}
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.map(result) }));
function result(entry) {
  return { intervalMs: entry.intervalMs, observedDemandSpacingMs: entry.observedDemandSpacingMs, verifiedSignatures: entry.independentlyVerifiedSignatures };
}
