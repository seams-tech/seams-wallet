import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const base = dirname(fileURLToPath(import.meta.url));
const report = JSON.parse(await readFile(base + '/load-driver-validation.json', 'utf8'));
assert.equal(report.passed, true);
const key = createPublicKey({ key: Buffer.from(report.publicKeyDerHex, 'hex'), format: 'der', type: 'spki' });
let verified = 0;
for (const entry of report.cases) {
  assert.ok(entry.observedDemandSpacingMs >= entry.intervalMs);
  assert.ok(entry.observedDemandSpacingMs < entry.intervalMs + 5000);
  assert.equal(entry.snapshot.state.state, 'complete');
  assert.equal(entry.snapshot.state.successes, 2);
  for (const row of entry.snapshot.requests) {
    if (row.state !== 'succeeded') continue;
    const message = Buffer.from(row.messageHex, 'hex');
    const signature = Buffer.from(row.signatureHex, 'hex');
    assert.equal(verify(null, message, key, signature), true);
    message[0] ^= 1;
    assert.equal(verify(null, message, key, signature), false);
    verified += 1;
  }
}
assert.equal(verified, 4);
console.log(JSON.stringify({ verified, alteredMessagesRejected: verified, passed: true }));
