# ML-DSA capacity-driver checkpoint

The verified hosted baseline remains 3.777968 signatures per cycle minute.
This checkpoint adds no hosted result and no preparation kernel change.
Four wallets with a sixty-second cooldown have a nominal four-demand-per-minute ceiling.
Closed-loop backpressure reduces actual demand. Failed retries can create more operation IDs within a demand.
Preparation uses 94.87% of captured protocol CPU in the old campaign. This measures cost, not utilization.

## Repeat local driver validation

From the Wallet repository with dependencies installed:

```sh
node /path/to/extracted/validate-load-driver.mjs
node /path/to/extracted/replay-load-driver.mjs
```

The first command runs for about seventy seconds. It uses actual workerd durable alarms.
The Router is simulated. It returns empty-pool and running replies before success.
Ordinary Node ML-DSA signatures check result accounting. This is not threshold performance evidence.
Private keys and authentication tokens exist only in memory.
The second command independently checks the retained signatures and altered messages.
`load-cli.mjs` is an inspection snapshot. The validation executes `load-worker.mjs`.

## Facts

| Fact | Instrument | Boundary | Check |
| --- | --- | --- | --- |
| Old campaign produces 38 verified signatures | Raw driver requests and provider records | Ten-minute load plus reserve restoration | Original analysis replays exactly |
| Preparation uses 1,036,261 of 1,092,319 CPU ms | Provider invocation CPU | Captured protocol Workers | Role totals reproduced independently |
| Three wallets finish all ten scheduled demands | Durable demand rows | Sixty-second offered cadence | Fourth wallet encounters rejection and empty-pool waits |
| Local drivers follow 45/60-second cadence | Actual workerd durable alarms | Simulated Router | Exact operation IDs persist through retries and four signatures verify |

## Causes and limits

| Claim | Evidence | Status |
| --- | --- | --- |
| 3.78 is maximum preparation capacity | Workload is capped near four admitted operations/minute | Unproven |
| Initial stock alone explains completions | All starting stock is consumed and full reserves are restored | Rejected |
| Unexplained material loss causes this cycle's deficit | Both material ledgers balance | Rejected for this cycle |
| The refill guard guarantees higher sustained throughput | No new matched hosted load exists | Unproven |
| CPU share establishes producer saturation | Invocation CPU does not measure unused available capacity | Rejected inference |

Next: matched twelve-minute baseline/candidate screens at a forty-five-second benchmark cooldown.
Keep production defaults and per-wallet capacity unchanged. Observe restoration immediately after driver completion.
Count all failed, unused and surplus work. Actual deployed versions and policy must match.
The exact new temporary-Worker credential approval is pending. No hosted action ran.
