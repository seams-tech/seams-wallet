# ML-DSA durable publication completion benchmark credential scope

Create the eight temporary Workers below and upload these exact fresh benchmark credentials.
A Workers receive only the A storage key. B Workers receive only the B storage key.
Credentials protect synthetic wallets. They contain no production wallet or account credentials.
The rerun retains two preparation slots, two-at-once consumption, sixteen pairs per wallet, and the sixty-second wallet cooldown.
Preparation stays on Workers. Wallet-seed recovery and standard FIPS export remain required.
Participant A reconciles durable publication after a completion error. Both participants expose the exact read-only publication check. Router uses the verified baseline. Cryptographic code, wire formats, and pool capacity stay unchanged.
All eight temporary Workers will be removed after measurements. Local private fixtures will be retained.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-pub-1026-278cab-router | 6ab74bef365679d5a8d747c45b8305e144e77a4a58668dd6ea109528a53457e8 |
| ml-dsa-pub-1026-278cab-a | 2b162f2d08cdc59782c43c6a2506e76337047ea748ae56396789d72872302fcb |
| ml-dsa-pub-1026-278cab-b | a22302eae580dc95e0ffbf88e3d43ee789a0576719dae000ed7de353d7976ef7 |
| ml-dsa-pub-1026-278cab-preparer-a | 2b162f2d08cdc59782c43c6a2506e76337047ea748ae56396789d72872302fcb |
| ml-dsa-pub-1026-278cab-preparer-b | a22302eae580dc95e0ffbf88e3d43ee789a0576719dae000ed7de353d7976ef7 |
| ml-dsa-pub-1026-278cab-preparer-a-secondary | 2b162f2d08cdc59782c43c6a2506e76337047ea748ae56396789d72872302fcb |
| ml-dsa-pub-1026-278cab-preparer-b-secondary | a22302eae580dc95e0ffbf88e3d43ee789a0576719dae000ed7de353d7976ef7 |
| ml-dsa-pub-1026-278cab-front | 6ab74bef365679d5a8d747c45b8305e144e77a4a58668dd6ea109528a53457e8 |
