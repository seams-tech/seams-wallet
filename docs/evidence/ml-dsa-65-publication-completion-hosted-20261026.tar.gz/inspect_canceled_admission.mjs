import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const client = JSON.parse(await readFile(base + '/cloud-driver/completion/client.json', 'utf8'));
const cycle = JSON.parse(await readFile(base + '/cloud-driver/completion/reserve-cycle.json', 'utf8'));
const requests = client.requests.filter(isCanceled);
assert.equal(requests.length, 1);
const request = requests[0];
const ids = cycle.complete_cycle_ledger.unaccounted_pairs;
assert.equal(ids.length, 12);
const results = [];
for (const role of ['a', 'b']) {
  const response = await fetch(scope.router_url + '/__benchmark/inspect/' + role, {
    method: 'POST',
    headers: {'content-type': 'application/json', 'x-router-ab-internal-service-auth': token},
    body: JSON.stringify({key: request.signingRequest.key, batches: ids.map(batchBytes)}),
    signal: AbortSignal.timeout(60000),
  });
  assert.equal(response.status, 200);
  const states = await response.json();
  assert.equal(states.length, ids.length);
  results.push({role, pairs: ids, states, observedAtMs: Date.now()});
}
const evidence = {
  scope: 'Read-only participant availability for the twelve pairs selected by the canceled admission. This proves final availability only. It does not identify the retirement mutation or distinguish burn from unlogged consumption.',
  requestId: request.requestId,
  operation: request.operation,
  key: request.signingRequest.key,
  results,
};
await writeFile(base + '/canceled-admission-inspection.json', JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify(results.map(summarize)));
function isCanceled(request) { return request.requestId === '134537fb2f81202e2c286bce38c22272'; }
function batchBytes(id) {
  assert.match(id, /^[0-9a-f]{64}$/);
  return Array.from(Buffer.from(id, 'hex'));
}
function summarize(result) { return {role: result.role, states: result.states}; }
