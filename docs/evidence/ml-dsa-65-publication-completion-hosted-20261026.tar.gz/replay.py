"""Reproduce recorded hosted checks without network access."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
BASE=Path(__file__).resolve().parent
PHASES=['warmup','completion']


def run(args,code=0):
    result=subprocess.run(args,cwd=BASE,capture_output=True,text=True)
    assert result.returncode==code,(args,result.stdout,result.stderr)


def reproduce(script,output,args):
    expected=json.loads((BASE/output).read_text())
    runtime='node' if script.endswith('.mjs') else sys.executable
    run([runtime,str(BASE/script),*args])
    assert json.loads((BASE/output).read_text())==expected,script


def main():
    manifest=json.loads((BASE/'manifest.json').read_text())
    for name,digest in manifest['files'].items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,name
    trace=BASE/'cloud-driver/qualified-closed-final/traces.json'
    checks=[]
    for phase in PHASES:
        folder=BASE/'cloud-driver'/phase
        if not (folder/'traces.json').exists():os.link(trace,folder/'traces.json')
        run([sys.executable,str(BASE/'frozen-measurement-qualified/tools/ml-dsa-investigation/research/summarize_capacity.py'),
             str(folder/'client.json'),str(trace),str(BASE/(phase+'-campaign.json')),str(folder/'replayed-summary.json')])
        assert json.loads((folder/'replayed-summary.json').read_text())==json.loads((folder/'summary.json').read_text())
        expected=json.loads((folder/'reserve-cycle.json').read_text())
        run([sys.executable,str(BASE/'reserve_cycle.py'),phase],0 if expected['qualified'] else 1)
        assert json.loads((folder/'reserve-cycle.json').read_text())==expected
        checks.append({'phase':phase,'qualified':expected['qualified']})
    for script,output,args in [
        ('registration_bindings.py','registration-stock-bindings.json',[]),
        ('verify_hosted.mjs','hosted-signature-verification.json',[]),
        ('collect_failed_material.py','failed-operation-materials.json',[]),
        ('audit_material.py','material-audit.json',[]),
        ('profile_failures.py','failure-profiles.json',[]),
        ('analyze_readiness_losses.py','readiness-losses.json',[]),
        ('publication_outcomes.py','publication-outcomes.json',[]),
        ('audit_canceled_admission.py','canceled-admission-audit.json',[]),
        ('analyze_parallel.py','parallel-comparison.json',[str(BASE),*PHASES]),
    ]:
        reproduce(script,output,args)
        checks.append({'script':script,'matched':True})
    result={'passed':True,'checks':checks}
    (BASE/'replay-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
