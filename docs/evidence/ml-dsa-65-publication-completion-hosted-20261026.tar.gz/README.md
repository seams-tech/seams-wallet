# Durable publication completion: hosted evidence

Run `python3 replay.py` after extraction with Python3 and the Node.js version recorded in client-node-version.txt.
The replay uses retained records and requires no network access.
It verifies manifest hashes, standard signatures, changed-message refusals, material accounting, publication outcomes, and version qualification.
Original failed requests and unqualified phases remain failed or unqualified.

The candidate checks exact durable publication bindings after a completion error.
The local real-Worker test forces a lost final A storage reply and exercises historical evidence after consumption.
Natural hosted failures may not exercise that exact fault. Hosted observations and local injected faults are reported separately.
A failed preparation group can expose some valid independent pairs. Complete publication requires evidence for every pair in the job.

The experiment uses two preparation slots, sixteen pairs per wallet, two candidates per consumed pair, and four candidates per ordinary preparation job.
The service can prepare two candidates for a one-pair deficit. The runtime default remains one preparation slot.
Refill material retains the one-hour expiry policy. Wallet-seed recovery and FIPS export remain required.
HTTP signing latency excludes earlier admission waits. Demand latency includes those waits.
The load uses private Router calls. Browser approval and public Gateway transport are outside this measurement.

An initial wallet-two setup lost its duplicate-registration reply to ECONNRESET after the first registration completed.
That failed record remains in the archive.
A wallet-three preparation also returned HTTP 500 with an A exception and canceled B calls. Its cause remains unresolved.
Separate synthetic identities replace both incomplete setups in the load.
Preparation activity from any non-target wallet remains visible. It must be considered before making capacity claims.
Retired inspections prove unavailability. They do not distinguish Burned from an unlogged Consumed record.

The hosted run confirms one publication through error reconciliation, with one observed producer execution.
One completion request times out after 45 seconds and later returns Declined.
Its final inventory matches twelve ledger gaps. Read-only inspection reports all twelve retired at A and B.
The retirement mutation remains unproven. Both primary cycle ledgers remain unqualified.
