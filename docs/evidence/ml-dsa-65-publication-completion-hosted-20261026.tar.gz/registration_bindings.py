"""Recompute initial signing-stock identities from public registration receipts."""
import hashlib
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent
bindings={}
for index in range(1,9):
    record=json.loads((BASE/f'registration-{index}.json').read_text())
    for case in record['cases']:
        preparation=bytes.fromhex(case['initialSigningPreparationId'])
        for ordinal in range(case['initialSigningBatches']):
            encoded=json.dumps([list(preparation),ordinal],separators=(',',':')).encode()
            pair=hashlib.sha256(b'seams/ml-dsa/registration-signing-stock/v1'+encoded).hexdigest()
            assert pair not in bindings
            bindings[pair]={'key':bytes(case['key']['public_key_digest']).hex(),'epoch':case['epoch'],
                            'expires_at_ms':case['initialSigningStockExpiresAtMs'],
                            'preparation':case['initialSigningPreparationId'],'ordinal':ordinal}
(BASE/'registration-stock-bindings.json').write_text(json.dumps({'bindings':bindings},indent=2)+'\n')
print(json.dumps({'initial_pair_bindings':len(bindings)}))
