import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
const base = new URL('./', import.meta.url);
const records = [];
function check(publicKeyHex, record) {
  const key = createPublicKey({key:Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100','hex'),Buffer.from(publicKeyHex,'hex')]),format:'der',type:'spki'});
  const message = Buffer.from(record.messageHex,'hex');
  const signature = Buffer.from(record.signatureHex,'hex');
  assert(verify(null,message,key,signature));
  message[0] ^= 1;
  assert.equal(verify(null,message,key,signature),false);
}
function matchWallet(index, wallet) { return wallet.index === index; }
for (let index=1; index<=8; index+=1) {
  const registration=JSON.parse(await readFile(new URL(`registration-${index}.json`,base),'utf8'));
  assert(registration.registrationChecksPassed && registration.recoveryPreservesCanonicalKey);
  assert.equal(registration.cases[0].publicKeyHex,registration.cases[1].publicKeyHex);
  for (const entry of registration.cases) {
    if (!entry.initialStockSign.verified) continue;
    check(entry.publicKeyHex,entry.initialStockSign);
    records.push({scope:'setup',wallet:index,epoch:entry.epoch});
  }
}
for (const phase of ['warmup','completion']) {
  const client=JSON.parse(await readFile(new URL(`cloud-driver/${phase}/client.json`,base),'utf8'));
  for (const request of client.requests) {
    if (!request.verified) continue;
    const wallet=client.wallets.find(matchWallet.bind(null,request.wallet));
    assert(wallet);
    check(wallet.publicKeyHex,request);
    records.push({scope:phase,wallet:request.wallet,operation:request.operation});
  }
}
const local=JSON.parse(await readFile(new URL('local-worker.json',base),'utf8'));
assert(local.passed);
for (const signature of local.signatures) {
  check(local.publicKeyHex,signature);
  records.push({scope:'local-worker'});
}
const result={verified:records.length,alteredMessagesRejected:records.length,records};
await writeFile(new URL('hosted-signature-verification.json',base),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({verified:records.length,alteredMessagesRejected:records.length}));
