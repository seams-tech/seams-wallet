"""Bind final participant availability to the canceled request and its inventory."""
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent


def read(name):
    return json.loads((BASE / name).read_text())


def main():
    inspection = read('canceled-admission-inspection.json')
    traces = read('timed-out-operation-traces.json')
    rows = read('cloud-driver/qualified-closed-final/traces.json')['records']
    matches = [row for row in rows if row['http_request'] == inspection['requestId'] and row['role'] == 'router']
    assert len(matches) == 1
    row = matches[0]
    assert row in traces['records'] and row['outcome'] == 'canceled'
    cycle = read('cloud-driver/completion/reserve-cycle.json')
    missing = set(cycle['complete_cycle_ledger']['unaccounted_pairs'])
    inventory = row['inventories'][-1]
    assert missing == set(inventory['ready_a']) & set(inventory['ready_b'])
    key = inspection['key']
    assert bytes(key['public_key_digest']).hex() == inventory['key']
    assert key['epoch'] == inventory['epoch']
    assert {result['role'] for result in inspection['results']} == {'a', 'b'}
    for result in inspection['results']:
        assert set(result['pairs']) == missing
        assert len(result['states']) == len(missing)
        assert all(state == 'retired' for state in result['states'])
    reconciliation = read('client-reconciliation.json')['results'][0]
    assert reconciliation['requestId'] == inspection['requestId']
    assert reconciliation['operation'] == inspection['operation']
    assert reconciliation['status'] == {'state': 'declined'}
    claims = [item for item in row['admission_stock'] if item['stage'] == 'claimed']
    assert len(claims) == 1
    losses = [item for item in read('readiness-losses.json')['pairs'] if item['pair'] in missing]
    assert len(losses) == len(missing)
    assert all(item['remaining_ms_at_first_absence'] > 30000 for item in losses)
    result = {
        'request_id': inspection['requestId'],
        'pairs': len(missing),
        'final_states': 'retired at both participants',
        'status': 'declined',
        'claim_to_final_inventory_ms': inventory['log_timestamp_ms'] - claims[0]['log_timestamp_ms'],
        'remaining_material_lifetime_ms_at_disappearance': {
            'minimum': min(item['remaining_ms_at_first_absence'] for item in losses),
            'maximum': max(item['remaining_ms_at_first_absence'] for item in losses),
        },
        'limit': 'Final availability and request-bound inventory match. Reservation expiry remains unproven. Original failed client and unqualified cycle remain unchanged.',
    }
    (BASE / 'canceled-admission-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
