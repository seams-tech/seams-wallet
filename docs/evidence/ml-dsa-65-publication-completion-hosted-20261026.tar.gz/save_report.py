"""Summarize the closed hosted evidence without replacing failed outcomes."""
import json
from pathlib import Path
from statistics import median
BASE=Path(__file__).resolve().parent


def seconds(value):
    return f'{value/1000:.3f}'


def main():
    comparisons=json.loads((BASE/'parallel-comparison.json').read_text())
    outcomes=json.loads((BASE/'publication-outcomes.json').read_text())
    verified=json.loads((BASE/'hosted-signature-verification.json').read_text())
    reconciled=json.loads((BASE/'client-reconciliation.json').read_text())
    deletion=json.loads((BASE/'deletion-verification.json').read_text())
    assert len(deletion)==8 and all(item['absent'] for item in deletion)
    registrations=[]
    setup_failures=0
    setup_signing=[]
    setup_preparation=[]
    for index in range(1,9):
        record=json.loads((BASE/f'registration-{index}.json').read_text())
        assert record['registrationChecksPassed'] and record['recoveryPreservesCanonicalKey']
        registrations.extend(case['registrationWithClientVerificationMs'] for case in record['cases'])
        setup_signing.extend(case['initialStockSign']['elapsedMs'] for case in record['cases'])
        setup_preparation.extend(case['preparationMs'] for case in record['cases'])
        setup_failures+=sum(not case['initialStockSign'].get('verified',False) for case in record['cases'])
    table=[]
    preparation=[]
    for phase in comparisons:
        http=phase['successful_http_ms']
        cycle=phase['reserve_cycle']
        empty=phase['admission_waits']['by_reason']['empty_pool']['responses']
        table.append(f"| {phase['phase']} | {phase['signatures']} | {seconds(http['minimum'])} / {seconds(http['median'])} / {seconds(http['maximum'])} | {empty} | {cycle['signatures_per_minute']:.3f} | {cycle['qualified']} |")
        for role in ['preparer-a','preparer-a-secondary']:
            group=phase['job_profiles'].get(role+'/4/published')
            if group:
                side=group['a']
                preparation.append(f"| {phase['phase']} | {role} | {side['count']} | {seconds(side['cpu_ms']['median'])} | {seconds(side['wall_ms']['minimum'])} / {seconds(side['wall_ms']['median'])} / {seconds(side['wall_ms']['maximum'])} |")
    direct=sum('running' in item['producer_stages'] for item in outcomes['confirmed_publication_reconciliations'])
    interrupted=sum('recovering' in item['producer_stages'] for item in outcomes['confirmed_publication_reconciliations'])
    contradictions=outcomes['reported_failures_with_paired_or_taken_material']
    complete_contradictions=sum(item['all_pairs_have_publication_evidence'] for item in contradictions)
    text=f'''# ML-DSA durable publication: hosted rerun

The completion fix remains selected. It checks exact durable publication records before reporting a preparation failure.
This report records the hosted validation and its limits. It does not establish a causal speed improvement.

## Completion evidence

The local real-Worker test drops the final A publication reply after the write.
It verifies Published, both ready halves, lease release, publication evidence after actual consumption, and changed-expiry refusal.
Existing failure-backoff, restart, single-use, and deadline cases pass with three verified signatures.

The hosted archive contains {outcomes['completion_receipts']} completion receipts.
It records {outcomes['published_receipts']} Published, {outcomes['failed_receipts']} Failed, and {outcomes['interrupted_receipts']} Interrupted receipts.
There are {direct} confirmations during ordinary error reconciliation and {interrupted} during interrupted-producer recovery.
Reported failures with evidence for every pair: {complete_contradictions}.
Reported failures with any paired or taken material: {len(contradictions)}.
A partially published group can supply valid independent pairs. This does not prove the whole group completed.
One hosted Run error confirms paired publication with one observed producer execution.
The deterministic lost-reply fault remains separate local workerd evidence.
Lease expiry retains the existing Interrupted behavior. Historical publication never restores signing rights.

## Hosted measurements

Eight target wallets use two preparation slots and sixteen pairs per wallet.
Consumption remains two candidates at a time. Ordinary refill jobs prepare four candidates.
One-pair deficits can use a two-candidate job. The runtime default remains one preparation slot.
Refill retention remains one hour. Preparation stays on Workers. GPU work stays deferred.
Wallet-seed recovery, standard FIPS export, and pool capacity remain unchanged.

All sixteen target registration/recovery cases reproduce their canonical key.
Registration/recovery seconds: {seconds(min(registrations))} minimum, {seconds(median(registrations))} median, {seconds(max(registrations))} maximum.
These times exclude prior generic preprocessing.
Generic setup preprocessing seconds: {seconds(min(setup_preparation))} minimum, {seconds(median(setup_preparation))} median, {seconds(max(setup_preparation))} maximum.
Setup signing seconds: {seconds(min(setup_signing))} minimum, {seconds(median(setup_signing))} median, {seconds(max(setup_signing))} maximum.
Setup signatures with failed outcomes: {setup_failures}.

| Phase | Verified client signatures | HTTP seconds: min / median / max | Empty responses | Signatures/minute with reserve restoration | Cycle qualified |
| --- | ---: | --- | ---: | ---: | --- |
'''+'\n'.join(table)+'''

Successful HTTP latency excludes earlier admission waits. Demand latency in the archive includes those waits.
The rates cover finite load plus restored reserves. They do not establish maximum capacity.
Qualification means the version, capture, and availability ledger checks passed. It does not mean every request succeeded.
These private Router calls exclude browser approval, public Gateway transport, and NEAR finality.

The following job measurements require positive completion receipts. Wall time includes waits.

| Phase | Producer | Jobs | A CPU median, seconds | A wall seconds: min / median / max |
| --- | --- | ---: | ---: | --- |
'''+ '\n'.join(preparation)+f'''

## Preserved failures and limits

An initial wallet-two run lost its exact duplicate-registration reply to ECONNRESET after registration returned HTTP200.
An initial wallet-three preparation returned HTTP500. Captured A execution threw an exception and B calls were canceled.
The preparation failure cause remains unresolved. Both failed records remain in the archive.
Separate synthetic identities replace those incomplete cases in the target load. No failed signing request is resubmitted.
Non-target preparation jobs observed in the phase profiles: {len(outcomes['non_target_preparation_jobs'])}.
Any such activity limits comparison with an isolated eight-wallet campaign.

Interrupted client requests reconciled by ordinary read-only status: {len(reconciled['results'])}.
The completion phase has one 45-second client timeout. Its later ordinary status is Declined, with no recovered signature.
Its last request-bound inventory contains exactly the twelve pairs missing from the availability ledger.
The inventory arrived 22.144 seconds after the claim. Both participants later report all twelve pairs retired.
Their material had 49–58 minutes remaining when readiness disappeared. Material expiry does not explain this loss.
The mutation that retired the pairs remains unknown. Reservation expiry is a hypothesis requiring further evidence.
Two warm-up ledger gaps fit the thirty-second readiness margin. Their physical retirement cause also remains unobserved.
Both cycles remain unqualified. These results do not meet a consistent latency or release-pass requirement.
The completion load records one preparer-B loadShed event. The warm-up load records none.
Original client results remain unchanged.
Retired pair inspections establish unavailability. They do not distinguish a physical burn from an unlogged consumption.
Readiness-loss timing supports an expiry-margin explanation only where the recorded deadlines match. It does not prove physical pruning.
The archive retains failed and unqualified runs.

## Reproduction and cleanup

The replay verifies {verified['verified']} standard signatures and rejects all {verified['alteredMessagesRejected']} changed messages.
It reproduces phase summaries, material accounting, publication outcomes, and observed-use checks without network access.
Run python3 replay.py after extracting the archive.
The closed capture uses stable fixed-window fingerprints and exact deployment versions through reserve restoration.
All eight temporary Workers are deleted. Independent deployment lookup confirms their absence.
Credential payloads are removed. Private fixture keys and raw authenticated tails are excluded from the public archive.
The required bloat check retains its inherited Rust duplication failure: 13,972 lines against a 13,754 baseline.

[Evidence index](../evidence/ml-dsa-65-publication-completion-hosted-20261026.json) and [replay archive](../evidence/ml-dsa-65-publication-completion-hosted-20261026.tar.gz).
'''
    (BASE/'final-report.md').write_text(text.replace('HTTP200','HTTP 200').replace('HTTP500','HTTP 500'))


if __name__=='__main__':main()
