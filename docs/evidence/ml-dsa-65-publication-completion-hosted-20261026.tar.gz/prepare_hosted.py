"""Prepare the existing eight-Worker benchmark with fresh synthetic credentials."""
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
OLD = Path('/private/tmp/ml-dsa-refill-retry-20261026')
os.umask(0o077)
assert not (BASE / 'scope.json').exists()
previous = json.loads((OLD / 'scope.json').read_text())
prefix = 'ml-dsa-pub-1026-' + secrets.token_hex(3)
policy = dict(previous['policy'], max_active_preparations=2)
first = BASE / 'wallet-1'
first.mkdir()
subprocess.run([str(ROOT / 'tools/ml-dsa-investigation/target/release/ml-dsa-investigation'), 'worker-registration-keys', str(first)], check=True, stdout=subprocess.DEVNULL)
for index in range(2, 9):
    target = BASE / f'wallet-{index}'
    target.mkdir()
    for name in ['a-kek', 'b-kek', 'publics.json']:
        shutil.copyfile(first / name, target / name)
gateway, internal = secrets.token_hex(32), secrets.token_hex(32)
(BASE / 'gateway-token').write_text(gateway + '\n')
driver = BASE / 'cloud-driver'
driver.mkdir()
shutil.copyfile(ROOT / 'tests/e2e/ml-dsa-cloud-load-worker.mjs', driver / 'worker.mjs')
front_build = BASE / 'front-build'
shutil.copytree(OLD / 'front-build', front_build)
entry = (OLD / 'cloud-driver/entry.mjs').read_text().replace(str(OLD / 'front-build'), str(front_build))
(driver / 'entry.mjs').write_text(entry)
workers = []
for old_worker in previous['workers']:
    role = old_worker['role']
    config = json.loads((OLD / f'{role}.json').read_text())
    config['name'] = prefix + '-' + role
    config['compatibility_flags'] = ['nodejs_compat']
    config['vars']['ML_DSA_ADMISSION_POLICY'] = json.dumps(policy, separators=(',', ':'))
    for service in config.get('services', []):
        service['service'] = service['service'].replace(previous['prefix'], prefix)
    for binding in config.get('durable_objects', {}).get('bindings', []):
        if 'script_name' in binding:
            binding['script_name'] = binding['script_name'].replace(previous['prefix'], prefix)
    if role == 'front':
        config['main'] = str(driver / 'entry.mjs')
        config['vars']['TEST_WORKER_PREFIX'] = prefix
    else:
        build_role = 'router' if role == 'router' else ('deriver-a' if role == 'a' or role.startswith('preparer-a') else 'deriver-b')
        config['main'] = str(BASE / 'baseline-build' / build_role / 'worker/shim.mjs')
        config['tail_consumers'] = [{'service': prefix + '-front'}]
    path = BASE / f'{role}.json'
    path.write_text(json.dumps(config, indent=2) + '\n')
    bootstrap = copy.deepcopy(config)
    bootstrap.pop('services', None)
    bootstrap.pop('tail_consumers', None)
    if 'durable_objects' in bootstrap:
        bootstrap['durable_objects']['bindings'] = [binding for binding in bootstrap['durable_objects']['bindings'] if 'script_name' not in binding]
    (BASE / f'{role}-bootstrap.json').write_text(json.dumps(bootstrap, indent=2) + '\n')
    payload = {'INTERNAL_AUTH': internal}
    if role in ['router', 'front']:
        payload['ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET'] = gateway
    else:
        participant = 'a' if role == 'a' or role.startswith('preparer-a') else 'b'
        payload['ROLE_KEK'] = (first / f'{participant}-kek').read_text()
    encoded = (json.dumps(payload, indent=2) + '\n').encode()
    (BASE / f'{role}-secrets.json').write_bytes(encoded)
    main = front_build / 'worker/shim.mjs' if role == 'front' else Path(config['main'])
    wasm = main.parent.parent / 'index_bg.wasm'
    workers.append({'role': role, 'name': config['name'], 'payload': role + '-secrets.json',
                    'credential_sha256': hashlib.sha256(encoded).hexdigest(),
                    'config_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'wasm_sha256': hashlib.sha256(wasm.read_bytes()).hexdigest(),
                    'wasm_bytes': wasm.stat().st_size})
scope = {'purpose':'Validate completion reconciliation after durable publication with eight synthetic wallets, unchanged two-slot policy, and sustained refill on Cloudflare.',
         'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff'],cwd=ROOT)).hexdigest(),
         'prefix':prefix, 'root':str(ROOT), 'build_root':str(BASE / 'baseline-build'),
         'router_url':f'https://{prefix}-front.n6378056.workers.dev', 'policy':policy,
         'workers':workers, 'front_build_root':str(front_build),
         'preparation_expiry_policy_ms':{'initial_registration_stock':900000,'refill_stock':3600000}}
(BASE / 'scope.json').write_text(json.dumps(scope, indent=2)+'\n')
lines = ['# ML-DSA durable publication completion benchmark credential scope', '',
         'Create the eight temporary Workers below and upload these exact fresh benchmark credentials.',
         'A Workers receive only the A storage key. B Workers receive only the B storage key.',
         'Credentials protect synthetic wallets. They contain no production wallet or account credentials.',
         'The rerun retains two preparation slots, two-at-once consumption, sixteen pairs per wallet, and the sixty-second wallet cooldown.',
         'Preparation stays on Workers. Wallet-seed recovery and standard FIPS export remain required.',
         'Participant A reconciles durable publication after a completion error. Both participants expose the exact read-only publication check. Router uses the verified baseline. Cryptographic code, wire formats, and pool capacity stay unchanged.',
         'All eight temporary Workers will be removed after measurements. Local private fixtures will be retained.', '',
         '| Worker | Credential payload SHA-256 |', '| --- | --- |']
lines.extend(f"| {worker['name']} | {worker['credential_sha256']} |" for worker in workers)
(BASE / 'hosted-upload-scope.md').write_text('\n'.join(lines)+'\n')
# Reuse the existing deployment workflow, with only its frozen front-build path changed.
deploy = (OLD / 'deploy.py').read_text().replace("ROOT/'crates/router-ab-cloudflare/build/router/worker/shim.mjs'", "pathlib.Path(SCOPE['front_build_root'])/'worker/shim.mjs'")
(BASE / 'deploy.py').write_text(deploy)
shutil.copyfile(OLD / 'verify_deletion.py', BASE / 'verify_deletion.py')
print(json.dumps({'prefix':prefix,'workers':len(workers),'scope':str(BASE/'hosted-upload-scope.md')}))
