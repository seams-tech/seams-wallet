"""Confirm that failed preparation never became paired stock or signing input."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
rows = json.loads((BASE / 'cloud-driver/qualified-closed-final/traces.json').read_text())['records']
paired_ids = set()
taken_ids = set()
for row in rows:
    for snapshot in row['inventories']:
        paired_ids.update(set(snapshot['ready_a']) & set(snapshot['ready_b']))
        paired_ids.update(set(snapshot['reserved_a']) & set(snapshot['reserved_b']))
    for trace in row['signing_traces']:
        taken_ids.update(item['value']['material_id'] for item in trace['batches'] if item['value']['stage'] == 'taken')
    for item in row['material_stages']:
        if item['value']['stage'] == 'taken':
            taken_ids.add(item['value']['material_id'])
result = {}
for phase in ['serial-settled', 'parallel-settled']:
    window = json.loads((BASE / 'cloud-driver' / phase / 'start.json').read_text())
    failed = [row for row in rows if row['outcome'] == 'loadShed' and row['refill_job']
              and window['startAtMs'] <= row['event_timestamp_ms'] <= window['endAtMs']]
    jobs = []
    for peer in failed:
        job = peer['refill_job']['batch']
        ids = peer['refill_job']['batches']
        producers = [row for row in rows if row['role'] == peer['role'].replace('preparer-b', 'preparer-a')
                     and row['producer_alarm'] and any(item['batch'] == job and item['stage'] == 'running' for item in row['producer_jobs'])]
        assert len(producers) == 1
        receipts = [item for row in rows for item in row['refill'] if item['batch'] == job]
        assert any(item['published'] is False for item in receipts)
        assert not any(item['published'] for item in receipts)
        assert not set(ids) & paired_ids
        assert not set(ids) & taken_ids
        jobs.append({'job': job, 'planned_pairs': ids, 'a_cpu_ms': producers[0]['cpu_ms'],
                     'b_cpu_ms': peer['cpu_ms'], 'a_wall_ms': producers[0]['wall_ms'],
                     'b_wall_ms': peer['wall_ms'], 'a_outcome': producers[0]['outcome'],
                     'b_outcome': peer['outcome'], 'paired_stock_seen': False, 'taken': False})
    result[phase] = {'failed_jobs': len(jobs), 'planned_pairs': sum(len(job['planned_pairs']) for job in jobs),
                     'reported_a_b_cpu_ms': sum(job['a_cpu_ms'] + job['b_cpu_ms'] for job in jobs),
                     'jobs': jobs}
(BASE / 'failed-material-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({name: {key: value for key, value in data.items() if key != 'jobs'} for name, data in result.items()}))
