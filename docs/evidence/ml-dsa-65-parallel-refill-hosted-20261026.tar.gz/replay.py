"""Verify the retained hosted results without network access."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
PHASES = ['serial-before', 'parallel', 'serial-after', 'serial-settled', 'parallel-settled']
manifest = json.loads((BASE / 'manifest.json').read_text())
for relative, digest in manifest['files'].items():
    assert hashlib.sha256((BASE / relative).read_bytes()).hexdigest() == digest, relative
trace = BASE / 'cloud-driver/qualified-closed-final/traces.json'
for phase in PHASES:
    for folder in [phase, phase + '-final']:
        target = BASE / 'cloud-driver' / folder / 'traces.json'
        if not target.exists():
            os.link(trace, target)
checks = []
result = subprocess.run(['node', str(BASE / 'verify_hosted.mjs')], cwd=BASE, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
assert json.loads((BASE / 'hosted-signature-verification.json').read_text())['verified'] == 345
checks.append({'check': 'signature verification', 'exit_code': result.returncode})
for phase in PHASES:
    expected = 1 if phase in ['parallel', 'serial-after'] else 0
    command = [sys.executable, str(BASE / 'current-analysis/summarize_capacity.py'),
               str(BASE / 'cloud-driver' / phase / 'client.json'),
               str(trace), str(BASE / (phase + '-campaign.json')),
               str(BASE / 'cloud-driver' / phase / 'qualification-replay.json')]
    result = subprocess.run(command, cwd=BASE, capture_output=True, text=True)
    assert result.returncode == expected, (phase, result.stdout, result.stderr)
    checks.append({'check': phase + ' authority qualification', 'exit_code': result.returncode})
    result = subprocess.run([sys.executable, str(BASE / 'reserve_cycle.py'), phase], cwd=BASE, capture_output=True, text=True)
    assert result.returncode == expected, (phase, result.stdout, result.stderr)
    checks.append({'check': phase + ' reserve cycle', 'exit_code': result.returncode})
for script, arguments in [('audit_failed_material.py', []), ('analyze_parallel.py', [str(BASE), *PHASES])]:
    expected = json.loads((BASE / ('failed-material-audit.json' if script.startswith('audit') else 'parallel-comparison.json')).read_text())
    result = subprocess.run([sys.executable, str(BASE / script), *arguments], cwd=BASE, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    actual = json.loads((BASE / ('failed-material-audit.json' if script.startswith('audit') else 'parallel-comparison.json')).read_text())
    assert actual == expected, script
    checks.append({'check': script, 'exit_code': result.returncode})
receipt = {'passed': True, 'checks': checks}
(BASE / 'replay-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
