# Reproduce the completed hosted measurements

These files contain sanitized public measurements. They contain no participant
seeds, private keys, preparation payloads, request credentials, or fixture storage.
The archive includes complete normalized records and final sanitized tail streams.
The two earlier capture hashes are retained as receipts; duplicate captures are
omitted. Benchmark Workers have been deleted. Do not redeploy the included configs.

Run `python3 replay.py` after extraction. Python 3.11+ and Node.js 24.7+ with
ML-DSA verification support are required. The replay checks every archived file's
SHA-256, validates 345 signatures and altered-message rejection, recomputes failed
material accounting, and replays authority qualification against all five phases.
It also recalculates full-reserve cycles and the preparation comparison. Mixed
policy phases must fail qualification. The serial and parallel settled phases must
pass. A `replay-result.json` file records the result.

One trace file is shared by all phases. The replay creates local hard links to it
at the paths expected by the frozen analyzers. Registration reports retain an
initial candidate-exhaustion result; the recovery signature for that wallet passes.

Measured private Router A/B latency excludes browser transport, public Gateway
approval, UI, and NEAR finality. See final-report.md for the full limits.
