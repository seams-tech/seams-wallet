"""Run a serial/parallel/serial campaign with unchanged participant deployments."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from authority_gate import wait_for_authority

BASE = Path(__file__).resolve().parent
SCOPE_PATH = BASE / 'scope.json'
SCOPE = json.loads(SCOPE_PATH.read_text())
ROOT = Path(SCOPE['root'])
FROZEN = BASE / 'frozen-measurement-qualified'
CONTROL = ['node', str(FROZEN / 'tests/e2e/ml-dsa-cloud-load.e2e.mjs')]
ENV = dict(os.environ,
    ML_DSA_TEST_BUILD_ROOT=SCOPE['build_root'],
    ML_DSA_REGISTRATION_ROUTER_URL=SCOPE['router_url'],
    ML_DSA_GATEWAY_TOKEN_FILE=str(BASE / 'gateway-token'),
    ML_DSA_TEST_CANDIDATE_GROUP_SIZE='2',
    ML_DSA_TEST_PREPARATION_GROUP_SIZE='4',
    ML_DSA_TEST_PREPARATION_JOBS='1',
    ML_DSA_TEST_COOLDOWN_MS='60000')
PHASES = [('serial-settled', 1), ('parallel-settled', 2)]
DURATION_MS = 600000


def run(arguments, log, environment=ENV, working_directory=ROOT):
    with log.open('w') as output:
        result = subprocess.run(arguments, cwd=working_directory, env=environment,
                                stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'Command failed ({result.returncode}); inspect {log}')


def control(action, name, *arguments):
    log = BASE / 'cloud-driver' / f'{name}-{action}.log'
    run(CONTROL + [action, str(BASE), name, *map(str, arguments)], log, working_directory=FROZEN)


def deployed_versions():
    versions = {}
    for worker in SCOPE['workers']:
        result = subprocess.run(['pnpm', 'exec', 'wrangler', 'deployments', 'list',
            '--config', str(BASE / (worker['role'] + '.json')), '--json'],
            cwd=ROOT, capture_output=True, text=True, check=True)
        latest = max(json.loads(result.stdout), key=lambda row: row['created_on'])
        assert len(latest['versions']) == 1 and latest['versions'][0]['percentage'] == 100
        versions[worker['role']] = latest['versions'][0]['version_id']
    return versions


assert (BASE / 'release-receipt.json').exists()
initial_versions = json.loads((BASE / 'versions.json').read_text())
(BASE / 'cloud-driver/versions.json').write_text(json.dumps(initial_versions, indent=2) + '\n')
for index in range(1, 9):
    artifact = BASE / f'registration-{index}.json'
    if not artifact.exists():
        print(json.dumps({'stage': 'registration', 'wallet': index}), flush=True)
        environment = dict(ENV, ML_DSA_TEST_WALLET_ID=f"{SCOPE['prefix']}-wallet-{index}")
        run(['node', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs',
             str(BASE / f'wallet-{index}'), str(artifact)],
            BASE / f'registration-{index}.log', environment)
    registration = json.loads(artifact.read_text())
    assert registration['registrationChecksPassed'] and registration['recoveryPreservesCanonicalKey']
    if not registration['functionalPassed']:
        reviewed = json.loads((BASE / 'reviewed-setup-failures.json').read_text())[artifact.name]
        assert reviewed['sha256'] == hashlib.sha256(artifact.read_bytes()).hexdigest()
        assert reviewed['classification'] == 'expected_candidate_exhaustion'
        assert registration['cases'][-1]['initialStockSign']['verified']
        print(json.dumps({'stage': 'retained_setup_exhaustion', 'wallet': index}), flush=True)
    assert registration['policy'] == dict(SCOPE['policy'], max_active_preparations=1)
    print(json.dumps({'stage': 'registered', 'wallet': index,
                     'canonical_recovery': True}), flush=True)
for name, jobs in PHASES:
    folder = BASE / 'cloud-driver' / name
    if (folder / 'reserve-cycle.json').exists():
        continue
    marker = BASE / (name + '-policy-ready.json')
    if not marker.exists():
        config = BASE / ('router-parallel.json' if jobs == 2 else 'router.json')
        expected = SCOPE['parallel_router_config_sha256'] if jobs == 2 else next(worker['config_sha256'] for worker in SCOPE['workers'] if worker['role'] == 'router')
        assert hashlib.sha256(config.read_bytes()).hexdigest() == expected
        if name != 'serial-settled':
            run(['pnpm', 'exec', 'wrangler', 'deploy', '--config', str(config)], BASE / (name + '-router-deploy.log'))
        versions = deployed_versions()
        assert all(versions[role] == version for role, version in initial_versions.items() if role != 'router')
        marker.write_text(json.dumps({'jobs': jobs, 'versions': versions}, indent=2) + '\n')
    phase = json.loads(marker.read_text())
    SCOPE['policy']['max_active_preparations'] = jobs
    SCOPE_PATH.write_text(json.dumps(SCOPE, indent=2) + '\n')
    (BASE / 'cloud-driver/versions.json').write_text(json.dumps(phase['versions'], indent=2) + '\n')
    if not (folder / 'start.json').exists():
        wait_for_authority(BASE, FROZEN, name, phase['versions']['router'])
        print(json.dumps({'stage': 'initial_reserve', 'phase': name}), flush=True)
        control('stock', name + '-initial', 8, int(time.time() * 1000))
        control('start', name, 8, DURATION_MS)
        shutil.copy2(SCOPE_PATH, BASE / (name + '-campaign.json'))
    start = json.loads((folder / 'start.json').read_text())
    print(json.dumps({'stage': 'load', 'phase': name, 'end_at_ms': start['endAtMs']}), flush=True)
    while time.time() * 1000 < start['endAtMs'] + 45000:
        time.sleep(30)
        control('status', name)
        progress = json.loads((folder / 'progress.json').read_text())
        print(json.dumps({'stage': 'progress', 'phase': name, 'rows': progress}), flush=True)
        if any(row['error'] is not None for row in progress):
            raise RuntimeError('Durable load driver failed; inspect progress')
    control('collect', name)
    print(json.dumps({'stage': 'restore_reserve', 'phase': name}), flush=True)
    control('stock', name + '-final', 8, start['endAtMs'])
    control('traces', name)
    run(['python3', str(FROZEN / 'tools/ml-dsa-investigation/research/summarize_capacity.py'),
         str(folder / 'client.json'), str(folder / 'traces.json'),
         str(BASE / (name + '-campaign.json')), str(folder / 'summary.json')], folder / 'summary.log')
    summary = json.loads((folder / 'summary.json').read_text())
    assert summary['authority_version_coverage']['complete'], 'Mixed or unobserved admission authority versions'
    assert summary['trace_coverage']['complete'], 'Incomplete signing trace coverage'
    assert summary['trace_coverage']['truncated_invocations'] == 0, 'Truncated invocation logs'
    if jobs == 1:
        assert all(job['worker_role'] == 'preparer-a' for job in summary['producer_profiles']['jobs']), 'Secondary job in a serial phase'
    run(['python3', str(BASE / 'reserve_cycle.py'), name], folder / 'reserve-cycle.log')
    cycle = json.loads((folder / 'reserve-cycle.json').read_text())
    print(json.dumps({'stage': 'phase_complete', 'phase': name,
                     'cycle_signatures_per_minute': cycle['signatures_per_minute']}), flush=True)
print(json.dumps({'stage': 'all_phases_complete'}), flush=True)
