"""Exercise profile boundaries on real setup traces before comparing load phases."""
import importlib.util
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
sys.path.insert(0, str(ROOT / 'tools/ml-dsa-investigation/research'))
from summarize_capacity import producer_profiles
spec = importlib.util.spec_from_file_location('parallel_analysis', BASE / 'analyze_parallel.py')
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
rows = json.loads((BASE / 'cloud-driver/setup-complete/traces.json').read_text())['records']
wallets = []
for index in range(1, 9):
    result = json.loads((BASE / f'registration-{index}.json').read_text())
    wallets.append({'key': result['cases'][-1]['key']})
start = min(row['event_timestamp_ms'] for row in rows if row['event_timestamp_ms'])
end = max(row['event_timestamp_ms'] for row in rows if row['event_timestamp_ms'])
raw = producer_profiles({'wallets': wallets}, rows, start, end)
jobs = [analysis.job_profile(job, rows) for job in raw['jobs'] if job['active_wallet']]
profiles = analysis.profiles(jobs)
assert profiles
for profile in profiles.values():
    for side in profile.values():
        if side['correlations_ms']['count']:
            assert side['correlations_ms']['maximum'] > 0
        if side['serialized_to_publication_ms']['count']:
            assert side['serialized_to_publication_ms']['maximum'] > 0
result = {'scope': 'Real setup job boundary checks. These are not sustained-load measurements.',
          'jobs': len(jobs), 'profiles': profiles}
(BASE / 'analysis-calibration.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'calibrated_jobs': len(jobs), 'profiles': list(profiles)}))
