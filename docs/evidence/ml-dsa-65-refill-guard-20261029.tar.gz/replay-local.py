import hashlib
import json
import runpy
import subprocess
from pathlib import Path

base = Path(__file__).resolve().parent


def read(name):
    return json.loads((base / name).read_text())


def events(name):
    result = []
    for line in (base / name).read_text().splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and 'event' in value:
            result.append(value)
    return result


manifest = base / 'manifest.json'
if manifest.exists():
    for name, digest in read('manifest.json').items():
        assert hashlib.sha256((base / name).read_bytes()).hexdigest() == digest, name

baseline = read('baseline-worker.json')
assert baseline['passed'] is False
baseline_events = events('baseline-worker.log')
assert any(value['event'] == 'ml_dsa_inventory_v1' and
           len(value['ready_a']) == len(value['ready_b']) == 18 for value in baseline_events)

reports = ['final-worker.json', 'final-profile-worker.json']
checks = []
for name in reports:
    report = read(name)
    assert report['passed'] is True
    assert len(report['signatures']) == 3
    record = report['unusedPreparation']
    assert record['readyPairs'] == [16, 16]
    assert record['producerExecutions'] == 1
    assert record['lostSettlementBeforeAndAfterCommit'] == {'before': 1, 'after': 1}
    assert record['staleFinishPreservedNewLease'] and record['failureBackoffPreserved']
    assert record['fullStockUnchanged'] and record['roleClaimsAbsent'] and record['cryptoStagesAbsent']
    captured = events(name.replace('.json', '.log'))
    for job in [record['unusedJob'], record['shrunkJob']]:
        identity = bytes(job['batch']).hex()
        stages = {value['stage'] for value in captured
                  if value['event'] == 'ml_dsa_preparation_stage_v1' and value['job'] == identity}
        assert {'stock_rechecked', 'preparation_not_needed'} <= stages
        assert not stages & {'role_claimed', 'peer_connected', 'crypto_started',
                             'commitment_started', 'commitment_completed', 'published'}
        running = [value for value in captured if value['event'] == 'ml_dsa_producer_job_v1'
                   and value['batch'] == identity and value['stage'] == 'running']
        assert len(running) == 1
        complete = [value for value in captured if value['event'] == 'ml_dsa_refill_completed_v1'
                    and value['batch'] == identity]
        assert len(complete) == 1
        assert complete[0]['outcome'] == 'unused'
        assert complete[0]['candidates'] == 0 and complete[0]['batches'] == []
        assert complete[0]['published'] is None
    retained = report['unopenedAfterFailure']
    assert retained['failureSettledMs'] < 5000
    assert retained['failureRequestedPeerClose'] and retained['retainedPairs'] == 15
    assert retained['failureOutcome']['status'] == 'dispatch_error'
    operation = retained['failedOperation']
    assert any(value['event'] == 'ml_dsa_socket_completion_v1' and value['id'] == operation
               and value['close_code'] == 1011 and value['close_requested'] is True for value in captured)
    wake = report['refillWakeInterleaving']
    assert wake['maintenanceDidNotPostponeWake']
    assert wake['releaseToNextAlarmUpperBoundMs'] < 3000
    for observation in wake['sameActorAlarmObservations']:
        assert observation['after_ms'] <= observation['requested_ms'] + 50
    checks.append({'report': name, 'failure_settlement_ms': retained['failureSettledMs'],
                   'retained_pairs': retained['retainedPairs'],
                   'wake_observation_upper_bound_ms': wake['releaseToNextAlarmUpperBoundMs']})

native = read('native-keygen.json')
assert all(value['canonical_key_verified'] for value in native['cases'])
assert native['prepared_component_checks']['all_matched_independent_oracle']

normalizer = runpy.run_path(str(base / 'source/tools/ml-dsa-investigation/research/collect_worker_traces.py'))
projected = []
for value in events('final-worker.log'):
    if value['event'] in {'ml_dsa_refill_completed_v1', 'ml_dsa_preparation_stage_v1', 'ml_dsa_refill_alarm_v1'}:
        projected.append({'message': [json.dumps(value)], 'timestamp': value.get('at_ms')})
path = base / 'console-parser-input.json'
path.write_text(json.dumps({'logs': projected}) + '\n')
normalized = normalizer['records'](path, 'local_console')
assert any(stage['stage'] == 'preparation_not_needed' for record in normalized for stage in record['preparation_stages'])
assert any(value.get('outcome') == 'unused' and value['batches'] == []
           for record in normalized for value in record['refill'])
assert any(value['event'] == 'ml_dsa_refill_alarm_v1' for record in normalized for value in record['refill_wakes'])
path.unlink()
verified = subprocess.run(['node', str(base / 'verify-signatures.mjs'), str(base), *reports],
                          capture_output=True, text=True, check=True)
print(json.dumps({'passed': True, 'scope': 'Offline local-Worker evidence replay. Provider CPU and hosted latency are unavailable.',
                  'checks': checks, 'signature_verification': json.loads(verified.stdout)}))
