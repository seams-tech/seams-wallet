# Local Worker verification replay

Run `python3 replay-local.py`. Node/OpenSSL with ML-DSA support is required.
The replay checks file hashes, the expected baseline failure, exact no-crypto
unused-job evidence, prompt failed settlement, retained pairs, wake observations,
and eight standard signatures plus altered-message rejection. No network is used.

The console parser replay uses actual local messages with provider invocation
metadata omitted. It supplies no billed CPU or hosted latency measurement.
The intermediate profiling failure and its classification remain retained.
Full Wasm files, participant keys, credential payloads and role material fixtures
are excluded. Build receipts record the measured Wasm hashes.
