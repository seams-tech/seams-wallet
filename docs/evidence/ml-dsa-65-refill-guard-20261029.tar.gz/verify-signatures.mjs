import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const base = resolve(process.argv[2] ?? import.meta.dirname);
const reports = process.argv.slice(3);
assert.ok(reports.length > 0);
let signatures = 0;
for (const name of reports) {
  const report = JSON.parse(await readFile(base + '/' + name, 'utf8'));
  assert.equal(report.passed, true);
  const bytes = Buffer.from(report.publicKeyHex, 'hex');
  assert.equal(bytes.length, 1952);
  const key = createPublicKey({ key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes,
  ]), format: 'der', type: 'spki' });
  for (const entry of report.signatures) {
    assert.equal(entry.contextHex, '');
    check(key, entry.messageHex, entry.signatureHex);
    signatures++;
  }
  check(key, report.unopenedAfterFailure.messageHex, report.unopenedAfterFailure.signatureHex);
  signatures++;
}
console.log(JSON.stringify({ passed: true, reports: reports.length, signatures,
  alteredMessagesRejected: signatures, node: process.version, openssl: process.versions.openssl }));

function check(key, messageHex, signatureHex) {
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  assert.equal(signature.length, 3309);
  assert.ok(message.length > 0);
  assert.equal(verify(null, message, key, signature), true);
  message[0] ^= 128;
  assert.equal(verify(null, message, key, signature), false);
}
