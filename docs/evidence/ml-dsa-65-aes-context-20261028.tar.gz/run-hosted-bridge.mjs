import assert from 'node:assert/strict';
import { createCipheriv, createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { performance } from 'node:perf_hooks';
const base = '/private/tmp/ml-dsa-aes-profile-20261028';
const scope = JSON.parse(await readFile(base + '/hosted/scope.json', 'utf8'));
const kernel = 'https://' + scope.prefix + '-kernel.n6378056.workers.dev/probe';
const collector = 'https://' + scope.prefix + '-metrics.n6378056.workers.dev/traces';
let phase = 'verification';
const evidence = {
  scope: 'Hosted Cloudflare public-fixture Rust/provider bridge. Provider CPU is obtained from exact-request tail records. External HTTP time includes network. No complete preparation, wallet signing, native-provider erasure, or sustained-capacity claim.',
  prefix: scope.prefix, kernel, collector, startedAtMs: Date.now(), passed: false,
  requests: [], verification: [], samples: [], traces: [],
};
function expected(rounds, seed, count) {
  const bytes = new Uint8Array(16 + 16 * count);
  const view = new DataView(bytes.buffer);
  let state = seed;
  for (let index = 0; index < bytes.length; index += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    view.setUint32(index, state >>> 0, true);
  }
  const blocks = bytes.subarray(16);
  const cipher = createCipheriv('aes-128-ecb', bytes.subarray(0, 16), new Uint8Array(0));
  cipher.setAutoPadding(false);
  for (let index = 0; index < rounds; index++) blocks.set(cipher.update(blocks));
  assert.equal(cipher.final().byteLength, 0);
  cipher.destroy();
  return blocks;
}

function checkCounters(mode, rounds, actual) {
  let contexts = 0;
  if (mode === 1) contexts = rounds;
  else if (mode === 2) contexts = 1;
  assert.deepEqual(actual, {
    created: contexts,
    updated: mode === 0 ? 0 : rounds,
    finished: contexts,
    destroyed: contexts,
    live: 0,
  });
}


async function call(kind, mode, rounds, seed, count) {
  const requestId = randomUUID();
  const row = { requestId, phase, kind, mode, rounds, seed, count, startedAtMs: Date.now() };
  evidence.requests.push(row);
  const started = performance.now();
  const response = await fetch(kernel, {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-aes-benchmark-request': requestId },
    body: JSON.stringify({ kind, mode, rounds, seed, count }), signal: AbortSignal.timeout(60000),
  });
  row.httpStatus = response.status;
  row.endedAtMs = Date.now();
  assert.equal(response.status, 200, 'Hosted AES request failed: ' + requestId);
  if (kind === 'fixture') {
    const bytes = new Uint8Array(await response.arrayBuffer());
    const counters = JSON.parse(response.headers.get('x-benchmark-counters'));
    checkCounters(mode, rounds, counters);
    row.elapsedMs = performance.now() - started;
    return { requestId, bytes, counters };
  }
  const result = await response.json();
  row.elapsedMs = performance.now() - started;
  checkCounters(mode, rounds, result.counters);
  return { requestId, mode, rounds, seed, count, elapsedMs: row.elapsedMs, ...result };
}
async function traces() {
  let cursor = null;
  const rows = [];
  do {
    const response = await fetch(collector + (cursor ? '?cursor=' + encodeURIComponent(cursor) : ''), { signal: AbortSignal.timeout(30000) });
    assert.equal(response.status, 200);
    const page = await response.json();
    rows.push(...page.rows);
    cursor = page.cursor;
  } while (cursor);
  return rows;
}
function ascending(left, right) { return left - right; }
function median(values) {
  values.sort(ascending);
  const middle = Math.floor(values.length / 2);
  return values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
}
async function save() {
  evidence.endedAtMs = Date.now();
  await writeFile(base + '/hosted/results.json', JSON.stringify(evidence, null, 2) + '\n');
}
try {
  for (const count of [0, 1, 8, 16, 64, 128, 256, 1024, 1025, 2048]) {
    for (const rounds of [1, 3]) {
      const seed = count + rounds + 1;
      const oracle = expected(rounds, seed, count);
      for (const mode of [0, 1, 2]) {
        const row = await call('fixture', mode, rounds, seed, count);
        assert.deepEqual(row.bytes, oracle);
        evidence.verification.push({ requestId: row.requestId, count, rounds, seed, mode,
          sha256: createHash('sha256').update(row.bytes).digest('hex'), counters: row.counters });
      }
    }
  }
  console.log('Verified all 60 hosted full-byte fixtures.');
  for (const count of [1, 8, 16, 64, 128, 256, 1024]) {
    const rounds = Math.min(16384, Math.floor(1048576 / count));
    phase = 'warmup';
    for (let warmup = 0; warmup < 2; warmup++) {
      for (const mode of [0, 1, 2]) await call('benchmark', mode, rounds, warmup + 1, count);
    }
    phase = 'timing';
    for (let repetition = 0; repetition < 8; repetition++) {
      const sequence = repetition % 2 === 0 ? [0, 1, 2] : [2, 1, 0];
      const group = [];
      for (const mode of sequence) {
        const row = await call('benchmark', mode, rounds, repetition + 100, count);
        group.push(row);
        evidence.samples.push({ repetition, ...row });
      }
      for (const row of group) assert.equal(row.checksum, group[0].checksum);
    }
    await save();
    console.log('Completed paired timings for ' + count * 16 + '-byte updates.');
  }
  for (let attempt = 0; attempt < 15; attempt++) {
    evidence.traces = await traces();
    const ids = new Set(evidence.traces.map(trace => trace.requestId));
    if (evidence.requests.every(row => ids.has(row.requestId))) break;
    await delay(1500);
  }
  const exact = new Map();
  for (const trace of evidence.traces) {
    assert.equal(exact.has(trace.requestId), false, 'Duplicate provider event');
    exact.set(trace.requestId, trace);
  }
  evidence.capture = { expected: evidence.requests.length, observed: evidence.traces.length,
    missing: evidence.requests.filter(row => !exact.has(row.requestId)).map(row => row.requestId) };
  assert.equal(evidence.capture.missing.length, 0, 'Incomplete exact-request capture');
  for (const request of evidence.requests) {
    const trace = exact.get(request.requestId);
    assert.equal(trace.outcome, 'ok');
    assert.equal(trace.exceptions.length, 0);
    assert.equal(trace.truncated, false);
    assert.equal(typeof trace.cpuMs, 'number');
  }
  evidence.medians = [];
  for (const count of [1, 8, 16, 64, 128, 256, 1024]) {
    for (const mode of [0, 1, 2]) {
      const cpu = [];
      const wall = [];
      for (const row of evidence.samples) {
        if (row.count === count && row.mode === mode) {
          cpu.push(exact.get(row.requestId).cpuMs);
          wall.push(row.elapsedMs);
        }
      }
      evidence.medians.push({ count, bytesPerCall: count * 16, mode,
        cpuMedianMs: median(cpu), httpMedianMs: median(wall) });
    }
  }
  evidence.passed = true;
  console.log(JSON.stringify({ passed: true, capture: evidence.capture, medians: evidence.medians }));
} finally {
  if (evidence.traces.length === 0) evidence.traces = await traces();
  await save();
}
