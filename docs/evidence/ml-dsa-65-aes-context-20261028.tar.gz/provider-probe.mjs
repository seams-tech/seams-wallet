import compiled from './aes-kernel.wasm';
import { createCipheriv, createHash } from 'node:crypto';

const wasm = new WebAssembly.Instance(compiled, {}).exports;

function fixture(seed) {
  const bytes = new Uint8Array(16 + 16384);
  let state = seed;
  for (let index = 0; index < bytes.length; index += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    new DataView(bytes.buffer).setUint32(index, state >>> 0, true);
  }
  return { key: bytes.subarray(0, 16), blocks: bytes.subarray(16) };
}

function cipherFor(key) {
  const cipher = createCipheriv('aes-128-ecb', key, new Uint8Array(0));
  cipher.setAutoPadding(false);
  return cipher;
}

function update(cipher, blocks) {
  const output = cipher.update(blocks);
  try {
    if (output.byteLength !== blocks.byteLength) throw new Error('Unexpected output size');
    blocks.set(output);
  } finally {
    output.fill(0);
  }
}

function finish(cipher) {
  const tail = cipher.final();
  try {
    if (tail.byteLength !== 0) throw new Error('Unexpected final data');
  } finally {
    tail.fill(0);
  }
}

function fresh(key, blocks, rounds) {
  for (let index = 0; index < rounds; index++) {
    const cipher = cipherFor(key);
    try {
      update(cipher, blocks);
      finish(cipher);
    } finally {
      cipher.destroy();
    }
  }
}

function reused(key, blocks, rounds) {
  const cipher = cipherFor(key);
  try {
    for (let index = 0; index < rounds; index++) update(cipher, blocks);
    finish(cipher);
  } finally {
    cipher.destroy();
  }
}

function setup(key, rounds) {
  for (let index = 0; index < rounds; index++) {
    const cipher = cipherFor(key);
    try {
      finish(cipher);
    } finally {
      cipher.destroy();
    }
  }
}

function checksum(bytes) {
  let result = 0;
  for (const byte of bytes) result = (Math.imul(result, 31) + byte) >>> 0;
  return result;
}

async function fetchProbe(request) {
  const { mode, rounds, seed } = await request.json();
  if (!Number.isSafeInteger(rounds) || rounds < 1 || rounds > 2048) {
    return new Response('Invalid public rounds', { status: 400 });
  }
  if (!Number.isSafeInteger(seed) || seed < 1 || seed > 65535) {
    return new Response('Invalid public seed', { status: 400 });
  }
  if (mode === 'software') return Response.json({ checksum: wasm.batch_throughput(rounds, seed) >>> 0 });
  const { key, blocks } = fixture(seed);
  try {
    switch (mode) {
      case 'native-fresh':
        fresh(key, blocks, rounds);
        break;
      case 'native-reused':
        reused(key, blocks, rounds);
        break;
      case 'native-setup':
        setup(key, rounds);
        break;
      default:
        return new Response('Invalid public mode', { status: 400 });
    }
    return Response.json({ checksum: checksum(blocks), sha256: createHash('sha256').update(blocks).digest('hex') });
  } finally {
    key.fill(0);
    blocks.fill(0);
  }
}

export default { fetch: fetchProbe };
