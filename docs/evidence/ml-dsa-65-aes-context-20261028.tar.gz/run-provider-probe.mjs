import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
const require = createRequire('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/package.json');
const { Miniflare } = require('miniflare');
const base = '/private/tmp/ml-dsa-aes-profile-20261028';
const modes = ['software', 'native-fresh', 'native-reused', 'native-setup'];
const runtime = new Miniflare({
  modules: true,
  rootPath: base,
  modulesRoot: base,
  scriptPath: base + '/provider-probe.mjs',
  modulesRules: [{ type: 'CompiledWasm', include: ['**/*.wasm'], fallthrough: true }],
  compatibilityDate: '2026-06-12',
  compatibilityFlags: ['nodejs_compat'],
});

function expected(rounds, seed) {
  const bytes = new Uint8Array(16 + 16384);
  const view = new DataView(bytes.buffer);
  let state = seed;
  for (let index = 0; index < bytes.length; index += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    view.setUint32(index, state >>> 0, true);
  }
  const key = bytes.subarray(0, 16);
  const blocks = bytes.subarray(16);
  const cipher = createCipheriv('aes-128-ecb', key, new Uint8Array(0));
  cipher.setAutoPadding(false);
  for (let index = 0; index < rounds; index++) blocks.set(cipher.update(blocks));
  assert.equal(cipher.final().byteLength, 0);
  cipher.destroy();
  let checksum = 0;
  for (const byte of blocks) checksum = (Math.imul(checksum, 31) + byte) >>> 0;
  return { checksum, sha256: createHash('sha256').update(blocks).digest('hex') };
}

async function call(mode, rounds, seed) {
  const started = performance.now();
  const response = await runtime.dispatchFetch('http://aes.local/probe', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ mode, rounds, seed }),
  });
  assert.equal(response.status, 200, mode + ' failed');
  const result = await response.json();
  return { mode, rounds, seed, elapsedMs: performance.now() - started, ...result };
}

function ascending(left, right) { return left - right; }

const evidence = { scope: 'Local workerd provider/context screen with public deterministic fixtures. External request time includes dispatch, fixture work, and checksum. Native paths omit Rust-to-JS per-batch crossings. Component results cannot establish complete protocol speed or hosted CPU.', passed: false, verification: [], samples: [] };
try {
  await runtime.ready;
  for (const rounds of [1, 2, 17]) {
    for (const seed of [1, 73, 101]) {
      const oracle = expected(rounds, seed);
      for (const mode of modes.slice(0, 3)) {
        const row = await call(mode, rounds, seed);
        assert.equal(row.checksum, oracle.checksum);
        if (mode !== 'software') assert.equal(row.sha256, oracle.sha256);
        evidence.verification.push({ mode, rounds, seed, matched: true });
      }
    }
  }
  for (let warmup = 0; warmup < 4; warmup++) {
    for (const mode of modes) await call(mode, 1024, warmup + 1);
  }
  for (let repetition = 0; repetition < 16; repetition++) {
    const sequence = repetition % 2 === 0 ? modes : [...modes].reverse();
    const group = [];
    for (const mode of sequence) {
      const row = await call(mode, 1024, repetition + 100);
      evidence.samples.push({ repetition, ...row });
      if (mode !== 'native-setup') group.push(row);
    }
    for (const row of group) assert.equal(row.checksum, group[0].checksum);
  }
  evidence.mediansMs = {};
  for (const mode of modes) {
    const values = [];
    for (const row of evidence.samples) if (row.mode === mode) values.push(row.elapsedMs);
    values.sort(ascending);
    evidence.mediansMs[mode] = (values[7] + values[8]) / 2;
  }
  evidence.wasmSha256 = createHash('sha256').update(await readFile(base + '/aes-kernel.wasm')).digest('hex');
  evidence.node = process.version;
  evidence.openssl = process.versions.openssl;
  evidence.passed = true;
  console.log(JSON.stringify({ passed: true, mediansMs: evidence.mediansMs }));
} finally {
  await writeFile(base + '/provider-context.json', JSON.stringify(evidence, null, 2) + '\n');
  await runtime.dispose();
}
