import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
const require = createRequire('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/package.json');
const { Miniflare } = require('miniflare');
const runtimeRequire = createRequire(require.resolve('miniflare'));
const base = '/private/tmp/ml-dsa-aes-profile-20261028';
const config = {
  modules: true,
  rootPath: base + '/bridge/pkg',
  modulesRoot: base + '/bridge/pkg',
  scriptPath: base + '/bridge/pkg/entry.mjs',
  modulesRules: [
    { type: 'ESModule', include: ['**/*.js', '**/*.mjs'] },
    { type: 'CompiledWasm', include: ['**/*.wasm'] },
  ],
  compatibilityDate: '2026-06-12',
  compatibilityFlags: ['nodejs_compat'],
};
const runtime = new Miniflare(config);

function expected(rounds, seed, count) {
  const bytes = new Uint8Array(16 + 16 * count);
  const view = new DataView(bytes.buffer);
  let state = seed;
  for (let index = 0; index < bytes.length; index += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    view.setUint32(index, state >>> 0, true);
  }
  const blocks = bytes.subarray(16);
  const cipher = createCipheriv('aes-128-ecb', bytes.subarray(0, 16), new Uint8Array(0));
  cipher.setAutoPadding(false);
  for (let index = 0; index < rounds; index++) blocks.set(cipher.update(blocks));
  assert.equal(cipher.final().byteLength, 0);
  cipher.destroy();
  return blocks;
}

function checkCounters(mode, rounds, actual) {
  let contexts = 0;
  if (mode === 1) contexts = rounds;
  else if (mode === 2) contexts = 1;
  assert.deepEqual(actual, {
    created: contexts,
    updated: mode === 0 ? 0 : rounds,
    finished: contexts,
    destroyed: contexts,
    live: 0,
  });
}

async function call(kind, mode, rounds, seed, count) {
  const started = performance.now();
  const response = await runtime.dispatchFetch('http://aes.local/probe', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ kind, mode, rounds, seed, count }),
  });
  assert.equal(response.status, 200);
  if (kind === 'fixture') {
    const bytes = new Uint8Array(await response.arrayBuffer());
    const counters = JSON.parse(response.headers.get('x-benchmark-counters'));
    checkCounters(mode, rounds, counters);
    return { bytes, counters };
  }
  const result = await response.json();
  checkCounters(mode, rounds, result.counters);
  return { mode, rounds, seed, count, elapsedMs: performance.now() - started, ...result };
}

function ascending(left, right) { return left - right; }

async function hashes(folder) {
  const result = {};
  for (const item of await readdir(folder, { withFileTypes: true })) {
    const path = folder + '/' + item.name;
    if (item.isDirectory()) {
      Object.assign(result, await hashes(path));
    } else {
      result[path.slice(base.length + 1)] = createHash('sha256').update(await readFile(path)).digest('hex');
    }
  }
  return result;
}

const evidence = {
  scope: 'Local workerd actual Rust/wasm-bindgen/provider bridge. Public deterministic fixtures, full-byte verification on all paths. Timings include input construction, Rust/JS crossings, copies, checksum, native context lifetime and erasure guards. No complete preparation, hosted CPU, peak-memory, or native internal-erasure claim.',
  config,
  versions: {
    miniflare: require('miniflare/package.json').version,
    workerd: runtimeRequire('workerd/package.json').version,
    referenceNode: process.version,
    referenceOpenSsl: process.versions.openssl,
    workerCryptoProviderVersion: 'Not independently observed',
  },
  passed: false,
  verification: [],
  samples: [],
};
try {
  await runtime.ready;
  for (const count of [0, 1, 8, 16, 1023, 1024, 1025, 2048]) {
    for (const rounds of [1, 3]) {
      for (const seed of [1, 73]) {
        const oracle = expected(rounds, seed, count);
        for (const mode of [0, 1, 2]) {
          const result = await call('fixture', mode, rounds, seed, count);
          assert.deepEqual(result.bytes, oracle);
          evidence.verification.push({ mode, rounds, seed, count,
            sha256: createHash('sha256').update(result.bytes).digest('hex'), counters: result.counters });
        }
      }
    }
  }
  for (const count of [1, 8, 16, 1024]) {
    const rounds = count === 1024 ? 1024 : 16384;
    for (let warmup = 0; warmup < 3; warmup++) {
      for (const mode of [0, 1, 2]) await call('benchmark', mode, rounds, warmup + 1, count);
    }
    for (let repetition = 0; repetition < 12; repetition++) {
      const sequence = repetition % 2 === 0 ? [0, 1, 2] : [2, 1, 0];
      const group = [];
      for (const mode of sequence) {
        const row = await call('benchmark', mode, rounds, repetition + 100, count);
        group.push(row);
        evidence.samples.push({ repetition, ...row });
      }
      for (const row of group) assert.equal(row.checksum, group[0].checksum);
    }
  }
  evidence.medians = [];
  for (const count of [1, 8, 16, 1024]) {
    for (const mode of [0, 1, 2]) {
      const values = [];
      for (const row of evidence.samples) {
        if (row.count === count && row.mode === mode) values.push(row.elapsedMs);
      }
      values.sort(ascending);
      evidence.medians.push({ count, bytesPerCall: count * 16, mode,
        medianMs: (values[5] + values[6]) / 2 });
    }
  }
  evidence.sourceHashes = await hashes(base + '/bridge/src');
  Object.assign(evidence.sourceHashes, await hashes(base + '/bridge/pkg'));
  for (const file of ['run-bridge-probe.mjs', 'bridge/Cargo.toml', 'bridge/Cargo.lock', 'bridge/bridge-aes.mjs']) {
    evidence.sourceHashes[file] = createHash('sha256').update(await readFile(base + '/' + file)).digest('hex');
  }
  evidence.productionSourceHashes = {};
  const sourceRoot = '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/';
  for (const file of [
    'crates/two-party-primitives/src/gate_aes.rs',
    'crates/two-party-primitives/src/gate_aes/eight.rs',
    'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs',
  ]) {
    evidence.productionSourceHashes[file] = createHash('sha256').update(await readFile(sourceRoot + file)).digest('hex');
  }
  evidence.passed = true;
  console.log(JSON.stringify({ passed: true, medians: evidence.medians }));
} finally {
  await writeFile(base + '/bridge-context.json', JSON.stringify(evidence, null, 2) + '\n');
  await runtime.dispose();
}
