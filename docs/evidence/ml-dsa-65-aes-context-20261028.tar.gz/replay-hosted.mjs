import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const base = resolve(process.argv[2] ?? import.meta.dirname);
const evidence = JSON.parse(await readFile(base + '/hosted/results.json', 'utf8'));
const history = JSON.parse(await readFile(base + '/hosted/deployment-history.json', 'utf8'));
const cleanup = JSON.parse(await readFile(base + '/hosted/cleanup.json', 'utf8'));
const requestIds = new Set();
const traces = new Map();

function ascending(left, right) {
  return left - right;
}

function median(values) {
  assert.equal(values.length, 8);
  values.sort(ascending);
  return (values[3] + values[4]) / 2;
}

function checkCounters(mode, rounds, counters) {
  let contexts = 0;
  if (mode === 1) contexts = rounds;
  if (mode === 2) contexts = 1;
  assert.deepEqual(counters, {
    created: contexts,
    updated: mode === 0 ? 0 : rounds,
    finished: contexts,
    destroyed: contexts,
    live: 0,
  });
}

function expectedSha256(rounds, seed, count) {
  const bytes = new Uint8Array(16 + 16 * count);
  const view = new DataView(bytes.buffer);
  let state = seed;
  for (let offset = 0; offset < bytes.length; offset += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    view.setUint32(offset, state >>> 0, true);
  }
  const blocks = bytes.subarray(16);
  const cipher = createCipheriv('aes-128-ecb', bytes.subarray(0, 16), new Uint8Array(0));
  cipher.setAutoPadding(false);
  for (let index = 0; index < rounds; index++) blocks.set(cipher.update(blocks));
  assert.equal(cipher.final().byteLength, 0);
  cipher.destroy();
  return createHash('sha256').update(blocks).digest('hex');
}

assert.equal(evidence.passed, true);
assert.equal(evidence.requests.length, 270);
assert.equal(evidence.traces.length, 270);
assert.equal(evidence.verification.length, 60);
assert.equal(evidence.samples.length, 168);
const version = history.kernel[0].versions[0].version_id;
for (const trace of evidence.traces) {
  assert.equal(traces.has(trace.requestId), false);
  traces.set(trace.requestId, trace);
  assert.equal(trace.version, version);
  assert.equal(trace.outcome, 'ok');
  assert.deepEqual(trace.exceptions, []);
  assert.equal(trace.truncated, false);
  assert.equal(Number.isFinite(trace.cpuMs), true);
  assert.equal(trace.cpuMs >= 0, true);
}
for (const row of evidence.requests) {
  assert.equal(requestIds.has(row.requestId), false);
  requestIds.add(row.requestId);
  assert.equal(row.httpStatus, 200);
  assert.equal(traces.has(row.requestId), true);
}
for (const row of evidence.verification) {
  assert.equal(row.sha256, expectedSha256(row.rounds, row.seed, row.count));
  checkCounters(row.mode, row.rounds, row.counters);
}
for (const row of evidence.samples) checkCounters(row.mode, row.rounds, row.counters);
const medians = [];
for (const count of [1, 8, 16, 64, 128, 256, 1024]) {
  for (const mode of [0, 1, 2]) {
    const cpu = [];
    const wall = [];
    for (const row of evidence.samples) {
      if (row.count === count && row.mode === mode) {
        cpu.push(traces.get(row.requestId).cpuMs);
        wall.push(row.elapsedMs);
      }
    }
    medians.push({ count, bytesPerCall: count * 16, mode,
      cpuMedianMs: median(cpu), httpMedianMs: median(wall) });
  }
}
assert.deepEqual(medians, evidence.medians);
assert.equal(cleanup.all_absent, true);
assert.equal(cleanup.absence.length, 2);
for (const row of cleanup.absence) assert.equal(row.confirmed_absent, true);
console.log(JSON.stringify({ passed: true, requests: requestIds.size,
  fullOutputFixturesReproduced: evidence.verification.length,
  cpuAndHttpMediansReproduced: medians.length, cleanupVerified: true,
  referenceNode: process.version, referenceOpenSsl: process.versions.openssl }));
