import { DurableObject } from 'cloudflare:workers';
export class PublicAesTraceStore extends DurableObject {
  async append(row) {
    await this.ctx.storage.put('trace/'+String(row.eventTimestamp)+'/'+row.requestId, row);
  }
  async fetch(request) {
    const cursor = new URL(request.url).searchParams.get('cursor');
    const options = { prefix: 'trace/', limit: 100 };
    if (cursor) options.startAfter = cursor;
    const rows = await this.ctx.storage.list(options);
    return Response.json({ rows: Array.from(rows.values()), cursor: rows.size === 100 ? Array.from(rows.keys()).at(-1) : null });
  }
}
async function tail(events, env) {
  for (const event of events) {
    if (event.scriptName !== env.KERNEL_NAME) continue;
    const requestId = event.event?.request?.headers?.['x-aes-benchmark-request'];
    if (typeof requestId !== 'string' || !/^[0-9a-f-]{36}$/.test(requestId)) continue;
    const row = { requestId, worker: event.scriptName, version: event.scriptVersion?.id ?? null,
      eventTimestamp: event.eventTimestamp, cpuMs: event.cpuTime ?? null,
      wallMs: event.wallTime ?? null, outcome: event.outcome,
      truncated: event.truncated ?? false, exceptions: (event.exceptions ?? []).map(exceptionName) };
    await env.TRACES.get(env.TRACES.idFromName('events')).append(row);
  }
}
function exceptionName(error) { return error.name ?? 'UnknownError'; }
async function fetch(request, env) {
  if (request.method !== 'GET' || new URL(request.url).pathname !== '/traces') return new Response('Unknown public metrics route', { status: 404 });
  return env.TRACES.get(env.TRACES.idFromName('events')).fetch(request);
}
export default { fetch, tail };
