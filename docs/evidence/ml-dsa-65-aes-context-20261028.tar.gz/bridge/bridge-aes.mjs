import { createCipheriv } from 'node:crypto';
let counters = { created: 0, updated: 0, finished: 0, destroyed: 0, live: 0 };
export function resetCounters() {
  if (counters.live !== 0) throw new Error('Leaked native context');
  counters = { created: 0, updated: 0, finished: 0, destroyed: 0, live: 0 };
}
export function readCounters() { return { ...counters }; }
export function makeCipher(key) {
  if (key.byteLength !== 16) throw new Error('Invalid AES key length');
  const cipher = createCipheriv('aes-128-ecb', key, new Uint8Array(0));
  cipher.setAutoPadding(false);
  counters.created++;
  counters.live++;
  return cipher;
}
export function updateCipher(cipher, bytes) {
  if (bytes.byteLength % 16 !== 0) throw new Error('Invalid AES block length');
  const output = cipher.update(bytes);
  try {
    if (output.byteLength !== bytes.byteLength) throw new Error('Unexpected output length');
    bytes.set(output);
    counters.updated++;
  } finally { output.fill(0); }
}
export function finishCipher(cipher) {
  const tail = cipher.final();
  try {
    if (tail.byteLength !== 0) throw new Error('Unexpected final data');
    counters.finished++;
  } finally { tail.fill(0); }
}
export function destroyCipher(cipher) {
  cipher.destroy();
  counters.destroyed++;
  counters.live--;
}
