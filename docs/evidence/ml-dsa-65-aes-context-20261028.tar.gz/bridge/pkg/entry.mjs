import compiled from './ml_dsa_aes_context_probe_bg.wasm';
import * as bindings from './ml_dsa_aes_context_probe_bg.js';
import * as provider from './snippets/ml-dsa-aes-context-probe-9d93e4d7e9e9acad/bridge-aes.mjs';
const { resetCounters, readCounters } = provider;
const instance = new WebAssembly.Instance(compiled, { './ml_dsa_aes_context_probe_bg.js': bindings, './snippets/ml-dsa-aes-context-probe-9d93e4d7e9e9acad/bridge-aes.mjs': provider });
bindings.__wbg_set_wasm(instance.exports);
instance.exports.__wbindgen_start();
async function fetchProbe(request) {
  const body = await request.json();
  resetCounters();
  if (body.kind === 'fixture') {
    const output = bindings.run_fixture(body.mode, body.rounds, body.seed, body.count);
    const response = new Response(output.slice());
    output.fill(0);
    response.headers.set('x-benchmark-counters', JSON.stringify(readCounters()));
    return response;
  }
  const checksum = bindings.run_benchmark(body.mode, body.rounds, body.seed, body.count);
  return Response.json({ checksum, counters: readCounters() });
}
export default { fetch: fetchProbe };
