/* tslint:disable */
/* eslint-disable */

export function run_benchmark(mode: number, rounds: number, seed: number, count: number): number;

export function run_fixture(mode: number, rounds: number, seed: number, count: number): Uint8Array;
