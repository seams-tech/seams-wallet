const EXPIRES_AT_MS = 1793162526282;
import compiled from './ml_dsa_aes_context_probe_bg.wasm';
import * as bindings from './ml_dsa_aes_context_probe_bg.js';
import * as provider from './snippets/ml-dsa-aes-context-probe-9d93e4d7e9e9acad/bridge-aes.mjs';
const { resetCounters, readCounters } = provider;
const instance = new WebAssembly.Instance(compiled, { './ml_dsa_aes_context_probe_bg.js': bindings, './snippets/ml-dsa-aes-context-probe-9d93e4d7e9e9acad/bridge-aes.mjs': provider });
bindings.__wbg_set_wasm(instance.exports);
instance.exports.__wbindgen_start();
async function fetchProbe(request) {
  if (Date.now() > EXPIRES_AT_MS) return new Response('Probe expired', { status: 410 });
  if (request.method !== 'POST' || new URL(request.url).pathname !== '/probe') {
    return new Response('Unknown public-fixture route', { status: 404 });
  }
  const text = await request.text();
  if (text.length > 256) return new Response('Oversized public request', { status: 400 });
  const body = JSON.parse(text);
  const counts = [0, 1, 8, 16, 64, 128, 256, 1024, 1025, 2048];
  if (!counts.includes(body.count) || ![0, 1, 2].includes(body.mode) ||
      !Number.isSafeInteger(body.seed) || body.seed < 1 || body.seed > 65535) {
    return new Response('Invalid public fixture', { status: 400 });
  }
  const maximumRounds = Math.min(16384, Math.floor(1048576 / Math.max(1, body.count)));
  if (!Number.isSafeInteger(body.rounds) || body.rounds < 1 ||
      (body.kind === 'fixture' ? body.rounds > 3 : body.rounds !== maximumRounds) ||
      !['fixture', 'benchmark'].includes(body.kind)) {
    return new Response('Invalid public workload', { status: 400 });
  }
  resetCounters();
  if (body.kind === 'fixture') {
    const output = bindings.run_fixture(body.mode, body.rounds, body.seed, body.count);
    const response = new Response(output.slice());
    output.fill(0);
    response.headers.set('x-benchmark-counters', JSON.stringify(readCounters()));
    return response;
  }
  const checksum = bindings.run_benchmark(body.mode, body.rounds, body.seed, body.count);
  return Response.json({ checksum, counters: readCounters() });
}
export default { fetch: fetchProbe };
