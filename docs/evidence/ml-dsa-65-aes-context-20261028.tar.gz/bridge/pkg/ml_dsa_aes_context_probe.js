/* @ts-self-types="./ml_dsa_aes_context_probe.d.ts" */
import * as wasm from "./ml_dsa_aes_context_probe_bg.wasm";
import { __wbg_set_wasm } from "./ml_dsa_aes_context_probe_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    run_benchmark, run_fixture
} from "./ml_dsa_aes_context_probe_bg.js";
