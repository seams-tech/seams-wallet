#![forbid(unsafe_code)]
use wasm_bindgen::prelude::*;
use zeroize::Zeroizing;
#[path = "/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs"]
mod software;

#[wasm_bindgen(module = "/bridge-aes.mjs")]
extern "C" {
    #[wasm_bindgen(catch, js_name = makeCipher)]
    fn make_cipher(key: &[u8]) -> Result<JsValue, JsValue>;
    #[wasm_bindgen(catch, js_name = updateCipher)]
    fn update_cipher(cipher: &JsValue, bytes: &mut [u8]) -> Result<(), JsValue>;
    #[wasm_bindgen(catch, js_name = finishCipher)]
    fn finish_cipher(cipher: &JsValue) -> Result<(), JsValue>;
    #[wasm_bindgen(js_name = destroyCipher)]
    fn destroy_cipher(cipher: &JsValue);
}
struct NativeCipher(JsValue);
impl Drop for NativeCipher {
    fn drop(&mut self) {
        destroy_cipher(&self.0);
    }
}
enum Backend { Software, Fresh, Reused }
fn backend(value: u32) -> Result<Backend, JsValue> {
    match value {
        0 => Ok(Backend::Software),
        1 => Ok(Backend::Fresh),
        2 => Ok(Backend::Reused),
        _ => Err(JsValue::from_str("Unknown public backend")),
    }
}
fn fill(bytes: &mut [u8], seed: &mut u32) {
    for word in bytes.chunks_mut(4) {
        *seed ^= *seed << 13;
        *seed ^= *seed >> 17;
        *seed ^= *seed << 5;
        word.copy_from_slice(&seed.to_le_bytes());
    }
}
fn run(mode: Backend, rounds: u32, mut seed: u32, count: usize) -> Result<Zeroizing<Vec<[u8; 16]>>, JsValue> {
    if rounds == 0 || rounds > 65536 || count > 2048 {
        return Err(JsValue::from_str("Invalid public dimensions"));
    }
    let mut key = Zeroizing::new([0u8; 16]);
    fill(&mut *key, &mut seed);
    let mut blocks = Zeroizing::new(vec![[0u8; 16]; count]);
    for block in blocks.iter_mut() { fill(block, &mut seed); }
    match mode {
        Backend::Software => {
            let cipher = software::CorrelationAes::new(&key);
            for _ in 0..rounds { cipher.encrypt(&mut blocks); }
        }
        Backend::Fresh => {
            for _ in 0..rounds {
                let cipher = NativeCipher(make_cipher(&key[..])?);
                update_cipher(&cipher.0, blocks.as_flattened_mut())?;
                finish_cipher(&cipher.0)?;
            }
        }
        Backend::Reused => {
            let cipher = NativeCipher(make_cipher(&key[..])?);
            for _ in 0..rounds { update_cipher(&cipher.0, blocks.as_flattened_mut())?; }
            finish_cipher(&cipher.0)?;
        }
    }
    Ok(blocks)
}
#[wasm_bindgen]
pub fn run_fixture(mode: u32, rounds: u32, seed: u32, count: usize) -> Result<Vec<u8>, JsValue> {
    let blocks = run(backend(mode)?, rounds, seed, count)?;
    Ok(blocks.as_flattened().to_vec())
}
#[wasm_bindgen]
pub fn run_benchmark(mode: u32, rounds: u32, seed: u32, count: usize) -> Result<u32, JsValue> {
    let blocks = run(backend(mode)?, rounds, seed, count)?;
    let mut checksum = 0u32;
    for byte in blocks.as_flattened() {
        checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(*byte));
    }
    Ok(core::hint::black_box(checksum))
}
