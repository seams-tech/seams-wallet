# Independent review

The reviewer reads the raw local and hosted evidence without editing source.

- All twenty-one CPU medians and twenty-one HTTP medians reproduce.
- All 270 unique requests match 270 unique provider records with successful outcomes.
- All sixty hosted full-output fixture hashes independently reproduce against AES-ECB.
- Source, generated binding, Wasm, deployment, and cleanup hashes agree.
- Context counters match the requested path and leave zero live contexts.
- The comparison includes real Rust/JavaScript crossings.
- The native path has no median CPU win at any tested size.
- Two individual native comparisons win at 16 KiB. No individual native comparison wins at production 128/256-byte sizes.
- Scope claims to this instrumented bridge. Provider internals, host contention, erasure, and cold execution remain unqualified.
- Component times are nonadditive. Software schedules are already reused.
- Archive the exact earlier harness, then remove its unused batch_throughput export from the retained tool.
- Both public Workers are deleted. Independent absence checks retain code 10007.

The reviewer recommends rejecting this native prototype and continuing unchanged-runtime capacity qualification.

Final prose review corrects four terms: four AES contexts use three fixed public keys, a native context lasts one benchmark request, the removed change unrolls the AES round loop, and automatic review rejects deployment. These corrections preserve the measured scope.
