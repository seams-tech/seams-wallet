# Replay

Run `node replay-hosted.mjs` from this extracted directory.
It reproduces fixture hashes, exact request correlation, context counters, CPU/HTTP medians, and cleanup checks.
The runner uses only Node built-ins and makes no network requests.

The bridge source and generated Wasm preserve the measured prototype.
Rebuilding requires the source revision and pinned Cargo/wasm-bindgen versions.
The exact earlier measurement script remains separate from the retained tool.
Production cryptographic source is unchanged.
Native canonical-keygen and wallet-recovery records use disposable public fixtures.
No authentication token, role storage key, or encrypted participant fixture is included.
