
pub use cryprot_codes::Coeff;
use cryprot_core::Block;
mod baseline;

fn input(size: usize, seed: u32) -> Vec<Block> {
    let mut values = Vec::with_capacity(size);
    for index in 0..size {
        values.push(Block::from([
            (index as u64).wrapping_mul(0x9e3779b97f4a7c15) ^ u64::from(seed),
            (!(index as u64)).wrapping_mul(0x517cc1b727220a95),
        ]));
    }
    values
}

#[unsafe(no_mangle)]
pub extern "C" fn check(size: usize, seed: u32, accumulator: usize, twice: bool, default_seed: bool) {
    let matrix_seed = if default_seed {
        cryprot_codes::ExConvCodeConfig::default().seed
    } else {
        Block::from([u64::from(seed), !u64::from(seed)])
    };
    let old = baseline::ExConvCode::new_with_conf(size, baseline::ExConvCodeConfig {
        seed: matrix_seed, accumulator_size: accumulator, acc_twice: twice,
        ..Default::default()
    });
    let new = cryprot_codes::ExConvCode::new_with_conf(size, cryprot_codes::ExConvCodeConfig {
        seed: matrix_seed, accumulator_size: accumulator, acc_twice: twice,
        ..Default::default()
    });
    let mut left = input(2 * size, seed);
    let mut right = left.clone();
    old.dual_encode(&mut left);
    new.dual_encode(&mut right);
    assert_eq!(left, right);
    let mut left_bytes: Vec<u8> = (0..2 * size)
        .map(|index| (index as u8).wrapping_mul(29).wrapping_add(seed as u8))
        .collect();
    let mut right_bytes = left_bytes.clone();
    old.dual_encode(&mut left_bytes);
    new.dual_encode(&mut right_bytes);
    assert_eq!(left_bytes, right_bytes);
}

#[unsafe(no_mangle)]
pub extern "C" fn measure(mode: u32, size: usize, seed: u32) -> u32 {
    let mut values = input(2 * size, seed);
    if mode == 0 {
        baseline::ExConvCode::new(size).dual_encode(&mut values);
    } else {
        cryprot_codes::ExConvCode::new(size).dual_encode(&mut values);
    }
    let mut checksum = 0u32;
    for value in values {
        for byte in bytemuck::bytes_of(&value) {
            checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(*byte));
        }
    }
    core::hint::black_box(checksum)
}
