
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
const bytes = await readFile(process.argv[2]);
const module = await WebAssembly.compile(bytes);
const imports = {};
for (const entry of WebAssembly.Module.imports(module)) {
  assert.equal(entry.kind, 'function');
  imports[entry.module] ??= {};
  imports[entry.module][entry.name] = unexpectedImport;
}
function unexpectedImport() { throw new Error('The deterministic encoder called a host import.'); }
const {exports: probe} = await WebAssembly.instantiate(module, imports);
let checks = 0;
for (const size of [33, 34, 63, 65, 255, 256, 257, 1024, 4093, 4094, 4095, 4096, 4097, 8191, 8192, 8193, 524288]) {
  for (const seed of [1, 17, 65537]) {
    for (const accumulator of [8, 17, 24, 32]) {
      for (const twice of [0, 1]) {
        probe.check(size, seed, accumulator, twice, 0);
        checks++;
      }
    }
  }
}
for (const size of [25, 26, 27, 28, 29, 30, 31, 32]) {
  for (const seed of [1, 17, 65537]) {
    for (const twice of [0, 1]) {
      probe.check(size, seed, 24, twice, 0);
      checks++;
    }
  }
}
for (const seed of [0, 1, 17, 255, 65537, 0x80000000, 0xffffffff]) {
  probe.check(524288, seed, 24, 1, 1);
  checks++;
}
for (let warmup = 0; warmup < 4; warmup++) {
  probe.measure(0, 524288, warmup);
  probe.measure(1, 524288, warmup);
}
const samples = [];
for (let repetition = 0; repetition < 20; repetition++) {
  const pair = [];
  for (const mode of repetition % 2 === 0 ? [0, 1] : [1, 0]) {
    const started = performance.now();
    const checksum = probe.measure(mode, 524288, repetition);
    const sample = {mode, repetition, elapsedMs: performance.now() - started, checksum};
    samples.push(sample);
    pair.push(sample);
  }
  assert.equal(pair[0].checksum, pair[1].checksum);
}
const medians = [];
for (const mode of [0, 1]) {
  const times = [];
  for (const sample of samples) if (sample.mode === mode) times.push(sample.elapsedMs);
  times.sort(ascending);
  medians.push((times[9] + times[10]) / 2);
}
function ascending(left, right) { return left - right; }
const result = {
  scope: 'Isolated Node Wasm SIMD complete ExConv encoder, including allocation and checksum. Each check compares all Block and byte outputs. No complete Worker claim.',
  passed: true, checks, node: process.version, samples, medians,
  wasmSha256: createHash('sha256').update(bytes).digest('hex'),
};
await writeFile(process.argv[3], JSON.stringify(result, null, 2));
console.log({passed: true, checks, medians});
