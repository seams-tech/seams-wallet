import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
VENDOR = ROOT / 'crates/ed25519-yao/vendor'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    candidate = BASE / 'vendor'
    candidate.mkdir(exist_ok=False)
    shutil.copytree(VENDOR / 'cryprot-codes', candidate / 'cryprot-codes')
    (candidate / 'cryprot-core').symlink_to(VENDOR / 'cryprot-core', target_is_directory=True)
    relative = Path('cryprot-codes/src/ex_conv/fast_aes_rng/public_round.rs')
    path = candidate / relative
    text = path.read_text()
    replacements = [
        ('const TABLE: [u32; 256] = round_table();', 'const TABLES: [[u32; 256]; 4] = round_tables();'),
        ('TABLE[usize::from(input[start])]', 'TABLES[0][usize::from(input[start])]'),
        ('TABLE[usize::from(input[((column + 1) % 4) * 4 + 1])].rotate_left(8)', 'TABLES[1][usize::from(input[((column + 1) % 4) * 4 + 1])]'),
        ('TABLE[usize::from(input[((column + 2) % 4) * 4 + 2])].rotate_left(16)', 'TABLES[2][usize::from(input[((column + 2) % 4) * 4 + 2])]'),
        ('TABLE[usize::from(input[((column + 3) % 4) * 4 + 3])].rotate_left(24)', 'TABLES[3][usize::from(input[((column + 3) % 4) * 4 + 3])]'),
        ('// rotations in apply implement ShiftRows and the other three column terms.', '// rotations below precompute the other three column terms.'),
        ('const fn round_table() -> [u32; 256] {\n    let mut table = [0; 256];', 'const fn round_tables() -> [[u32; 256]; 4] {\n    let mut tables = [[0; 256]; 4];'),
        ('while value < table.len() {', 'while value < tables[0].len() {'),
        ('        table[value] = u32::from_le_bytes([twice, substituted, substituted, twice ^ substituted]);', '''        let word = u32::from_le_bytes([twice, substituted, substituted, twice ^ substituted]);
        tables[0][value] = word;
        tables[1][value] = word.rotate_left(8);
        tables[2][value] = word.rotate_left(16);
        tables[3][value] = word.rotate_left(24);'''),
        ('    table\n}', '    tables\n}'),
    ]
    for old, new in replacements:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    path.write_text(text)
    subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', str(path)], check=True)
    patch = subprocess.run(['git', 'diff', '--no-index', '--', str(VENDOR / relative), str(path)], capture_output=True, text=True)
    assert patch.returncode == 1
    (BASE / 'candidate.patch').write_text(patch.stdout)
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    harness = (ROOT / 'tools/ml-dsa-investigation/research/run_encoding_screen.py').read_text()
    harness = harness.replace('ROOT = Path(__file__).resolve().parents[3]', f'ROOT = Path({str(ROOT)!r})')
    harness = harness.replace('VENDOR = ROOT / "crates/ed25519-yao/vendor"', f'VENDOR = Path({str(candidate)!r})')
    harness = harness.replace('SOURCE = VENDOR / "cryprot-codes/src/ex_conv.rs"', 'SOURCE = ROOT / "crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv.rs"')
    harness = harness.replace('default="a60af34e"', f'default="{revision}"')
    harness = harness.replace('import subprocess\n', 'import subprocess\nimport shutil\n')
    needle = '        result = json.loads(args.output.read_text())\n'
    assert harness.count(needle) == 1
    harness = harness.replace(needle, '''        archive = args.output.with_suffix("")
        archive.mkdir()
        shutil.copy2(wasm, archive / "screen.wasm")
        for name in ["Cargo.toml", "Cargo.lock", "run.mjs"]:
            shutil.copy2(work / name, archive / name)
        shutil.copytree(work / "src", archive / "src")
''' + needle)
    harness = harness.replace('str(path.relative_to(SOURCE.with_suffix("")))', 'str(path.relative_to(VENDOR / "cryprot-codes/src/ex_conv"))')
    harness = harness.replace('sorted(SOURCE.with_suffix("").rglob("*.rs"))', 'sorted((VENDOR / "cryprot-codes/src/ex_conv").rglob("*.rs"))')
    (BASE / 'screen.py').write_text(harness)
    record = {
        'baseline_revision': revision,
        'baseline_public_round_sha256': digest(VENDOR / relative),
        'candidate_public_round_sha256': digest(path),
        'candidate_source_sha256': {str(p.relative_to(candidate / 'cryprot-codes')): digest(p) for p in sorted((candidate / 'cryprot-codes').rglob('*.rs'))},
        'scope': 'Temporary public-only rotated AES tables. No new unsafe code, protocol parameter, private AES change, or production source change.',
        'static_table_bytes': {'baseline': 1024, 'candidate': 4096},
    }
    (BASE / 'source.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'baseline_revision': revision, 'candidate': str(path)}))


if __name__ == '__main__':
    main()
