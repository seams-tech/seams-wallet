import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
STAGE = BASE / 'evidence-final/public-round'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    STAGE.mkdir(parents=True, exist_ok=False)
    files = [
        'prepare.py', 'screen.py', 'run.py', 'replay.py', 'package.py',
        'source.json', 'candidate.patch', 'measurement-plan.md',
        'first.json', 'repeat.json', 'first.log', 'repeat.log', 'run.log',
        'decision.json', 'README.md', 'review.md',
    ]
    for name in files:
        shutil.copy2(BASE / name, STAGE / name)
    for name in ['first', 'repeat', 'vendor/cryprot-codes']:
        shutil.copytree(BASE / name, STAGE / name, ignore=shutil.ignore_patterns('__pycache__'))
    members = sorted(path for path in STAGE.rglob('*') if path.is_file())
    manifest = {
        'scope': 'Deterministic public fixtures only. No credentials were generated.',
        'member_sha256': {str(path.relative_to(STAGE)): digest(path) for path in members},
    }
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-public-round-20261031.tar.gz'
    with tarfile.open(archive, 'w:gz') as bundle:
        bundle.add(STAGE, arcname=STAGE.name)
    summary = {
        'archive': {
            'name': archive.name,
            'sha256': digest(archive),
            'bytes': archive.stat().st_size,
            'member_files': len(members) + 1,
        },
        'source': json.loads((BASE / 'source.json').read_text()),
        'screens': {},
        'decision': json.loads((BASE / 'decision.json').read_text()),
        'limits': [
            'Node-Wasm elapsed time includes allocation and checksum work.',
            'Table payload is not measured Worker bundle growth.',
            'No complete Worker or hosted performance claim.',
        ],
    }
    for label in ['first', 'repeat']:
        record = json.loads((BASE / f'{label}.json').read_text())
        summary['screens'][label] = {
            'checks': record['checks'],
            'medians_ms': record['medians'],
            'wasm_sha256': record['wasmSha256'],
        }
    (BASE / 'ml-dsa-65-public-round-20261031.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary['archive']))


if __name__ == '__main__':
    main()
