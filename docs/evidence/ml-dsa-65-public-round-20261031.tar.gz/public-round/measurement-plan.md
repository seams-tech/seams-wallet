# Public matrix round experiment

The existing production profile attributes about seven percent of local samples to public index refill.
The next small candidate precomputes the three fixed word rotations used by its public AES round.
The source table grows from 1,024 to 4,096 bytes.
Public matrix seeds and state control its lookup addresses. Private AES remains unchanged.
The candidate changes no code parameter, update order, PPRF seed, binding, or material lifecycle.

1. Compare the temporary candidate against frozen current production after the dev rebase.
2. Require complete Block and byte output agreement over the existing 463-case encoder corpus.
3. Run two independent Node-Wasm screens with twenty alternating control/candidate pairs each after warmup.
4. Advance only if both complete-encoder kernel median improvements reach ten percent.
5. If the gate passes, run complete Worker lifecycle and unchanged-reserve controls before hosted qualification.
6. Discard the candidate if it misses the gate. Preserve the raw evidence and source patch.

These isolated elapsed times include deterministic input allocation and checksum work.
They establish no complete preparation latency, hosted throughput, or CPU billing result.
The table size is a source-level constant size, rather than a measured final Worker bundle increase.
Keep preparation on Workers, wallet-seed recovery, FIPS export, two-at-once consumption, and pool capacity unchanged.
No cloud deployments, new credentials, or cleanup actions are part of this local screen.
