# Public matrix round evidence

Run `python3 replay.py` after extraction.
Python3 and Node with Wasm SIMD support are required. No credentials or external calls are needed.

The replay verifies member hashes, source identities, original medians, the ten-percent gate, and both exact compiled output-comparison screens.
Each screen compares complete Block and byte encoder results over 463 shape, seed, and configuration cases.
New replay timings are ignored because they belong to the replay host.

The candidate precomputes three public word rotations. The generator recurrence and private AES paths remain unchanged.
Declared table payload grows from 1 KiB to 4 KiB. This is not a measured final Worker bundle increase.
The raw field production_source_sha256 identifies the unchanged ex_conv.rs entry file.
The changed public_round.rs hash is recorded explicitly in source.json and production_module_sha256.

The first median is 0.394 percent lower. The repeat is 0.118 percent higher.
Both miss the predeclared ten-percent gate. The candidate is discarded without production source changes or hosted testing.
The setup scripts retain original local paths as provenance. The exact standalone Wasm files support portable output replay.
