import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')


def main():
    source = json.loads((BASE / 'source.json').read_text())
    records = []
    for label in ['first', 'repeat']:
        with (BASE / f'{label}.log').open('w') as log:
            subprocess.run(
                ['python3', str(BASE / 'screen.py'), str(BASE / f'{label}.json'),
                 '--baseline', source['baseline_revision']],
                cwd=ROOT, check=True, stdout=log, stderr=subprocess.STDOUT,
            )
        record = json.loads((BASE / f'{label}.json').read_text())
        assert record['passed'] and record['checks'] == 463
        records.append(record)
        print(json.dumps({'phase': label, 'medians_ms': record['medians']}), flush=True)
    gains = []
    for record in records:
        control, candidate = record['medians']
        gains.append(1 - candidate / control)
    decision = {
        'gate': 'Both complete encoder median improvements must reach ten percent',
        'gains': gains,
        'advance': all(gain >= 0.10 for gain in gains),
        'runtime_changed': False,
        'hosted_gain_established': False,
    }
    (BASE / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
    print(json.dumps(decision), flush=True)


if __name__ == '__main__':
    main()
