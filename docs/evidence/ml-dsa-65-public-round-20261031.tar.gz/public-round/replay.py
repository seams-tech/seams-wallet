import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def main():
    manifest = read(BASE / 'manifest.json')
    for name, expected in manifest['member_sha256'].items():
        assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == expected, name
    source = read(BASE / 'source.json')
    gains = []
    for label in ['first', 'repeat']:
        record = read(BASE / f'{label}.json')
        assert record['baseline_revision'] == source['baseline_revision']
        assert record['production_module_sha256']['fast_aes_rng/public_round.rs'] == source['candidate_public_round_sha256']
        baseline = BASE / label / 'src/baseline/fast_aes_rng/public_round.rs'
        assert hashlib.sha256(baseline.read_bytes()).hexdigest() == source['baseline_public_round_sha256']
        medians = []
        for mode in [0, 1]:
            times = [row['elapsedMs'] for row in record['samples'] if row['mode'] == mode]
            assert len(times) == 20
            medians.append(statistics.median(times))
        assert medians == record['medians']
        gains.append(1 - medians[1] / medians[0])
        wasm = BASE / label / 'screen.wasm'
        assert hashlib.sha256(wasm.read_bytes()).hexdigest() == record['wasmSha256']
        with tempfile.TemporaryDirectory(prefix='ml-dsa-public-round-replay-') as directory:
            output = Path(directory) / 'result.json'
            subprocess.run(
                ['node', str(BASE / label / 'run.mjs'), str(wasm), str(output)],
                check=True, capture_output=True, text=True,
            )
            repeated = read(output)
            assert repeated['passed'] and repeated['checks'] == record['checks'] == 463
            for original, replayed in zip(record['samples'], repeated['samples'], strict=True):
                for field in ['mode', 'repetition', 'checksum']:
                    assert original[field] == replayed[field]
    decision = read(BASE / 'decision.json')
    assert gains == decision['gains']
    assert decision['advance'] == all(gain >= 0.10 for gain in gains)
    assert decision['advance'] is False
    print(json.dumps({
        'passed': True,
        'member_hashes': len(manifest['member_sha256']),
        'complete_output_cases_per_artifact': 463,
        'artifacts': 2,
        'candidate_retained': False,
    }))


if __name__ == '__main__':
    main()
