import hashlib
import json
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
label = sys.argv[1]
client = json.loads((base / (label + '-scenarios.json')).read_text())
assert client['passed']
assert client['scenario'] == 'warmup'
assert len(client['cases']) == 1
rows = json.loads((base / 'final-traces.json').read_text())['records']
versions = {row['role']: row['version'] for row in json.loads((base / 'deployments' / label.removesuffix('-warmup') / 'receipts.json').read_text())}
actors = json.loads((base / 'producer-actor-identities.json').read_text())
proof = []
for job in client['cases'][0]['jobs']:
    identity = bytes(job['batch']).hex()
    expected = {identity, hashlib.sha256(b'seams/ml-dsa/preparation-second-pair/v1' + bytes(job['batch'])).hexdigest()}
    a_role = 'preparer-a' if job['producer_slot'] == 'primary' else 'preparer-a-secondary'
    b_role = a_role.replace('preparer-a', 'preparer-b')
    cohort = []
    for role in [a_role, b_role]:
        found = [row for row in rows if row['role'] == role and any(stage['job'] == identity and stage['stage'] == 'correlations_completed' for stage in row['preparation_stages'])]
        assert len(found) == 1, (identity, role, len(found))
        row = found[0]
        assert row['version'] == versions[role], (role, row['version'], versions[role])
        assert row['outcome'] == 'ok' and not row['exception_names'] and not row['logs_truncated']
        published = {stage['batch'] for stage in row['preparation_stages'] if stage['job'] == identity and stage['stage'] == 'published'}
        assert published == expected
        if role == a_role:
            matching = [event for event in row['producer_jobs'] if event['batch'] == identity and event['stage'] == 'running']
            assert len(matching) == 1 and matching[0]['producer'] == actors[job['producer_slot']]
        cohort.append({'role': role, 'version': row['version'], 'cpu_ms': row['cpu_ms'], 'wall_ms': row['wall_ms'], 'published': sorted(published)})
    proof.append({'job': identity, 'slot': job['producer_slot'], 'roles': cohort})
assert {row['slot'] for row in proof} == {'primary', 'secondary'}
result = {'passed': True, 'label': label, 'jobs': proof, 'qualification': 'Actual producer actor, version, complete paired publications and provider outcomes match. No remote binary attestation or platform placement claim.'}
(base / (label + '-qualification.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'label': label, 'passed': True, 'matched_jobs': len(proof)}))
