import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const base = process.argv[2] ?? dirname(fileURLToPath(import.meta.url));
let signatures = 0;
const report = { qualification: 'Independent ordinary Node/OpenSSL ML-DSA-65 verification of retained setup and load signatures, with empty context.', setup: [], phases: [], passed: false };

function publicKey(encoded) {
  const bytes = Buffer.from(encoded, 'hex');
  assert.equal(bytes.length, 1952);
  return createPublicKey({ key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes,
  ]), format: 'der', type: 'spki' });
}

function checkSignature(row, key) {
  assert.equal(row.contextHex, '');
  const message = Buffer.from(row.messageHex, 'hex');
  const signature = Buffer.from(row.signatureHex, 'hex');
  assert.ok(message.length > 0);
  assert.equal(signature.length, 3309);
  assert.equal(verify(null, message, key, signature), true);
  message[0] ^= 1;
  assert.equal(verify(null, message, key, signature), false);
  signatures += 1;
}

for (let index = 1; index <= 4; index++) {
  const value = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(value.registrationChecksPassed, true);
  assert.equal(value.recoveryPreservesCanonicalKey, true);
  let accepted = 0;
  let failed = 0;
  for (const entry of value.cases) {
    if (entry.initialStockSign.verified) {
      checkSignature(entry.initialStockSign, publicKey(entry.publicKeyHex));
      accepted += 1;
    } else {
      assert.equal(entry.initialStockSign.failed, true);
      failed += 1;
    }
  }
  assert.equal(value.cases.at(-1).initialStockSign.verified, true);
  report.setup.push({ wallet: index, verified: accepted, preservedFailedSamples: failed });
}
for (const phase of ['baseline60', 'baseline45', 'candidate45']) {
  const value = JSON.parse(await readFile(base + '/cloud-driver/' + phase + '/client.json', 'utf8'));
  const keys = new Map();
  for (const wallet of value.wallets) {
    const registration = JSON.parse(await readFile(base + '/registration-' + (wallet.index + 1) + '.json', 'utf8'));
    const recovered = registration.cases.at(-1);
    assert.deepEqual(wallet.key, recovered.key);
    assert.equal(wallet.publicKeyHex, recovered.publicKeyHex);
    keys.set(wallet.index, publicKey(wallet.publicKeyHex));
  }
  let count = 0;
  for (const row of value.requests) {
    if (row.state !== 'succeeded') continue;
    assert.equal(keys.has(row.wallet), true);
    checkSignature(row, keys.get(row.wallet));
    count += 1;
  }
  assert.equal(count, value.successfulSignatures);
  assert.equal(value.duplicateRequests.length, 4);
  for (const duplicate of value.duplicateRequests) assert.equal(duplicate.sameSignature, true);
  report.phases.push({ phase, verified: count, idempotentReplays: 4 });
}
report.verifiedSignatures = signatures;
report.alteredMessagesRejected = signatures;
report.passed = true;
await writeFile(base + '/offline-hosted-signatures.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, signatures, alteredMessagesRejected: signatures }));
