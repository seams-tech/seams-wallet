import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';

const base = '/private/tmp/ml-dsa-refill-guard-20261029';
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]+$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const input = JSON.parse(await readFile(base + '/cloud-driver/' + label + '/start.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const report = { label, atMs: Date.now(), qualification: 'In-progress snapshot. No reserve-restored throughput claim.', wallets: [] };
for (const wallet of input.wallets) {
  const response = await fetch(scope.router_url + '/__benchmark/wallet/' + label + '-' + wallet.index, {
    headers: { 'x-router-ab-internal-service-auth': token }, signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  const snapshot = await response.json();
  const publicKey = createPublicKey({ key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
    Buffer.from(wallet.publicKeyHex, 'hex'),
  ]), format: 'der', type: 'spki' });
  let verified = 0;
  const unavailable = {};
  for (const row of snapshot.requests) {
    if (row.status === 'unavailable') unavailable[row.reason] = (unavailable[row.reason] ?? 0) + 1;
    if (row.state !== 'succeeded') continue;
    assert.equal(verify(null, Buffer.from(row.messageHex, 'hex'), publicKey, Buffer.from(row.signatureHex, 'hex')), true);
    verified += 1;
  }
  assert.equal(verified, snapshot.state.successes);
  report.wallets.push({ wallet: wallet.index, state: snapshot.state.state, verifiedSignatures: verified,
    requests: snapshot.requests.length, unavailable, snapshot });
}
await mkdir(base + '/live', { recursive: true });
await writeFile(base + '/live/' + label + '-' + report.atMs + '.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ label, elapsedMs: report.atMs - input.startAtMs, wallets: report.wallets.map(summary) }));
function summary(value) {
  return { wallet: value.wallet, state: value.state, verified: value.verifiedSignatures, requests: value.requests, unavailable: value.unavailable };
}
