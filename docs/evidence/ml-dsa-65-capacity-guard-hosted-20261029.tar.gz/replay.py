import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
work = base / 'replay-work'
work.mkdir(exist_ok=False)
command = [sys.executable, str(base / 'collect_worker_traces.py'), str(base / 'raw/a.jsonl'), str(base / 'raw/b.jsonl'), str(work / 'traces.json'), '--router', str(base / 'raw/router.jsonl')]
for role in ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
    command.extend(['--' + role, str(base / 'raw' / (role + '.jsonl'))])
result = subprocess.run(command, capture_output=True, text=True)
(work / 'normalization.log').write_text(result.stdout + result.stderr)
assert result.returncode == 0
records = json.loads((work / 'traces.json').read_text())['records']
assert records == json.loads((base / 'final-traces.json').read_text())['records']
phases = []
for label in ['baseline60', 'baseline45', 'candidate45']:
    destination = work / 'cloud-driver' / label
    destination.mkdir(parents=True)
    for name in ['start.json', 'client.json', 'initial-stock.json', 'restoration.json']:
        shutil.copy2(base / 'cloud-driver' / label / name, destination / name)
    (destination / 'traces.json').symlink_to(work / 'traces.json')
    result = subprocess.run([sys.executable, str(base / 'analyze-capacity.py'), str(work), label], capture_output=True, text=True)
    (destination / 'analysis.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0, label
    actual = json.loads((destination / 'analysis.json').read_text())
    expected = json.loads((base / 'cloud-driver' / label / 'analysis.json').read_text())
    assert actual == expected, label
    phases.append({'phase': label, 'verified_signatures': actual['successes'], 'cycle_signatures_per_minute': actual['whole_cycle_signatures_per_minute'], 'ledger_balanced': actual['ledger_balanced']})
for mode in ['baseline', 'candidate']:
    result = subprocess.run([sys.executable, str(base / 'qualify-guard.py'), mode], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
for label in ['baseline45-warmup', 'candidate45-warmup']:
    result = subprocess.run([sys.executable, str(base / 'qualify-warmup.py'), label], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
result = subprocess.run(['node', str(base / 'verify-hosted-signatures.mjs'), str(base)], capture_output=True, text=True)
assert result.returncode == 0, result.stderr
verification = json.loads(result.stdout)
report = {'passed': True, 'normalized_records': len(records), 'phases': phases, 'signature_verification': verification, 'scope': 'Offline replay of public provider records, exact cycle metrics, material ledgers, actual versions, guard cases, and ordinary signatures. No network or private credentials.'}
(base / 'offline-replay.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
