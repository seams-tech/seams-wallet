import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-refill-guard-20261029';
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]+$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const input = JSON.parse(await readFile(base + '/cloud-driver/' + label + '/start.json', 'utf8'));
assert.deepEqual(input.policy, scope.policy);
assert.equal(input.wallets.length, 4);
const gateway = (await readFile(base + '/gateway-token', 'utf8')).trim();
const internal = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const report = { label, startedAtMs: Date.now(), windowEndAtMs: input.endAtMs, snapshots: [], complete: false };
const artifact = base + '/cloud-driver/' + label + '/restoration.json';
assert.ok(report.startedAtMs < input.endAtMs, 'Start the observer before the load window ends');

async function readDriver(wallet) {
  const response = await fetch(scope.router_url + '/__benchmark/wallet/' + label + '-' + wallet.index, {
    headers: { 'x-router-ab-internal-service-auth': gateway }, signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  const value = await response.json();
  assert.deepEqual(value.state.config.key, wallet.key);
  const lastByOperation = new Map();
  for (const row of value.requests) lastByOperation.set(hex(row.operation), row);
  const unresolved = [];
  for (const row of lastByOperation.values()) {
    if (['succeeded', 'failed', 'declined'].includes(row.state)) continue;
    const statusResponse = await fetch(scope.router_url + '/router-ab/ml-dsa/status', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': gateway },
      body: JSON.stringify(row.signingRequest), signal: AbortSignal.timeout(30000),
    });
    assert.equal(statusResponse.status, 200);
    const status = await statusResponse.json();
    const active = activeStatus(status);
    unresolved.push({ operation: hex(row.operation), state: status === null ? 'absent' : status.state, active });
  }
  return { wallet: wallet.index, state: value.state.state, successes: value.state.successes,
    unresolved, error: value.state.error ?? null };
}

function activeStatus(value) {
  if (value === null) return false;
  switch (value.state) {
    case 'awaiting_stock':
      return false;
    case 'preparing':
    case 'running':
      return true;
    case 'succeeded':
    case 'failed':
    case 'declined':
      return false;
    default:
      throw new Error('Unknown authoritative signing status');
  }
}

async function inventory(wallet, role) {
  const url = new URL(scope.router_url);
  const prefix = scope.prefix + '-front.';
  assert.ok(url.hostname.startsWith(prefix));
  url.hostname = scope.prefix + '-' + role + '.' + url.hostname.slice(prefix.length);
  url.pathname = '/router-ab/ml-dsa/role';
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': internal },
    body: JSON.stringify({ command: 'inventory', key: wallet.key, target: 16, ready_until_ms: Date.now() + 30000 }),
    signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  return response.json();
}

function hex(value) {
  return Buffer.from(value).toString('hex');
}

async function stock(wallet) {
  const [a, b] = await Promise.all([inventory(wallet, 'a'), inventory(wallet, 'b')]);
  const idsA = a.ready.map(hex).sort();
  const idsB = b.ready.map(hex).sort();
  const full = idsA.length === 16 && idsB.length === 16 && new Set(idsA).size === 16 &&
    new Set(idsB).size === 16 && JSON.stringify(idsA) === JSON.stringify(idsB) &&
    a.reserved.length === 0 && b.reserved.length === 0;
  return { wallet: wallet.index, key: wallet.key, a, b, full };
}

async function snapshot(wallet) {
  const driver = await readDriver(wallet);
  const value = await stock(wallet);
  return { ...value, driver };
}

function restored(value) {
  return value.full && value.driver.state === 'complete' && value.driver.unresolved.every(terminal);
}

function terminal(value) {
  return !value.active;
}

try {
  while (Date.now() < input.endAtMs) await delay(Math.min(5000, input.endAtMs - Date.now()));
  const deadline = input.endAtMs + 900000;
  while (Date.now() < deadline) {
    const values = await Promise.all(input.wallets.map(snapshot));
    report.snapshots.push({ atMs: Date.now(), wallets: values });
    await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
    if (values.every(restored)) {
      report.complete = true;
      report.final = values;
      report.observedFullReserveAtMs = Date.now();
      break;
    }
    await delay(3000);
  }
  assert.equal(report.complete, true, 'Reserve restoration was not observed after driver completion');
} finally {
  report.endedAtMs = Date.now();
  await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ label, complete: report.complete, afterWindowMs: report.observedFullReserveAtMs - input.endAtMs }));
