# Offline Cloudflare comparison replay

Run `python3 replay.py` from a fresh extraction with Python 3 and Node.js that supports ML-DSA-65.
The replay makes no network calls and requires no private credentials.
It reconstructs normalized provider records, exact cycle metrics, material ledgers, actual versions, guard cases, and ordinary signatures.
It writes a disposable replay-work directory and offline-replay.json. Use a fresh extraction to repeat.
The receipt-selected public guard/warmup adapters use the archived final capture; original orchestration sources are inspection records.

The three fixed comparison windows are complete. All eight Workers remain active only for the user-requested follow-up prototype.
No active authentication token, role storage key, or private wallet seed belongs in this archive.
Production policy, wallet-seed recovery, canonical FIPS export, two-at-once consumption, and per-wallet capacity remain unchanged.
