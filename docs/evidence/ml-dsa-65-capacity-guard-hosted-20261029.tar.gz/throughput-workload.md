# Sustained throughput comparison

Use the eight exact Worker names and credential payloads in [the unchanged upload scope](hosted-upload-scope.md).
Extend the synthetic workload to four independent wallets on the same Workers.
No production route, wallet, storage key, cooldown, or capacity changes.

1. Repeat the ten-minute operational test with a sixty-second cooldown. Four wallets offer at most four operations per minute.
2. Run separate twelve-minute capacity screens with a forty-five-second benchmark cooldown. Four wallets offer approximately 5.33 operations per minute.
3. Compare baseline and candidate with identical policy within each screen. Restore the original reserve after each screen.
4. Measure verified signatures, useful candidates, complete paired CPU, empty-pool waits, dispatch gaps, failed work, and material loss.
5. Count setup and first-touch separately. Do not label a cooldown change as a protocol speedup.

Preparation stays on Workers. Wallet-seed recovery, canonical FIPS export, two-at-once consumption, and thirty-two candidates per wallet remain required.
The two preparation slots remain experimental. Production defaults remain unchanged.
All eight temporary Workers will be deleted after the comparison.

No hosted action has run. The local baseline and candidate binaries remain frozen.
