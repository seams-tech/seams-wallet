import hashlib
import json
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ['baseline', 'candidate']
label = mode + '-guard'
client = json.loads((base / (label + '-scenarios.json')).read_text())
assert client['passed'] and client['scenario'] == 'guard'
rows = json.loads((base / 'final-traces.json').read_text())['records']
version_file = base / ('release/receipts.json' if mode == 'baseline' else 'deployments/candidate45/receipts.json')
versions = {row['role']: row['version'] for row in json.loads(version_file.read_text())}
proof = []
for case in client['cases']:
    for job in case['jobs']:
        identity = bytes(job['batch']).hex()
        role_a = 'preparer-a' if job['producer_slot'] == 'primary' else 'preparer-a-secondary'
        role_b = role_a.replace('preparer-a', 'preparer-b')
        found = [row for row in rows if row['role'] == role_a and any(event['batch'] == identity for event in row['refill'])]
        assert len(found) == 1
        a = found[0]
        assert a['version'] == versions[role_a] and a['outcome'] == 'ok'
        outcome = next(event for event in a['refill'] if event['batch'] == identity)
        stages = [stage['stage'] for row in rows for stage in row['preparation_stages'] if stage['job'] == identity]
        result = {'case': case['name'], 'job': identity, 'role_a': role_a, 'version_a': a['version'], 'cpu_a_ms': a['cpu_ms'], 'wall_a_ms': a['wall_ms'], 'outcome': outcome, 'stages': stages}
        if mode == 'candidate':
            assert outcome.get('outcome') == 'unused' and outcome['published'] is None
            assert outcome['candidates'] == 0 and outcome['batches'] == []
            assert 'stock_rechecked' in stages and 'preparation_not_needed' in stages
            assert 'role_claimed' not in stages and 'crypto_started' not in stages
            assert not any(event['job'] == identity for row in rows for event in row['preparation_transport'])
        else:
            expected = {identity, hashlib.sha256(b'seams/ml-dsa/preparation-second-pair/v1' + bytes(job['batch'])).hexdigest()}
            assert outcome['published'] is True and outcome['candidates'] == 4
            assert set(outcome['batches']) == expected
            peers = [row for row in rows if row['role'] == role_b and any(stage['job'] == identity and stage['stage'] == 'correlations_completed' for stage in row['preparation_stages'])]
            assert len(peers) == 1
            b = peers[0]
            assert b['version'] == versions[role_b] and b['outcome'] == 'ok'
            for row in [a, b]:
                actual = {stage['batch'] for stage in row['preparation_stages'] if stage['job'] == identity and stage['stage'] == 'published'}
                assert actual == expected
            assert stages.count('role_claimed') == 2 and stages.count('crypto_started') == 2
            result.update({'role_b': role_b, 'version_b': b['version'], 'cpu_b_ms': b['cpu_ms'], 'wall_b_ms': b['wall_ms']})
        proof.append(result)
assert len(proof) == 4
if mode == 'candidate':
    warmup = json.loads((base / 'candidate45-warmup-scenarios.json').read_text())
    warmup_ids = {bytes(job['batch']).hex() for job in warmup['cases'][0]['jobs']}
    positive = [stage for row in rows for stage in row['preparation_stages'] if stage['job'] in warmup_ids and stage['stage'] == 'role_claimed']
    assert len(positive) == 4, 'The no-claim observation needs known positive role-claim events'
result = {'passed': True, 'mode': mode, 'manual_jobs': proof,
          'scope': 'Selected controlled jobs, exact provider versions, outputs and stages. Role CPU belongs to the complete selected invocation. This does not include all metadata/caller work or fresh bounded replacement jobs and establishes no sustained speedup.'}
(base / (label + '-qualification.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'mode': mode, 'passed': True, 'jobs': len(proof), 'selected_invocation_cpu_ms': sum(row['cpu_a_ms'] + row.get('cpu_b_ms', 0) for row in proof)}))
