import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-refill-guard-20261029';
const [mode, label, scenario] = process.argv.slice(2);
assert.ok(['guard', 'warmup'].includes(scenario));
assert.ok(['baseline', 'candidate'].includes(mode));
assert.match(label, /^[a-z0-9-]+$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const gateway = (await readFile(base + '/gateway-token', 'utf8')).trim();
const internal = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const keys = [];
for (let index = 1; index <= 2; index++) {
  const value = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(value.registrationChecksPassed, true);
  assert.equal(value.recoveryPreservesCanonicalKey, true);
  keys.push(value.cases.at(-1).key);
}
const report = { qualification: 'Stock checks only; require matching provider outcomes and versions before acceptance.', mode, label, scenario, startedAtMs: Date.now(), requests: [], cases: [], passed: false };
const artifact = base + '/' + label + '-scenarios.json';

async function request(url, body, credential) {
  const startedAtMs = Date.now();
  const response = await fetch(url, {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': credential },
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000),
  });
  const text = await response.text();
  const row = { path: new URL(url).pathname, startedAtMs, endedAtMs: Date.now(), status: response.status };
  report.requests.push(row);
  await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
  assert.ok(response.status === 200 || response.status === 202, text);
  return JSON.parse(text);
}

function roleUrl(role) {
  const url = new URL(scope.router_url);
  const marker = scope.prefix + '-front.';
  assert.ok(url.hostname.startsWith(marker));
  url.hostname = scope.prefix + '-' + role + '.' + url.hostname.slice(marker.length);
  url.pathname = '/router-ab/ml-dsa/role';
  return url.href;
}

async function admission(body) {
  return request(scope.router_url + '/__benchmark/refill/admission', body, gateway);
}

async function stock(key) {
  const body = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 };
  const a = await request(roleUrl('a'), body, internal);
  const b = await request(roleUrl('b'), body, internal);
  assert.equal(a.reserved.length, 0);
  assert.equal(b.reserved.length, 0);
  assert.deepEqual(a.ready.map(hex).sort(), b.ready.map(hex).sort());
  return { key, a, b, paired: a.ready.map(hex).sort() };
}

function hex(value) { return Buffer.from(value).toString('hex'); }

function batchIds(job) {
  assert.equal(job.groups, 'two');
  return [job.batch, Array.from(createHash('sha256').update('seams/ml-dsa/preparation-second-pair/v1').update(Buffer.from(job.batch)).digest())];
}

async function claim(key) {
  const deadline = Date.now() + 60000;
  while (Date.now() < deadline) {
    const result = await admission({ command: 'claim_refill', key, groups: 'two' });
    if (result.status === 'acquired') return result.job;
    assert.equal(result.status, 'busy');
    await delay(Math.max(50, Math.min(1000, result.retry_at_ms - Date.now())));
  }
  throw new Error('The synthetic refill lease was unavailable');
}

async function retire(key, batches) {
  for (const role of ['a', 'b']) await request(roleUrl(role), { command: 'retire_unpaired', key, batches }, internal);
}

async function runCase(name, deficit) {
  const entry = { name, deficit, startedAtMs: Date.now(), initial: [], jobs: [], retired: [], final: [], normalized: [], passed: false };
  report.cases.push(entry);
  for (const key of keys) {
    const value = await stock(key);
    assert.equal(value.paired.length, 16, 'Require exact unchanged reserves');
    entry.initial.push(value);
  }
  for (const key of keys) entry.jobs.push(await claim(key));
  assert.equal(new Set(entry.jobs.map(producerSlot)).size, 2, 'Both configured producer slots must participate');
  if (deficit > 0) {
    for (const value of entry.initial) {
      const batches = value.a.ready.slice(0, deficit);
      await retire(value.key, batches);
      entry.retired.push({ key: value.key, batches });
    }
  }
  entry.queueStartedAtMs = Date.now();
  for (const job of entry.jobs) assert.equal(await request(scope.router_url + '/__benchmark/refill/queue', job, gateway), true);
  const deadline = Date.now() + 120000;
  for (const job of entry.jobs) {
    while (await admission({ command: 'check_refill', job })) {
      assert.ok(Date.now() < deadline, 'The test lease did not settle');
      await delay(500);
    }
  }
  entry.leasesSettledAtMs = Date.now();
  for (let index = 0; index < keys.length; index++) {
    let value;
    do {
      value = await stock(keys[index]);
      if (mode === 'candidate' && deficit === 1 && value.paired.length < 16) await delay(500);
      else break;
      assert.ok(Date.now() < deadline, 'The smaller fresh replacement did not arrive');
    } while (true);
    const expected = mode === 'baseline' ? 18 - deficit : 16;
    assert.equal(value.paired.length, expected);
    entry.final.push(value);
    if (mode === 'baseline') {
      const unused = batchIds(entry.jobs[index]).slice(deficit);
      if (unused.length) await retire(keys[index], unused);
      entry.normalized.push({ key: keys[index], retired: unused, stock: await stock(keys[index]) });
      assert.equal(entry.normalized.at(-1).stock.paired.length, 16);
    }
  }
  entry.passed = true;
  entry.endedAtMs = Date.now();
  await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ mode, name, passed: true, clientMs: entry.endedAtMs - entry.queueStartedAtMs }));
}

function producerSlot(job) { return job.producer_slot; }

try {
  if (scenario === 'guard') {
    await runCase('full-stock', 0);
    await runCase('smaller-deficit', 1);
  } else {
    await runCase('fresh-warmup', 2);
  }
  report.passed = true;
} finally {
  report.endedAtMs = Date.now();
  await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
}
