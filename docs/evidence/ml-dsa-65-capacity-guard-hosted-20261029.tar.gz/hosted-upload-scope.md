# ML-DSA refill guard hosted upload scope

Compare the frozen baseline with the stale-deficit guard on eight temporary Workers and two synthetic wallets. Verify canonical creation and wallet-seed recovery, force stale full/smaller-capacity preparation leases, count all material and work, and measure refill wake/dispatch. Keep thirty-two candidates per wallet, two-at-once consumption, Workers preparation, and FIPS export. No production wallets or routes.

Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.
A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.
Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.
All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-guard-1029-28c437-router | 06816f467da409dc442c057a779a833bb2d9a2108f32c022fb2bca194a0f8588 |
| ml-dsa-guard-1029-28c437-a | c02c11a498f0ec8f766dc658bef7567b0e1bd4564e00936a6faeb95821b67603 |
| ml-dsa-guard-1029-28c437-b | 1ebbca819d074b9598643589f20ebc49eba7060c326009e4bc024420422754e2 |
| ml-dsa-guard-1029-28c437-preparer-a | c02c11a498f0ec8f766dc658bef7567b0e1bd4564e00936a6faeb95821b67603 |
| ml-dsa-guard-1029-28c437-preparer-b | 1ebbca819d074b9598643589f20ebc49eba7060c326009e4bc024420422754e2 |
| ml-dsa-guard-1029-28c437-preparer-a-secondary | c02c11a498f0ec8f766dc658bef7567b0e1bd4564e00936a6faeb95821b67603 |
| ml-dsa-guard-1029-28c437-preparer-b-secondary | 1ebbca819d074b9598643589f20ebc49eba7060c326009e4bc024420422754e2 |
| ml-dsa-guard-1029-28c437-front | 06816f467da409dc442c057a779a833bb2d9a2108f32c022fb2bca194a0f8588 |

The authenticated benchmark front can request synthetic refill leases and queue them on these same Workers. Core admission validates each job. This enables a controlled baseline/candidate test at full stock and a shrinking deficit. All wasted material and metadata-only skipped jobs remain accounted. Existing optional wait diagnostics record queue commits and alarm before/after times. Baseline and candidate use the same configured capacity and policy.

No deployment, credential upload, database creation, or hosted request has run for this scope.
