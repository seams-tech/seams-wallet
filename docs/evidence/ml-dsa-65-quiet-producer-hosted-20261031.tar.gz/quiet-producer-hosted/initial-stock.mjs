import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';

const base = import.meta.dirname;
const [directory, label] = process.argv.slice(2);
assert.equal(directory, base);
assert.equal(label, 'ordinary');
const root = '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa';
const record = { scope: 'Setup only. Replace short-lived registration stock before timed producer controls.',
  startedAtMs: Date.now(), steps: [], passed: false };

function run(stage, command) {
  const startedAtMs = Date.now();
  const output = execFileSync(command[0], command.slice(1), { cwd: root, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  record.steps.push({ stage, startedAtMs, endedAtMs: Date.now(), output });
}

try {
  run('before', ['node', base + '/snapshot-stock.mjs', base, 'ordinary-before-normalization']);
  run('capture', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', base, 'setup-complete']);
  run('retire-short-lived-registration-stock', ['node', base + '/replace-registration-stock.mjs']);
  run('restore', ['node', base + '/snapshot-stock.mjs', base, label]);
  const final = JSON.parse(await readFile(base + '/ordinary-initial-stock.json', 'utf8'));
  assert.equal(final.complete, true);
  const retired = JSON.parse(await readFile(base + '/registration-stock-retirement.json', 'utf8'));
  for (const origin of retired.classification) {
    const stock = final.final.find(sameKey.bind(null, origin.key));
    const retained = new Set(stock.paired);
    for (const batch of origin.normalIds) assert.ok(retained.has(batch), 'Existing normal material was lost during setup');
    for (const batch of origin.registrationIds) assert.ok(!retained.has(batch), 'Retired registration material returned');
  }
  record.passed = true;
} finally {
  record.endedAtMs = Date.now();
  await writeFile(base + '/setup-stock-normalization.json', JSON.stringify(record, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: true, setupNormalizationMs: record.endedAtMs - record.startedAtMs }));

function sameKey(key, stock) { return JSON.stringify(key) === JSON.stringify(stock.key); }
