import assert from 'node:assert/strict';
import { createHash, createPublicKey, randomBytes, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
const base = '/private/tmp/ml-dsa-quiet-producer-20261030';
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const report = { passed: false, scope: 'Standard signatures from final fresh ready material. Private Router path. Failed attempts and admission waits remain recorded.', cases: [] };

function digest(bytes) {
  return Array.from(createHash('sha256').update(Buffer.from(bytes)).digest());
}

async function sign(wallet, index) {
  const value = wallet.cases.at(-1);
  const message = Array.from(Buffer.from('ML-DSA quiet producer controls proof ' + index));
  const entry = { wallet: index, key: value.key, publicKeyHex: value.publicKeyHex, messageHex: Buffer.from(message).toString('hex'), requests: [], verified: false };
  report.cases.push(entry);
  const deadline = Date.now() + 180000;
  let operation = Array.from(randomBytes(32));
  while (Date.now() < deadline) {
    const body = { request: { key: value.key, operation, message_digest: digest(message), context_digest: digest([]) }, message, context: [] };
    const startedAtMs = Date.now();
    const response = await fetch(scope.router_url + '/router-ab/ml-dsa/sign', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token },
      body: JSON.stringify(body), signal: AbortSignal.timeout(60000),
    });
    assert.equal(response.status, 200);
    const result = await response.json();
    const row = { operation, startedAtMs, completedAtMs: Date.now(), result };
    entry.requests.push(row);
    await writeFile(base + '/final-signatures.json', JSON.stringify(report, null, 2) + '\n');
    if (result.status === 'unavailable') {
      await delay(Math.max(1000, Math.min(5000, result.retry_at_ms - Date.now())));
      continue;
    }
    assert.equal(result.status, 'existing');
    if (result.operation.state === 'failed') {
      operation = Array.from(randomBytes(32));
      continue;
    }
    assert.equal(result.operation.state, 'succeeded');
    const key = createPublicKey({ key: Buffer.concat([
      Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), Buffer.from(value.publicKeyHex, 'hex'),
    ]), format: 'der', type: 'spki' });
    const signature = Buffer.from(result.operation.signature);
    assert.equal(verify(null, Buffer.from(message), key, signature), true);
    const altered = Buffer.from(message);
    altered[0] ^= 0x80;
    assert.equal(verify(null, altered, key, signature), false);
    entry.operation = operation;
    entry.signatureHex = signature.toString('hex');
    entry.verified = true;
    entry.alteredMessageRejected = true;
    return;
  }
  throw new Error('Final signature did not finish within its qualification window');
}

try {
  for (let index = 1; index <= 4; index++) {
    const wallet = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
    await sign(wallet, index);
  }
  report.passed = true;
} finally {
  await writeFile(base + '/final-signatures.json', JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: report.passed, verified: report.cases.length }));
