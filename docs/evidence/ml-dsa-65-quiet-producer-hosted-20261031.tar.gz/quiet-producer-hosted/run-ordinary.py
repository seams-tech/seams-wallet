import json
import shutil
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BLOCKS = [
    ('ordinary-0-first', [0]),
    ('ordinary-1-first', [1]),
    ('ordinary-overlap', [0, 1]),
    ('ordinary-1-return', [1]),
    ('ordinary-0-return', [0]),
    ('reverse-1-first', [3]),
    ('reverse-0-first', [2]),
    ('reverse-overlap', [3, 2]),
    ('reverse-0-return', [2]),
    ('reverse-1-return', [3]),
]


def run(label, command):
    with (BASE / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    print(json.dumps({'stage': label, 'exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit('Preserved failed stage: ' + label)


def main():
    plan = [{'label': label, 'wallets': wallets} for label, wallets in BLOCKS]
    path = BASE / 'ordinary-order.json'
    assert not path.exists()
    path.write_text(json.dumps(plan, indent=2) + '\n')
    for label, wallets in BLOCKS:
        run(label, ['node', str(BASE / 'quiet-block.mjs'), label, *map(str, wallets)])
    run('ordinary-final-capture', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs',
                                  'traces', str(BASE), 'ordinary-final'])
    rows = []
    for role in ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
        for line in (BASE / f'cloud-driver/ordinary-final/{role}-raw.jsonl').read_text().splitlines():
            rows.append(json.loads(line))
    raw = BASE / 'ordinary-final-producer-traces.json'
    raw.write_text(json.dumps(rows) + '\n')
    for label, _ in BLOCKS:
        run(label + '-qualification', ['python3', str(BASE / 'qualify-block.py'),
                                       str(BASE / 'blocks' / label), str(BASE / 'deployments.json'), str(raw)])
    run('ordinary-gap-analysis', ['python3', str(BASE / 'analyze-ordinary.py')])


if __name__ == '__main__':
    main()
