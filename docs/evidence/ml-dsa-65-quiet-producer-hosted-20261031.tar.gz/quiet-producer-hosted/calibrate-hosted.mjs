import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';

const base = import.meta.dirname;
const [label, mode] = process.argv.slice(2);
assert.match(label, /^[a-z0-9-]{1,60}$/);
assert.ok(['empty', 'heavy'].includes(mode));
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const selection = JSON.parse(await readFile(base + '/actor-selection.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const local = JSON.parse(await readFile(base + '/local-calibration.json', 'utf8'));
const folder = base + '/calibrations/' + label;
await mkdir(base + '/calibrations', { recursive: true });
await mkdir(folder);
const report = { label, mode, startedAtMs: Date.now(), samples: [], passed: false,
  scope: 'Fixed public workload calibration. Bulk AES batching differs from production conversion.' };

try {
  let repetition = 0;
  for (const seed of [1, 17, 65537]) {
    let groups = selection.groups;
    let kinds = mode === 'empty' ? [0] : [1, 2];
    if (repetition % 2 === 1) {
      groups = [...groups].reverse();
      kinds = [...kinds].reverse();
    }
    for (const group of groups) {
      for (const kind of kinds) {
        for (const role of ['a', 'b']) {
          const requestId = randomBytes(16).toString('hex');
          const record = { group: group.group, slot: group.slot, role, kind, seed, requestId, startedAtMs: Date.now() };
          report.samples.push(record);
          const response = await fetch(scope.router_url + '/__benchmark/calibrate/' + group.group + '/' + group.slot + '/' + role, {
            method: 'POST', headers: { 'content-type': 'application/json',
              'x-router-ab-internal-service-auth': token, 'x-ml-dsa-request-id': requestId },
            body: JSON.stringify({ kind, seed }), signal: AbortSignal.timeout(30000),
          });
          record.httpStatus = response.status;
          record.endedAtMs = Date.now();
          assert.equal(response.status, 200, 'Calibration refused or preparation was active');
          record.result = await response.json();
          const expected = local.samples.find(localReference.bind(null, role, kind, seed));
          assert.equal(record.result.checksum, expected.result.checksum);
          assert.equal(record.result.active_crypto, 0);
          assert.ok(record.result.memory_bytes < 128 * 1024 * 1024);
          if (role === 'a') assert.equal(record.result.actor, group.actor);
          await writeFile(folder + '/results.json', JSON.stringify(report, null, 2) + '\n');
        }
      }
    }
    repetition += 1;
  }
  report.passed = true;
} finally {
  report.endedAtMs = Date.now();
  await writeFile(folder + '/results.json', JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ label, passed: report.passed, samples: report.samples.length }));

function localReference(role, kind, seed, sample) {
  return sample.role === role && sample.result.kind === kind && sample.result.seed === seed;
}
