// Test-copy export only. This is absent from production source and builds.
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen::prelude::wasm_bindgen]
pub fn ml_dsa_public_calibration(kind: u32, seed: u32) -> std::result::Result<String, wasm_bindgen::JsValue> {
    if kind > 2 || ![1, 17, 65_537].contains(&seed) {
        return Err(wasm_bindgen::JsValue::from_str("Invalid public calibration input"));
    }
    let Some(_guard) = compute_slot().try_lock_owned() else {
        return Err(wasm_bindgen::JsValue::from_str("Preparation is active"));
    };
    let checksum = ml_dsa_threshold::runtime::boolean_mpc::silent::public_preparation_calibration(kind, seed);
    Ok(serde_json::json!({
        "kind": kind,
        "seed": seed,
        "checksum": checksum,
        "module_instance": signing_trace::module_identity(),
        "memory_bytes": core::arch::wasm32::memory_size::<0>() as u64 * 65_536,
        "active_crypto": ACTIVE_CRYPTO.load(std::sync::atomic::Ordering::Relaxed),
    }).to_string())
}
