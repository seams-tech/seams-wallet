import * as core from './probe-build/deriver-a/worker/shim.mjs';
import { calibrate, configuredSecret, protocolTag } from './calibration-a.mjs';
export * from './probe-build/deriver-a/worker/shim.mjs';

const identities = new WeakMap();

export class RouterAbMlDsaProducerDurableObject extends core.RouterAbMlDsaProducerDurableObject {
  constructor(state, env) {
    super(state, env);
    identities.set(this, { actor: state.id.toString(), env, alarmRunning: false });
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (!['/__benchmark/calibration', '/__benchmark/calibration-peer'].includes(path)) {
      return super.fetch(request);
    }
    const entry = identities.get(this);
    const secret = configuredSecret(entry.env);
    if (secret === null) return new Response('Auth is not configured', { status: 503 });
    if (request.headers.get('x-router-ab-internal-service-auth') !== secret) {
      return new Response('Unauthorized', { status: 403 });
    }
    if (request.method !== 'POST') return new Response('POST required', { status: 405 });
    if (entry.alarmRunning) return new Response('Preparation is active', { status: 409 });
    const text = await request.text();
    if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
    if (entry.alarmRunning) return new Response('Preparation is active', { status: 409 });
    if (path === '/__benchmark/calibration-peer') {
      return entry.env.DERIVER_B.fetch(new Request('https://peer/__benchmark/calibration', {
        method: 'POST', headers: { 'content-type': 'application/json',
          'x-router-ab-internal-service-auth': secret,
          'x-ml-dsa-request-id': request.headers.get('x-ml-dsa-request-id') ?? '' }, body: text,
      }));
    }
    return calibrate(text, entry.actor, request.headers.get('x-ml-dsa-request-id'));
  }

  async alarm() {
    const entry = identities.get(this);
    entry.alarmRunning = true;
    protocolTag(entry.actor, 'alarm_entered');
    try {
      return await super.alarm();
    } finally {
      protocolTag(entry.actor, 'alarm_returned');
      entry.alarmRunning = false;
    }
  }
}

export default core.default;
