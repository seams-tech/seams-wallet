# ML-DSA quiet producer control: exact upload scope

Quiet/overlap/quiet producer controls before probing. If the CPU gap persists, deploy same-module fixed-public-input calibration and restore the production build as a return control. Four synthetic wallets in two stable service groups. No production wallets or resources.

Create eight temporary Workers and upload only these exact fresh benchmark credentials.
A receives only its separate role key. B receives only its separate role key.
Front and Router receive benchmark access tokens only. No production wallet or account credentials.

| Worker | Secret bindings | Payload SHA-256 |
| --- | --- | --- |
| ml-dsa-quiet-1030-3cf645-router | INTERNAL_AUTH, ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET | 46b9d50bc136af1aa088d1a769bc9705166f65b5ef2af787450b4134ebca6d4f |
| ml-dsa-quiet-1030-3cf645-a | INTERNAL_AUTH, ROLE_KEK | adeaf3f437a9e6f0f257236d0c826c87d732892797657390f093b28a1984855e |
| ml-dsa-quiet-1030-3cf645-b | INTERNAL_AUTH, ROLE_KEK | d61dcbe904c4eb09dffe034155950d549fcd7d1960206291fcfc673222294bf1 |
| ml-dsa-quiet-1030-3cf645-preparer-a | INTERNAL_AUTH, ROLE_KEK | adeaf3f437a9e6f0f257236d0c826c87d732892797657390f093b28a1984855e |
| ml-dsa-quiet-1030-3cf645-preparer-b | INTERNAL_AUTH, ROLE_KEK | d61dcbe904c4eb09dffe034155950d549fcd7d1960206291fcfc673222294bf1 |
| ml-dsa-quiet-1030-3cf645-preparer-a-secondary | INTERNAL_AUTH, ROLE_KEK | adeaf3f437a9e6f0f257236d0c826c87d732892797657390f093b28a1984855e |
| ml-dsa-quiet-1030-3cf645-preparer-b-secondary | INTERNAL_AUTH, ROLE_KEK | d61dcbe904c4eb09dffe034155950d549fcd7d1960206291fcfc673222294bf1 |
| ml-dsa-quiet-1030-3cf645-front | INTERNAL_AUTH, ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET | 46b9d50bc136af1aa088d1a769bc9705166f65b5ef2af787450b4134ebca6d4f |

Preparation remains on Workers. Each wallet retains thirty-two candidates and consumes two at a time.
The test uses two preparation slots per group and a five-second benchmark cooldown. Production defaults stay unchanged.
Only preparer code changes between ordinary, diagnostic, and ordinary-return blocks. Keep collection settings fixed.
Stop the calibration campaign if quiet ordinary runs do not reproduce the gap.
Retain failed and unmatched work. Record exact A/B publications and full reserve restoration.
Delete all eight Workers and private test credentials after collection. No D1 databases or R2 buckets are created.

See measurement-plan.md for ordered phases, sample limits, matching rules, and stopping rules.
