import json
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BLOCKS = [
    ('diagnostic-unprobed-0', [0]),
    ('diagnostic-unprobed-1', [1]),
    ('diagnostic-after-empty-1', [3]),
    ('diagnostic-after-empty-0', [2]),
    ('diagnostic-after-heavy-0', [0]),
    ('diagnostic-after-heavy-1', [1]),
]


def run(label, command):
    with (BASE / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    print(json.dumps({'stage': label, 'exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit('Preserved diagnostic failure: ' + label)


def block(label, wallets):
    run(label, ['node', str(BASE / 'quiet-block.mjs'), label, *map(str, wallets)])


def main():
    gate = json.loads((BASE / 'ordinary-analysis.json').read_text())
    assert gate['diagnostic_gate'] == 'run_matched_calibration'
    original = json.loads((BASE / 'deployments.json').read_text())
    changed = json.loads((BASE / 'preparer-deployments/diagnostic-first/receipts.json').read_text())
    assert len(changed) == 4 and all(row['version'] and row['exit_code'] == 0 for row in changed)
    by_role = {row['role']: row for row in changed}
    versions = [by_role.get(row['role'], row) for row in original]
    (BASE / 'diagnostic-versions.json').write_text(json.dumps(versions, indent=2) + '\n')
    (BASE / 'diagnostic-order.json').write_text(json.dumps(BLOCKS, indent=2) + '\n')
    for label, wallets in BLOCKS[:2]:
        block(label, wallets)
    run('diagnostic-empty-probes', ['node', str(BASE / 'calibrate-hosted.mjs'), 'diagnostic-empty', 'empty'])
    for label, wallets in BLOCKS[2:4]:
        block(label, wallets)
    run('diagnostic-heavy-probes', ['node', str(BASE / 'calibrate-hosted.mjs'), 'diagnostic-heavy', 'heavy'])
    for label, wallets in BLOCKS[4:]:
        block(label, wallets)
    run('diagnostic-final-capture', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs',
                                    'traces', str(BASE), 'diagnostic-final'])
    rows = []
    for role in ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
        for line in (BASE / f'cloud-driver/diagnostic-final/{role}-raw.jsonl').read_text().splitlines():
            rows.append(json.loads(line))
    raw = BASE / 'diagnostic-final-producer-traces.json'
    raw.write_text(json.dumps(rows) + '\n')
    for label, _ in BLOCKS:
        run(label + '-qualification', ['python3', str(BASE / 'qualify-block.py'),
                                       str(BASE / 'blocks' / label), str(BASE / 'diagnostic-versions.json'), str(raw)])


if __name__ == '__main__':
    main()
