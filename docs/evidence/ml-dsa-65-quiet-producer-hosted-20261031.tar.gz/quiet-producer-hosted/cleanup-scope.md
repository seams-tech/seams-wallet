# Exact temporary Worker deletion scope

Delete only these eight Cloudflare Workers created for the approved quiet-producer experiment.
This removes their synthetic Durable Object test state. No production wallet or account resources are involved.
All test results and material ledgers are saved. All four wallets have zero pending jobs and zero reservations.

| Worker | Current test version |
| --- | --- |
| ml-dsa-quiet-1030-3cf645-router | fb4d30d5-c97b-4db2-b3e2-b38a98547aa2 |
| ml-dsa-quiet-1030-3cf645-a | 861e7980-f6fa-4e07-8d62-6b27b2c71400 |
| ml-dsa-quiet-1030-3cf645-b | 55230c3e-f216-4008-96c7-493a87e30990 |
| ml-dsa-quiet-1030-3cf645-preparer-a | 57880da1-5c5e-4c7d-aac6-7d48ec863e20 |
| ml-dsa-quiet-1030-3cf645-preparer-b | 7306bb2b-f5ee-46ed-82b9-fd0a95699c95 |
| ml-dsa-quiet-1030-3cf645-preparer-a-secondary | 950b36ea-064f-4b65-b9f0-618a2c4d19cd |
| ml-dsa-quiet-1030-3cf645-preparer-b-secondary | 9ad6f7f5-1fc8-4246-942e-1068d0cd943b |
| ml-dsa-quiet-1030-3cf645-front | e1446997-965d-45c9-9579-8b981127fa29 |

The final evidence closure passes: 64 initial + 59 fresh = 48 experiment retirements + 11 signing consumption + 64 final pairs.
The independent review found no blocker to test-fleet cleanup.
Automatic approval review requires explicit deletion approval because the earlier answer named deployment and credential uploads.
