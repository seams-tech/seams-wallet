import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const base = '/private/tmp/ml-dsa-quiet-producer-20261030';
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const setup = JSON.parse(await readFile(base + '/cloud-driver/setup-complete/traces.json', 'utf8'));
const publications = { a: new Set(), b: new Set() };
for (const record of setup.records) {
  for (const stage of record.preparation_stages) {
    if (stage.stage === 'published') publications[stage.role].add(stage.batch);
  }
}
const normal = new Set([...publications.a].filter(inSet.bind(null, publications.b)));
const report = { startedAtMs: Date.now(), classification: [], retirements: [], passed: false };

function hex(value) {
  return Buffer.from(value).toString('hex');
}

async function call(role, body) {
  const response = await fetch('https://' + scope.prefix + '-' + role + '.n6378056.workers.dev/router-ab/ml-dsa/role', {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token },
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  return response.json();
}

const original = JSON.parse(await readFile(base + '/ordinary-before-normalization-initial-stock.json', 'utf8'));
for (let index = 0; index < original.final.length; index += 1) {
  const stock = original.final[index];
  const registration = JSON.parse(await readFile(base + '/registration-' + (index + 1) + '.json', 'utf8'));
  const latest = registration.cases.at(-1);
  assert.deepEqual(latest.key, stock.key);
  const initial = new Set();
  for (let ordinal = 0; ordinal < latest.initialSigningBatches; ordinal += 1) {
    initial.add(createHash('sha256').update('seams/ml-dsa/registration-signing-stock/v1')
      .update(JSON.stringify([Array.from(Buffer.from(latest.initialSigningPreparationId, 'hex')), ordinal])).digest('hex'));
  }
  const registrationIds = [];
  const normalIds = [];
  for (const batch of stock.paired) {
    assert.ok(initial.has(batch) || normal.has(batch), 'Unknown Ready material origin; capture complete tails before normalization');
    assert.ok(!(initial.has(batch) && normal.has(batch)), 'Material has conflicting origin proofs');
    if (initial.has(batch)) registrationIds.push(batch);
    else normalIds.push(batch);
  }
  report.classification.push({ key: stock.key, registrationIds, normalIds,
    registrationPreparationId: latest.initialSigningPreparationId });
}
for (const stock of original.final) {
  const origin = report.classification.find(sameKey.bind(null, stock.key));
  const registration = new Set(origin.registrationIds);
  for (const role of ['a', 'b']) {
    const inventory = await call(role, { command: 'inventory', key: stock.key, target: 16, ready_until_ms: Date.now() + 30000 });
    assert.equal(inventory.reserved.length, 0);
    const batches = [];
    for (const value of inventory.ready) if (registration.has(hex(value))) batches.push(value);
    let result = null;
    if (batches.length) result = await call(role, { command: 'retire_unpaired', key: stock.key, batches });
    report.retirements.push({ key: stock.key, role, batches, result });
  }
  await call('a', { command: 'wake_refill', key: stock.key });
}
report.passed = true;
report.endedAtMs = Date.now();
await writeFile(base + '/registration-stock-retirement.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, roleRetirements: report.retirements.map(count) }));

function inSet(set, value) { return set.has(value); }
function sameKey(key, value) { return JSON.stringify(key) === JSON.stringify(value.key); }

function count(value) {
  return value.batches.length;
}
