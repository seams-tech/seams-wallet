import Core from './probe-build/deriver-a/worker/shim.mjs';

let moduleId;

function identity() {
  if (moduleId === undefined) moduleId = crypto.randomUUID();
  return moduleId;
}

function instance() {
  const value = globalThis.__worker_init_state?.instanceId;
  if (!Number.isSafeInteger(value) || value < 0) throw new Error('Missing core instance epoch');
  return value;
}

export function configuredSecret(env) {
  if (env.ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING !== 'INTERNAL_AUTH') return null;
  if (typeof env.INTERNAL_AUTH !== 'string' || env.INTERNAL_AUTH.trim().length === 0) return null;
  return env.INTERNAL_AUTH;
}

export function protocolTag(actor, stage) {
  console.log(JSON.stringify({ event: 'ml_dsa_public_probe_protocol_v1',
    js_module: identity(), core_epoch: instance(), actor, stage, at_ms: Date.now() }));
}

export function calibrate(text, actor, requestId) {
  let input;
  try {
    input = JSON.parse(text);
  } catch {
    return new Response('Invalid calibration JSON', { status: 400 });
  }
  if (input === null || typeof input !== 'object' || Array.isArray(input) ||
      Object.keys(input).length !== 2 || ![0, 1, 2].includes(input.kind) ||
      ![1, 17, 65537].includes(input.seed)) {
    return new Response('Invalid public calibration input', { status: 400 });
  }
  let result;
  try {
    result = JSON.parse(Core.prototype.ml_dsa_public_calibration(input.kind, input.seed));
  } catch (error) {
    if (String(error).includes('Preparation is active')) {
      return new Response('Preparation is active', { status: 409 });
    }
    throw error;
  }
  const record = { event: 'ml_dsa_public_probe_v1', js_module: identity(), core_epoch: instance(),
    actor, request_id: requestId, at_ms: Date.now(), ...result };
  console.log(JSON.stringify(record));
  return Response.json(record);
}
