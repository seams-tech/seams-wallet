import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    SOURCE.mkdir(exist_ok=False)
    files = subprocess.check_output(
        ['git', 'ls-files', '-z', '--', 'crates', 'tools', 'wasm', '.cargo'],
        cwd=ROOT,
    ).decode().split('\0')
    copied = []
    for name in files:
        if not name:
            continue
        original = ROOT / name
        destination = SOURCE / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, destination)
        copied.append({'path': name, 'sha256': digest(original)})

    generated = ROOT / 'crates/ed25519-yao-cloudflare-bench/src/ml_dsa_schedules'
    for original in generated.glob('*.bin'):
        name = original.relative_to(ROOT)
        destination = SOURCE / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, destination)
        copied.append({'path': str(name), 'sha256': digest(original), 'generated_schedule': True})

    silent = SOURCE / 'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent.rs'
    silent.write_text(silent.read_text() + '\n' + (BASE / 'public-calibration.rs').read_text())

    preparation = SOURCE / 'crates/router-ab-cloudflare/src/ml_dsa/workers/preparation.rs'
    preparation.write_text(preparation.read_text() + '\n' + (BASE / 'calibration-export.rs').read_text())
    patches = []
    for path in [silent, preparation]:
        patch = subprocess.run(
            ['git', 'diff', '--no-index', '--', str(ROOT / path.relative_to(SOURCE)), str(path)],
            capture_output=True, text=True,
        )
        if patch.returncode not in [0, 1]:
            raise RuntimeError(patch.stderr)
        patches.append(patch.stdout)
    (BASE / 'instrumentation.patch').write_text(''.join(patches))
    record = {
        'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'tracked_source_untouched': True,
        'copied': copied,
        'patched': [
            {'path': str(path.relative_to(SOURCE)), 'sha256': digest(path)}
            for path in [silent, preparation]
        ],
    }
    (BASE / 'source.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'files': len(copied), 'source': str(SOURCE), 'revision': record['revision']}))


if __name__ == '__main__':
    main()
