import hashlib
import json
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent


def run(command):
    result = subprocess.run(command, cwd=BASE, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout


def main():
    manifest = json.loads((BASE / 'manifest.json').read_text())
    for entry in manifest['files']:
        data = (BASE / entry['path']).read_bytes()
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
    expected = {name: json.loads((BASE / name).read_text()) for name in
                ['closure.json', 'ordinary-analysis.json', 'diagnostic-analysis.json']}
    run(['python3', str(BASE / 'close-campaign.py')])
    run(['python3', str(BASE / 'analyze-ordinary.py')])
    run(['python3', str(BASE / 'analyze-diagnostic.py')])
    for name, value in expected.items():
        assert json.loads((BASE / name).read_text()) == value, name
    verified = json.loads(run(['node', str(BASE / 'verify-hosted-signatures.mjs')]))
    assert verified['signatures'] == verified['alteredMessagesRejected'] == 12
    assert expected['closure.json']['post_setup_jobs'] == 31
    assert expected['diagnostic-analysis.json']['eligible_samples'] == 36
    print(json.dumps({'passed': True, 'member_hashes': len(manifest['files']),
                      'selected_jobs': 24, 'post_setup_jobs': 31, 'public_probes': 36,
                      'signatures': 12, 'altered_messages_rejected': 12,
                      'ledger': expected['closure.json']['ledger_pairs'],
                      'scope': 'Offline evidence replay. No external calls or credentials required.'}))


if __name__ == '__main__':
    main()
