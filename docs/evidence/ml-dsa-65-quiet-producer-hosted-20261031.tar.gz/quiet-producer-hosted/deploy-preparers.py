import argparse
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['ordinary', 'diagnostic'])
    parser.add_argument('label')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch('[a-z0-9-]{1,60}', args.label)
    folder = BASE / 'preparer-deployments' / args.label
    folder.mkdir(parents=True, exist_ok=False)
    scope = json.loads((BASE / 'scope.json').read_text())
    receipts = []
    for row in scope['workers']:
        role = row['role']
        if not role.startswith('preparer-'):
            continue
        config = json.loads((BASE / (role + '.json')).read_text())
        participant = 'a' if role.startswith('preparer-a') else 'b'
        if args.kind == 'diagnostic':
            config['main'] = str(BASE / ('preparer-' + participant + '-entry.mjs'))
        path = folder / (role + '.json')
        path.write_text(json.dumps(config, indent=2) + '\n')
        command = [str(ROOT / 'node_modules/.bin/wrangler'), 'deploy', '--config', str(path)]
        if args.dry_run:
            command.extend(['--dry-run', '--outdir', str(folder / role)])
        started = round(time.time() * 1000)
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        (folder / (role + '.log')).write_text(result.stdout + result.stderr)
        matched = re.search(r'Current Version ID: ([0-9a-f-]{36})', result.stdout)
        record = {'role': role, 'worker': row['name'], 'kind': args.kind, 'dry_run': args.dry_run,
                  'exit_code': result.returncode, 'version': matched.group(1) if matched else None,
                  'started_at_ms': started, 'ended_at_ms': round(time.time() * 1000),
                  'config_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        receipts.append(record)
        (folder / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if result.returncode or (not args.dry_run and not matched):
            raise SystemExit('Preparer deployment failed; inspect retained log')


if __name__ == '__main__':
    main()
