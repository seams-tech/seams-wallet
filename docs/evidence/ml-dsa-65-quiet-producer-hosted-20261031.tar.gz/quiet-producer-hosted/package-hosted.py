import hashlib
import json
import shutil
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
STAGE = BASE / 'hosted-evidence' / 'quiet-producer-hosted'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    for name in ['verify-hosted-signatures.mjs', 'replay-hosted.py', 'hosted-independent-review.md',
                 'stage-hosted.py', 'package-hosted.py', 'cleanup-scope.md',
                 'cleanup-preflight/verified-current-versions.json']:
        destination = STAGE / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(BASE / name, destination)
    cleanup = BASE / 'cleanup/absence.json'
    status = 'pending_explicit_worker_deletion_approval'
    if cleanup.exists():
        absence = json.loads(cleanup.read_text())
        assert len(absence) == 8 and all(row['confirmed_absent'] for row in absence)
        for name in ['cleanup/deletions.json', 'cleanup/absence.json']:
            destination = STAGE / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(BASE / name, destination)
        status = 'all_eight_workers_deleted_and_independently_absent'
    privacy = []
    for path in BASE.glob('*-secrets.json'):
        privacy.extend(value.encode() for value in json.loads(path.read_text()).values())
    for path in (BASE / 'hosted-keys').glob('*-kek'):
        privacy.append(path.read_text().strip().encode())
    files = []
    for path in sorted(STAGE.rglob('*')):
        if not path.is_file() or path.name == 'manifest.json':
            continue
        data = path.read_bytes()
        assert not any(value and value in data for value in privacy), 'Private credential in ' + str(path)
        files.append({'path': str(path.relative_to(STAGE)), 'bytes': len(data), 'sha256': sha(data)})
    manifest = {'schema': 'ml-dsa-quiet-producer-hosted-v1', 'files': files,
                'private_credential_matches': 0, 'cleanup': status}
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-quiet-producer-hosted-20261031.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as output:
        output.add(STAGE, arcname=STAGE.name)
    closure = json.loads((BASE / 'closure.json').read_text())
    ordinary = json.loads((BASE / 'ordinary-analysis.json').read_text())
    diagnostic = json.loads((BASE / 'diagnostic-analysis.json').read_text())
    summary = {'schema': 'ml-dsa-quiet-producer-hosted-summary-v1',
               'measurement_date': '2026-10-31 Asia/Tokyo', 'frozen_runtime_revision': json.loads((BASE / 'source.json').read_text())['revision'],
               'production_source_changed': False, 'retained_optimization': None,
               'ordinary_quiet_summary': ordinary['quiet_summary'], 'ordinary_ratios': ordinary['ratios'],
               'public_probe_summary': diagnostic['summary'], 'public_probes_eligible': diagnostic['eligible_samples'],
               'closure': closure, 'standard_signatures_verified': 12, 'altered_messages_rejected': 12,
               'cleanup': status, 'private_credential_matches': 0,
               'archive': {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'files': len(files) + 1},
               'replay': 'Extract the archive and run python3 quiet-producer-hosted/replay-hosted.py. Requires Node with ML-DSA verification and Python3; no credentials or external calls.',
               'limits': ['No new sustained throughput or production latency guarantee.',
                          'Host and compiler causes remain unknown.',
                          'Bulk AES does not quantify production conversion batch costs.',
                          'Wasm allocation excludes JavaScript heap and native memory.',
                          'Setup and normalization work remain outside selected producer timing samples.']}
    (BASE / 'ml-dsa-65-quiet-producer-hosted-20261031.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'files': len(files) + 1,
                      'cleanup': status, 'private_credential_matches': 0}))


if __name__ == '__main__':
    main()
