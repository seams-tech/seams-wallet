# ML-DSA quiet producer controls

Preserve the Workers backend, participant trust boundaries, canonical wallet-derived FIPS seed, two-at-once consumption, and the thirty-two-candidate pool.
This campaign measures preparation. It does not claim public SDK latency or a production capacity ceiling.

## Ordinary code first

Use the same eight temporary scripts, collection settings, compatibility date, policy, and binaries throughout each build phase.
Create four synthetic wallets in two stable service groups. Confirm canonical creation and wallet-seed recovery for each wallet.
Record all setup failures. Keep all wallets outside their expiry-maintenance window during each selected block.
Require full identical sixteen-pair reserves at both participants and zero pending jobs before a block.

Measure the two primary producer pairs before exposing either to calibration.
Deleted prior Workers do not preserve hardware or runtime conditions. Reconfirm which actor is slower in this new fleet.

Use the order: group zero alone, group one alone, both together, group one alone, group zero alone.
This block has six real four-candidate jobs. Reverse the order for one repeat, for twelve jobs total.
Alternate the wallet used within each group on the repeat. Keep actor identities stable.
Do not redeploy until both ordinary blocks complete and all complete tails are captured.

Each selected job retires exactly two unused pairs and publishes two fresh pairs.
Read only the front's trace archive while preparation runs. Require complete A/B publication and terminal settlement before the final inventory read.
Preserve every old ID except the two explicit retirements. Check the exact two new IDs, zero reservations, and zero pending jobs.
Retirement experiments replace unused stock. They do not measure signatures per minute.

## Gate the diagnostic phase

Stop if the quiet gap fails to reproduce. Do not add another broad warmup campaign to a disappearing signal.
Apply `qualify-block.py` to the final complete capture before using any CPU ratio.
It rejects version mismatches, exceptions, truncation, duplicate crypto starts, incomplete publication, transport mismatch, and overlapping unselected cryptographic work.
The live publication barrier does not qualify a timing sample.
Before retirement, verify that a two-wallet overlap block selects distinct authoritative service groups.
For this bounded screen, a persistent gap means at least a 1.5 ratio of qualified paired CPU medians across quiet jobs, with the same ordering in both blocks.
This threshold selects follow-up work. It is not a statistical confidence claim.
Keep failed jobs and unmatched instances in the record. A missing or failed ordinary control prevents attribution.

If the gap persists, deploy the diagnostic build to the same four preparer scripts.
Keep Router, participant storage, front, policy, credentials, and actor names fixed.
Run ordinary jobs before any probe in the diagnostic build. Code presence alone is an intervention.
Then run empty probes, ordinary jobs, public AES/encoder probes, and ordinary jobs.
Use all three fixed public seeds. Reverse actor and workload order between repetitions.
Do not overlap probes with private preparation. The actual core preparation mutex rejects a probe while private work holds it.
Use A's actual peer service binding for B probes. Retain probes that reach another B instance, and exclude them from attribution.

Finally restore the ordinary preparer build and repeat the quiet control without probes.
This return control is separate from ordinary jobs inside the diagnostic build.
Allow at most forty real four-candidate jobs after setup in this campaign.

## Instruments and eligibility

The diagnostic source exists in an isolated copy. Production Rust source is unchanged.
The bulk public AES workload calls the existing correlation AES adapter on 262,144 public blocks.
Production conversion repeatedly calls this adapter on sixteen-block A batches and eight-block B batches.
The bulk probe does not establish private conversion cost. A path-specific conclusion requires matching those batch sizes first.
The encoder uses the production full-chunk dimensions: 1,048,576 public blocks and a 524,288-symbol message.
The probe accepts only workload IDs zero through two and seeds 1, 17, and 65,537.
It accepts no key, mask, correlation, wallet, or private input.

Native output checks cover all nine workload/seed combinations.
Node/OpenSSL independently checks the AES checksum and records the reference ciphertext hash.
Wasm returns a thirty-two-bit checksum. This is checksum agreement, not a comparison of every Wasm output byte.
Native encoder agreement checks cross-runtime consistency against the same pinned encoder. It is not an independent encoder proof.

Retain role, actor, JS module UUID, core epoch, Rust module UUID, request identity, build hash, and exact public output for each probe.
Match B retrospectively to the actual complete production invocation. Shared routing alone cannot establish a match.
Preserve whole invocations, outcomes, exceptions, deferrals, transport counters, public-cache state, publication IDs, and settlement.
Record A CPU and B CPU separately. Derive paired CPU per published candidate only from complete matching jobs.
Cloudflare invocation CPU does not isolate kernel CPU. Public probes include their fixed setup and checksum work.
Wasm allocation excludes JS heap and native memory. Do not report it as complete isolate peak memory.

## Interpretation

- Quiet gaps before probes contradict overlap as the sole cause.
- Gaps only during overlap identify a concurrency condition for the next profile.
- Matching gaps in both public workloads support a broader runtime condition, without identifying the physical host or compiler tier.
- A gap only in one workload supports a focused profile of that path.
- Changed jobs after probes make calibration an intervention. Preserve both return controls.
- Matching probes with different real-job CPU require a lower-level production profile or an accounting review.

Do not change cryptographic kernels, domains, protocol bytes, expiry, pool size, or production budgets during this diagnosis.
Keep one shared service group as the production default.
More active and idle wallets remain a separate scaling qualification after this bounded control.
Delete all temporary Workers and private test credentials after collecting replayable evidence.
