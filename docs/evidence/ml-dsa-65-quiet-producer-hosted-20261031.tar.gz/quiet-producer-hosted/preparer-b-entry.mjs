import * as core from './probe-build/deriver-b/worker/shim.mjs';
import { calibrate, configuredSecret, protocolTag } from './calibration-b.mjs';
export * from './probe-build/deriver-b/worker/shim.mjs';

export default class CalibratedParticipant extends core.default {
  async fetch(request) {
    if (new URL(request.url).pathname !== '/__benchmark/calibration') {
      protocolTag('fetch', 'fetch_entered');
      const response = await super.fetch(request);
      protocolTag('fetch', 'fetch_returned');
      return response;
    }
    const secret = configuredSecret(this.env);
    if (secret === null) return new Response('Auth is not configured', { status: 503 });
    if (request.headers.get('x-router-ab-internal-service-auth') !== secret) {
      return new Response('Unauthorized', { status: 403 });
    }
    if (request.method !== 'POST') return new Response('POST required', { status: 405 });
    const text = await request.text();
    if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
    return calibrate(text, 'fetch', request.headers.get('x-ml-dsa-request-id'));
  }
}
