import json
import statistics
from pathlib import Path

BASE = Path(__file__).resolve().parent


def events(row):
    return [json.loads(message) for log in row.get('logs', []) for message in log.get('message', [])]


def private_identity(rows, label, role):
    directory = BASE / 'blocks' / label
    result = json.loads((directory / 'result.json').read_text())
    qualified = json.loads((directory / 'timing-qualification.json').read_text())
    assert result['passed'] and qualified['timing_qualified'] and qualified['quiet_eligible']
    job = qualified['jobs'][0]
    group = result['placements'][result['selected'][0]]['group']
    matching = []
    for row in rows:
        if row['scriptName'] != job[role]['worker']:
            continue
        log = events(row)
        own = [event for event in log if event.get('event') == 'ml_dsa_preparation_stage_v1'
               and event.get('job') == job['job'] and event.get('role') == role and event['stage'] == 'crypto_started']
        if not own:
            continue
        tags = [event for event in log if event.get('event') == 'ml_dsa_public_probe_protocol_v1'
                and event.get('stage') in ['alarm_returned', 'fetch_returned']]
        assert len(tags) == 1
        matching.append({'group': group, 'worker': row['scriptName'], 'version': row['scriptVersion']['id'],
                         'module_instance': own[0]['module_instance'],
                         'js_module': tags[0]['js_module'], 'core_epoch': tags[0]['core_epoch'],
                         'actor': tags[0]['actor'], 'job': job['job']})
    assert len(matching) == 1
    return matching[0]


def same_instance(probe, identity):
    return (probe['worker'] == identity['worker'] and probe['version'] == identity['version']
            and probe['module_instance'] == identity['module_instance']
            and probe['js_module'] == identity['js_module'] and probe['core_epoch'] == identity['core_epoch']
            and probe['actor'] == identity['actor'])


def main():
    rows = json.loads((BASE / 'diagnostic-final-producer-traces.json').read_text())
    identities = {}
    for phase in ['unprobed', 'after-empty', 'after-heavy']:
        for group in [0, 1]:
            for role in ['a', 'b']:
                identities[(phase, group, role)] = private_identity(rows, f'diagnostic-{phase}-{group}', role)
    samples = []
    for mode in ['empty', 'heavy']:
        report = json.loads((BASE / f'calibrations/diagnostic-{mode}/results.json').read_text())
        assert report['passed']
        for sample in report['samples']:
            matching = []
            for row in rows:
                for event in events(row):
                    if event.get('event') != 'ml_dsa_public_probe_v1' or event.get('request_id') != sample['requestId']:
                        continue
                    assert row['outcome'] == 'ok' and row['truncated'] is False and row['exceptions'] == []
                    assert event == sample['result']
                    assert event['active_crypto'] == 0 and event['memory_bytes'] < 128 * 1024 * 1024
                    if event['kind'] > 0:
                        assert row['cpuTime'] > 0, 'Heavy public workload did not produce a nonzero CPU reading'
                    matching.append({'mode': mode, 'group': sample['group'], 'role': sample['role'],
                                     'kind': event['kind'], 'seed': event['seed'], 'request_id': event['request_id'],
                                     'checksum': event['checksum'], 'cpu_ms': row['cpuTime'], 'wall_ms': row['wallTime'],
                                     'worker': row['scriptName'], 'version': row['scriptVersion']['id'],
                                     'module_instance': event['module_instance'], 'js_module': event['js_module'],
                                     'core_epoch': event['core_epoch'], 'actor': event['actor']})
            assert len(matching) == 1
            probe = matching[0]
            before = 'unprobed' if mode == 'empty' else 'after-empty'
            after = 'after-empty' if mode == 'empty' else 'after-heavy'
            probe['matches_previous'] = same_instance(probe, identities[(before, sample['group'], sample['role'])])
            probe['matches_next'] = same_instance(probe, identities[(after, sample['group'], sample['role'])])
            probe['eligible'] = probe['matches_previous'] and probe['matches_next']
            samples.append(probe)
    table = []
    for kind in [0, 1, 2]:
        for group in [0, 1]:
            for role in ['a', 'b']:
                selected = [row for row in samples if row['kind'] == kind and row['group'] == group
                            and row['role'] == role and row['eligible']]
                table.append({'kind': kind, 'group': group, 'role': role, 'eligible': len(selected),
                              'cpu_ms_median': statistics.median(row['cpu_ms'] for row in selected) if selected else None})
    preparation = []
    for phase in ['unprobed', 'after-empty', 'after-heavy']:
        for group in [0, 1]:
            q = json.loads((BASE / f'blocks/diagnostic-{phase}-{group}/timing-qualification.json').read_text())
            job = q['jobs'][0]
            preparation.append({'phase': phase, 'group': group, 'paired_cpu_ms': job['paired_cpu_ms'],
                                'a_cpu_ms': job['a']['cpu_ms'], 'b_cpu_ms': job['b']['cpu_ms'],
                                'a_wall_ms': job['a']['wall_ms']})
    result = {'passed': True, 'samples': samples, 'summary': table, 'preparation': preparation,
              'eligible_samples': sum(row['eligible'] for row in samples), 'total_samples': len(samples),
              'limits': ['Software-instance matching does not identify a physical host or compiler tier.',
                         'Bulk AES batching differs from private conversion. No private kernel cost inference.',
                         'Public workload CPU includes setup, input filling, checksum, serialization, and authentication.',
                         'Production timings include complete invocations. They do not isolate kernel CPU.']}
    (BASE / 'diagnostic-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'eligible': result['eligible_samples'], 'samples': len(samples),
                      'summary': table, 'preparation': preparation}))


if __name__ == '__main__':
    main()
