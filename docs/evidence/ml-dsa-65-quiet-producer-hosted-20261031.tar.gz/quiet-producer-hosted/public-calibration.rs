// Temporary public-input instrument. Never used with wallet secrets.
// These calls use the same AES adapter and encoder as production preparation.
pub fn public_preparation_calibration(kind: u32, seed: u32) -> u32 {
    match kind {
        0 => seed,
        1 => public_aes_calibration(seed),
        2 => public_encoder_calibration(seed),
        _ => unreachable!("validated public calibration kind"),
    }
}

fn public_calibration_word(state: &mut u32) -> u32 {
    *state ^= *state << 13;
    *state ^= *state >> 17;
    *state ^= *state << 5;
    *state
}

fn public_aes_calibration(seed: u32) -> u32 {
    let mut state = seed;
    let mut key = [0u8; 16];
    for word in key.chunks_exact_mut(4) {
        word.copy_from_slice(&public_calibration_word(&mut state).to_le_bytes());
    }
    let mut blocks = vec![[0u8; 16]; 262_144];
    for block in &mut blocks {
        for word in block.chunks_exact_mut(4) {
            word.copy_from_slice(&public_calibration_word(&mut state).to_le_bytes());
        }
    }
    let cipher = CorrelationAes::new(core::hint::black_box(&key));
    cipher.encrypt(core::hint::black_box(&mut blocks));
    let mut checksum = 0u32;
    for block in core::hint::black_box(&blocks) {
        for byte in block {
            checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(*byte));
        }
    }
    core::hint::black_box(checksum)
}

fn public_encoder_calibration(seed: u32) -> u32 {
    // Match one production silent-correlation chunk's full public dimensions.
    let mut state = seed;
    let mut blocks = vec![Block::ZERO; SPARSE_BLOCKS];
    for block in &mut blocks {
        let low = u64::from(public_calibration_word(&mut state))
            | (u64::from(public_calibration_word(&mut state)) << 32);
        let high = u64::from(public_calibration_word(&mut state))
            | (u64::from(public_calibration_word(&mut state)) << 32);
        *block = Block::from([low, high]);
    }
    ExConvCode::new(OT_COUNT).dual_encode(core::hint::black_box(&mut blocks));
    let mut checksum = 0u32;
    for block in core::hint::black_box(&blocks) {
        let bytes = u128::from(block).to_le_bytes();
        for byte in bytes {
            checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(byte));
        }
    }
    core::hint::black_box(checksum)
}
