import copy
import hashlib
import json
import os
import secrets
import subprocess
from pathlib import Path

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
PREVIOUS = Path('/private/tmp/ml-dsa-service-groups-20261030/hosted')


def main():
    os.umask(0o077)
    assert not (BASE / 'hosted-scope.json').exists()
    prefix = 'ml-dsa-quiet-1030-' + secrets.token_hex(3)
    internal = secrets.token_hex(32)
    gateway = secrets.token_hex(32)
    subprocess.run([
        str(ROOT / 'tools/ml-dsa-investigation/target/release/ml-dsa-investigation'),
        'worker-registration-keys', str(BASE / 'hosted-keys'),
    ], check=True, stdout=subprocess.DEVNULL)
    (BASE / 'gateway-token').write_text(gateway + '\n')
    previous = json.loads((PREVIOUS / 'scope.json').read_text())
    policy = copy.deepcopy(previous['policy'])
    policy['service_groups'] = 2
    roles = [row['role'] for row in previous['workers']]
    workers = []
    for role in roles:
        text = (PREVIOUS / (role + '.json')).read_text()
        text = text.replace(previous['prefix'], prefix).replace(str(PREVIOUS), str(BASE))
        config = json.loads(text)
        config['vars']['ML_DSA_ADMISSION_POLICY'] = json.dumps(policy, separators=(',', ':'))
        if role == 'front':
            config['vars']['TEST_WORKER_PREFIX'] = prefix
        payload = {'INTERNAL_AUTH': internal}
        if role in ['front', 'router']:
            payload['ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET'] = gateway
        else:
            participant = 'a' if role == 'a' or role.startswith('preparer-a') else 'b'
            payload['ROLE_KEK'] = (BASE / 'hosted-keys' / (participant + '-kek')).read_text().strip()
        path = BASE / (role + '.json')
        path.write_text(json.dumps(config, indent=2) + '\n')
        bootstrap = copy.deepcopy(config)
        bootstrap.pop('services', None)
        bootstrap.pop('tail_consumers', None)
        bootstrap['durable_objects']['bindings'] = [
            row for row in bootstrap['durable_objects']['bindings'] if 'script_name' not in row
        ]
        (BASE / (role + '-bootstrap.json')).write_text(json.dumps(bootstrap, indent=2) + '\n')
        encoded = (json.dumps(payload, indent=2) + '\n').encode()
        (BASE / (role + '-secrets.json')).write_bytes(encoded)
        workers.append({'role': role, 'name': config['name'], 'secret_bindings': list(payload),
                        'payload_sha256': hashlib.sha256(encoded).hexdigest()})
    scope = {'prefix': prefix, 'router_url': 'https://' + prefix + '-front.n6378056.workers.dev',
             'policy': policy, 'workers': workers,
             'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
             'purpose': 'Quiet/overlap/quiet producer controls before probing. If the CPU gap persists, deploy same-module fixed-public-input calibration and restore the production build as a return control. Four synthetic wallets in two stable service groups. No production wallets or resources.'}
    for name in ['scope.json', 'hosted-scope.json']:
        (BASE / name).write_text(json.dumps(scope, indent=2) + '\n')
    lines = ['# ML-DSA quiet producer control: exact upload scope', '', scope['purpose'], '',
             'Create eight temporary Workers and upload only these exact fresh benchmark credentials.',
             'A receives only its separate role key. B receives only its separate role key.',
             'Front and Router receive benchmark access tokens only. No production wallet or account credentials.', '',
             '| Worker | Secret bindings | Payload SHA-256 |', '| --- | --- | --- |']
    for row in workers:
        lines.append('| ' + row['name'] + ' | ' + ', '.join(row['secret_bindings']) + ' | ' + row['payload_sha256'] + ' |')
    lines += ['', 'Preparation remains on Workers. Each wallet retains thirty-two candidates and consumes two at a time.',
              'The test uses two preparation slots per group and a five-second benchmark cooldown. Production defaults stay unchanged.',
              'Only preparer code changes between ordinary, diagnostic, and ordinary-return blocks. Keep collection settings fixed.',
              'Stop the calibration campaign if quiet ordinary runs do not reproduce the gap.',
              'Retain failed and unmatched work. Record exact A/B publications and full reserve restoration.',
              'Delete all eight Workers and private test credentials after collection. No D1 databases or R2 buckets are created.', '',
              'See measurement-plan.md for ordered phases, sample limits, matching rules, and stopping rules.']
    (BASE / 'hosted-upload-scope.md').write_text('\n'.join(lines) + '\n')
    fleet = (PREVIOUS / 'fleet.py').read_text().replace('ml-dsa-groups-1030-', 'ml-dsa-quiet-1030-')
    (BASE / 'fleet.py').write_text(fleet)
    cleanup = (PREVIOUS / 'cleanup.py').read_text().replace(str(PREVIOUS), str(BASE))
    cleanup = cleanup.replace("assert scope['prefix'] == 'ml-dsa-groups-1030-3cd638'", "assert scope['prefix'].startswith('ml-dsa-quiet-1030-')")
    (BASE / 'cleanup.py').write_text(cleanup)
    print(json.dumps({'scope': str(BASE / 'hosted-upload-scope.md'), 'workers': len(workers), 'prefix': prefix}))


if __name__ == '__main__':
    main()
