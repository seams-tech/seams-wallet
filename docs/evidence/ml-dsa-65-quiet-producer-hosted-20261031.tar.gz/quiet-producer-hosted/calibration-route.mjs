async function calibrationRoute(request, env) {
  if (typeof env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET !== 'string' ||
      env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET.trim().length === 0) {
    return new Response('Auth is not configured', { status: 503 });
  }
  if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) {
    return new Response('Unauthorized', { status: 401 });
  }
  const parts = new URL(request.url).pathname.split('/');
  if (request.method !== 'POST' || parts.length !== 6 || !['0', '1'].includes(parts[3]) ||
      !['primary', 'secondary'].includes(parts[4]) || !['a', 'b'].includes(parts[5])) {
    return new Response('Invalid calibration route', { status: 400 });
  }
  const text = await request.text();
  if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
  const namespace = parts[4] === 'primary' ? env.TEST_PRODUCER : env.TEST_SECONDARY_PRODUCER;
  const name = 'ml-dsa-producer-v1' + (parts[3] === '0' ? '' : '-group-1');
  const path = '/__benchmark/calibration' + (parts[5] === 'a' ? '' : '-peer');
  return namespace.get(namespace.idFromName(name)).fetch(new Request('https://probe' + path, {
    method: 'POST', headers: { 'content-type': 'application/json',
      'x-router-ab-internal-service-auth': env.INTERNAL_AUTH,
      'x-ml-dsa-request-id': request.headers.get('x-ml-dsa-request-id') ?? '' }, body: text,
  }));
}
