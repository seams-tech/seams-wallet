# Independent hosted review

The reviewer independently checked raw provider records, source boundaries, software identities, public outputs, material ledgers, signatures, and closure.
The review found no evidence blocker to test-fleet cleanup.

## Controls and gate

The setup medians reproduce: group-zero primary 7,413.5 ms, group-one primary 8,061.5 ms,
group-zero secondary 16,136 ms, and group-one secondary 7,025.5 ms of paired CPU for four candidates.
The setup-informed secondary-versus-secondary amendment was frozen before timed work.
Both groups use the same authoritative unqueued-primary-holder fixture.
Holder IDs never reach participant or producer execution. All holder wallets retain their exact material IDs.

Twelve specific canceled alarm records report zero CPU, empty logs/exceptions, expected versions, and no truncation.
They contain no evidence of entering the instrumented Rust alarm body.
Every real A crypto invocation contains the unconditional entry marker. The deployed collector includes that marker.
The cancellation cause remains unknown. Zero CPU can conceal sub-resolution work.
Those records cannot numerically create the several-second processing gap.
The original strict rejection remains retained. The narrow classification excludes cancellations with CPU, logs, exceptions, truncation, or mismatched versions.

Quiet paired CPU medians reproduce 15,741.5 versus 7,336 ms, then 16,495.5 versus 7,037 ms in reversed order.
The unchanged 1.5 threshold therefore admits diagnostics.
Actual reported lifetimes overlap in both concurrent-dispatch blocks. This does not establish physical CPU parallelism.

## Matched diagnostics

All thirty-six public probes match both bracketing jobs by Worker/version, actor, JS UUID, core epoch, and Rust UUID.
Chronological bracketing holds. Public checksums match their references, heavy CPU is nonzero, and active private cryptography is zero.
No probe overlaps captured private cryptography or its complete invocation envelope.

Bulk AES CPU medians are 23/25 ms on the slower A/B instances and 15/17 ms on the faster instances.
Full encoder medians are 226/212 ms and 97/87 ms.
The public probe invocations total 2,162 ms CPU. Forwarding/front costs require separate accounting.

Each diagnostic preparation state contains one job per actor. Those are observations rather than stable medians.
Both unprobed jobs miss the public schedule cache. Later jobs hit it.
Unprobed-to-post-probe changes therefore combine cache warming and probe intervention.
No warmup benefit is established.
Bulk AES cannot quantify the production conversion path's repeated eight/sixteen-block batches, copying, extraction, and erasure.

## Final closure

Twenty-four selected jobs and forty-eight participant invocations match exact roles, actors, versions, publications, and holder releases.
They retire forty-eight pairs and publish forty-eight fresh pairs.
All thirty-one post-setup jobs remain below the forty-job cap.
The full pair ledger is 64 initial + 59 fresh = 48 experiment retirements + 11 signing consumption + 64 final.
Paired preparation CPU is 330,568 ms across sixty-two participant invocations.
Ordinary, diagnostic, return, and final-refill totals are 138,277, 70,084, 73,093, and 49,114 ms.

Eight setup signatures and four final signatures verify independently. Twelve altered messages fail verification.
Final requests take 3,497, 2,327, 1,766, and 1,135 ms, one request each.
All final pairs have both publication records. Each wallet retains sixteen pairs, zero reservations, and zero pending jobs.

Return paired CPU medians are 16,281.5 and 8,551 ms. A whole-invocation wall medians are 17,504 and 9,582 ms.
Each return median includes two jobs, combining a cache miss and a cache hit. These are not steady-state percentiles.
No additional captured refill cryptographic failure or missing participant tail was found.
Setup exceptions and decoder failure remain separate records.

The evidence establishes execution-cost variation across matched instances and multiple public workloads.
It establishes no speedup, throughput gain, host cause, or compiler-tier cause.
