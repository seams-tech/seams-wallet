import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const base = import.meta.dirname;
let signatures = 0;

function check(publicKeyHex, messageHex, signatureHex) {
  const key = createPublicKey({ key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
    Buffer.from(publicKeyHex, 'hex'),
  ]), format: 'der', type: 'spki' });
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  assert.equal(verify(null, message, key, signature), true);
  assert.equal(verify(null, Buffer.concat([message, Buffer.from([1])]), key, signature), false);
  signatures += 1;
}

for (let index = 1; index <= 4; index += 1) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.registrationChecksPassed, true);
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  assert.equal(registration.cases.length, 2);
  assert.equal(registration.cases[0].publicKeyHex, registration.cases[1].publicKeyHex);
  for (const sample of registration.cases) {
    assert.equal(sample.canonicalKeyVerified, true);
    assert.equal(sample.initialStockSign.contextHex, '');
    check(sample.publicKeyHex, sample.initialStockSign.messageHex, sample.initialStockSign.signatureHex);
  }
}
const final = JSON.parse(await readFile(base + '/final-signatures.json', 'utf8'));
assert.equal(final.passed, true);
for (const sample of final.cases) check(sample.publicKeyHex, sample.messageHex, sample.signatureHex);
assert.equal(signatures, 12);
console.log(JSON.stringify({ passed: true, signatures, alteredMessagesRejected: signatures,
  canonicalCreationAndRecoveryCases: 8 }));
