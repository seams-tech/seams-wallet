import json
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BLOCKS = [('return-0-first', [0]), ('return-1-first', [1]), ('return-overlap', [0, 1]),
          ('return-1-last', [1]), ('return-0-last', [0])]


def run(label, command):
    with (BASE / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    print(json.dumps({'stage': label, 'exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit('Preserved return-control failure: ' + label)


def main():
    original = json.loads((BASE / 'deployments.json').read_text())
    changed = json.loads((BASE / 'preparer-deployments/ordinary-return/receipts.json').read_text())
    assert len(changed) == 4 and all(row['version'] and row['exit_code'] == 0 for row in changed)
    by_role = {row['role']: row for row in changed}
    versions = [by_role.get(row['role'], row) for row in original]
    (BASE / 'return-versions.json').write_text(json.dumps(versions, indent=2) + '\n')
    (BASE / 'return-order.json').write_text(json.dumps(BLOCKS, indent=2) + '\n')
    for label, wallets in BLOCKS:
        run(label, ['node', str(BASE / 'quiet-block.mjs'), label, *map(str, wallets)])
    run('return-final-capture', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(BASE), 'return-final'])
    rows = []
    for role in ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
        for line in (BASE / f'cloud-driver/return-final/{role}-raw.jsonl').read_text().splitlines():
            rows.append(json.loads(line))
    raw = BASE / 'return-final-producer-traces.json'
    raw.write_text(json.dumps(rows) + '\n')
    for label, _ in BLOCKS:
        run(label + '-qualification', ['python3', str(BASE / 'qualify-block.py'), str(BASE / 'blocks' / label),
                                       str(BASE / 'return-versions.json'), str(raw)])


if __name__ == '__main__':
    main()
