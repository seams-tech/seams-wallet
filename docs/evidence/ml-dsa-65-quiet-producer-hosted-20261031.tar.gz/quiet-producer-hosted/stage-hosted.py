import hashlib
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parent
STAGE = BASE / 'hosted-evidence' / 'quiet-producer-hosted'


def main():
    STAGE.mkdir(parents=True, exist_ok=True)
    names = [
        'scope.json', 'hosted-scope.json', 'hosted-upload-scope.md', 'measurement-plan.md',
        'source.json', 'instrumentation.patch', 'public-calibration.rs', 'calibration-export.rs',
        'calibration.mjs', 'calibration-a.mjs', 'calibration-b.mjs', 'calibration-route.mjs',
        'preparer-a-entry.mjs', 'preparer-b-entry.mjs', 'front.mjs', 'load-worker.mjs',
        'local-calibration.json', 'native-reference.txt',
        'prepare-source.py', 'prepare-hosted.py', 'deploy-preparers.py', 'fleet.py', 'register.py', 'cleanup.py',
        'quiet-block.mjs', 'qualify-block.py', 'analyze-ordinary.py', 'analyze-diagnostic.py',
        'calibrate-hosted.mjs', 'run-ordinary.py', 'run-diagnostic.py', 'run-return.py',
        'initial-stock.mjs', 'snapshot-stock.mjs', 'replace-registration-stock.mjs', 'sign-final.mjs',
        'actor-selection.json', 'actor-selection-first-proposal.json', 'setup-actors.json',
        'ordinary-order.json', 'diagnostic-order.json', 'return-order.json',
        'deployments.json', 'diagnostic-versions.json', 'return-versions.json',
        'ordinary-analysis.json', 'diagnostic-analysis.json', 'canceled-alarm-classification.json',
        'ordinary-final-producer-traces.json', 'diagnostic-final-producer-traces.json',
        'return-final-producer-traces.json', 'closure.json', 'close-campaign.py',
        'setup-stock-normalization-first.json', 'setup-stock-normalization-complete.json',
        'registration-stock-retirement.json', 'ordinary-before-normalization-initial-stock.json',
        'ordinary-initial-stock.json', 'ordinary-actors.json', 'final-initial-stock.json', 'final-actors.json',
        'final-signatures.json', 'ordinary-initial-stock.log', 'final-capture.log',
        'cloud-driver/final-complete-decoder-first/collection.log',
        'cloud-driver/setup-complete-first/traces.json', 'cloud-driver/setup-complete/traces.json',
        'cloud-driver/setup-progress-2/traces.json',
    ]
    for index in range(1, 5):
        names.append(f'registration-{index}.json')
    for label in ['bootstrap', 'credentials', 'ordinary-first']:
        names.append(label + '/receipts.json')
    for label in ['diagnostic-first', 'ordinary-return']:
        names.append('preparer-deployments/' + label + '/receipts.json')
    names.extend(str(path.relative_to(BASE)) for path in (BASE / 'ordinary-strict-qualification').glob('*'))
    for directory in (BASE / 'blocks').iterdir():
        names.extend(str(path.relative_to(BASE)) for path in directory.glob('*.json') if path.name != 'producer-traces.json')
    names.extend(str(path.relative_to(BASE)) for path in (BASE / 'calibrations').glob('*/results.json'))
    for pattern in ['*-raw.jsonl', 'traces.json', 'collection.log']:
        names.extend(str(path.relative_to(BASE)) for path in (BASE / 'cloud-driver/final-complete').glob(pattern))
    names.extend(str(path.relative_to(BASE)) for path in (BASE / 'cloud-driver/final-complete-decoder-first').glob('*-raw.jsonl'))
    for row in json.loads((BASE / 'scope.json').read_text())['workers']:
        names.append(row['role'] + '.json')
    credentials = set()
    for path in BASE.glob('*-secrets.json'):
        credentials.update(value.encode() for value in json.loads(path.read_text()).values())
    for path in (BASE / 'hosted-keys').glob('*-kek'):
        credentials.add(path.read_text().strip().encode())
    copied = []
    for name in sorted(set(names)):
        source = BASE / name
        destination = STAGE / name
        data = source.read_bytes()
        assert not any(value and value in data for value in credentials), 'Private test credential in ' + name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    (STAGE / 'pre-cleanup-manifest.json').write_text(json.dumps({'files': copied, 'private_credential_matches': 0}, indent=2) + '\n')
    builds = []
    for profile in ['build', 'probe-build']:
        for role in ['deriver-a', 'deriver-b', 'router']:
            path = BASE / profile / role / 'index_bg.wasm'
            if path.exists():
                data = path.read_bytes()
                builds.append({'profile': profile, 'role': role, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    (STAGE / 'builds.json').write_text(json.dumps(builds, indent=2) + '\n')
    print(json.dumps({'stage': str(STAGE), 'files': len(copied), 'bytes': sum(row['bytes'] for row in copied),
                      'private_credential_matches': 0}))


if __name__ == '__main__':
    main()
