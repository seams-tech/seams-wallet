import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = import.meta.dirname;
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]{1,60}$/);
const selected = process.argv.slice(3).map(Number);
assert.ok(selected.length >= 1 && selected.length <= 2);
assert.equal(new Set(selected).size, selected.length);
assert.ok(selected.every(validWallet));
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const secrets = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8'));
const selection = JSON.parse(await readFile(base + '/actor-selection.json', 'utf8'));
const keys = [];
for (let index = 1; index <= 4; index += 1) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.registrationChecksPassed, true);
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  keys.push(registration.cases.at(-1).key);
}
const folder = base + '/blocks/' + label;
await mkdir(base + '/blocks', { recursive: true });
await mkdir(folder, { recursive: false });
const report = { label, selected, startedAtMs: Date.now(), initial: [], retired: [], jobs: [],
  queueReceipts: [], placements: [], heldLeases: [], actorSelection: selection,
  timingQualified: false, passed: false,
  scope: 'Functional publication barrier only. Qualify final complete traces before using CPU ratios.' };

function validWallet(index) { return Number.isInteger(index) && index >= 0 && index < 4; }
function hex(bytes) { return Buffer.from(bytes).toString('hex'); }
function headers(token) {
  return { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token };
}
async function call(path, body) {
  const response = await fetch(scope.router_url + path, { method: 'POST',
    headers: headers(secrets.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET),
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
  assert.equal(response.status, 200, path + ': ' + await response.clone().text());
  return response.json();
}
async function roleCall(role, body) {
  const url = new URL(scope.router_url);
  const suffix = url.hostname.slice((scope.prefix + '-front.').length);
  assert.ok(url.hostname.startsWith(scope.prefix + '-front.'));
  url.hostname = scope.prefix + '-' + role + '.' + suffix;
  url.pathname = '/router-ab/ml-dsa/role';
  const response = await fetch(url, { method: 'POST', headers: headers(secrets.INTERNAL_AUTH),
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
  assert.equal(response.status, 200, role + ': ' + await response.clone().text());
  return response.json();
}
async function inventory(key) {
  const input = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 600000 };
  const [a, b] = await Promise.all([roleCall('a', input), roleCall('b', input)]);
  const readyA = a.ready.map(hex).sort();
  const readyB = b.ready.map(hex).sort();
  assert.equal(readyA.length, 16);
  assert.equal(new Set(readyA).size, 16);
  assert.deepEqual(readyA, readyB);
  assert.equal(a.reserved.length + b.reserved.length, 0);
  const pending = await call('/__benchmark/refill/admission', { command: 'pending_refills', key });
  assert.equal(pending.length, 0);
  return { key, a, b, ready: readyA };
}
async function traces(role) {
  const rows = [];
  let cursor = null;
  do {
    const url = new URL(scope.router_url + '/__benchmark/traces/' + role);
    if (cursor !== null) url.searchParams.set('cursor', cursor);
    const response = await fetch(url, { headers: headers(secrets.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET),
      signal: AbortSignal.timeout(30000) });
    assert.equal(response.status, 200);
    const page = await response.json();
    rows.push(...page.rows);
    cursor = page.cursor;
  } while (cursor !== null);
  return rows;
}
function logEvents(row) {
  const result = [];
  for (const log of row.logs ?? []) for (const message of log.message ?? []) result.push(JSON.parse(message));
  return result;
}
function publicationId(job) {
  const hash = createHash('sha256').update('seams/ml-dsa/preparation-second-pair/v1').update(Buffer.from(job.batch));
  return [hex(job.batch), hash.digest('hex')].sort();
}
function completeJob(rows, job) {
  const expected = publicationId(job);
  const own = { a: new Set(), b: new Set() };
  let settled = false;
  for (const row of rows) {
    for (const event of logEvents(row)) {
      if (event.event === 'ml_dsa_preparation_stage_v1' && event.job === hex(job.batch) && event.stage === 'published') {
        assert.ok(event.role === 'a' || event.role === 'b');
        own[event.role].add(event.batch);
      }
      if (event.event === 'ml_dsa_refill_settled_v1' && event.batch === hex(job.batch)) {
        assert.equal(event.outcome, 'published');
        settled = true;
      }
    }
  }
  return settled && JSON.stringify([...own.a].sort()) === JSON.stringify(expected) &&
    JSON.stringify([...own.b].sort()) === JSON.stringify(expected);
}
async function queueJob(job) {
  const startedAtMs = Date.now();
  const response = await fetch(scope.router_url + '/__benchmark/refill/queue', {
    method: 'POST', headers: headers(secrets.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET),
    body: JSON.stringify(job), signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 202, await response.clone().text());
  assert.equal(await response.json(), true);
  return { batch: hex(job.batch), startedAtMs, acknowledgedAtMs: Date.now() };
}

try {
  for (const key of keys) report.placements.push(await call('/__benchmark/refill/placement', { wallet: key.wallet }));
  if (selected.length === 2) {
    assert.notEqual(report.placements[selected[0]].group, report.placements[selected[1]].group,
      'Concurrent control requires distinct service groups');
  }
  for (const key of keys) report.initial.push(await inventory(key));
  for (const index of selected) {
    const stock = report.initial[index];
    const group = report.placements[index].group;
    const actor = selection.groups.find(groupSelection.bind(null, group));
    if (actor.slot === 'secondary') {
      const heldIndex = report.placements.findIndex(otherGroupWallet.bind(null, group, index));
      assert.ok(heldIndex >= 0);
      const heldStock = report.initial[heldIndex];
      const held = await call('/__benchmark/refill/admission', { command: 'claim_refill',
        key: heldStock.key, occupied: heldStock.a.ready.slice(2) });
      assert.equal(held.status, 'acquired');
      assert.equal(held.job.producer_slot, 'primary');
      report.heldLeases.push({ wallet: heldIndex, job: held.job, state: 'held_unqueued' });
    }
    const batches = stock.a.ready.slice(0, 2);
    await Promise.all([roleCall('a', { command: 'retire_unpaired', key: stock.key, batches }),
      roleCall('b', { command: 'retire_unpaired', key: stock.key, batches })]);
    report.retired.push({ index, batches });
    const removed = new Set(batches.map(hex));
    const occupied = stock.a.ready.filter(retained.bind(null, removed));
    const claim = await call('/__benchmark/refill/admission', { command: 'claim_refill', key: stock.key, occupied });
    assert.equal(claim.status, 'acquired', 'A concurrent controller claim invalidates this controlled block');
    assert.equal(claim.job.producer_slot, actor.slot);
    assert.equal(claim.job.groups, 'two');
    report.jobs.push(claim.job);
  }
  report.queueReceipts = await Promise.all(report.jobs.map(queueJob));
  const deadline = Date.now() + 180000;
  let rows;
  do {
    await delay(3000);
    const captures = await Promise.all(['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary'].map(traces));
    rows = captures.flat();
    await writeFile(folder + '/producer-traces.json', JSON.stringify(rows) + '\n');
    // The observer reads only the front's archive while cryptography runs.
    if (report.jobs.every(completeJob.bind(null, rows))) break;
  } while (Date.now() < deadline);
  assert.ok(report.jobs.every(completeJob.bind(null, rows)), 'Paired publication/settlement was not observed');
  report.publicationObservedAtMs = Date.now();
  await releaseHeldLeases();
  assert.ok(report.heldLeases.every(authoritativeHolder), 'Holder lease expired before release');
  report.final = [];
  for (const key of keys) report.final.push(await inventory(key));
  for (let index = 0; index < keys.length; index += 1) {
    const final = report.final[index].ready;
    const old = report.initial[index].ready;
    const removed = report.retired.find(walletRetirement.bind(null, index));
    const job = report.jobs.find(walletJob.bind(null, keys[index]));
    const expected = removed === undefined ? old :
      [...old.filter(retainedHex.bind(null, new Set(removed.batches.map(hex)))), ...publicationId(job)].sort();
    assert.deepEqual(final, expected);
  }
  report.passed = true;
} finally {
  await releaseHeldLeases();
  report.endedAtMs = Date.now();
  await writeFile(folder + '/result.json', JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ label, passed: report.passed, jobs: report.jobs.length }));

function retained(removed, batch) { return !removed.has(hex(batch)); }
function retainedHex(removed, batch) { return !removed.has(batch); }
function walletRetirement(index, value) { return value.index === index; }
function walletJob(key, job) { return hex(job.key.public_key_digest) === hex(key.public_key_digest); }
function groupSelection(group, value) { return value.group === group; }
function otherGroupWallet(group, selected, placement, index) { return index !== selected && placement.group === group; }
async function releaseHeldLeases() {
  for (const lease of report.heldLeases) {
    if (lease.state === 'released_unused') continue;
    lease.checkedAtMs = Date.now();
    lease.authoritativeBeforeRelease = await call('/__benchmark/refill/admission', {
      command: 'check_refill', job: lease.job,
    });
    const wakeHints = await call('/__benchmark/refill/admission', {
      command: 'finish_refill', job: lease.job, outcome: 'unused',
    });
    assert.ok(Array.isArray(wakeHints));
    lease.state = 'released_unused';
  }
}
function authoritativeHolder(lease) {
  return lease.authoritativeBeforeRelease === true && lease.checkedAtMs < lease.job.expires_at_ms;
}
