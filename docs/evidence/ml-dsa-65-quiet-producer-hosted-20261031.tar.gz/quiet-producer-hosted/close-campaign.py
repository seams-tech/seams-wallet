import hashlib
import json
import statistics
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent


def hex_id(value):
    return bytes(value).hex()


def main():
    folder = BASE / 'cloud-driver/final-complete'
    records = json.loads((folder / 'traces.json').read_text())['records']
    raw = []
    for role in ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
        for line in (folder / (role + '-raw.jsonl')).read_text().splitlines():
            raw.append(json.loads(line))
    final_raw = BASE / 'final-all-traces.json'
    final_raw.write_text(json.dumps(raw) + '\n')
    selected = set()
    phases = [
        ('ordinary', json.loads((BASE / 'ordinary-order.json').read_text()), BASE / 'deployments.json'),
        ('diagnostic', json.loads((BASE / 'diagnostic-order.json').read_text()), BASE / 'diagnostic-versions.json'),
        ('return', json.loads((BASE / 'return-order.json').read_text()), BASE / 'return-versions.json'),
    ]
    for phase, order, versions in phases:
        for step in order:
            label = step['label'] if phase == 'ordinary' else step[0]
            directory = BASE / 'blocks' / label
            subprocess.run(['python3', str(BASE / 'qualify-block.py'), str(directory), str(versions), str(final_raw)], check=True)
            result = json.loads((directory / 'result.json').read_text())
            qualified = json.loads((directory / 'timing-qualification.json').read_text())
            assert qualified['quiet_eligible']
            for job in result['jobs']:
                job_id = hex_id(job['batch'])
                assert job_id not in selected
                selected.add(job_id)
    assert len(selected) == 24

    initial = json.loads((BASE / 'ordinary-initial-stock.json').read_text())['final']
    final = json.loads((BASE / 'final-initial-stock.json').read_text())['final']
    initial_ids = {batch for wallet in initial for batch in wallet['paired']}
    final_ids = {batch for wallet in final for batch in wallet['paired']}
    assert len(initial_ids) == 64 and len(final_ids) == 64
    for wallet in final:
        assert len(wallet['paired']) == 16 and wallet['pending'] == 0
        assert wallet['a']['reserved'] == wallet['b']['reserved'] == []
    retired = set()
    for directory in (BASE / 'blocks').iterdir():
        result = json.loads((directory / 'result.json').read_text())
        for entry in result['retired']:
            for batch in entry['batches']:
                value = hex_id(batch)
                assert value not in retired
                retired.add(value)
    assert len(retired) == 48

    signatures = json.loads((BASE / 'final-signatures.json').read_text())
    assert signatures['passed'] and len(signatures['cases']) == 4
    operations = {hex_id(request['operation']) for case in signatures['cases'] for request in case['requests']}
    taken = {'a': {}, 'b': {}}
    for row in records:
        for trace in row['signing_traces']:
            if trace['operation'] not in operations:
                continue
            own = taken[trace['role']].setdefault(trace['operation'], [])
            for event in trace['batches']:
                if event['value']['stage'] == 'taken':
                    own.append(event['value']['material_id'])
    consumed = set()
    for operation in operations:
        a, b = taken['a'].get(operation, []), taken['b'].get(operation, [])
        assert a and a == b and len(a) == len(set(a))
        assert not consumed.intersection(a)
        consumed.update(a)
    assert not retired.intersection(consumed)

    publication = {'a': {}, 'b': {}}
    for row in records:
        for event in row['preparation_stages']:
            if event['stage'] == 'published':
                own = publication[event['role']]
                if event['batch'] in own:
                    assert own[event['batch']] == event['job']
                own[event['batch']] = event['job']
    for role in ['a', 'b']:
        assert final_ids <= publication[role].keys()
    fresh_a = set(publication['a']) - initial_ids
    fresh_b = set(publication['b']) - initial_ids
    # Only post-control IDs belong to this ledger; setup and older epochs remain in raw evidence.
    allowed_new = (final_ids | retired | consumed) - initial_ids
    assert allowed_new <= fresh_a and allowed_new <= fresh_b
    assert len(initial_ids) + len(allowed_new) == len(retired) + len(consumed) + len(final_ids)
    assert final_ids == (initial_ids | allowed_new) - retired - consumed
    job_ids = {publication['a'][batch] for batch in allowed_new}
    first = json.loads((BASE / 'blocks/ordinary-0-first/result.json').read_text())['startedAtMs']
    observed_jobs = set()
    for row in records:
        if row['role'] not in ['preparer-a', 'preparer-a-secondary']:
            continue
        for event in row['preparation_stages']:
            if event['stage'] == 'crypto_started' and event['at_ms'] >= first:
                observed_jobs.add(event['job'])
    assert observed_jobs == job_ids, 'Unaccounted post-setup cryptographic work'
    all_fresh_a = {batch for batch, job in publication['a'].items() if job in observed_jobs}
    all_fresh_b = {batch for batch, job in publication['b'].items() if job in observed_jobs}
    assert all_fresh_a == all_fresh_b == allowed_new, 'Unaccounted published material'
    assert len(job_ids) <= 40
    crypto = {}
    for row in records:
        for event in row['preparation_stages']:
            if event['stage'] == 'crypto_started' and event['job'] in job_ids:
                identity = (event['job'], event['role'])
                assert identity not in crypto
                assert row['outcome'] == 'ok' and row['logs_truncated'] is False
                assert not row['exception_names']
                crypto[identity] = {'cpu_ms': row['cpu_ms'], 'wall_ms': row['wall_ms']}
    assert len(crypto) == 2 * len(job_ids)
    cases = []
    for case in signatures['cases']:
        assert case['verified'] and case['alteredMessageRejected']
        elapsed = case['requests'][-1]['completedAtMs'] - case['requests'][0]['startedAtMs']
        cases.append({'wallet': case['wallet'], 'request_count': len(case['requests']), 'elapsed_ms': elapsed})
    output = {'passed': True, 'selected_jobs': len(selected), 'post_setup_jobs': len(job_ids),
              'ledger_pairs': {'initial': 64, 'fresh': len(allowed_new), 'explicitly_retired': 48,
                               'signature_consumed': len(consumed), 'final': 64},
              'paired_preparation_cpu_ms': sum(row['cpu_ms'] for row in crypto.values()),
              'final_signature_cases': cases,
              'raw_invocations': len(records),
              'final_trace_sha256': hashlib.sha256(final_raw.read_bytes()).hexdigest(),
              'limits': ['This is a controlled retirement/refill experiment, not sustained signature throughput.',
                         'The selected24jobs include48 explicit retired pairs as experiment cost.',
                         'The ledger excludes separately recorded setup and normalization work.']}
    (BASE / 'closure.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output))


if __name__ == '__main__':
    main()
