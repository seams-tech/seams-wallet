import json
import statistics
from pathlib import Path

BASE = Path(__file__).resolve().parent


def main():
    order = json.loads((BASE / 'ordinary-order.json').read_text())
    assert len(order) == 10
    records = []
    uncertain = []
    overlap = []
    for step in order:
        directory = BASE / 'blocks' / step['label']
        result = json.loads((directory / 'result.json').read_text())
        qualified = json.loads((directory / 'timing-qualification.json').read_text())
        assert result['passed'] and qualified['timing_qualified']
        uncertain.extend(qualified['uncertain_overlapping_producer_rows'])
        assert result['selected'] == step['wallets']
        groups = [result['placements'][index]['group'] for index in result['selected']]
        if len(groups) == 2:
            assert len(set(groups)) == 2
        by_id = {row['job']: row for row in qualified['jobs']}
        for index, job in zip(result['selected'], result['jobs']):
            record = dict(by_id[bytes(job['batch']).hex()])
            record['label'] = step['label']
            record['group'] = result['placements'][index]['group']
            record['wallet'] = index
            record['workload'] = 'quiet' if len(result['jobs']) == 1 else 'overlap'
            record['repeat'] = 'reverse' if step['label'].startswith('reverse-') else 'ordinary'
            records.append(record)
        if len(result['jobs']) == 2:
            first, second = qualified['jobs']
            observed = {'label': step['label']}
            for role in ['a', 'b']:
                low = max(first[role]['crypto_started_at_ms'], second[role]['crypto_started_at_ms'])
                high = min(first[role]['crypto_completed_at_ms'], second[role]['crypto_completed_at_ms'])
                observed[role + '_reported_crypto_overlap_ms'] = max(0, high - low)
                observed[role + '_same_module'] = first[role]['module_instance'] == second[role]['module_instance']
            overlap.append(observed)
    assert len(records) == 12
    table = []
    directions = []
    for repeat in ['ordinary', 'reverse']:
        medians = []
        for group in [0, 1]:
            samples = [record for record in records if record['repeat'] == repeat and
                       record['group'] == group and record['workload'] == 'quiet']
            assert len(samples) == 2
            paired = statistics.median(record['paired_cpu_ms'] for record in samples)
            medians.append(paired)
            table.append({'repeat': repeat, 'group': group, 'quiet_jobs': len(samples),
                          'paired_cpu_ms_median': paired,
                          'a_cpu_ms_median': statistics.median(record['a']['cpu_ms'] for record in samples),
                          'b_cpu_ms_median': statistics.median(record['b']['cpu_ms'] for record in samples)})
        directions.append(1 if medians[1] > medians[0] else 0)
    ratios = []
    for offset in [0, 2]:
        values = [table[offset]['paired_cpu_ms_median'], table[offset + 1]['paired_cpu_ms_median']]
        ratios.append(max(values) / min(values))
    persists = directions[0] == directions[1] and all(ratio >= 1.5 for ratio in ratios)
    gate = 'run_matched_calibration' if persists else 'stop_no_persistent_quiet_gap'
    if uncertain:
        gate = 'stop_unqualified_quiet_capture'
    report = {'passed': True, 'jobs': records, 'quiet_summary': table, 'ratios': ratios,
              'diagnostic_gate': gate, 'reported_overlap': overlap, 'uncertain_overlapping_rows': uncertain,
              'scope': 'Bounded whole-invocation CPU screen. No kernel speedup, host identity, or sustained throughput claim.'}
    (BASE / 'ordinary-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'gate': report['diagnostic_gate'], 'quiet_summary': table, 'ratios': ratios}))


if __name__ == '__main__':
    main()
