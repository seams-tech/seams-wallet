import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { join } from 'node:path';
const base = import.meta.dirname;
async function load(name) { return JSON.parse(await readFile(join(base, name), 'utf8')); }
const manifest = await load('manifest.json');
for (const [file, expected] of Object.entries(manifest)) {
  assert.equal(createHash('sha256').update(await readFile(join(base, file))).digest('hex'), expected, file);
}
const grouped = await load('groups-final-proof.json');
const single = await load('single-group-final-proof.json');
const build = await load('final-build-manifest.json');
assert.equal(grouped.passed, true);
assert.equal(single.passed, true);
assert.equal(grouped.assertions.migrationCrossesSixtyFourRowPage, true);
assert.equal(grouped.assertions.legacyJournalsAndCooldownKeepGroupZero, true);
assert.equal(grouped.preparationResources.maximumActiveCrypto, 1);
assert.ok(grouped.preparationResources.maximumWasmBytes < 128 * 1024 * 1024);
for (const [role, entry] of Object.entries(build)) {
  assert.equal(grouped.sourceHashes[role + '.wasm'], entry.wasm_sha256);
  assert.equal(single.workerWasmSha256[role], entry.wasm_sha256);
}
const signatures = [...grouped.signatures];
for (const record of single.signatures) signatures.push({ publicKeyHex: single.publicKeyHex, messageHex: record.messageHex, signatureHex: record.signatureHex });
for (const name of ['unopenedAfterFailure', 'truncatedMaterialDelivery']) {
  const record = single[name];
  assert.deepEqual(record.committedTakesA, record.committedTakesB);
  assert.ok(record.committedTakesA.length > 0);
  signatures.push({ publicKeyHex: single.publicKeyHex, messageHex: record.messageHex, signatureHex: record.signatureHex });
}
for (const record of signatures) {
  const key = createPublicKey({ key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), Buffer.from(record.publicKeyHex, 'hex')]), format: 'der', type: 'spki' });
  const message = Buffer.from(record.messageHex, 'hex');
  const signature = Buffer.from(record.signatureHex, 'hex');
  assert.equal(verify(null, message, key, signature), true);
  assert.equal(verify(null, Buffer.concat([message, Buffer.from([1])]), key, signature), false);
}
for (const stocks of grouped.finalStocks) {
  const a = stocks[0].ready.map(hex).sort();
  const b = stocks[1].ready.map(hex).sort();
  assert.equal(a.length, 16);
  assert.equal(new Set(a).size, 16);
  assert.deepEqual(a, b);
  assert.equal(stocks[0].reserved.length + stocks[1].reserved.length, 0);
}
assert.equal(grouped.parallelRefill.lifetimes.length, 2);
assert.equal(new Set(grouped.parallelRefill.lifetimes.map(producer)).size, 2);
for (const job of grouped.parallelRefill.lifetimes) {
  const second = createHash('sha256').update('seams/ml-dsa/preparation-second-pair/v1').update(Buffer.from(job.job, 'hex')).digest('hex');
  const expected = [job.job, second].sort();
  for (const role of ['a', 'b']) {
    const stages = grouped.events.filter(matchesJob.bind(null, job.job, role));
    assert.equal(stages.filter(started).length, 1);
    assert.equal(stages.filter(completed).length, 1);
    assert.deepEqual(stages.filter(published).map(batch).sort(), expected);
  }
}
assert.equal(signatures.length, 9);
console.log(JSON.stringify({ passed: true, memberHashesVerified: Object.keys(manifest).length, standardSignaturesVerified: signatures.length, alteredMessagesRejected: signatures.length, pairedRefillJobsVerified: 2 }));
function hex(bytes) { return Buffer.from(bytes).toString('hex'); }
function producer(job) { return job.producer; }
function matchesJob(job, role, event) { return event.event === 'ml_dsa_preparation_stage_v1' && event.job === job && event.role === role; }
function started(event) { return event.stage === 'crypto_started'; }
function completed(event) { return event.stage === 'crypto_completed'; }
function published(event) { return event.stage === 'published'; }
function batch(event) { return event.batch; }
