import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-parallel-refill-20261029';
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]+$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const internal = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const registration = JSON.parse(await readFile(base + '/registration-1.json', 'utf8'));
assert.equal(registration.recoveryPreservesCanonicalKey, true);
const key = registration.cases.at(-1).key;
const artifact = base + '/' + label + '-depletion.json';
const report = { label, mode: scope.active_mode, scope: 'One deliberately depleted wallet, other wallet reserves unchanged, two configured producer slots, exact sixteen-pair target. Not sustained throughput.', policy: scope.policy, startedAtMs: Date.now(), snapshots: [], complete: false };

function id(value) { return Buffer.from(value).toString('hex'); }
async function roleCall(role, body) {
  const url = new URL(scope.router_url);
  const prefix = scope.prefix + '-front.';
  assert.ok(url.hostname.startsWith(prefix));
  url.hostname = scope.prefix + '-' + role + '.' + url.hostname.slice(prefix.length);
  url.pathname = '/router-ab/ml-dsa/role';
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': internal },
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200, 'Role ' + role + ' returned ' + response.status);
  return response.json();
}
async function inventories() {
  const command = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 };
  const [a, b] = await Promise.all([roleCall('a', command), roleCall('b', command)]);
  return { atMs: Date.now(), a, b };
}
function full(stock) {
  const a = stock.a.ready.map(id).sort();
  const b = stock.b.ready.map(id).sort();
  return a.length === 16 && new Set(a).size === 16 && JSON.stringify(a) === JSON.stringify(b) &&
    stock.a.reserved.length === 0 && stock.b.reserved.length === 0;
}
try {
  report.initial = await inventories();
  assert.ok(full(report.initial), 'Start with exact paired reserves');
  report.retired = report.initial.a.ready;
  report.depletionStartedAtMs = Date.now();
  for (const role of ['a', 'b']) {
    await roleCall(role, { command: 'retire_unpaired', key, batches: report.retired });
  }
  await roleCall('a', { command: 'wake_refill', key });
  report.depletedAndWokenAtMs = Date.now();
  const deadline = Date.now() + 300000;
  while (Date.now() < deadline) {
    const stock = await inventories();
    report.snapshots.push(stock);
    for (const inventory of [stock.a, stock.b]) {
      assert.ok(inventory.ready.length + inventory.reserved.length <= 16);
      const old = new Set(report.retired.map(id));
      for (const batch of inventory.ready) assert.equal(old.has(id(batch)), false);
    }
    await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
    if (full(stock)) {
      report.final = stock;
      report.complete = true;
      report.observedRestorationMs = stock.atMs - report.depletionStartedAtMs;
      break;
    }
    await delay(1000);
  }
  assert.equal(report.complete, true, 'Depleted wallet failed to restore');
} finally {
  report.endedAtMs = Date.now();
  await writeFile(artifact, JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ label, complete: report.complete, observedRestorationMs: report.observedRestorationMs }));
