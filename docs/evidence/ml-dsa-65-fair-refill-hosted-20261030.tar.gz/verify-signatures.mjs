import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createPublicKey, verify } from 'node:crypto';
import { join, resolve } from 'node:path';
const base = resolve(process.argv[2]);
let accepted = 0;
let changedMessagesRejected = 0;
for (const label of ['serial30-oct30', 'parallel30-oct30']) {
  const folder = join(base, 'cloud-driver', label);
  const input = JSON.parse(await readFile(join(folder, 'start.json'), 'utf8'));
  const client = JSON.parse(await readFile(join(folder, 'client.json'), 'utf8'));
  const keys = new Map();
  for (const wallet of input.wallets) {
    keys.set(wallet.index, createPublicKey({ key: Buffer.concat([
      Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
      Buffer.from(wallet.publicKeyHex, 'hex'),
    ]), format: 'der', type: 'spki' }));
  }
  for (const row of client.requests) {
    if (row.state !== 'succeeded') continue;
    assert.equal(row.contextHex, '');
    const message = Buffer.from(row.messageHex, 'hex');
    const signature = Buffer.from(row.signatureHex, 'hex');
    assert.equal(signature.length, 3309);
    assert.equal(verify(null, message, keys.get(row.wallet), signature), true);
    accepted += 1;
    const changed = Buffer.from(message);
    assert.ok(changed.length > 0);
    changed[0] ^= 1;
    assert.equal(verify(null, changed, keys.get(row.wallet), signature), false);
    changedMessagesRejected += 1;
  }
}
assert.equal(accepted, 187);
assert.equal(changedMessagesRejected, 187);
console.log(JSON.stringify({ accepted, changedMessagesRejected, node: process.version, openssl: process.versions.openssl }));
