import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';

const base = '/private/tmp/ml-dsa-parallel-refill-20261029';
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]+$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const internal = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const report = { startedAtMs: Date.now(), complete: false, final: [] };
function id(value) { return Buffer.from(value).toString('hex'); }
async function inventory(role, key) {
  const url = new URL(scope.router_url);
  const prefix = scope.prefix + '-front.';
  assert.ok(url.hostname.startsWith(prefix));
  url.hostname = scope.prefix + '-' + role + '.' + url.hostname.slice(prefix.length);
  url.pathname = '/router-ab/ml-dsa/role';
  const response = await fetch(url, { method: 'POST', headers: {
    'content-type': 'application/json', 'x-router-ab-internal-service-auth': internal,
  }, body: JSON.stringify({ command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 }), signal: AbortSignal.timeout(30000) });
  assert.equal(response.status, 200);
  return response.json();
}
for (let index = 1; index <= 4; index++) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  const key = registration.cases.at(-1).key;
  const [a, b] = await Promise.all([inventory('a', key), inventory('b', key)]);
  const idsA = a.ready.map(id).sort();
  const idsB = b.ready.map(id).sort();
  assert.equal(idsA.length, 16);
  assert.equal(new Set(idsA).size, 16);
  assert.deepEqual(idsA, idsB);
  assert.equal(a.reserved.length + b.reserved.length, 0);
  report.final.push({ key, a, b, paired: idsA });
}
report.complete = true;
report.endedAtMs = Date.now();
await writeFile(base + '/' + label + '-initial-stock.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ label, complete: true, pairedReservePerWallet: 16 }));
