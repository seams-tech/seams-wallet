# Fair parallel refill on the existing temporary fleet

The user requested this prototype after the completed Cloudflare comparison and raised the sustained target to six–seven verified signatures per minute.
Reuse the eight explicitly approved Worker names and existing credentials. No new token, role key, Worker name, D1 database, or bucket.

- Keep preparation on Workers, wallet-seed recovery, canonical FIPS export, four-candidate jobs and two-at-once consumption.
- Keep thirty-two candidates per wallet and the sixteen-candidate admission minimum.
- Keep two experimental producer slots. Production defaults remain one slot and a sixty-second cooldown.
- Use a thirty-second benchmark cooldown across four wallets, offering at most eight demands per minute.
- Count all failed work, candidate consumption, exact paired reserves, drain, and empty-pool waits.
- Compare unchanged serial-per-key artifacts with the reviewed prototype. The prototype also corrects preserved overdue-alarm scheduling; separate those findings and avoid assigning a compound gain solely to parallelism.
- Exercise waiting-wallet priority and a same-key partial-publication race. Never reuse material or enlarge reserves to improve a result.
- Delete and independently verify absence of all eight Workers after the follow-up. Keep active credentials private.
