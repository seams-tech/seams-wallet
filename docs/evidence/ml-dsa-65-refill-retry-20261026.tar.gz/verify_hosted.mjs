import { readFile, writeFile } from 'node:fs/promises';
import { createPublicKey, verify } from 'node:crypto';
import assert from 'node:assert/strict';
const base = new URL('./', import.meta.url);
const records = [];
function check(publicKeyHex, record) {
  const publicKey = createPublicKey({key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
    Buffer.from(publicKeyHex, 'hex'),
  ]), format: 'der', type: 'spki'});
  const message = Buffer.from(record.messageHex, 'hex');
  const signature = Buffer.from(record.signatureHex, 'hex');
  assert(verify(null, message, publicKey, signature));
  message[0] ^= 1;
  assert.equal(verify(null, message, publicKey, signature), false);
}
for (let index = 1; index <= 8; index += 1) {
  const registration = JSON.parse(await readFile(new URL(`registration-${index}.json`, base), 'utf8'));
  assert(registration.registrationChecksPassed && registration.recoveryPreservesCanonicalKey);
  assert.equal(registration.cases[0].publicKeyHex, registration.cases[1].publicKeyHex);
  for (const result of registration.cases) {
    if (!result.initialStockSign.verified) continue;
    check(result.publicKeyHex, result.initialStockSign);
    records.push({scope: 'setup', wallet: index, epoch: result.epoch});
  }
}
for (const name of ['control', 'candidate', 'control-settled', 'control-repeat']) {
  const client = JSON.parse(await readFile(new URL(`cloud-driver/${name}/client.json`, base), 'utf8'));
  for (const request of client.requests) {
    if (!request.verified) continue;
    const wallet = client.wallets.find(matchWallet.bind(null, request.wallet));
    assert(wallet);
    check(wallet.publicKeyHex, request);
    records.push({scope: name, wallet: request.wallet, operation: request.operation});
  }
}
function matchWallet(index, wallet) { return wallet.index === index; }
const local = JSON.parse(await readFile(new URL('worker-retry-final.json', base), 'utf8'));
assert.equal(local.passed, true);
for (const signature of local.signatures) {
  check(local.publicKeyHex, signature);
  records.push({scope: 'local-worker'});
}
const result = {verified: records.length, alteredMessagesRejected: records.length, records};
await writeFile(new URL('hosted-signature-verification.json', base), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({verified: result.verified, alteredMessagesRejected: result.alteredMessagesRejected}));
