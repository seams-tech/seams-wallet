mod gate_aes;
use gate_aes::{EightBlockAes128, FourBlockAes128};
use zeroize::Zeroizing;

#[link(wasm_import_module = "native_aes")]
extern "C" {
    fn encrypt(key: *const u8, data: *mut u8, bytes: usize);
}

#[no_mangle]
pub extern "C" fn measure(native: u32, batch: u32, rounds: u32, seed: u32) -> u32 {
    assert!([8, 16, 64, 256, 1024].contains(&batch));
    assert!(rounds <= 16_384);
    let mut key = Zeroizing::new([0u8; 16]);
    for (index, byte) in key.iter_mut().enumerate() {
        *byte = (index as u8).wrapping_add(seed as u8);
    }
    let four = FourBlockAes128::new(&key);
    let aes = EightBlockAes128::from_four(&four);
    let mut blocks = Zeroizing::new(vec![[0u8; 16]; batch as usize]);
    for (index, block) in blocks.iter_mut().enumerate() {
        for (byte_index, byte) in block.iter_mut().enumerate() {
            *byte = (index as u8).wrapping_mul(17).wrapping_add(byte_index as u8).wrapping_add(seed as u8);
        }
    }
    for _ in 0..rounds {
        if native == 1 {
            unsafe { encrypt(key.as_ptr(), blocks.as_mut_ptr().cast(), blocks.len() * 16) };
        } else {
            for chunk in blocks.chunks_exact_mut(8) {
                aes.encrypt_eight(chunk.try_into().expect("eight blocks"));
            }
        }
    }
    let mut checksum = 0u32;
    for block in blocks.iter() {
        for byte in block {
            checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(*byte));
        }
    }
    checksum
}

#[no_mangle]
pub extern "C" fn verify(batch: u32, seed: u32) {
    assert!([8, 16, 64, 256, 1024].contains(&batch));
    let mut key = Zeroizing::new([0u8; 16]);
    for (index, byte) in key.iter_mut().enumerate() {
        *byte = (index as u8).wrapping_add(seed as u8);
    }
    let cipher = FourBlockAes128::new(&key);
    let aes = EightBlockAes128::from_four(&cipher);
    let mut expected = Zeroizing::new(vec![[seed as u8; 16]; batch as usize]);
    for (index, block) in expected.iter_mut().enumerate() {
        block[0] = index as u8;
        block[1] = (index >> 8) as u8;
    }
    let mut actual = Zeroizing::new(expected.to_vec());
    for _ in 0..3 {
        for chunk in expected.chunks_exact_mut(8) {
            aes.encrypt_eight(chunk.try_into().expect("eight blocks"));
        }
        unsafe { encrypt(key.as_ptr(), actual.as_mut_ptr().cast(), actual.len() * 16) };
        assert_eq!(&*actual, &*expected);
    }
}
