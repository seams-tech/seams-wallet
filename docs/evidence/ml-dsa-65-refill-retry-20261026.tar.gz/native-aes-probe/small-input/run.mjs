import { Miniflare } from '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/node_modules/miniflare/dist/src/index.js';
import { readFile, writeFile, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import assert from 'node:assert/strict';
const base = import.meta.dirname;
await copyFile(base + '/target/wasm32-unknown-unknown/release/worker_native_aes_probe.wasm', base + '/kernel.wasm');
const runtime = new Miniflare({
  modules: true, scriptPath: base + '/worker.mjs', modulesRoot: base,
  modulesRules: [{type: 'ESModule', include: ['**/*.mjs']}, {type: 'CompiledWasm', include: ['**/*.wasm']}],
  compatibilityDate: '2026-06-12', compatibilityFlags: ['nodejs_compat'],
});
const samples = [];
const exactOutputChecks = [];
const summaries = [];
async function call(input) {
  const start = performance.now();
  const response = await runtime.dispatchFetch('http://probe.internal', {method: 'POST', body: JSON.stringify(input)});
  const data = await response.json();
  const elapsedMs = performance.now() - start;
  assert.equal(response.status, 200);
  return { ...data, elapsedMs };
}
function numericOrder(a, b) { return a - b; }
try {
  await runtime.ready;
  for (const batch of [8, 16, 64, 256, 1024]) {
    for (const mode of ['native-fresh', 'native-reused']) {
      for (const seed of [0, 17, 255]) {
        const result = await call({action: 'verify', mode, batch, seed});
        assert.equal(result.exactOutputMatched, true);
        exactOutputChecks.push({ batch, mode, seed });
      }
    }
    const expected = await call({action: 'measure', mode: 'wasm', batch, seed: 123});
    for (let iteration = 0; iteration < 4; iteration += 1) {
      for (const mode of ['wasm', 'native-fresh', 'native-reused']) {
        const result = await call({action: 'measure', mode, batch, seed: 123});
        assert.equal(result.checksum, expected.checksum);
        samples.push({batch, mode, iteration, ...result});
      }
    }
    for (const mode of ['wasm', 'native-fresh', 'native-reused']) {
      const selected = samples.filter(sample => sample.batch === batch && sample.mode === mode).map(sample => sample.elapsedMs).sort(numericOrder);
      summaries.push({batch, mode, medianMs: (selected[1] + selected[2]) / 2, minimumMs: selected[0], maximumMs: selected.at(-1)});
    }
    console.log(JSON.stringify(summaries.filter(row => row.batch === batch)));
  }
} finally {
  await runtime.dispose();
}
const sourceHashes = {};
for (const name of ['src/gate_aes.rs', 'src/gate_aes/eight.rs', 'src/lib.rs', 'Cargo.toml', 'Cargo.lock', 'worker.mjs', 'run.mjs', 'kernel.wasm']) {
  sourceHashes[name] = createHash('sha256').update(await readFile(base + '/' + name)).digest('hex');
}
await writeFile(base + '/result.json', JSON.stringify({
  scope: 'Local workerd, public data only. Client-observed request wall time includes Wasm/JS calls, copies, wiping, cipher setup, and local dispatch. This is not billed CPU or a full preparation result.',
  productionBackendChanged: false, protocolParityEstablished: false, blocksPerRequest: 131072,
  exactOutputChecks, samples, summaries, sourceHashes,
  limitations: ['Hosted speed is unmeasured.', 'No private-data integration or buffer-lifetime review is established.', 'A reused cipher is local to one synchronous request in this public-data probe.'],
}, null, 2) + '\n');
