import kernel from './kernel.wasm';
import { createCipheriv } from 'node:crypto';

let currentMode = 'wasm';
let cachedCipher = null;
let instance;
function newCipher(key) {
  const cipher = createCipheriv('aes-128-ecb', key, new Uint8Array(0));
  cipher.setAutoPadding(false);
  return cipher;
}
function finishCipher(cipher) {
  const tail = cipher.final();
  if (tail.length !== 0) throw new Error('Unexpected AES padding');
  tail.fill(0);
  cipher.destroy();
}
function encrypt(keyOffset, dataOffset, bytes) {
  const memory = instance.exports.memory.buffer;
  if (keyOffset < 0 || dataOffset < 0 || bytes <= 0 || bytes % 16 !== 0
    || keyOffset + 16 > memory.byteLength || dataOffset + bytes > memory.byteLength) {
    throw new Error('Invalid public AES buffer bounds');
  }
  const key = new Uint8Array(memory, keyOffset, 16);
  const input = new Uint8Array(memory, dataOffset, bytes);
  const cipher = currentMode === 'native-reused'
    ? (cachedCipher ??= newCipher(key)) : newCipher(key);
  const output = cipher.update(input);
  try {
    if (output.length !== bytes) throw new Error('Unexpected AES output length');
    input.set(output);
  } finally {
    output.fill(0);
    if (currentMode !== 'native-reused') finishCipher(cipher);
  }
}
instance = new WebAssembly.Instance(kernel, { native_aes: { encrypt } });

async function fetch(request) {
  const input = await request.json();
  if (!['wasm', 'native-fresh', 'native-reused'].includes(input.mode)
    || ![8, 16, 64, 256, 1024].includes(input.batch)
    || !Number.isInteger(input.seed) || input.seed < 0 || input.seed > 255
    || !['verify', 'measure'].includes(input.action)) {
    return new Response('Invalid public benchmark input', { status: 400 });
  }
  currentMode = input.mode;
  try {
    if (input.action === 'verify') {
      instance.exports.verify(input.batch, input.seed);
      return Response.json({ exactOutputMatched: true });
    }
    const rounds = 131072 / input.batch;
    const checksum = instance.exports.measure(input.mode === 'wasm' ? 0 : 1, input.batch, rounds, input.seed);
    return Response.json({ blocks: 131072, checksum });
  } finally {
    if (cachedCipher !== null) {
      finishCipher(cachedCipher);
      cachedCipher = null;
    }
  }
}
export default { fetch };
