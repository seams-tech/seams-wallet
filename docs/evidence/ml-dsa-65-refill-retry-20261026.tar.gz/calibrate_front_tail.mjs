import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const startedAtMs = Date.now();
const path = '/__benchmark/wallet/tail-error-calibration';
const response = await fetch(scope.router_url + path, {
  method: 'POST', headers: {'content-type': 'application/json', 'x-router-ab-internal-service-auth': token},
  body: '{}', signal: AbortSignal.timeout(60000),
});
const body = await response.text();
const receipt = {path, startedAtMs, completedAtMs: Date.now(), status: response.status,
  bodySha256: createHash('sha256').update(body).digest('hex'),
  scope: 'Intentional invalid start for a separate benchmark-only driver identity. No real wallet key or signing request supplied.'};
await writeFile(base + '/front-tail-calibration.json', JSON.stringify(receipt, null, 2) + '\n');
if (response.status !== 500) throw new Error('Expected benchmark validation failure');
console.log(JSON.stringify({calibrationHttpStatus: response.status}));
