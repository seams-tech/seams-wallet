"""Retain late tails, then compare fixed-window record digests across captures."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
FROZEN = BASE / 'frozen-measurement-qualified'
sys.path.insert(0, str(FROZEN / 'tools/ml-dsa-investigation/research'))
from summarize_capacity import bounded_records
PHASES = ['control', 'candidate', 'control-settled', 'control-repeat']
TRANSITIONS = set()


def run(arguments, log):
    with log.open('w') as output:
        subprocess.run(arguments, cwd=FROZEN, stdout=output, stderr=subprocess.STDOUT, check=True)


def capture(name):
    run(['node', str(FROZEN / 'tests/e2e/ml-dsa-cloud-load.e2e.mjs'), 'traces', str(BASE), name], BASE / (name + '.log'))
    return json.loads((BASE / 'cloud-driver' / name / 'traces.json').read_text())['records']


def phase_digest(rows, name):
    client = json.loads((BASE / 'cloud-driver' / name / 'client.json').read_text())
    start = json.loads((BASE / 'cloud-driver' / name / 'start.json').read_text())
    selected = [row for row in rows if row['version'] == client['deploymentVersions'].get(row['role'])]
    selected = bounded_records(selected, start['endAtMs'] + 120000)
    receipt = json.loads((BASE / 'cloud-driver' / (name + '-final') / 'stock.json').read_text())
    observation_end = max(item['log_timestamp_ms'] for item in receipt['observations'])
    full_cycle = [row for row in rows if row['event_timestamp_ms'] is not None
                  and start['startAtMs'] <= row['event_timestamp_ms'] <= observation_end]
    return {'bounded_profile': fingerprint(selected), 'unfiltered_full_cycle': fingerprint(full_cycle)}


def fingerprint(rows):
    encoded = [json.dumps(row, sort_keys=True, separators=(',', ':')) for row in rows]
    return {'records': len(encoded), 'sha256': hashlib.sha256('\n'.join(sorted(encoded)).encode()).hexdigest()}



def main():
    first = capture('qualified-closed-first')
    time.sleep(20)
    second = capture('qualified-closed-final')
    stability = {}
    for name in PHASES:
        left = phase_digest(first, name)
        right = phase_digest(second, name)
        assert left == right, f'Late fixed-window trace changes in {name}'
        stability[name] = right
    (BASE / 'capture-stability.json').write_text(json.dumps(stability, indent=2) + '\n')
    for name in PHASES:
        folder = BASE / 'cloud-driver' / name
        shutil.copy2(BASE / 'cloud-driver/qualified-closed-final/traces.json', folder / 'traces.json')
        run(['python3', str(FROZEN / 'tools/ml-dsa-investigation/research/summarize_capacity.py'),
             str(folder / 'client.json'), str(folder / 'traces.json'),
             str(BASE / (name + '-campaign.json')), str(folder / 'summary.json')], folder / 'summary-closed.log')
        summary = json.loads((folder / 'summary.json').read_text())
        assert summary['trace_coverage']['complete']
        assert summary['trace_coverage']['truncated_invocations'] == 0
        assert summary['configured_pool_target_respected']
        assert summary['authority_version_coverage']['complete'] == (name not in TRANSITIONS)
        subprocess.run(['python3', str(BASE / 'reserve_cycle.py'), name], cwd=FROZEN,
                       stdout=(folder / 'reserve-cycle-closed.log').open('w'),
                       stderr=subprocess.STDOUT, check=name not in ['control', 'control-settled'])
    run(['python3', str(BASE / 'analyze_parallel.py'), str(BASE), *PHASES], BASE / 'comparison-closed.log')
    run(['node', str(BASE / 'verify_hosted.mjs')], BASE / 'signature-verification.log')
    print(json.dumps({'closed_capture_stability': stability}), flush=True)


if __name__ == '__main__':
    main()
