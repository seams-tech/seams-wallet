"""Run the preserved two-slot control before changing the Worker runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE=Path(__file__).resolve().parent
SCOPE=json.loads((BASE/'scope.json').read_text())
ROOT=Path(SCOPE['root'])
FROZEN=BASE/'frozen-measurement-qualified'
if not FROZEN.exists():
    for source in (ROOT/'tools/ml-dsa-investigation/research').glob('*.py'):
        target=FROZEN/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    for name in ['ml-dsa-cloud-load.e2e.mjs','ml-dsa-cloud-load-worker.mjs']:
        source=ROOT/'tests/e2e'/name
        target=FROZEN/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    files={str(source.relative_to(FROZEN)):hashlib.sha256(source.read_bytes()).hexdigest() for source in FROZEN.rglob('*') if source.is_file()}
    (BASE/'frozen-measurement.json').write_text(json.dumps(files,indent=2)+'\n')
ENV=dict(os.environ,ML_DSA_TEST_BUILD_ROOT=SCOPE['build_root'],
    ML_DSA_REGISTRATION_ROUTER_URL=SCOPE['router_url'],
    ML_DSA_GATEWAY_TOKEN_FILE=str(BASE/'gateway-token'),
    ML_DSA_TEST_CANDIDATE_GROUP_SIZE='2',ML_DSA_TEST_PREPARATION_GROUP_SIZE='4',
    ML_DSA_TEST_PREPARATION_JOBS='2',ML_DSA_TEST_COOLDOWN_MS='60000')
CONTROL=['node',str(FROZEN/'tests/e2e/ml-dsa-cloud-load.e2e.mjs')]


def run(arguments,log,working_directory=ROOT):
    with log.open('w') as output:
        result=subprocess.run(arguments,cwd=working_directory,env=ENV,stdout=output,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'Command failed with exit {result.returncode}; inspect {log}')


def control(action,name,*arguments):
    run(CONTROL+[action,str(BASE),name,*map(str,arguments)],BASE/'cloud-driver'/f'{name}-{action}.log',FROZEN)


def main():
    assert all(row['passed'] for row in json.loads((BASE/'release-receipt.json').read_text()))
    versions=json.loads((BASE/'versions.json').read_text())
    (BASE/'cloud-driver/versions.json').write_text(json.dumps(versions,indent=2)+'\n')
    for index in range(1,9):
        artifact=BASE/f'registration-{index}.json'
        if not artifact.exists():
            print(json.dumps({'stage':'registration','wallet':index}),flush=True)
            ENV['ML_DSA_TEST_WALLET_ID']=f"{SCOPE['prefix']}-wallet-{index}"
            run(['node','tests/e2e/ml-dsa-registration-worker.e2e.mjs',str(BASE/f'wallet-{index}'),str(artifact)],BASE/f'registration-{index}.log')
        registration=json.loads(artifact.read_text())
        assert registration['registrationChecksPassed'] and registration['recoveryPreservesCanonicalKey']
        assert registration['policy']==SCOPE['policy']
        checks=[]
        for case in registration['cases']:
            assert case['canonicalKeyVerified'] and case['holderResultsAuthenticated'] and case['manifestVerified']
            sign=case['initialStockSign']
            assert sign.get('verified') is True or sign.get('failed') is True or sign.get('cooldownPreserved') is True
            checks.append({'epoch':case['epoch'],'verified':sign.get('verified',False),
                           'exhausted':sign.get('failed',False),'cooldown_preserved':sign.get('cooldownPreserved',False)})
        print(json.dumps({'stage':'registered','wallet':index,'checks':checks}),flush=True)
    name='control'
    folder=BASE/'cloud-driver'/name
    if not (folder/'start.json').exists():
        print(json.dumps({'stage':'restore_initial_reserves','phase':name}),flush=True)
        control('stock',name+'-initial',8,int(time.time()*1000))
        control('start',name,8,600000)
        shutil.copyfile(BASE/'scope.json',BASE/(name+'-campaign.json'))
    start=json.loads((folder/'start.json').read_text())
    print(json.dumps({'stage':'load','phase':name,'end_at_ms':start['endAtMs']}),flush=True)
    while time.time()*1000<start['endAtMs']+45000:
        time.sleep(30)
        control('status',name)
        rows=json.loads((folder/'progress.json').read_text())
        print(json.dumps({'stage':'progress','phase':name,'rows':rows}),flush=True)
        assert all(row['error'] is None for row in rows)
    control('collect',name)
    print(json.dumps({'stage':'restore_final_reserves','phase':name}),flush=True)
    control('stock',name+'-final',8,start['endAtMs'])
    control('traces',name)
    run(['python3',str(FROZEN/'tools/ml-dsa-investigation/research/summarize_capacity.py'),
         str(folder/'client.json'),str(folder/'traces.json'),str(BASE/(name+'-campaign.json')),
         str(folder/'summary.json')],folder/'summary.log',FROZEN)
    summary=json.loads((folder/'summary.json').read_text())
    assert summary['trace_coverage']['complete'] and summary['authority_version_coverage']['complete']
    assert summary['trace_coverage']['truncated_invocations']==0
    print(json.dumps({'stage':'control_complete','phase':name,'successful_http_ms':summary['successful_http_ms']}),flush=True)


if __name__ == '__main__':
    main()
