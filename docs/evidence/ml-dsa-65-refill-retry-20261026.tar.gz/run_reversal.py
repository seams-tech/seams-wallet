"""Return to the preserved control after the retry-policy cohort."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
from run_control import BASE, ROOT, FROZEN, SCOPE, control, run
import sys
sys.path.insert(0,str(BASE))


def deployment_versions():
    versions={}
    for worker in SCOPE['workers']:
        result=subprocess.run(['pnpm','exec','wrangler','deployments','list',
            '--config',str(BASE/(worker['role']+'.json')),'--json'],cwd=ROOT,capture_output=True,text=True,check=True)
        deployment=max(json.loads(result.stdout),key=lambda row:row['created_on'])
        assert len(deployment['versions'])==1 and deployment['versions'][0]['percentage']==100
        versions[worker['role']]=deployment['versions'][0]['version_id']
    return versions


def effective_versions(folder,versions):
    records=json.loads((folder/'traces.json').read_text())['records']
    final=json.loads((BASE/'cloud-driver'/(folder.name+'-final')/'stock.json').read_text())
    start=json.loads((folder/'start.json').read_text())['startAtMs']
    end=max(item['log_timestamp_ms'] for item in final['observations'])
    observed={role:set() for role in versions if role!='front'}
    for row in records:
        if row['role'] in observed and row['event_timestamp_ms'] is not None and start<=row['event_timestamp_ms']<=end:
            observed[row['role']].add(row['version'])
    report={'start_at_ms':start,'end_at_ms':end,'observed':{role:sorted(found,key=str) for role,found in observed.items()},
            'expected':versions,'qualified':all(found=={versions[role]} for role,found in observed.items())}
    (folder/'effective-versions.json').write_text(json.dumps(report,indent=2)+'\n')
    return report['qualified']


def main():
    assert any((BASE/'cloud-driver'/name/'summary.json').exists() for name in ['candidate','candidate-settled'])
    from authority_gate import wait_for_authority
    manifest={'configs':[{'role':worker['role'],'worker':worker['name'],'config':worker['role']+'.json','config_sha256':worker['config_sha256'],'wasm_sha256':worker['wasm_sha256']} for worker in SCOPE['workers'] if worker['role']!='front']}
    ready=BASE/'control-settled-policy-ready.json'
    if not ready.exists():
        control_versions=json.loads((BASE/'candidate-policy-ready.json').read_text())['versions']
        wait_for_authority(BASE,FROZEN,'candidate-before-reversal',control_versions['router'])
        print(json.dumps({'stage':'deploy_control_reversal'}),flush=True)
        for item in manifest['configs']:
            config=BASE/item['config']
            assert hashlib.sha256(config.read_bytes()).hexdigest()==item['config_sha256']
            wasm=Path(json.loads(config.read_text())['main']).parent.parent/'index_bg.wasm'
            assert hashlib.sha256(wasm.read_bytes()).hexdigest()==item['wasm_sha256']
            run(['pnpm','exec','wrangler','deploy','--config',str(config)],BASE/('control-settled-deploy-'+item['role']+'.log'))
        versions=deployment_versions()
        ready.write_text(json.dumps({'versions':versions,'policy':SCOPE['policy']},indent=2)+'\n')
    versions=json.loads(ready.read_text())['versions']
    (BASE/'cloud-driver/versions.json').write_text(json.dumps(versions,indent=2)+'\n')
    for name in ['control-settled','control-settled-repeat']:
        folder=BASE/'cloud-driver'/name
        if not (folder/'start.json').exists():
            wait_for_authority(BASE,FROZEN,name,versions['router'])
            print(json.dumps({'stage':'restore_initial_reserves','phase':name}),flush=True)
            control('stock',name+'-initial',8,int(time.time()*1000))
            control('traces',name+'-initial')
            from audit_starting_lifetimes import audit
            audit(BASE,name)
            control('start',name,8,600000)
            campaign=dict(SCOPE,build_root=str(BASE/'baseline-build'),runtime_source_manifest='scope.json')
            (BASE/(name+'-campaign.json')).write_text(json.dumps(campaign,indent=2)+'\n')
        start=json.loads((folder/'start.json').read_text())
        print(json.dumps({'stage':'load','phase':name,'end_at_ms':start['endAtMs']}),flush=True)
        while time.time()*1000<start['endAtMs']+45000:
            time.sleep(30)
            control('status',name)
            rows=json.loads((folder/'progress.json').read_text())
            print(json.dumps({'stage':'progress','phase':name,'rows':rows}),flush=True)
            assert all(row['error'] is None for row in rows)
        control('collect',name)
        print(json.dumps({'stage':'restore_final_reserves','phase':name}),flush=True)
        control('stock',name+'-final',8,start['endAtMs'])
        control('traces',name)
        mixed=not effective_versions(folder,versions)
        with (folder/'summary.log').open('w') as log:
            result=subprocess.run(['python3',str(FROZEN/'tools/ml-dsa-investigation/research/summarize_capacity.py'),
                str(folder/'client.json'),str(folder/'traces.json'),str(BASE/(name+'-campaign.json')),
                str(folder/'summary.json')],cwd=FROZEN,stdout=log,stderr=subprocess.STDOUT)
        summary=json.loads((folder/'summary.json').read_text())
        assert summary['trace_coverage']['complete'] and summary['trace_coverage']['truncated_invocations']==0
        if mixed or not summary['authority_version_coverage']['complete']:
            print(json.dumps({'stage':'mixed_versions_repeat_required','phase':name}),flush=True)
            continue
        assert result.returncode==0
        print(json.dumps({'stage':'control_reversal_complete','phase':name,'successful_http_ms':summary['successful_http_ms']}),flush=True)
        return
    raise RuntimeError('Control reversal authority or participant versions did not qualify after the settled repeat')


if __name__=='__main__':
    main()
