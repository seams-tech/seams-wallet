"""Write the completed report and a compact public evidence index."""
import hashlib
import json
from pathlib import Path
from statistics import median
import shutil

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
PHASES = json.loads((BASE / 'parallel-comparison.json').read_text())
AUDIT = json.loads((BASE / 'material-audit.json').read_text())
SELECTED = [next(row for row in PHASES if row['phase'] == name) for name in ['control-repeat', 'candidate']]
assert all(row['cycle_qualified'] for row in SELECTED)
assert all(AUDIT[row['phase']]['failed_jobs'] == 0 for row in SELECTED)


def seconds(value):
    return f'{value / 1000:.3f}'


def range_seconds(value):
    return f"{seconds(value['minimum'])}–{seconds(value['maximum'])}"


def main():
    table = ['| Measure | Settled control | Retry candidate |', '| --- | ---: | ---: |']
    table.append('| Verified signatures in ten minutes | ' + ' | '.join(str(row['signatures']) for row in SELECTED) + ' |')
    table.append('| Successful HTTP range | ' + ' | '.join(range_seconds(row['successful_http_ms']) + ' s' for row in SELECTED) + ' |')
    table.append('| Successful HTTP median | ' + ' | '.join(seconds(row['successful_http_ms']['median']) + ' s' for row in SELECTED) + ' |')
    table.append('| Empty-pool responses | ' + ' | '.join(str(row['admission_waits']['by_reason']['empty_pool']['responses']) for row in SELECTED) + ' |')
    table.append('| Verified signatures/minute, with restoration | ' + ' | '.join(f"{row['reserve_cycle']['signatures_per_minute']:.3f}" for row in SELECTED) + ' |')
    rates = {row['phase']: row['reserve_cycle']['complete_cycle_ledger']['new_paired_pairs'] * 2 * 60000 / row['reserve_cycle']['cycle_ms'] for row in SELECTED}
    table.append('| Useful replacement candidates/minute, with restoration | ' + ' | '.join(f"{rates[row['phase']]:.3f}" for row in SELECTED) + ' |')
    table.append('| Failed executing preparation jobs during load | ' + ' | '.join(str(AUDIT[row['phase']]['failed_jobs']) for row in SELECTED) + ' |')
    table.append('| First full-reserve observation after cutoff | ' + ' | '.join(seconds(row['reserve_cycle']['after_load_ms']) + ' s' for row in SELECTED) + ' |')
    table.append('| Full A/B stock ledger | ' + ' | '.join('balanced' for row in SELECTED) + ' |')
    table.extend(['', 'Producer wall time includes waits. These jobs begin during the ten-minute load.', '',
                  '| Producer job | Settled control A median | Retry candidate A median |', '| --- | ---: | ---: |'])
    for slot in ['preparer-a', 'preparer-a-secondary']:
        for candidates in [2, 4]:
            values = [row['job_profiles'][f'{slot}/{candidates}/all']['a']['wall_ms']['median'] for row in SELECTED]
            table.append(f'| {slot}, {candidates} candidates | ' + ' | '.join(seconds(value) + ' s' for value in values) + ' |')
    demand = '; '.join(row['phase'] + ' ' + range_seconds(row['successful_demand_ms']) + ' seconds' for row in SELECTED)
    control = SELECTED[0]
    limits = f'''Complete successful demand ranges are {demand}.
These include recorded cooldown and admission waits. They exceed successful-call times substantially.
One successful control request takes 9.749 seconds and exceeds the eight-second upper target.
That call remains a release latency gap. This screen does not establish its cause.
The fixed synchronized load and sixty-second cooldown constrain the result.

The settled control ledger is **{control['reserve_cycle']['complete_cycle_ledger']['initial_pairs']} initial + {control['reserve_cycle']['complete_cycle_ledger']['new_paired_pairs']} new = {control['reserve_cycle']['complete_cycle_ledger']['consumed_pairs']} consumed + {control['reserve_cycle']['complete_cycle_ledger']['final_pairs']} final pairs**.
Its starting pairs have at least **{AUDIT['control-repeat']['minimum_initial_remaining_ms'] / 60000:.3f} minutes** remaining at actual load start.
The two arms consume different rejection material when their exact take counts differ.
Provider timing and cache state also vary. This campaign establishes no causal preparation speedup.
Neither settled arm contains a failed executing preparation job, so it does not compare failure rates under an unhealthy slot.
Canceled idle lifecycle alarms remain separate from executing preparation outcomes.

All sixteen hosted creation/recovery calls preserve canonical keys, authenticated holder results, and manifests.
Thirteen setup signatures verify. Three recovery signing requests preserve the existing cooldown.
The setup does not establish a new registration performance claim.'''
    failed = json.loads((BASE / 'failed-control-analysis.json').read_text())
    failed_summary = json.loads((BASE / 'cloud-driver/control-settled/summary.json').read_text())
    failed_text = f'''### Interrupted control retained

An earlier settled control records **{failed['verified_signatures']} verified signatures and four interrupted driver requests**.
One request has a recorded server dispatch error, HTTP 500, after admission.
The other three reach the Router, but their response status and body are absent.
A provider outcome of `ok` does not establish HTTP or signing success.
A nearby `loadShed` occurs on ordinary participant B's signing connection.
It lacks an operation identity, so its direct association with that failed operation remains unproved.

All **{failed['published_receipts_in_window']} observed preparation publication receipts** in that load window succeed.
The producer alarm exception follows successful publication. A subsequent settlement retry completes.
Its closed summary reports **{failed_summary['unused_material_audit']['count']} newly prepared pairs** without recorded consumption or retained ready stock.
Their disposal cause remains unproved. The interrupted control fails full-cycle qualification.
It remains in the reliability record and is excluded from the completed throughput comparison.

The frozen driver drops the exact request input when it records interruption.
Its random message and digest cannot be reconstructed from the operation ID.
No guessed request or mutation is replayed.
The final repeat uses unchanged signing code, policy, and capacity.
It adds a direct front-Worker error-only tail and a separate invalid-start calibration request.
The calibration supplies no wallet key and starts no signature. Its two expected exception events are counted separately.
The added observation and different rejection histories also prevent a causal timing claim.

Provider analytics report two front-Worker exception buckets during the failed screen.
Their minute-level aggregates cannot identify the four driver invocations.
The same query returns no participant-B rows despite its known tail event, so that dataset cannot prove absence of B failures.
The historical cause of the four lost outcomes remains unresolved. This is a release qualification gap.'''
    report = (BASE / 'report-template.md').read_text().replace('{{HOSTED_TABLE}}', '\n'.join(table)).replace('{{HOSTED_LIMITS}}', limits).replace('{{FAILED_SCREEN}}', failed_text)
    assert '{{' not in report
    report = report.replace('The public evidence index and archive provide an offline replay of signatures, stock accounting, and profile attribution.',
        'The [public evidence index](../evidence/ml-dsa-65-refill-retry-20261026.json) and its archive provide an offline replay of signatures, stock accounting, and profile attribution.')
    (BASE / 'final-report.md').write_text(report)
    compact = []
    for row in SELECTED:
        compact.append({key: row[key] for key in ['phase', 'policy', 'signatures', 'successful_http_ms', 'successful_demand_ms',
                     'under_five_seconds', 'under_eight_seconds', 'trace_coverage_complete', 'pool_target_respected', 'cycle_qualified', 'reserve_cycle', 'job_profiles']})
        compact[-1]['useful_candidates_per_cycle_minute'] = rates[row['phase']]
        compact[-1]['failed_executing_jobs'] = AUDIT[row['phase']]['failed_jobs']
        compact[-1]['empty_pool_responses'] = row['admission_waits']['by_reason']['empty_pool']['responses']
        compact[-1]['admission_response_counts'] = {reason: value['responses'] for reason, value in row['admission_waits']['by_reason'].items()}
        compact[-1]['minimum_initial_remaining_ms'] = AUDIT[row['phase']]['minimum_initial_remaining_ms']
    summary = {'date': '2026-10-26', 'status': 'Durable retry implemented and qualified locally. Hosted healthy-load screen completed. Provider failure mitigation and native-AES protocol gain remain unproved.',
               'report': '../router-ab/ml-dsa-65-refill-retry-report.md', 'source_commit_before_changes': '656aa261717b98920ecb13d71022cc29b08e1e54',
               'constraints': ['Workers preparation', 'wallet-seed recovery', 'standard FIPS export', 'passive server-blind model', 'two-at-once consumption', 'unchanged per-wallet capacity'],
               'gpu_work': 'deferred', 'runtime_default_preparation_slots': 1, 'matched_screen_preparation_slots': 2,
               'retry_delays_ms': [2000, 4000, 8000, 16000, 30000], 'settled_phases': compact,
               'interrupted_control': failed,
               'driver_retention_probe_passed': json.loads((BASE / 'driver-retention-probe/result.json').read_text())['passed'],
               'excluded_initial_control': {'reason': 'Six unused initial pairs lack unique recorded lifetime bindings and remain unaccounted.', 'ledger': AUDIT['control']['cycle_ledger']},
               'local': {'native_passed': json.loads((BASE / 'durable-retry-final.json').read_text())['passed'],
                         'worker_passed': json.loads((BASE / 'worker-retry-final.json').read_text())['passed'],
                         'worker_failure': json.loads((BASE / 'worker-retry-final.json').read_text())['preparationFailure']},
               'cpu_profile': {'scope': 'Calibrated local sampled stacks, not billed CPU or hosted attribution.',
                               'private_aes_sample_percent': [profile['categories']['private_aes']['percent'] for profile in json.loads((BASE / 'preparation-cpu-profile.json').read_text())['profiles']]},
               'native_aes_probe': {'production_changed': False, 'protocol_parity_established': False, 'scope': 'Client-observed local Workerd whole-request medians, including bridge, copying, setup, wiping, and dispatch.', 'blocks_per_request': 1048576,
                                    'repeats_per_case': 4, 'exact_output_cases': 30,
                                    'at_1024_blocks': {'wasm_median_ms': 26.202792, 'native_fresh_median_ms': 15.4082295, 'native_reused_median_ms': 10.066729}},
               'bloat': {'exit_code': 1, 'rust_duplicated_lines': 13972, 'baseline': 13754, 'added_duplicate_lines': 0}}
    (BASE / 'public-summary-draft.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'report_ready': True, 'phases': [row['phase'] for row in SELECTED], 'rates': rates}))


if __name__ == '__main__':
    main()
