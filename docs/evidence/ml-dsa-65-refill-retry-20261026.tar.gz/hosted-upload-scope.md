# ML-DSA preparation retry benchmark credential scope

Create the eight temporary Workers below and upload these exact fresh benchmark credentials.
A Workers receive only the A storage key. B Workers receive only the B storage key.
Credentials protect synthetic wallets. They contain no production wallet or account credentials.
Both comparison arms retain two preparation slots, two-at-once consumption, sixteen pairs per wallet, and the sixty-second wallet cooldown.
Preparation stays on Workers. Wallet-seed recovery and standard FIPS export remain required.
The control uses preserved pre-change Worker binaries. The candidate changes retry and publication-recovery handling.
All eight temporary Workers will be removed after measurements. Local private fixtures will be retained.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-retry-1026-6155ed-router | 322213f36fa72b39b9c8f6f49f33d14e8b12ec33188739a8c58c641f718d2b2c |
| ml-dsa-retry-1026-6155ed-a | 2db389652cecb25a1c9c0b90f76cf4abe7014336e93d1e9fbc63fbaf0b37bbe2 |
| ml-dsa-retry-1026-6155ed-b | d43471e8f0f2c38c4a352c17a02e190ee95c96c43e5253e3654e35301624887e |
| ml-dsa-retry-1026-6155ed-preparer-a | 2db389652cecb25a1c9c0b90f76cf4abe7014336e93d1e9fbc63fbaf0b37bbe2 |
| ml-dsa-retry-1026-6155ed-preparer-b | d43471e8f0f2c38c4a352c17a02e190ee95c96c43e5253e3654e35301624887e |
| ml-dsa-retry-1026-6155ed-preparer-a-secondary | 2db389652cecb25a1c9c0b90f76cf4abe7014336e93d1e9fbc63fbaf0b37bbe2 |
| ml-dsa-retry-1026-6155ed-preparer-b-secondary | d43471e8f0f2c38c4a352c17a02e190ee95c96c43e5253e3654e35301624887e |
| ml-dsa-retry-1026-6155ed-front | 322213f36fa72b39b9c8f6f49f33d14e8b12ec33188739a8c58c641f718d2b2c |
