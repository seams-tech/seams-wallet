import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const snapshots = [];
for (let index = 0; index < 8; index += 1) {
  const response = await fetch(scope.router_url + '/__benchmark/wallet/control-settled-' + index, {
    headers: {'x-router-ab-internal-service-auth': token}, signal: AbortSignal.timeout(60000),
  });
  if (!response.ok) throw new Error('Read failed with HTTP ' + response.status);
  snapshots.push(await response.json());
}
await writeFile(base + '/control-interrupted-driver-snapshots.json', JSON.stringify({capturedAt: Date.now(), snapshots}, null, 2) + '\n');
console.log(JSON.stringify({captured: snapshots.length}));
