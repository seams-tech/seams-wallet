"""Recompute sampled-stack attribution from archived profiles and symbol maps."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'frozen-measurement-qualified/tools/ml-dsa-investigation/research'))
from summarize_preparation_profile import summarize

campaign_path = BASE / 'worker-retry-profile.json'
campaign = json.loads(campaign_path.read_text())
expected = json.loads((BASE / 'preparation-cpu-profile.json').read_text())
assert campaign['passed'] and campaign['profilerCalibration']['passed']
assert hashlib.sha256(campaign_path.read_bytes()).hexdigest() == expected['campaign_sha256']
for item, recorded in zip(campaign['preparationProfile']['profiles'], expected['profiles'], strict=True):
    role = item['title'][-1]
    path = BASE / 'candidate-build' / ('deriver-' + role) / 'index_bg.wasm.names.json'
    symbols = json.loads(path.read_text())
    assert hashlib.sha256(path.read_bytes()).hexdigest() == recorded['symbol_map_sha256']
    assert symbols['wasmSha256'] == campaign['workerWasmSha256']['deriver-' + role] == recorded['wasm_sha256']
    actual = json.loads(json.dumps(summarize(item, symbols)))
    assert all(actual[field] == recorded[field] for field in actual), role
print(json.dumps({'passed': True, 'profiles': len(expected['profiles']),
                  'limit': 'Counts and symbol-map provenance replayed. Production Wasm binaries are excluded from this public archive.'}))
