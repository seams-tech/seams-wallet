# ML-DSA refill retry evidence

Run `python3 replay.py` after extraction. Python 3.11+ and Node.js with native ML-DSA verification are required.
The replay verifies file hashes, signatures, altered-message rejection, exact participant takes, reserve accounting, and sampled-stack counts.
It writes `replay-result.json` without network access.

The archive retains the first control with six unaccounted initial pairs. Its reserve-cycle qualification must fail.
The candidate and final control repeat must qualify.
The interrupted control remains failed, including its unknown server outcomes. Complete starting and ending reserves are equal in capacity.
Successful request latency excludes earlier admission waits. Full-cycle throughput includes observed reserve restoration.
These finite runs do not establish maximum production capacity or prove mitigation of provider failures that did not recur.

Only public diagnostic fields are retained. Hosted test credentials, seeds, private keys, preparation payloads, and persisted participant stores are excluded.
The frozen measurement code identifies the actual hosted instrument. Later source changes retain settlement outcome and registration preparation IDs for future runs.
Those additional fields cannot restore missing historical observations.

Production Wasm binaries are excluded. Symbol maps and exact build hashes retain profile provenance.
CPU attribution is local statistical sampling. The native AES result is an isolated public-input Workerd probe.
Protocol parity and complete preparation speedup from native AES remain unproved.
Temporary Workers are deleted. Included configurations record the tests and must not be redeployed.
