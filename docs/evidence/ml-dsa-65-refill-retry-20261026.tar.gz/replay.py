"""Verify the retained measurements without network access."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
PHASES = ['control', 'candidate', 'control-settled', 'control-repeat']
manifest = json.loads((BASE / 'manifest.json').read_text())
for relative, digest in manifest['files'].items():
    assert hashlib.sha256((BASE / relative).read_bytes()).hexdigest() == digest, relative
trace = BASE / 'cloud-driver/qualified-closed-final/traces.json'
for phase in PHASES:
    target = BASE / 'cloud-driver' / phase / 'traces.json'
    if not target.exists():
        os.link(trace, target)
checks = []
for phase in PHASES:
    folder = BASE / 'cloud-driver' / phase
    command = [sys.executable, str(BASE / 'frozen-measurement-qualified/tools/ml-dsa-investigation/research/summarize_capacity.py'),
               str(folder / 'client.json'), str(trace), str(BASE / (phase + '-campaign.json')),
               str(folder / 'qualification-replay.json')]
    result = subprocess.run(command, cwd=BASE, capture_output=True, text=True)
    assert result.returncode == 0, (phase, result.stdout, result.stderr)
    assert json.loads((folder / 'qualification-replay.json').read_text()) == json.loads((folder / 'summary.json').read_text()), phase
    checks.append({'check': phase + ' load qualification', 'exit_code': result.returncode})
    result = subprocess.run([sys.executable, str(BASE / 'reserve_cycle.py'), phase], cwd=BASE, capture_output=True, text=True)
    assert result.returncode == (1 if phase in ['control', 'control-settled'] else 0), (phase, result.stdout, result.stderr)
    checks.append({'check': phase + ' reserve cycle', 'exit_code': result.returncode})
for script, arguments, output in [
    ('verify_hosted.mjs', [], 'hosted-signature-verification.json'),
    ('audit_material.py', [], 'material-audit.json'),
    ('analyze_failed_control.py', [], 'failed-control-analysis.json'),
    ('analyze_parallel.py', [str(BASE), *PHASES], 'parallel-comparison.json'),
]:
    expected = json.loads((BASE / output).read_text())
    runtime = 'node' if script.endswith('.mjs') else sys.executable
    result = subprocess.run([runtime, str(BASE / script), *arguments], cwd=BASE, capture_output=True, text=True)
    assert result.returncode == 0, (script, result.stdout, result.stderr)
    assert json.loads((BASE / output).read_text()) == expected, script
    checks.append({'check': script, 'exit_code': result.returncode})
result = subprocess.run([sys.executable, str(BASE / 'replay_profiles.py')], cwd=BASE, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
checks.append({'check': 'sampled-stack attribution', 'exit_code': 0})
for phase in ['candidate', 'control-repeat']:
    window = json.loads((BASE / 'cloud-driver' / phase / 'start.json').read_text())
    audit = json.loads((BASE / 'material-audit.json').read_text())[phase]
    assert audit['minimum_initial_remaining_ms'] >= 900000
    assert audit['cycle_qualified'] and audit['no_observed_reuse']
receipt = {'passed': True, 'checks': checks}
(BASE / 'replay-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
