"""One unchanged control repeat after retaining the interrupted driver cohort."""
import json
from pathlib import Path
import subprocess
import time
from run_control import BASE, FROZEN, SCOPE, control, run
from authority_gate import wait_for_authority
from audit_starting_lifetimes import audit
from run_reversal import effective_versions

name = 'control-repeat'
versions = json.loads((BASE / 'control-settled-policy-ready.json').read_text())['versions']
assert json.loads((BASE / 'cloud-driver/control-settled/client.json').read_text())['functionalPassed'] is False
wait_for_authority(BASE, FROZEN, name, versions['router'])
control('stock', name + '-initial', 8, int(time.time() * 1000))
control('traces', name + '-initial')
audit(BASE, name)
control('start', name, 8, 600000)
folder = BASE / 'cloud-driver' / name
window = json.loads((folder / 'start.json').read_text())
print(json.dumps({'stage': 'repeat_load_started', 'end_at_ms': window['endAtMs']}), flush=True)
(BASE / (name + '-campaign.json')).write_text(json.dumps(dict(SCOPE, build_root=str(BASE / 'baseline-build'), runtime_source_manifest='scope.json'), indent=2) + '\n')
while time.time() * 1000 < window['endAtMs'] + 45000:
    time.sleep(30)
    control('status', name)
    rows = json.loads((folder / 'progress.json').read_text())
    print(json.dumps({'stage': 'progress', 'rows': rows}), flush=True)
    # Preserve a second failure through the cutoff instead of selecting another run.
result = subprocess.run(['node', str(FROZEN / 'tests/e2e/ml-dsa-cloud-load.e2e.mjs'), 'collect', str(BASE), name],
                        cwd=FROZEN, capture_output=True, text=True)
(folder / 'collect.log').write_text(result.stdout + result.stderr)
assert result.returncode in [0, 1]
control('stock', name + '-final', 8, window['endAtMs'])
control('traces', name)
run(['python3', str(FROZEN / 'tools/ml-dsa-investigation/research/summarize_capacity.py'),
     str(folder / 'client.json'), str(folder / 'traces.json'), str(BASE / (name + '-campaign.json')), str(folder / 'summary.json')], folder / 'summary.log', FROZEN)
assert effective_versions(folder, versions)
client = json.loads((folder / 'client.json').read_text())
print(json.dumps({'stage': 'control_repeat_complete', 'functional_passed': client['functionalPassed'], 'signatures': client['successfulSignatures']}), flush=True)
