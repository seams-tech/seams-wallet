import { Miniflare } from '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/node_modules/miniflare/dist/src/index.js';
import { readFile, writeFile, mkdtemp } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const base = import.meta.dirname;
const forwarded = [];
const persistence = await mkdtemp(base + '/storage-');
async function failForward(request) {
  forwarded.push(await request.json());
  return new Response('Controlled response loss', {status: 500});
}
function runtime() {
  return new Miniflare({
    modules: true, scriptPath: base + '/entry.mjs', modulesRoot: base,
    compatibilityDate: '2026-06-12',
    durableObjects: {TEST_WALLET: 'RetentionWallet', TEST_TRACES: 'LoadTraceArchive'},
    durableObjectsPersist: persistence,
    bindings: {ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET: 'synthetic-probe-auth'},
    serviceBindings: {TEST_FRONT: failForward},
  });
}
async function snapshot(instance) {
  const response = await instance.dispatchFetch('http://probe/__benchmark/wallet/retention', {
    headers: {'x-router-ab-internal-service-auth': 'synthetic-probe-auth'},
  });
  assert.equal(response.status, 200);
  return response.json();
}
function checkExact(snapshot, input) {
  assert.equal(snapshot.state.state, 'failed');
  assert.deepEqual(snapshot.state.operation, input);
  assert.deepEqual(snapshot.requests[0].signingRequest, input.request);
  assert.equal(snapshot.requests[0].messageHex, Buffer.from(input.message).toString('hex'));
  assert.equal(snapshot.requests[0].contextHex, Buffer.from(input.context).toString('hex'));
}
let instance = runtime();
let afterHttpFailure;
let afterRestart;
let afterWatchdog;
try {
  await instance.ready;
  const start = Date.now() + 500;
  const input = {index: 0, key: {wallet: 'synthetic-retention-wallet', key_id: 'near', epoch: 2,
    public_key_digest: Array(32).fill(1), schedule_digest: Array(32).fill(2)},
    startAtMs: start, endAtMs: start + 60000, intervalMs: 60000};
  const response = await instance.dispatchFetch('http://probe/__benchmark/wallet/retention', {
    method: 'POST', headers: {'content-type': 'application/json', 'x-router-ab-internal-service-auth': 'synthetic-probe-auth'},
    body: JSON.stringify(input),
  });
  assert.equal(response.status, 200);
  for (let attempt = 0; attempt < 50; attempt += 1) {
    afterHttpFailure = await snapshot(instance);
    if (afterHttpFailure.state.state === 'failed') break;
    await delay(100);
  }
  assert.equal(forwarded.length, 1);
  checkExact(afterHttpFailure, forwarded[0]);
  await instance.dispose();
  instance = runtime();
  await instance.ready;
  afterRestart = await snapshot(instance);
  checkExact(afterRestart, forwarded[0]);
  const namespace = await instance.getDurableObjectNamespace('TEST_WALLET');
  const stub = namespace.get(namespace.idFromName('retention'));
  await stub.emulateInterruptedCheckpoint();
  await stub.invokeRecoveryAlarm();
  afterWatchdog = await snapshot(instance);
  checkExact(afterWatchdog, forwarded[0]);
  assert.equal(forwarded.length, 1, 'Watchdog must not start another mutation');
  const sources = {};
  for (const name of ['run.mjs', 'entry.mjs', 'load-worker.mjs']) {
    sources[name] = createHash('sha256').update(await readFile(base + '/' + name)).digest('hex');
  }
  const result = {passed: true,
    scope: 'Actual local Workerd HTTP and durable storage. A controlled HTTP 500 tests catch retention. Restart and an explicitly restored in-flight checkpoint test the source watchdog handler. No signer protocol or hosted latency claim.',
    forwardedRequests: forwarded.length, exactInput: forwarded[0], afterHttpFailure, afterRestart, afterWatchdog,
    noWatchdogResubmission: true, sourceHashes: sources};
  await writeFile(base + '/result.json', JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({passed: true, exactRequestPreservedAcrossRestartAndWatchdog: true}));
} finally {
  await instance.dispose();
}
