import { LoadWallet, LoadTraceArchive, routeLoadRequest } from './load-worker.mjs';
export { LoadTraceArchive };
export class RetentionWallet extends LoadWallet {
  async emulateInterruptedCheckpoint() {
    const failed = await this.ctx.storage.get('wallet');
    if (failed.state !== 'failed' || !failed.operation) throw new Error('Missing exact failed input');
    const row = await this.ctx.storage.get('request/' + String(failed.sequence).padStart(8, '0'));
    await this.ctx.storage.put('wallet', {
      state: 'in_flight', config: failed.config, sequence: failed.sequence,
      successes: failed.successes, demands: failed.demands, operation: failed.operation,
      demandStartAtMs: row.startAtMs,
    });
  }
  async invokeRecoveryAlarm() {
    await super.alarm();
  }
}
export default {fetch: routeLoadRequest};
