import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const window = JSON.parse(await readFile(base + '/cloud-driver/control-settled/start.json', 'utf8'));
const auth = await readFile('/Users/pta/Library/Preferences/.wrangler/config/default.toml', 'utf8');
const token = JSON.parse(/^oauth_token\s*=\s*(".*")$/m.exec(auth)[1]);
const from = new Date(window.startAtMs).toISOString();
const to = new Date(window.endAtMs + 120000).toISOString();
const results = [];
for (const role of ['front', 'b', 'preparer-a']) {
  const worker = scope.workers.find(item => item.role === role);
  const query = `query { viewer { accounts(filter: {accountTag: "ba924da36f2ffc3839e8d323000b66b4"}) {
    workersInvocationsAdaptive(limit: 100, filter: {scriptName: "${worker.name}", datetime_geq: "${from}", datetime_leq: "${to}"}) {
      dimensions { datetimeMinute status }
      sum { requests errors }
      quantiles { cpuTimeP50 cpuTimeP99 }
    }
  } } }`;
  const response = await fetch('https://api.cloudflare.com/client/v4/graphql', {
    method: 'POST', headers: {authorization: `Bearer ${token}`, 'content-type': 'application/json'},
    body: JSON.stringify({query}), signal: AbortSignal.timeout(30000),
  });
  results.push({role, query, status: response.status, data: await response.json()});
  await writeFile(base + '/provider-failure-metrics.json', JSON.stringify(results, null, 2) + '\n');
}
console.log(JSON.stringify({queries: results.length, statuses: results.map(item => item.status)}));
