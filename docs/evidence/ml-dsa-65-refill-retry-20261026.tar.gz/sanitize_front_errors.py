"""Retain only public fields from the live front error instrument."""
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

BASE = Path(__file__).resolve().parent
source = BASE / 'front-errors.private.jsonl'
text = source.read_text()
decoder = json.JSONDecoder()
position = 0
records = []
known = {'Invalid wallet index', 'The script will never generate a response.', 'Network connection lost.',
         'Durable Object storage operation exceeded timeout which caused object to be reset.',
         'Durable Object reset because its code was updated.'}
while position < len(text):
    start = text.find('{', position)
    if start < 0:
        break
    try:
        value, consumed = decoder.raw_decode(text[start:])
    except json.JSONDecodeError:
        raise ValueError('Incomplete live tail JSON; stop the tail after its last complete event')
    position = start + consumed
    path = urlsplit(value.get('event', {}).get('request', {}).get('url', '')).path
    errors = []
    for item in value.get('exceptions', []):
        message = item.get('message', '')
        errors.append({'name': item.get('name'), 'message': message if message in known else None,
                       'message_sha256': hashlib.sha256(message.encode()).hexdigest()})
    records.append({'entrypoint': value.get('entrypoint'), 'event_at_ms': value.get('eventTimestamp'),
                    'outcome': value.get('outcome'), 'version': value.get('scriptVersion'),
                    'path': path, 'calibration': path == '/__benchmark/wallet/tail-error-calibration',
                    'exceptions': errors})
calibration = [item for item in records if item['calibration'] and any(error['message'] == 'Invalid wallet index' for error in item['exceptions'])]
assert len(calibration) == 2, 'Known default and Durable Object exception calibration must be visible'
result = {'calibration_passed': True, 'calibration_events': len(calibration),
          'noncalibration_error_events': sum(not item['calibration'] for item in records),
          'records': records, 'scope': 'Live error-only tail attached for the final control repeat. It cannot diagnose earlier events or prove absence of unobserved failures.'}
(BASE / 'front-errors-public.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'records'}))
