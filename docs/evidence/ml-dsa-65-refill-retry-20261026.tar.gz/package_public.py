"""Package an explicit whitelist after scanning every available test secret literal."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
STAGE = BASE / 'public-archive'
PHASES = ['control', 'candidate', 'control-settled', 'control-repeat']
ROLES = ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary', 'front']


def copy(relative):
    source = BASE / relative
    assert source.is_file(), relative
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def prepare():
    STAGE.mkdir(exist_ok=True)
    files = [
        'scope.json', 'hosted-upload-scope.md', 'bootstrap-receipt.json', 'credentials-receipt.json',
        'release-receipt.json', 'versions.json', 'candidate-build-sources.json', 'candidate-manifest.json',
        'candidate-policy-ready.json', 'control-settled-policy-ready.json', 'control-interrupted-driver-snapshots.json', 'provider-failure-metrics.json',
        'run_control_repeat.py', 'retain_failed_control.py', 'capture_failed_driver.mjs', 'query_failure_metrics.mjs',
        'failed-control-analysis.json', 'front-errors-public.json', 'analyze_failed_control.py', 'sanitize_front_errors.py',
        'front-tail-calibration.json', 'calibrate_front_tail.mjs', 'front-tail-stop.json', 'frozen-measurement.json',
        'parallel-comparison.json', 'capture-stability.json', 'material-audit.json',
        'hosted-signature-verification.json', 'durable-retry-final.json', 'worker-retry-final.json',
        'worker-retry-first.json', 'worker-retry-repeat.json', 'worker-script-repeat.mjs',
        'worker-retry-profile.json', 'preparation-cpu-profile.json', 'bloat-final.log',
        'analyze_parallel.py', 'reserve_cycle.py', 'audit_material.py', 'verify_hosted.mjs',
        'audit_starting_lifetimes.py', 'authority_gate.py', 'run_control.py', 'run_candidate.py',
        'run_reversal.py', 'close_measurements.py', 'replay_profiles.py', 'package_public.py',
        'replay.py', 'README.md', 'save_report.py', 'report-template.md',
        'cloud-driver/qualified-closed-final/traces.json',
    ]
    files.extend(f'{role}.json' for role in ROLES)
    files.extend(f'candidate-{role}.json' for role in ROLES if role != 'front')
    files.extend(f'registration-{index}.json' for index in range(1, 9))
    files.extend(f'cloud-driver/qualified-closed-final/{role}-raw.jsonl' for role in ROLES if role != 'front')
    files.extend(f'{phase}-campaign.json' for phase in PHASES)
    for phase in PHASES:
        files.extend(f'cloud-driver/{phase}/{name}.json' for name in ['start', 'client', 'driver-snapshots', 'summary', 'reserve-cycle'])
        files.extend(f'cloud-driver/{phase}-{boundary}/stock.json' for boundary in ['initial', 'final'])
    files.extend('cloud-driver/' + phase + '-initial/starting-lifetimes.json' for phase in ['control-settled', 'control-repeat'])
    files.extend(f'{phase}-authority-gate.json' for phase in ['candidate', 'control-settled', 'control-repeat'])
    files.extend(f'candidate-build/deriver-{role}/index_bg.wasm.names.json' for role in ['a', 'b'])
    files.extend(str(path.relative_to(BASE)) for path in sorted((BASE / 'frozen-measurement-qualified').rglob('*')) if path.is_file() and '__pycache__' not in path.parts)
    for prefix in ['native-aes-probe', 'native-aes-probe/small-input']:
        files.extend(f'{prefix}/{name}' for name in ['Cargo.toml', 'Cargo.lock', 'src/lib.rs', 'src/gate_aes.rs', 'src/gate_aes/eight.rs', 'kernel.wasm', 'worker.mjs', 'run.mjs', 'result.json'])
    files.append('native-aes-probe/null-iv-failure.log')
    files.extend('driver-retention-probe/' + name for name in ['run.mjs', 'entry.mjs', 'load-worker.mjs', 'result.json'])
    for relative in files:
        copy(relative)
    current = STAGE / 'current-sources'
    for relative in [
        'crates/router-ab-cloudflare/src/ml_dsa/refill.rs',
        'crates/router-ab-cloudflare/src/ml_dsa/workers/preparation.rs',
        'crates/router-ab-cloudflare/src/ml_dsa/workers/preparation/producer.rs',
        'crates/router-ab-cloudflare/src/ml_dsa/workers.rs',
        'crates/router-ab-cloudflare/tests/ml_dsa_durable_pool_e2e.rs',
        'crates/router-ab-cloudflare/tests/ml_dsa_durable_pool/refill_backoff.rs',
        'tests/e2e/ml-dsa-durable-worker.e2e.mjs', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs',
        'tests/e2e/ml-dsa-cloud-load-worker.mjs',
        'tools/ml-dsa-investigation/research/collect_worker_traces.py',
    ]:
        target = current / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, target)


def patterns():
    values = set()
    for role in ROLES:
        path = BASE / (role + '-secrets.json')
        if path.exists():
            for value in json.loads(path.read_text()).values():
                if isinstance(value, str) and len(value) >= 24:
                    values.add(value.encode())
    token = BASE / 'gateway-token'
    if token.exists():
        values.add(token.read_bytes().strip())
    for index in range(1, 9):
        role_values = []
        for name in ['a-kek', 'b-kek']:
            value = (BASE / f'wallet-{index}' / name).read_bytes().strip()
            assert len(value) >= 32
            values.add(value)
            role_values.append(value)
        assert role_values[0] != role_values[1], 'Participant storage keys must differ'
    # Storage keys belong to participants. Wallet fixture copies can share them.
    assert values
    return values


def finish(secret_patterns):
    for relative in ['delete-receipt.json', 'deletion-verification.json', 'final-report.md']:
        copy(relative)
    files = sorted(path for path in STAGE.rglob('*') if path.is_file() and path.name != 'manifest.json')
    for path in files:
        data = path.read_bytes()
        assert not any(value in data for value in secret_patterns), str(path.relative_to(STAGE))
    manifest = {'files': {str(path.relative_to(STAGE)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
                'secret_exclusion': {'method': 'Explicit public whitelist and literal scan against all available fresh credentials and 16 fixture-key files.',
                                     'distinct_literals_checked': len(secret_patterns), 'fixture_key_files_checked': 16, 'matches': 0}}
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-refill-retry-20261026.tar.gz'
    with archive.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(mode='w', fileobj=compressed) as bundle:
                for path in sorted(path for path in STAGE.rglob('*') if path.is_file()):
                    data = path.read_bytes()
                    info = tarfile.TarInfo(str(path.relative_to(STAGE)))
                    info.size = len(data)
                    info.mode = 0o644
                    bundle.addfile(info, io.BytesIO(data))
    receipt = {'path': archive.name, 'bytes': archive.stat().st_size,
               'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': len(files) + 1,
               'secret_exclusion': manifest['secret_exclusion']}
    (BASE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
