"""Retain direct request correlations without assigning unknown server decisions."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
rows = json.loads((BASE / 'cloud-driver/qualified-closed-final/traces.json').read_text())['records']
folder = BASE / 'cloud-driver/control-settled'
client = json.loads((folder / 'client.json').read_text())
window = json.loads((folder / 'start.json').read_text())
selected = [row for row in rows if row['event_timestamp_ms'] is not None and window['startAtMs'] <= row['event_timestamp_ms'] <= window['endAtMs']]
requests = []
for request in client['requests']:
    if request['status'] != 'client_error_unknown_server_outcome':
        continue
    identity = bytes(request['operation']).hex()
    routers = [row for row in selected if row['role'] == 'router' and row['http_request'] == request['requestId']]
    assert len(routers) == 1
    outcomes = [item['outcome'] for row in selected for item in row['signing'] if item['operation'] == identity]
    takes = [item for row in selected for item in row['material_stages'] if item['operation'] == identity and item['value']['stage'] == 'taken']
    takes += [item for row in selected for trace in row['signing_traces'] if trace['operation'] == identity for item in trace['batches'] if item['value']['stage'] == 'taken']
    row = routers[0]
    requests.append({'wallet': request['wallet'], 'operation': identity, 'request_id': request['requestId'],
                     'driver_elapsed_ms': request['elapsedMs'], 'router_cpu_ms': row['cpu_ms'],
                     'router_wall_ms': row['wall_ms'], 'router_provider_outcome': row['outcome'],
                     'recorded_signing_outcomes': outcomes, 'observed_take_events': len(takes),
                     'http_response_body_retained': False, 'exact_original_request_retained': False})
load_shed = [{key: row[key] for key in ['role', 'path', 'event_timestamp_ms', 'outcome', 'operation', 'run_id', 'cpu_ms', 'wall_ms']}
             for row in selected if row['outcome'] == 'loadShed']
post_publication = []
for row in selected:
    published = [item for item in row['refill'] if item['published'] is True]
    if row['outcome'] == 'exception' and published:
        for item in published:
            settlements = [entry for candidate in rows for entry in candidate['refill_wakes'] if entry['event'] == 'ml_dsa_refill_settled_v1' and entry['batch'] == item['batch']]
            post_publication.append({'role': row['role'], 'batch': item['batch'], 'published_at_ms': item['log_timestamp_ms'],
                                     'provider_outcome': row['outcome'], 'settlements': settlements})
result = {'functional_passed': client['functionalPassed'], 'verified_signatures': client['successfulSignatures'],
          'interrupted_requests': requests, 'load_shed_rows': load_shed,
          'post_publication_exceptions': post_publication,
          'published_receipts_in_window': len({item['batch'] for row in selected for item in row['refill'] if item['published'] is True}),
          'failed_receipts_in_window': len({item['batch'] for row in selected for item in row['refill'] if item['published'] is False}),
          'limit': 'Router provider outcome ok does not prove HTTP success. The B loadShed has no direct operation identity. Driver invocation tails and exact request bodies are absent for the failed cohort. No guessed replay is attempted.'}
assert len(requests) == 4 and result['failed_receipts_in_window'] == 0
assert sum(any(item['status'] == 'dispatch_error' for item in row['recorded_signing_outcomes']) for row in requests) == 1
(BASE / 'failed-control-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'verified': result['verified_signatures'], 'interrupted': len(requests), 'failed_preparation_receipts': result['failed_receipts_in_window']}))
