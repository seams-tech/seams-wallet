//! Three durable SQLite stores exercise the same transitions as the Worker objects.
use ::ml_dsa::Keypair;
use router_ab_cloudflare::ml_dsa::{
    self as m,
    admission::{self, Claim, Completion, Decision, Status, UnavailableReason},
    policy::Policy,
    pool, sealing, *,
};
use rusqlite::{Connection, OptionalExtension};
use serde::{de::DeserializeOwned, Serialize};
use sha2::Digest;
use std::{
    future::Future,
    path::{Path, PathBuf},
    time::Duration,
};
use zeroize::Zeroizing;

#[path = "ml_dsa_durable_pool/refill_backoff.rs"]
mod refill_backoff;

struct Db(Connection);
impl Db {
    fn open(path: &Path) -> Self {
        let connection = Connection::open(path).unwrap();
        connection.busy_timeout(Duration::from_secs(10)).unwrap();
        connection
            .execute_batch(
                "CREATE TABLE IF NOT EXISTS records (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
            )
            .unwrap();
        Self(connection)
    }
}
impl Store for Db {
    async fn get<T: DeserializeOwned>(&self, key: &str) -> m::Result<Option<T>> {
        let value: Option<String> = self
            .0
            .query_row("SELECT value FROM records WHERE key=?", [key], |row| {
                row.get(0)
            })
            .optional()
            .unwrap();
        Ok(value.map(|text| serde_json::from_str(&text).unwrap()))
    }
    async fn put<T: Serialize>(&self, key: &str, value: &T) -> m::Result<()> {
        self.0.execute("INSERT INTO records(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [key, &serde_json::to_string(value).unwrap()]).unwrap();
        Ok(())
    }
    async fn delete(&self, key: &str) -> m::Result<()> {
        self.0
            .execute("DELETE FROM records WHERE key=?", [key])
            .unwrap();
        Ok(())
    }
}
fn tx<T>(db: &Db, work: impl Future<Output = m::Result<T>>) -> m::Result<T> {
    db.0.execute_batch("BEGIN IMMEDIATE").unwrap();
    let result = futures::executor::block_on(work);
    db.0.execute_batch(if result.is_ok() { "COMMIT" } else { "ROLLBACK" })
        .unwrap();
    result
}
fn id(text: &str) -> Identifier {
    Identifier::try_from(text.to_owned()).unwrap()
}
fn key(wallet: &str) -> KeyScope {
    KeyScope {
        wallet: WalletScope {
            org: id("org"),
            project: id("project"),
            environment: id("local-e2e"),
            wallet: id(wallet),
        },
        key_id: id("near-ml-dsa"),
        epoch: 1,
        public_key_digest: [7; 32],
        schedule_digest: [8; 32],
    }
}
fn request(key: &KeyScope, operation: u8) -> SigningRequest {
    SigningRequest {
        key: key.clone(),
        operation: [operation; 32],
        message_digest: [9; 32],
        context_digest: [10; 32],
    }
}
fn claim(db: &Db, policy: &Policy, request: SigningRequest, now: u64) -> Claim {
    activate(db, &request.key);
    match tx(db, admission::begin(db, policy, request, now)).unwrap() {
        Decision::Claimed { claim } => claim,
        other => panic!("Expected claim, got {other:?}"),
    }
}
fn activate(db: &Db, key: &KeyScope) {
    tx(
        db,
        admission::authorize_key(
            db,
            admission::KeyActivation {
                key: key.clone(),
                ceremony_id: [44; 32],
                manifest_digest: [45; 32],
            },
        ),
    )
    .unwrap();
    let state = tx(db, admission::key_state(db, key)).unwrap().unwrap();
    tx(db, admission::commit_key(db, state.activation().clone())).unwrap();
}
fn binding(key: &KeyScope, role: Participant, batch: u8) -> sealing::Binding {
    sealing::Binding {
        key: key.clone(),
        role,
        batch: [batch; 32],
        expires_at_ms: 1_000_000,
        wrapping_key_version: id("kek-1"),
    }
}
fn fill(db: &Db, key: &KeyScope, role: Participant, seed: &[u8; 32], start: u8, count: u8) {
    tx(db, pool::install_key(db, key.clone())).unwrap();
    for batch in start..start + count {
        let binding = binding(key, role, batch);
        let sealed = sealing::seal(Zeroizing::new(vec![batch; 100_000]), &binding, seed).unwrap();
        let wire = serde_json::to_vec(&sealed).unwrap();
        let sealed = serde_json::from_slice(&wire).unwrap();
        tx(db, pool::put(db, binding.clone(), sealed, 1_000)).unwrap();
        tx(
            db,
            pool::install_registration_batch(
                db,
                binding,
                serde_json::from_slice(&wire).unwrap(),
                1_001,
            ),
        )
        .unwrap();
    }
}
fn race(path: PathBuf, key: KeyScope, operation: u8) -> Decision {
    let db = Db::open(&path);
    activate(&db, &key);
    tx(
        &db,
        admission::begin(&db, &Policy::default(), request(&key, operation), 300_000),
    )
    .unwrap()
}
#[test]
fn durable_admission_pool_restart_and_concurrent_claims() {
    let directory = std::env::temp_dir().join(format!("ml-dsa-pool-e2e-{}", std::process::id()));
    std::fs::create_dir(&directory).unwrap();
    let service_path = directory.join("router.sqlite");
    let a_path = directory.join("a.sqlite");
    let b_path = directory.join("b.sqlite");
    let router = Db::open(&service_path);
    let a = Db::open(&a_path);
    let b = Db::open(&b_path);
    let key = key("wallet");
    let policy = Policy::parse(
        r#"{"wallet_cooldown":{"mode":"enabled","interval_ms":60000},"max_active_operations":1,"operation_timeout_ms":30000,"candidate_group_size":2,"preparation_group_size":4,"minimum_ready_batches":4,"refill_target_batches":4}"#,
    )
    .unwrap();
    fill(&a, &key, Participant::A, &[1; 32], 0, 4);
    fill(&b, &key, Participant::B, &[2; 32], 0, 4);
    drop(a);
    drop(b);
    let a = Db::open(&a_path);
    let b = Db::open(&b_path);
    let first = request(&key, 1);
    let activation = admission::KeyActivation {
        key: key.clone(),
        ceremony_id: [44; 32],
        manifest_digest: [45; 32],
    };
    tx(
        &router,
        admission::authorize_key(&router, activation.clone()),
    )
    .unwrap();
    assert!(tx(&router, admission::active_key(&router, &key))
        .unwrap()
        .is_none());
    assert!(tx(
        &router,
        admission::begin(&router, &policy, first.clone(), 1_000)
    )
    .is_err());
    drop(router);
    let router = Db::open(&service_path);
    assert!(matches!(
        tx(&router, admission::key_state(&router, &key)).unwrap(),
        Some(admission::KeyState::Installing { .. })
    ));
    let mut changed_activation = activation.clone();
    changed_activation.ceremony_id = [46; 32];
    assert!(tx(&router, admission::commit_key(&router, changed_activation)).is_err());
    activate(&router, &key);
    let empty_preflight = request(&key, 98);
    assert!(matches!(
        tx(
            &router,
            admission::preflight(&router, &policy, &empty_preflight, 400)
        )
        .unwrap(),
        admission::Preflight::CheckStock
    ));
    assert!(tx(&router, router.get::<Vec<serde_json::Value>>("active"))
        .unwrap()
        .unwrap_or_default()
        .is_empty());
    assert!(matches!(
        tx(
            &router,
            admission::defer_empty(&router, &policy, empty_preflight.clone(), 1_500, 500)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::EmptyPool,
            retry_at_ms: 1_500
        }
    ));
    assert!(tx(&router, router.get::<Vec<serde_json::Value>>("active"))
        .unwrap()
        .unwrap_or_default()
        .is_empty());
    let ready_key = self::key("ready-while-empty");
    let ready_claim = claim(&router, &policy, request(&ready_key, 99), 502);
    tx(&router, admission::cancel(&router, &ready_claim)).unwrap();
    // Empty preflight persists without a slot across restart.
    drop(router);
    let router = Db::open(&service_path);
    assert_eq!(
        tx(&router, admission::lookup(&router, &empty_preflight, 503)).unwrap(),
        Some(Status::AwaitingStock { retry_at_ms: 1_500 })
    );
    let empty_claim = claim(&router, &policy, first.clone(), 504);
    tx(
        &router,
        admission::await_stock(&router, &empty_claim, 1_000),
    )
    .unwrap();
    drop(router);
    let router = Db::open(&service_path);
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &policy, first.clone(), 999)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: admission::UnavailableReason::EmptyPool,
            retry_at_ms: 1_000,
        }
    ));
    let mut changed_waiting = first.clone();
    changed_waiting.message_digest = [98; 32];
    assert!(tx(
        &router,
        admission::begin(&router, &policy, changed_waiting, 1_000)
    )
    .is_err());
    let first_claim = claim(&router, &policy, first.clone(), 1_000);
    assert_ne!(first_claim.token, empty_claim.token);
    assert!(tx(
        &router,
        admission::admit(
            &router,
            &policy,
            empty_claim,
            vec![[0; 32], [1; 32], [2; 32], [3; 32]],
            1_001
        )
    )
    .is_err());
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &policy, first.clone(), 1_001)
        )
        .unwrap(),
        Decision::Existing {
            operation: Status::Preparing { .. }
        }
    ));
    let mut changed = first.clone();
    changed.message_digest = [99; 32];
    assert!(tx(&router, admission::begin(&router, &policy, changed, 1_001)).is_err());
    let batches = vec![[0; 32], [1; 32], [2; 32], [3; 32]];
    tx(
        &a,
        pool::reserve(&a, &first, &batches, first_claim.expires_at_ms, 1_001),
    )
    .unwrap();
    tx(
        &b,
        pool::reserve(&b, &first, &batches, first_claim.expires_at_ms, 1_001),
    )
    .unwrap();
    let permit = match tx(
        &router,
        admission::admit(&router, &policy, first_claim, batches.clone(), 1_002),
    )
    .unwrap()
    {
        Decision::Admitted { permit } => permit,
        _ => panic!(),
    };
    assert!(tx(&router, admission::settled(&router, &first)).is_err());
    let reserved_inventory = tx(&a, pool::inventory(&a, &key, 4, 1_002, 1_002)).unwrap();
    assert!(reserved_inventory.ready.is_empty());
    assert_eq!(reserved_inventory.reserved, batches);
    assert!(!reserved_inventory.refill_due);
    let (own_binding, sealed) =
        tx(&a, pool::take(&a, Participant::A, &permit, [0; 32], 1_003)).unwrap();
    let consumed_delivery = serde_json::from_slice(&serde_json::to_vec(&sealed).unwrap()).unwrap();
    assert!(tx(
        &a,
        pool::install_registration_batch(&a, own_binding.clone(), consumed_delivery, 1_004)
    )
    .is_err());
    assert_eq!(
        sealing::open(sealed, &own_binding, &[1; 32]).unwrap().len(),
        100_000
    );
    let after_take = tx(&a, pool::inventory(&a, &key, 4, 1_003, 1_003)).unwrap();
    assert!(after_take.ready.is_empty());
    assert_eq!(after_take.reserved, vec![[1; 32], [2; 32], [3; 32]]);
    assert!(after_take.refill_due);
    drop(a);
    let a = Db::open(&a_path);
    assert!(tx(&a, pool::take(&a, Participant::A, &permit, [0; 32], 1_004)).is_err());
    assert!(tx(&b, pool::take(&b, Participant::A, &permit, [0; 32], 1_004)).is_err());
    let wrong_role_binding = binding(&key, Participant::B, 99);
    let wrong_role_envelope = sealing::seal(
        Zeroizing::new(vec![5; 100_000]),
        &wrong_role_binding,
        &[2; 32],
    )
    .unwrap();
    assert!(sealing::open(wrong_role_envelope, &wrong_role_binding, &[1; 32]).is_err());
    // Both a prior domain and an AES envelope using the new domain must fail closed.
    for domain in [
        b"seams/ml-dsa/prepared-storage/v1".as_slice(),
        b"seams/ml-dsa/prepared-storage/v2".as_slice(),
    ] {
        let incompatible = aes_envelope(&wrong_role_binding, &[2; 32], domain);
        assert!(sealing::open(incompatible, &wrong_role_binding, &[2; 32]).is_err());
    }
    assert!(
        tx(&a, pool::inventory(&a, &key, 10, 1_004, 1_004))
            .unwrap()
            .refill_due
    );
    // An admitted failure consumes the cooldown and burns its reserved material.
    tx(
        &router,
        admission::finish(&router, &permit, Completion::Failed, 1_005),
    )
    .unwrap();
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                key.clone(),
                m::refill::Groups::One,
                1_005
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let mut changed_settlement = first.clone();
    changed_settlement.message_digest = [88; 32];
    assert!(tx(&router, admission::settled(&router, &changed_settlement)).is_err());
    tx(&a, pool::fence(&a, &first, &batches)).unwrap();
    tx(&b, pool::fence(&b, &first, &batches)).unwrap();
    tx(
        &a,
        pool::release(&a, &first, &batches, pool::Settlement::Failed, &[]),
    )
    .unwrap();
    tx(
        &b,
        pool::release(&b, &first, &batches, pool::Settlement::Failed, &[]),
    )
    .unwrap();
    tx(&router, admission::settled(&router, &first)).unwrap();
    tx(&router, admission::settled(&router, &first)).unwrap();
    let m::refill::Claim::Acquired {
        job: after_settlement,
    } = tx(
        &router,
        m::refill::claim(
            &router,
            &Policy::default(),
            key.clone(),
            m::refill::Groups::One,
            1_006,
        ),
    )
    .unwrap()
    else {
        panic!("Settlement did not release refill");
    };
    tx(
        &router,
        m::refill::finish(
            &router,
            &Policy::default(),
            &after_settlement,
            m::refill::Outcome::Published,
            1_007,
        ),
    )
    .unwrap();
    assert!(tx(&a, pool::inventory(&a, &key, 10, 1_006, 1_006))
        .unwrap()
        .ready
        .is_empty());
    assert!(tx(&b, pool::inventory(&b, &key, 10, 1_006, 1_006))
        .unwrap()
        .ready
        .is_empty());
    fill(&a, &key, Participant::A, &[1; 32], 10, 3);
    fill(&b, &key, Participant::B, &[2; 32], 10, 3);
    drop(router);
    let router = Db::open(&service_path);
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &policy, first.clone(), 1_006)
        )
        .unwrap(),
        Decision::Existing {
            operation: Status::Failed
        }
    ));
    let mut other_key = key.clone();
    other_key.key_id = id("another-key");
    activate(&router, &other_key);
    activate(&router, &self::key("other-wallet"));
    activate(&router, &self::key("other"));
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &policy, request(&other_key, 2), 61_001)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::WalletCooldown,
            retry_at_ms: 61_002
        }
    ));
    let second = claim(&router, &policy, request(&key, 2), 61_002);
    assert!(matches!(
        tx(
            &router,
            admission::begin(
                &router,
                &policy,
                request(&self::key("other-wallet"), 3),
                61_003
            )
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::ServiceCapacity,
            ..
        }
    ));
    tx(&router, admission::cancel(&router, &second)).unwrap();
    // Empty-pool refusal does not charge a new cooldown.
    let empty = claim(&router, &policy, request(&key, 4), 61_004);
    assert!(matches!(
        tx(
            &router,
            admission::admit(&router, &policy, empty, vec![], 61_005)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::EmptyPool,
            ..
        }
    ));
    let configured=Policy::parse(r#"{"wallet_cooldown":{"mode":"enabled","interval_ms":300000},"max_active_operations":1,"operation_timeout_ms":30000,"candidate_group_size":8,"preparation_group_size":8,"minimum_ready_batches":2,"refill_target_batches":10}"#).unwrap();
    let next = claim(&router, &configured, request(&key, 5), 61_006);
    let long = match tx(
        &router,
        admission::admit(&router, &configured, next, vec![[1; 32], [2; 32]], 61_007),
    )
    .unwrap()
    {
        Decision::Admitted { permit } => permit,
        _ => panic!(),
    };
    tx(
        &router,
        admission::finish(&router, &long, Completion::Failed, 61_008),
    )
    .unwrap();
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &configured, request(&key, 6), 361_006)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::WalletCooldown,
            retry_at_ms: 361_007
        }
    ));
    let disabled=Policy::parse(r#"{"wallet_cooldown":{"mode":"disabled"},"max_active_operations":1,"operation_timeout_ms":30000,"candidate_group_size":8,"preparation_group_size":8,"minimum_ready_batches":2,"refill_target_batches":10}"#).unwrap();
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &disabled, request(&key, 7), 61_009)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::ServiceCapacity,
            ..
        }
    ));
    tx(&router, admission::settled(&router, &long.request)).unwrap();
    let no_cooldown = claim(&router, &disabled, request(&key, 7), 61_009);
    assert!(matches!(
        tx(
            &router,
            admission::begin(&router, &disabled, request(&self::key("other"), 8), 61_010)
        )
        .unwrap(),
        Decision::Unavailable {
            reason: UnavailableReason::ServiceCapacity,
            ..
        }
    ));
    tx(&router, admission::cancel(&router, &no_cooldown)).unwrap();
    // A failed multi-record reservation rolls back its earlier writes.
    let rollback = request(&key, 9);
    assert!(tx(
        &a,
        pool::reserve(&a, &rollback, &[[10; 32], [255; 32]], 100_000, 62_000)
    )
    .is_err());
    assert_eq!(
        tx(&a, pool::inventory(&a, &key, 10, 62_000, 62_000))
            .unwrap()
            .ready
            .len(),
        3
    );
    // A late one-sided take cannot create an orphan after successful settlement.
    let settling = request(&key, 99);
    let settling_batches = vec![[10; 32], [11; 32], [12; 32]];
    tx(
        &a,
        pool::reserve(&a, &settling, &settling_batches, 65_000, 62_000),
    )
    .unwrap();
    tx(
        &b,
        pool::reserve(&b, &settling, &settling_batches, 65_000, 62_000),
    )
    .unwrap();
    let settling_permit = admission::Permit {
        request: settling.clone(),
        expires_at_ms: 65_000,
        batches: settling_batches.clone(),
    };
    tx(
        &a,
        pool::take(&a, Participant::A, &settling_permit, [10; 32], 62_001),
    )
    .unwrap();
    tx(
        &b,
        pool::take(&b, Participant::B, &settling_permit, [10; 32], 62_001),
    )
    .unwrap();
    tx(
        &a,
        pool::take(&a, Participant::A, &settling_permit, [11; 32], 62_002),
    )
    .unwrap();
    let mut consumed_union = tx(&a, pool::fence(&a, &settling, &settling_batches)).unwrap();
    for batch in tx(&b, pool::fence(&b, &settling, &settling_batches)).unwrap() {
        if !consumed_union.contains(&batch) {
            consumed_union.push(batch);
        }
    }
    assert!(tx(
        &b,
        pool::take(&b, Participant::B, &settling_permit, [11; 32], 62_003)
    )
    .is_err());
    assert!(tx(
        &a,
        pool::reserve(&a, &settling, &settling_batches, 65_000, 62_003)
    )
    .is_err());
    tx(
        &a,
        pool::release(
            &a,
            &settling,
            &settling_batches,
            pool::Settlement::Succeeded,
            &consumed_union,
        ),
    )
    .unwrap();
    tx(
        &b,
        pool::release(
            &b,
            &settling,
            &settling_batches,
            pool::Settlement::Succeeded,
            &consumed_union,
        ),
    )
    .unwrap();
    assert_eq!(
        tx(&a, pool::inventory(&a, &key, 10, 62_004, 62_004))
            .unwrap()
            .ready,
        vec![[12; 32]]
    );
    assert_eq!(
        tx(&b, pool::inventory(&b, &key, 10, 62_004, 62_004))
            .unwrap()
            .ready,
        vec![[12; 32]]
    );
    // A lost pre-admission cleanup can leave an unmatched ready half. Retire it
    // only after observing the peer's permanent tombstone, never on Missing.
    let abandoned = request(&key, 98);
    tx(
        &a,
        pool::reserve(&a, &abandoned, &[[12; 32]], 63_000, 62_100),
    )
    .unwrap();
    assert!(tx(&a, pool::inventory(&a, &key, 10, 63_001, 63_001))
        .unwrap()
        .ready
        .is_empty());
    assert_eq!(
        tx(&a, pool::inspect(&a, &key, &[[12; 32], [250; 32]])).unwrap(),
        vec![
            pool::BatchAvailability::Retired,
            pool::BatchAvailability::Missing
        ]
    );
    tx(&b, pool::retire_unpaired(&b, &key, &[[12; 32]])).unwrap();
    assert!(tx(&b, pool::inventory(&b, &key, 10, 63_002, 63_002))
        .unwrap()
        .ready
        .is_empty());
    // Refilling another key slot cannot erase this slot's pending request.
    let mut sibling = key.clone();
    sibling.key_id = id("sibling");
    fill(&a, &sibling, Participant::A, &[1; 32], 100, 3);
    tx(&a, pool::inventory(&a, &sibling, 1, 62_000, 62_000)).unwrap();
    assert!(matches!(
        tx(&a, pool::refill_status(&a, &sibling, 62_000)).unwrap(),
        pool::RefillStatus::Sufficient
    ));
    assert!(
        matches!(tx(&a, pool::refill_status(&a, &key, 62_000)).unwrap(), pool::RefillStatus::Requested { key: pending, .. } if pending == key)
    );
    // A ready record must remain valid throughout the admitted operation.
    assert!(tx(&a, pool::inventory(&a, &sibling, 1, 999_999, 1_000_001))
        .unwrap()
        .ready
        .is_empty());
    // Recovery advances the epoch and burns all older preparation.
    let mut substituted = key.clone();
    substituted.epoch = 2;
    substituted.public_key_digest = [66; 32];
    assert!(tx(
        &router,
        admission::authorize_key(
            &router,
            admission::KeyActivation {
                key: substituted.clone(),
                ceremony_id: [67; 32],
                manifest_digest: [68; 32],
            }
        )
    )
    .is_err());
    assert!(tx(&a, pool::install_key(&a, substituted)).is_err());
    let mut recovered = key.clone();
    recovered.epoch = 2;
    let recovered_activation = admission::KeyActivation {
        key: recovered.clone(),
        ceremony_id: [44; 32],
        manifest_digest: [45; 32],
    };
    tx(
        &router,
        admission::authorize_key(&router, recovered_activation),
    )
    .unwrap();
    assert!(tx(&router, admission::active_key(&router, &recovered))
        .unwrap()
        .is_none());
    assert!(tx(&router, admission::commit_key(&router, activation)).is_err());
    activate(&router, &recovered);
    tx(&a, pool::install_key(&a, recovered.clone())).unwrap();
    assert!(tx(&a, pool::inventory(&a, &key, 10, 62_001, 62_001)).is_err());
    assert!(tx(&a, pool::inventory(&a, &recovered, 10, 62_001, 62_001))
        .unwrap()
        .ready
        .is_empty());
    assert!(tx(&a, pool::install_key(&a, key.clone())).is_err());
    let replay_binding = binding(&recovered, Participant::A, 0);
    let replay =
        sealing::seal(Zeroizing::new(vec![0; 100_000]), &replay_binding, &[1; 32]).unwrap();
    assert!(tx(&a, pool::put(&a, replay_binding, replay, 62_002)).is_err());
    // Two independent connections contend for the global service slot.
    let path_a = service_path.clone();
    let path_b = service_path.clone();
    let key_a = self::key("racing-a");
    let key_b = self::key("racing-b");
    let left = std::thread::spawn(move || race(path_a, key_a, 20));
    let right = std::thread::spawn(move || race(path_b, key_b, 21));
    let outcomes = [left.join().unwrap(), right.join().unwrap()];
    assert_eq!(
        outcomes
            .iter()
            .filter(|value| matches!(value, Decision::Claimed { .. }))
            .count(),
        1
    );
    // Completion verifies the exact admitted inputs and persists an idempotent result.
    let ordinary = ::ml_dsa::SigningKey::<::ml_dsa::MlDsa65>::from_seed(&[6; 32].into());
    let public_key = ordinary.verifying_key().encode().to_vec();
    let message = b"router-completion".to_vec();
    let context = b"private-e2e".to_vec();
    let signature = ordinary
        .expanded_key()
        .sign_deterministic(&message, &context)
        .unwrap()
        .encode()
        .to_vec();
    let mut verified_key = self::key("verified-wallet");
    verified_key.public_key_digest = sha2::Sha256::digest(&public_key).into();
    let mut verified_request = request(&verified_key, 30);
    verified_request.message_digest = sha2::Sha256::digest(&message).into();
    verified_request.context_digest = sha2::Sha256::digest(&context).into();
    let verified_claim = claim(&router, &policy, verified_request.clone(), 500_000);
    let verified_permit = match tx(
        &router,
        admission::admit(
            &router,
            &policy,
            verified_claim,
            vec![[30; 32], [31; 32], [32; 32], [33; 32]],
            500_001,
        ),
    )
    .unwrap()
    {
        Decision::Admitted { permit } => permit,
        _ => panic!(),
    };
    let mut changed_signature = signature.clone();
    changed_signature[0] ^= 1;
    assert!(tx(
        &router,
        admission::finish(
            &router,
            &verified_permit,
            Completion::Succeeded {
                public_key: public_key.clone(),
                message: message.clone(),
                context: context.clone(),
                signature: changed_signature,
            },
            500_002
        )
    )
    .is_err());
    let success = tx(
        &router,
        admission::finish(
            &router,
            &verified_permit,
            Completion::Succeeded {
                public_key,
                message,
                context,
                signature: signature.clone(),
            },
            500_003,
        ),
    )
    .unwrap();
    assert_eq!(success, Status::Succeeded { signature });
    drop(router);
    let router = Db::open(&service_path);
    assert_eq!(
        tx(
            &router,
            admission::lookup(&router, &verified_request, 500_004)
        )
        .unwrap(),
        Some(success.clone())
    );
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                verified_request.key.clone(),
                m::refill::Groups::One,
                500_004
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let mut recovered_key = verified_request.key.clone();
    recovered_key.epoch += 1;
    tx(
        &router,
        admission::authorize_key(
            &router,
            admission::KeyActivation {
                key: recovered_key,
                ceremony_id: [77; 32],
                manifest_digest: [78; 32],
            },
        ),
    )
    .unwrap();
    assert_eq!(
        tx(
            &router,
            admission::lookup(&router, &verified_request, 500_005)
        )
        .unwrap(),
        Some(success)
    );
    // Preprocessing uses a separate global lease and fresh IDs after interruption.
    let refill_key = self::key("refill-wallet");
    activate(&router, &refill_key);
    tx(&a, pool::install_key(&a, refill_key.clone())).unwrap_err();
    let refill_store_path = directory.join("refill.sqlite");
    let refill_store = Db::open(&refill_store_path);
    tx(
        &refill_store,
        pool::install_key(&refill_store, refill_key.clone()),
    )
    .unwrap();
    let m::refill::Claim::Acquired { job } = tx(
        &router,
        m::refill::claim(
            &router,
            &Policy::default(),
            refill_key.clone(),
            m::refill::Groups::One,
            600_000,
        ),
    )
    .unwrap() else {
        panic!("Missing preprocessing lease")
    };
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                refill_key.clone(),
                m::refill::Groups::One,
                600_001
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    tx(
        &refill_store,
        m::refill::start_role(&refill_store, &job, 600_001),
    )
    .unwrap();
    drop(refill_store);
    let refill_store = Db::open(&refill_store_path);
    assert!(tx(
        &refill_store,
        m::refill::start_role(&refill_store, &job, 600_002)
    )
    .is_err());
    let mut late_binding = binding(&job.key, Participant::A, 1);
    late_binding.batch = job.batch;
    late_binding.expires_at_ms = job.material_expires_at_ms;
    let late_sealed =
        sealing::seal(Zeroizing::new(vec![7; 100_000]), &late_binding, &[1; 32]).unwrap();
    assert!(tx(
        &refill_store,
        m::refill::publish_role(
            &refill_store,
            &job,
            late_binding,
            late_sealed,
            job.expires_at_ms
        )
    )
    .is_err());
    assert!(!tx(&router, m::refill::check(&router, &job, job.expires_at_ms)).unwrap());
    let m::refill::Claim::Busy {
        retry_at_ms: replacement_at,
    } = tx(
        &router,
        m::refill::claim(
            &router,
            &Policy::default(),
            refill_key.clone(),
            m::refill::Groups::Two,
            job.expires_at_ms,
        ),
    )
    .unwrap()
    else {
        panic!("Expired producer bypassed its retry delay")
    };
    assert_eq!(replacement_at, job.expires_at_ms + 2_000);
    let m::refill::Claim::Acquired { job: replacement } = tx(
        &router,
        m::refill::claim(
            &router,
            &Policy::default(),
            refill_key,
            m::refill::Groups::Two,
            replacement_at,
        ),
    )
    .unwrap() else {
        panic!("Expired producer did not resume after its retry delay")
    };
    assert_ne!(job.batch, replacement.batch);
    tx(
        &refill_store,
        m::refill::start_role(&refill_store, &replacement, replacement_at),
    )
    .unwrap();
    let pair_ids = replacement.batch_ids();
    assert_eq!(pair_ids.len(), 2);
    assert_ne!(pair_ids[0], pair_ids[1]);
    for id in &pair_ids {
        let mut fresh_binding = binding(&replacement.key, Participant::A, 2);
        fresh_binding.batch = *id;
        fresh_binding.expires_at_ms = replacement.material_expires_at_ms;
        let fresh_sealed =
            sealing::seal(Zeroizing::new(vec![8; 100_000]), &fresh_binding, &[1; 32]).unwrap();
        tx(
            &refill_store,
            m::refill::publish_role(
                &refill_store,
                &replacement,
                fresh_binding.clone(),
                fresh_sealed,
                replacement_at + 1,
            ),
        )
        .unwrap();
        let duplicate_sealed =
            sealing::seal(Zeroizing::new(vec![8; 100_000]), &fresh_binding, &[1; 32]).unwrap();
        assert!(tx(
            &refill_store,
            m::refill::publish_role(
                &refill_store,
                &replacement,
                fresh_binding,
                duplicate_sealed,
                replacement_at + 2,
            )
        )
        .is_err());
    }
    let prepared_inventory = tx(
        &refill_store,
        pool::inventory(
            &refill_store,
            &replacement.key,
            2,
            replacement_at + 3,
            replacement_at + 30_000,
        ),
    )
    .unwrap();
    assert!(pair_ids
        .iter()
        .all(|id| prepared_inventory.ready.contains(id)));

    assert!(tx(
        &router,
        m::refill::finish(
            &router,
            &Policy::default(),
            &job,
            m::refill::Outcome::Published,
            replacement_at + 3
        )
    )
    .unwrap()
    .is_empty());
    assert!(tx(
        &router,
        m::refill::check(&router, &replacement, replacement.expires_at_ms - 1)
    )
    .unwrap());
    tx(
        &router,
        m::refill::finish(
            &router,
            &Policy::default(),
            &replacement,
            m::refill::Outcome::Published,
            replacement_at + 4,
        ),
    )
    .unwrap();
    // Unused stock survives the former ten-minute deadline, then expires at its
    // sealed deadline. Recovery still fences the same material immediately.
    let retained_at = replacement_at + 700_000;
    let retained = tx(
        &refill_store,
        pool::inventory(
            &refill_store,
            &replacement.key,
            2,
            retained_at,
            retained_at + 30_000,
        ),
    )
    .unwrap();
    assert_eq!(retained.ready.len(), 2);
    let expired = tx(
        &refill_store,
        pool::inventory(
            &refill_store,
            &replacement.key,
            2,
            replacement.material_expires_at_ms,
            replacement.material_expires_at_ms + 30_000,
        ),
    )
    .unwrap();
    assert!(expired.ready.is_empty());
    drop(refill_store);
    registration_allocator_campaign(&directory);
    registration_retirement_campaign(&directory);
    let refill_fairness = refill_fairness_campaign(&directory);
    let parallel_refill = parallel_refill_campaign(&directory);
    let refill_backoff = refill_backoff::campaign(&directory);
    let retirement_evidence = serde_json::json!({ "restart": true, "late_ready_rejected": true, "changed_identity_rejected": true, "claimed_job_preserved": true, "other_stock_preserved": true, "fresh_replacement": true });
    let output = std::env::var_os("ML_DSA_E2E_REPORT")
        .map(PathBuf::from)
        .unwrap_or_else(|| std::env::temp_dir().join("ml-dsa-durable-admission-e2e.json"));
    let mut evidence = serde_json::json!({
        "policy": policy,
        "stock_wait": {
            "survives_restart": true,
            "rejects_changed_inputs": true,
            "requires_fresh_claim": true,
        },
        "refill_fairness": refill_fairness,
        "registration_stock_delivery_idempotent":true,"consumed_registration_stock_not_reinstalled":true,"registration_allocator":true,"refill_waits_for_settlement_and_registration":true,"pending_activation_blocks_signing":true,"pending_activation_survives_restart":true,"stale_activation_commit_rejected":true,"recovery_waits_for_installation":true,"reserved_stock_does_not_trigger_refill":true,"consumption_triggers_refill":true,"preprocessing_capacity_and_restart_replay":true,"paired_publication_has_distinct_single_use_records":true,"expired_preprocessing_uses_fresh_id":true,"expired_producer_publication_rejected":true,"schema":"seams.ml-dsa-durable-admission-e2e.v1","passed":true,"production_eligible":false,"worker_http_routes_exercised":false,"successful_settlement_fences_and_reconciles":true,"interrupted_reservation_orphans_retired":true,"separate_sqlite_stores":4,
        "restart_and_single_use":true,"one_sided_take_failure_burns_both_pools":true,"refill_requests_are_key_scoped":true,"readiness_covers_operation_lifetime":true,"changed_message_replay_rejected":true,"cross_role_open_rejected":true,"prior_aes_suite_rejected":true,
        "cooldown_across_keys_and_restart":true,"five_minute_configuration":true,"disabled_cooldown_preserves_capacity":true,
        "empty_pool_not_charged":true,"partial_write_rollback":true,"recovery_epoch_retires_preparation":true,"recovery_cannot_substitute_public_key":true,
        "concurrent_service_claim_winners":1,"verified_completion_and_restart_replay":true,"scope":"Transactional lifecycle and encrypted storage E2E. Synthetic prepared bytes. Real threshold persistence is covered by the investigation harness. No hosted latency claim."
    });
    evidence["failed_registration_retirement"] = retirement_evidence;
    evidence["parallel_refill"] = parallel_refill;
    evidence["refill_backoff"] = refill_backoff;
    evidence["expiry_and_contention"] = serde_json::json!({
        "preflight_and_empty_wait_leave_capacity_free": true,
        "ready_wallet_claims_while_other_wallet_waits": true,
        "untouched_stock_survives_ten_minutes_and_still_expires": true,
    });
    std::fs::write(&output, serde_json::to_vec_pretty(&evidence).unwrap()).unwrap();
    drop(a);
    drop(b);
    drop(router);
    std::fs::remove_dir_all(directory).unwrap();
    eprintln!("ML-DSA lifecycle evidence: {}", output.display());
}

fn parallel_refill_campaign(directory: &Path) -> serde_json::Value {
    let path = directory.join("parallel-refill.sqlite");
    let router = Db::open(&path);
    let policy = Policy::parse(r#"{"wallet_cooldown":{"mode":"enabled","interval_ms":60000},"max_active_operations":1,"max_active_preparations":2,"operation_timeout_ms":30000,"candidate_group_size":2,"preparation_group_size":4,"minimum_ready_batches":8,"refill_target_batches":16}"#).unwrap();
    let a = key("parallel-a");
    let b = key("parallel-b");
    let c = key("parallel-c");
    for key in [&a, &b, &c] {
        activate(&router, key);
    }
    let m::refill::Claim::Acquired { job: first } = tx(
        &router,
        m::refill::claim(&router, &policy, a.clone(), m::refill::Groups::Two, 1_000),
    )
    .unwrap() else {
        panic!("Missing first slot")
    };
    let m::refill::Claim::Acquired { job: second } = tx(
        &router,
        m::refill::claim(&router, &policy, b.clone(), m::refill::Groups::Two, 1_001),
    )
    .unwrap() else {
        panic!("Missing second slot")
    };
    assert_ne!(first.producer_slot, second.producer_slot);
    assert_ne!(
        first.producer_slot.namespace(),
        second.producer_slot.namespace()
    );
    assert!(tx(&router, m::refill::check(&router, &first, 1_002)).unwrap());
    assert!(tx(&router, m::refill::check(&router, &second, 1_002)).unwrap());
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(&router, &policy, a.clone(), m::refill::Groups::Two, 1_002)
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(&router, &policy, c.clone(), m::refill::Groups::Two, 1_003)
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    // Restart preserves both leases. A one-slot policy cannot overbook the other slot.
    drop(router);
    let router = Db::open(&path);
    let wake = tx(
        &router,
        m::refill::finish(
            &router,
            &policy,
            &first,
            m::refill::Outcome::Published,
            1_004,
        ),
    )
    .unwrap();
    assert_eq!(wake.first(), Some(&c));
    assert!(tx(&router, m::refill::check(&router, &second, 1_004)).unwrap());
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                c.clone(),
                m::refill::Groups::Two,
                1_005
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let m::refill::Claim::Acquired { job: replacement } = tx(
        &router,
        m::refill::claim(&router, &policy, c.clone(), m::refill::Groups::Two, 1_006),
    )
    .unwrap() else {
        panic!("Missing reused slot")
    };
    assert_eq!(replacement.producer_slot, first.producer_slot);
    assert!(tx(
        &router,
        m::refill::finish(
            &router,
            &policy,
            &first,
            m::refill::Outcome::Published,
            1_007
        )
    )
    .unwrap()
    .is_empty());
    assert!(tx(&router, m::refill::check(&router, &replacement, 1_007)).unwrap());
    let mut changed = second.clone();
    changed.producer_slot = first.producer_slot;
    assert!(!tx(&router, m::refill::check(&router, &changed, 1_007)).unwrap());
    assert!(tx(
        &router,
        m::refill::finish(
            &router,
            &policy,
            &changed,
            m::refill::Outcome::Published,
            1_007
        )
    )
    .unwrap()
    .is_empty());
    let mut recovered = b.clone();
    recovered.epoch += 1;
    activate(&router, &recovered);
    assert!(!tx(&router, m::refill::check(&router, &second, 1_008)).unwrap());
    assert!(tx(&router, m::refill::check(&router, &replacement, 1_008)).unwrap());
    tx(
        &router,
        m::refill::finish(
            &router,
            &policy,
            &second,
            m::refill::Outcome::Published,
            1_009,
        ),
    )
    .unwrap();
    assert!(tx(&router, m::refill::check(&router, &replacement, 1_009)).unwrap());
    // Decode the existing primary storage format at its persistence boundary.
    let mut stored = serde_json::to_value(&replacement).unwrap();
    stored.as_object_mut().unwrap().remove("producer_slot");
    tx(&router, router.put("preprocessing-active", &stored)).unwrap();
    assert!(tx(&router, m::refill::check(&router, &replacement, 1_010)).unwrap());
    serde_json::json!({"two_distinct_slots":true,"one_job_per_key":true,"third_job_waits":true,"restart":true,"serial_reconfiguration_drains":true,"stale_finish_preserves_successor":true,"changed_slot_rejected":true,"recovery_fences_only_its_key":true,"primary_storage_boundary":true,"per_wallet_target_candidates":32})
}

fn refill_fairness_campaign(directory: &Path) -> serde_json::Value {
    let path = directory.join("fair-refill.sqlite");
    let router = Db::open(&path);
    let a = key("fair-a");
    let b = key("fair-b");
    let c = key("fair-c");
    for key in [&a, &b, &c] {
        activate(&router, key);
    }
    let first = refill_turn(&router, &a, 1_000);
    for now in 1_001..1_006 {
        assert!(matches!(
            tx(
                &router,
                m::refill::claim(
                    &router,
                    &Policy::default(),
                    a.clone(),
                    m::refill::Groups::One,
                    now
                )
            )
            .unwrap(),
            m::refill::Claim::Busy { .. }
        ));
    }
    for (key, now) in [(&b, 1_006), (&c, 1_007), (&b, 1_008)] {
        assert!(matches!(
            tx(
                &router,
                m::refill::claim(
                    &router,
                    &Policy::default(),
                    key.clone(),
                    m::refill::Groups::One,
                    now
                )
            )
            .unwrap(),
            m::refill::Claim::Busy { .. }
        ));
    }
    drop(router);
    let router = Db::open(&path);
    // The first settlement and its lost-reply retry return the same wake hints.
    for _ in 0..2 {
        assert_eq!(
            tx(
                &router,
                m::refill::finish(
                    &router,
                    &Policy::default(),
                    &first,
                    m::refill::Outcome::Published,
                    1_009
                )
            )
            .unwrap(),
            vec![b.clone(), a.clone()]
        );
    }
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                a.clone(),
                m::refill::Groups::One,
                1_009
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let second = refill_turn(&router, &b, 1_010);
    assert_ne!(first.batch, second.batch);
    tx(&router, m::refill::withdraw(&router, &c)).unwrap();
    assert!(tx(&router, m::refill::check(&router, &second, 1_011)).unwrap());
    assert_eq!(
        tx(
            &router,
            m::refill::finish(
                &router,
                &Policy::default(),
                &second,
                m::refill::Outcome::Published,
                1_012
            )
        )
        .unwrap(),
        vec![a.clone(), b.clone()]
    );
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                b.clone(),
                m::refill::Groups::One,
                1_012
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let third = refill_turn(&router, &a, 1_013);
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                c.clone(),
                m::refill::Groups::One,
                1_014
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));

    let mut recovered_b = b.clone();
    recovered_b.epoch += 1;
    activate(&router, &recovered_b);
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                recovered_b.clone(),
                m::refill::Groups::One,
                1_015
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    tx(&router, m::refill::withdraw(&router, &b)).unwrap();
    let mut installing_c = c.clone();
    installing_c.epoch += 1;
    tx(
        &router,
        admission::authorize_key(
            &router,
            admission::KeyActivation {
                key: installing_c.clone(),
                ceremony_id: [44; 32],
                manifest_digest: [45; 32],
            },
        ),
    )
    .unwrap();
    assert_eq!(
        tx(
            &router,
            m::refill::finish(
                &router,
                &Policy::default(),
                &third,
                m::refill::Outcome::Published,
                1_016
            )
        )
        .unwrap(),
        vec![recovered_b.clone(), a.clone()]
    );
    let fourth = refill_turn(&router, &recovered_b, 1_016);
    assert_eq!(fourth.key.epoch, 2);
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                a.clone(),
                m::refill::Groups::One,
                1_017
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    activate(&router, &installing_c);
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                installing_c.clone(),
                m::refill::Groups::One,
                1_018
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    assert!(matches!(
        tx(
            &router,
            m::refill::claim(
                &router,
                &Policy::default(),
                installing_c.clone(),
                m::refill::Groups::One,
                30_000
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    assert_eq!(
        tx(
            &router,
            m::refill::finish(
                &router,
                &Policy::default(),
                &fourth,
                m::refill::Outcome::Published,
                32_000
            )
        )
        .unwrap(),
        vec![installing_c.clone(), recovered_b.clone()]
    );
    let fifth = refill_turn(&router, &installing_c, 32_000);
    let mut waiting = Vec::new();
    for index in 0..66 {
        let key = key(&format!("bounded-waiter-{index}"));
        activate(&router, &key);
        assert!(matches!(
            tx(
                &router,
                m::refill::claim(
                    &router,
                    &Policy::default(),
                    key.clone(),
                    m::refill::Groups::One,
                    32_001 + index
                )
            )
            .unwrap(),
            m::refill::Claim::Busy { .. }
        ));
        waiting.push(key);
    }
    let entries: Vec<serde_json::Value> = tx(&router, router.get("preprocessing-waiting"))
        .unwrap()
        .unwrap();
    assert_eq!(entries.len(), 64);
    assert_eq!(
        tx(
            &router,
            m::refill::finish(
                &router,
                &Policy::default(),
                &fifth,
                m::refill::Outcome::Published,
                32_100
            )
        )
        .unwrap(),
        vec![waiting[0].clone(), installing_c.clone()]
    );
    let sixth = refill_turn(&router, &waiting[0], 32_100);
    assert!(tx(
        &router,
        m::refill::finish(
            &router,
            &Policy::default(),
            &fifth,
            m::refill::Outcome::Published,
            32_101
        )
    )
    .unwrap()
    .is_empty());
    assert!(tx(&router, m::refill::check(&router, &sixth, 32_101)).unwrap());
    let grants = [first, second, third, fourth, fifth, sixth];
    let mut batches = std::collections::HashSet::new();
    for job in &grants {
        assert!(batches.insert(job.batch));
    }
    serde_json::json!({
        "scope": "SQLite lifecycle E2E with trusted fixture activations and simulated clocks. Worker E2Es separately verify real private preparation and signatures.",
        "active_owner_cannot_requeue": true,
        "renewal_preserves_turn": true,
        "queue_survives_restart": true,
        "full_key_withdrawal_preserves_lease": true,
        "inactive_and_expired_heads_pruned": true,
        "old_epoch_withdrawal_preserves_new_epoch": true,
        "stale_settlement_preserves_new_lease": true,
        "wake_targets_follow_fifo": true,
        "idle_settlement_replays_hints": true,
        "superseded_settlement_returns_no_hints": true,
        "bounded_waiting_keys": entries.len(),
        "distinct_grant_batches": batches.len(),
        "grants": grants,
    })
}

fn refill_turn(router: &Db, key: &KeyScope, now: u64) -> m::refill::Job {
    match tx(
        router,
        m::refill::claim(
            router,
            &Policy::default(),
            key.clone(),
            m::refill::Groups::One,
            now,
        ),
    )
    .unwrap()
    {
        m::refill::Claim::Acquired { job } => job,
        other => panic!("The queued refill turn was not granted: {other:?}"),
    }
}

fn registration_retirement_campaign(directory: &Path) {
    use m::registration::{self, PreparationRetirement};
    let path = directory.join("registration-retirement.sqlite");
    let db = Db::open(&path);
    let input = registration_request("retirement-wallet", 33);
    let scope = registration::scope(&input.wallet).unwrap();
    let retained = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 100),
    )
    .unwrap();
    for role in [Participant::A, Participant::B] {
        tx(&db, registration::ready(&db, &retained, role, 101)).unwrap();
    }
    let failed = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 102),
    )
    .unwrap();
    tx(&db, registration::ready(&db, &failed, Participant::A, 103)).unwrap();
    let mut changed = failed.clone();
    changed.expires_at += 1;
    assert!(tx(&db, registration::retire_preparation(&db, &changed)).is_err());
    assert!(tx(&db, registration::check_job(&db, &failed, 104)).unwrap());
    assert_eq!(
        tx(&db, registration::retire_preparation(&db, &failed)).unwrap(),
        PreparationRetirement::Retired
    );
    drop(db);
    let db = Db::open(&path);
    assert_eq!(
        tx(&db, registration::retire_preparation(&db, &failed)).unwrap(),
        PreparationRetirement::AlreadyRetired
    );
    assert!(!tx(&db, registration::check_job(&db, &failed, 105)).unwrap());
    for role in [Participant::A, Participant::B] {
        assert!(tx(&db, registration::ready(&db, &failed, role, 105)).is_err());
    }
    let replacement = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 106),
    )
    .unwrap();
    assert_ne!(replacement.id, failed.id);
    tx(&db, registration::retire_preparation(&db, &failed)).unwrap();
    assert!(tx(&db, registration::check_job(&db, &replacement, 107)).unwrap());
    assert_eq!(
        tx(&db, registration::retire_preparation(&db, &replacement)).unwrap(),
        PreparationRetirement::Retired
    );
    // The other ready entry survives removal of the exact failed job.
    let claim = match tx(
        &db,
        registration::claim(&db, input, [7; 32], [8; 32], 4, 108),
    )
    .unwrap()
    {
        registration::Decision::Admitted { claim } => claim,
        _ => panic!("Retirement removed unrelated ready stock"),
    };
    assert_eq!(claim.job, retained);
    assert_eq!(
        tx(&db, registration::retire_preparation(&db, &retained)).unwrap(),
        PreparationRetirement::Claimed
    );
    assert!(tx(&db, registration::check_claim(&db, &claim, 109)).unwrap());
    let completed = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 110),
    )
    .unwrap();
    for role in [Participant::A, Participant::B] {
        tx(&db, registration::ready(&db, &completed, role, 111)).unwrap();
    }
    assert_eq!(
        tx(&db, registration::retire_preparation(&db, &completed)).unwrap(),
        PreparationRetirement::Retired
    );
    assert!(tx(
        &db,
        registration::ready(&db, &completed, Participant::B, 112)
    )
    .is_err());
}

fn registration_allocator_campaign(directory: &std::path::Path) {
    use m::registration;
    let path = directory.join("registration-allocator.sqlite");
    let db = Db::open(&path);
    let input = registration_request("registration-wallet", 1);
    let scope = registration::scope(&input.wallet).unwrap();
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, input.clone(), [7; 32], [8; 32], 4, 100)
        )
        .unwrap(),
        registration::Decision::Unavailable { .. }
    ));
    let job = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 100),
    )
    .unwrap();
    assert!(tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 101)
    )
    .is_err());
    tx(&db, registration::ready(&db, &job, Participant::A, 102)).unwrap();
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, input.clone(), [7; 32], [8; 32], 4, 103)
        )
        .unwrap(),
        registration::Decision::Unavailable { .. }
    ));
    tx(&db, registration::ready(&db, &job, Participant::B, 104)).unwrap();
    drop(db);
    let db = Db::open(&path);
    for (layout, groups) in [([9; 32], 4), ([8; 32], 8)] {
        assert!(matches!(
            tx(
                &db,
                registration::claim(&db, input.clone(), [7; 32], layout, groups, 105)
            )
            .unwrap(),
            registration::Decision::Unavailable { .. }
        ));
    }
    let claim = match tx(
        &db,
        registration::claim(&db, input.clone(), [7; 32], [8; 32], 4, 105),
    )
    .unwrap()
    {
        registration::Decision::Admitted { claim } => claim,
        _ => panic!("Ready registration was not admitted"),
    };
    assert_eq!(claim.job, job);
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, input.clone(), [7; 32], [8; 32], 4, 106)
        )
        .unwrap(),
        registration::Decision::Existing {
            operation: registration::Operation::Running { .. }
        }
    ));
    let mut changed = input.clone();
    changed.epoch = 2;
    assert!(tx(
        &db,
        registration::claim(&db, changed, [7; 32], [8; 32], 4, 106)
    )
    .is_err());
    assert!(!tx(&db, registration::check_job(&db, &job, 106)).unwrap());
    let refill_key = key("registration-refill");
    activate(&db, &refill_key);
    assert!(matches!(
        tx(
            &db,
            m::refill::claim(
                &db,
                &Policy::default(),
                refill_key,
                m::refill::Groups::One,
                107
            )
        )
        .unwrap(),
        m::refill::Claim::Busy { .. }
    ));
    let next = tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 107),
    )
    .unwrap();
    tx(&db, registration::ready(&db, &next, Participant::A, 108)).unwrap();
    tx(&db, registration::ready(&db, &next, Participant::B, 108)).unwrap();
    let other = registration_request("registration-other", 2);
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, other.clone(), [7; 32], [8; 32], 4, 109)
        )
        .unwrap(),
        registration::Decision::Unavailable { .. }
    ));
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, input, [7; 32], [8; 32], 4, claim.deadline)
        )
        .unwrap(),
        registration::Decision::Existing {
            operation: registration::Operation::Failed
        }
    ));
    assert!(!tx(&db, registration::check_claim(&db, &claim, claim.deadline)).unwrap());
    assert!(matches!(
        tx(
            &db,
            registration::claim(&db, other, [7; 32], [8; 32], 4, claim.deadline)
        )
        .unwrap(),
        registration::Decision::Admitted { .. }
    ));
    for ordinal in 0..4 {
        let ready = tx(
            &db,
            registration::prepare(&db, scope, [7; 32], [8; 32], 4, 40_000 + ordinal),
        )
        .unwrap();
        tx(
            &db,
            registration::ready(&db, &ready, Participant::A, 40_010 + ordinal),
        )
        .unwrap();
        tx(
            &db,
            registration::ready(&db, &ready, Participant::B, 40_010 + ordinal),
        )
        .unwrap();
    }
    assert!(tx(
        &db,
        registration::prepare(&db, scope, [7; 32], [8; 32], 4, 40_100)
    )
    .is_err());
}
fn registration_request(wallet: &str, operation: u8) -> m::registration::Request {
    let encrypted = serde_json::json!({"encapsulated_key":vec![0u8;32],"ciphertext":vec![0u8;80]});
    m::registration::Request {
        wallet: key(wallet).wallet,
        key_id: id("near"),
        epoch: 1,
        operation: [operation; 32],
        continuity: m::registration::Continuity::Create,
        input_a: serde_json::from_value(encrypted.clone()).unwrap(),
        input_b: serde_json::from_value(encrypted).unwrap(),
    }
}

struct FixtureRng;
impl rand_core::RngCore for FixtureRng {
    fn next_u32(&mut self) -> u32 {
        let mut bytes = [0; 4];
        self.fill_bytes(&mut bytes);
        u32::from_le_bytes(bytes)
    }
    fn next_u64(&mut self) -> u64 {
        let mut bytes = [0; 8];
        self.fill_bytes(&mut bytes);
        u64::from_le_bytes(bytes)
    }
    fn fill_bytes(&mut self, bytes: &mut [u8]) {
        getrandom::getrandom(bytes).unwrap();
    }
}
impl rand_core::CryptoRng for FixtureRng {}

fn aes_envelope(binding: &sealing::Binding, seed: &[u8; 32], domain: &[u8]) -> sealing::Sealed {
    use base64::Engine;
    use hpke_ng::{Aes256Gcm, DhKemX25519HkdfSha256, HkdfSha256, Hpke, Kem};
    type IncompatibleCipher = Hpke<DhKemX25519HkdfSha256, HkdfSha256, Aes256Gcm>;
    let (secret, public) = DhKemX25519HkdfSha256::derive_key_pair(seed).unwrap();
    let (enc, ciphertext) = IncompatibleCipher::seal_auth(
        &mut FixtureRng,
        &public,
        domain,
        &m::digest(domain, binding).unwrap(),
        &[8; 100],
        &secret,
    )
    .unwrap();
    serde_json::from_value(serde_json::json!({
        "encapsulated_key": enc.as_ref(),
        "ciphertext_b64u": base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(ciphertext),
    }))
    .unwrap()
}
