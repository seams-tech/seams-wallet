"""Retain a failed driver cohort and restore the same reserve before any repeat."""
import json
from pathlib import Path
import subprocess
import time
from run_control import BASE, FROZEN, control

name = 'control-settled'
folder = BASE / 'cloud-driver' / name
window = json.loads((folder / 'start.json').read_text())
while time.time() * 1000 < window['endAtMs'] + 45000:
    time.sleep(10)
result = subprocess.run(['node', str(FROZEN / 'tests/e2e/ml-dsa-cloud-load.e2e.mjs'), 'collect', str(BASE), name],
                        cwd=FROZEN, capture_output=True, text=True)
(folder / 'collect-failure.log').write_text(result.stdout + result.stderr)
client = json.loads((folder / 'client.json').read_text())
assert result.returncode == 1 and not client['functionalPassed']
assert any(row['error'] == 'Interrupted request has an unknown server outcome' for row in client['errors'])
print(json.dumps({'stage': 'failed_control_retained', 'verified_signatures': client['successfulSignatures'], 'errors': client['errors']}), flush=True)
control('stock', name + '-final', 8, window['endAtMs'])
control('traces', name)
result = subprocess.run(['python3', str(FROZEN / 'tools/ml-dsa-investigation/research/summarize_capacity.py'),
                         str(folder / 'client.json'), str(folder / 'traces.json'), str(BASE / (name + '-campaign.json')), str(folder / 'summary.json')],
                        cwd=FROZEN, capture_output=True, text=True)
(folder / 'summary-failed.log').write_text(result.stdout + result.stderr)
assert result.returncode == 0
print(json.dumps({'stage': 'failed_control_restored'}), flush=True)
