import assert from 'node:assert/strict';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
const base = process.argv[2];
assert.ok(base, 'Supply the extracted evidence directory');
let signatures = 0;
for (const cohort of ['local-two', 'cloud-control', 'cloud-four', 'cloud-eight']) {
  const client = JSON.parse(await readFile(join(base, 'cohorts', cohort, 'client.json'), 'utf8'));
  for (const wallet of client.wallets) {
    const bytes = Buffer.from(wallet.publicKeyHex, 'hex');
    assert.equal(bytes.length, 1952);
    assert.deepEqual(Array.from(createHash('sha256').update(bytes).digest()), wallet.key.public_key_digest);
    const key = createPublicKey({ key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes]), format: 'der', type: 'spki' });
    for (const row of client.requests) {
      if (row.wallet === wallet.index && row.verified) {
        const message = Buffer.from(row.messageHex, 'hex');
        const signature = Buffer.from(row.signatureHex, 'hex');
        assert.equal(verify(null, message, key, signature), true);
        const changed = Buffer.from(message);
        changed[0] ^= 1;
        assert.equal(verify(null, changed, key, signature), false);
        signatures += 1;
      }
    }
  }
}
console.log(JSON.stringify({ signaturesVerified: signatures, changedMessagesRejected: signatures }));
