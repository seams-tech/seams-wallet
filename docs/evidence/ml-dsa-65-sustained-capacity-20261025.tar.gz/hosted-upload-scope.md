# Sustained ML-DSA refill campaign

Create these six temporary Workers and upload the exact test credential payloads below.
Gateway access and internal-service authentication use separate fresh tokens.
Each participant and its preparer receive only that participant’s fresh storage key.
These credentials contain no production wallet, account, Google, or recovery-signing credentials.
The Workers use the same binaries as the completed hosted lifecycle qualification.
Policy: 60-second wallet cooldown, one active signing operation, prepare four candidates, consume two, 16 ready candidates for admission, 32 candidates per wallet.
The campaign measures the private authenticated Worker path. Browser UI, Console admission, and chain submission are excluded.
All temporary Workers and their synthetic Durable Object namespaces will be removed after evidence collection.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-load-1025-78bd57-router | 2789565d810ad73c9fcfc6a4a166074042b5935d06508d10d1d7bdd1796a56ab |
| ml-dsa-load-1025-78bd57-a | 9cf2eff4877a88e78f1226a30ec6aafe7b5bf28043e93be7562038fda0bb03e2 |
| ml-dsa-load-1025-78bd57-b | 741e2a5957144d87f1779388ea9d7e96910fb4ebbce8339f7fc7efafcc699e90 |
| ml-dsa-load-1025-78bd57-preparer-a | 9cf2eff4877a88e78f1226a30ec6aafe7b5bf28043e93be7562038fda0bb03e2 |
| ml-dsa-load-1025-78bd57-preparer-b | 741e2a5957144d87f1779388ea9d7e96910fb4ebbce8339f7fc7efafcc699e90 |
| ml-dsa-load-1025-78bd57-front | 2789565d810ad73c9fcfc6a4a166074042b5935d06508d10d1d7bdd1796a56ab |
