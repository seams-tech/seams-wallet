import datetime,hashlib,json,pathlib,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent
SCOPE=json.loads((BASE/'scope.json').read_text());ROOT=pathlib.Path(SCOPE['root'])
PHASE=sys.argv[1];assert PHASE in ['preflight','bootstrap','credentials','release','delete']
file=BASE/(PHASE+'-receipt.json');receipt=json.loads(file.read_text()) if file.exists() else []
cleanup_order=['preparer-a','preparer-b','a','b','router','front']
workers=sorted(SCOPE['workers'],key=lambda worker:cleanup_order.index(worker['role'])) if PHASE=='delete' else SCOPE['workers']
for worker in workers:
 role=worker['role'];name=worker['name']
 if any(row['worker']==name and row['passed'] for row in receipt):continue
 config=BASE/(role+'.json');assert hashlib.sha256(config.read_bytes()).hexdigest()==worker['config_sha256']
 assert json.loads(config.read_text())['name']==name
 if PHASE!='delete':
  assert hashlib.sha256((BASE/worker['payload']).read_bytes()).hexdigest()==worker['credential_sha256']
  main=pathlib.Path(json.loads(config.read_text())['main'])
  assert hashlib.sha256((main.parent.parent/'index_bg.wasm').read_bytes()).hexdigest()==worker['wasm_sha256']
 if PHASE=='preflight':args=['deployments','list','--config',str(config),'--json']
 elif PHASE=='bootstrap':args=['deploy','--config',str(BASE/(role+'-bootstrap.json'))]
 elif PHASE=='credentials':args=['secret','bulk',str(BASE/worker['payload']),'--config',str(config)]
 elif PHASE=='release':args=['deploy','--config',str(config)]
 else:args=['delete','--config',str(config),'--force']
 result=subprocess.run(['pnpm','exec','wrangler',*args],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 output=result.stdout.decode();(BASE/(role+'-'+PHASE+'.log')).write_text(output)
 passed=result.returncode==0
 if PHASE=='preflight':passed=result.returncode!=0 and any(marker in output for marker in ['10007','Worker does not exist','Could not find Worker'])
 receipt.append({'worker':name,'phase':PHASE,'passed':passed,'exit_code':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});file.write_text(json.dumps(receipt,indent=2)+'\n')
 print(role,PHASE,'passed' if passed else 'FAILED',flush=True)
 if not passed:raise SystemExit(1)
if PHASE=='release':
 versions={}
 for worker in SCOPE['workers']:
  result=subprocess.run(['pnpm','exec','wrangler','deployments','list','--config',str(BASE/(worker['role']+'.json')),'--json'],cwd=ROOT,capture_output=True,text=True,check=True)
  latest=max(json.loads(result.stdout),key=lambda row:row['created_on']);assert len(latest['versions'])==1 and latest['versions'][0]['percentage']==100
  versions[worker['role']]=latest['versions'][0]['version_id']
 (BASE/'versions.json').write_text(json.dumps(versions,indent=2)+'\n')
if PHASE=='delete':
 for worker in SCOPE['workers']:(BASE/worker['payload']).unlink(missing_ok=True)
 (BASE/'gateway-token').unlink(missing_ok=True)
