import copy,hashlib,json,os,pathlib,secrets,shutil,subprocess
BASE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
TEMPLATES=pathlib.Path('/private/tmp/ml-dsa-modularity-hosted-20261023/separated/hosted')
ROLES=['router','a','b','preparer-a','preparer-b','front']
os.umask(0o077)
assert not (BASE/'scope.json').exists(), 'Preserve the reviewed deployment scope'
prefix='ml-dsa-load-1025-'+secrets.token_hex(3)
policy={'wallet_cooldown':{'mode':'enabled','interval_ms':60000},'max_active_operations':1,'operation_timeout_ms':30000,'candidate_group_size':2,'preparation_group_size':4,'minimum_ready_batches':8,'refill_target_batches':16}
first=BASE/'wallet-1';first.mkdir()
result=subprocess.run([str(ROOT/'tools/ml-dsa-investigation/target/release/ml-dsa-investigation'),'worker-registration-keys',str(first)],capture_output=True,check=True)
assert json.loads(result.stdout)['ready']
for i in range(2,9):
 folder=BASE/f'wallet-{i}';folder.mkdir()
 for name in ['a-kek','b-kek','publics.json']:shutil.copy2(first/name,folder/name)
gateway=secrets.token_hex(32);internal=secrets.token_hex(32)
(BASE/'gateway-token').write_text(gateway+'\n')
old_prefix='ml-dsa-mod-1023-372dff-separated'
workers=[]
expected=json.loads((ROOT/'docs/evidence/ml-dsa-65-final-hosted-lifecycle-20261025.json').read_text())['workerModules']['receipts']
for role in ROLES:
 config=json.loads((TEMPLATES/(role+'.json')).read_text())
 profile='standard' if role=='front' else 'ml-dsa'
 build_role={'a':'deriver-a','b':'deriver-b','preparer-a':'deriver-a','preparer-b':'deriver-b','front':'router'}.get(role,role)
 build=ROOT/'crates/router-ab-cloudflare/build'
 if profile=='ml-dsa':build=build/profile
 build=build/build_role
 config['main']=str(build/'worker/shim.mjs');config['name']=prefix+'-'+role
 config['vars']['ML_DSA_ADMISSION_POLICY']=json.dumps(policy,separators=(',',':'))
 for item in config.get('services',[]):item['service']=item['service'].replace(old_prefix,prefix)
 for item in config.get('durable_objects',{}).get('bindings',[]):
  if 'script_name' in item:item['script_name']=item['script_name'].replace(old_prefix,prefix)
 config['workers_dev']=role=='front';config['preview_urls']=False
 for key in ['build','env']:config.pop(key,None)
 (BASE/(role+'.json')).write_text(json.dumps(config,indent=2)+'\n')
 initial=copy.deepcopy(config);initial.pop('services',None)
 if 'durable_objects' in initial:
  initial['durable_objects']['bindings']=[item for item in initial['durable_objects']['bindings'] if 'script_name' not in item]
 (BASE/(role+'-bootstrap.json')).write_text(json.dumps(initial,indent=2)+'\n')
 payload={'INTERNAL_AUTH':internal}
 if role in ['front','router']:payload['ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET']=gateway
 else:payload['ROLE_KEK']=(first/('a-kek' if role.endswith('a') else 'b-kek')).read_text()
 data=(json.dumps(payload,indent=2)+'\n').encode();(BASE/(role+'-secrets.json')).write_bytes(data)
 wasm=(build/'index_bg.wasm').read_bytes();digest=hashlib.sha256(wasm).hexdigest()
 matching=next(item for item in expected if item['profile']==profile and item['role']==build_role)
 assert matching['sha256']==digest, 'Worker differs from the final hosted qualification'
 workers.append({'role':role,'name':config['name'],'payload':role+'-secrets.json','credential_sha256':hashlib.sha256(data).hexdigest(),'config_sha256':hashlib.sha256((BASE/(role+'.json')).read_bytes()).hexdigest(),'wasm_sha256':digest,'wasm_bytes':len(wasm)})
scope={'purpose':'Sustained 2, 4 and 8-wallet refill tests with unchanged production policy. Synthetic keys only.','runtime_commit':'c0292b42','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'prefix':prefix,'root':str(ROOT),'build_root':str(ROOT/'crates/router-ab-cloudflare/build/ml-dsa'),'router_url':f'https://{prefix}-front.n6378056.workers.dev','policy':policy,'workers':workers,'cohorts':[{'wallets':2,'duration_ms':600000},{'wallets':4,'duration_ms':720000},{'wallets':8,'duration_ms':1200000}]}
(BASE/'scope.json').write_text(json.dumps(scope,indent=2)+'\n')
rows=['# Sustained ML-DSA refill campaign','','Create these six temporary Workers and upload the exact test credential payloads below.','Gateway access and internal-service authentication use separate fresh tokens.','Each participant and its preparer receive only that participant’s fresh storage key.','These credentials contain no production wallet, account, Google, or recovery-signing credentials.','The Workers use the same binaries as the completed hosted lifecycle qualification.','Policy: 60-second wallet cooldown, one active signing operation, prepare four candidates, consume two, 16 ready candidates for admission, 32 candidates per wallet.','The campaign measures the private authenticated Worker path. Browser UI, Console admission, and chain submission are excluded.','All temporary Workers and their synthetic Durable Object namespaces will be removed after evidence collection.','','| Worker | Credential payload SHA-256 |','| --- | --- |']
for item in workers:rows.append(f"| {item['name']} | {item['credential_sha256']} |")
(BASE/'hosted-upload-scope.md').write_text('\n'.join(rows)+'\n')
print(json.dumps({'workers':6,'prefix':prefix,'scope':str(BASE/'hosted-upload-scope.md'),'cohorts':scope['cohorts']}))
