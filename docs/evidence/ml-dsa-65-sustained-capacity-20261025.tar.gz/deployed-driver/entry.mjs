import Router from "/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/crates/router-ab-cloudflare/build/router/worker/shim.mjs";
import { routeLoadRequest, archiveTail } from "./worker.mjs";
export { LoadWallet, LoadTraceArchive } from "./worker.mjs";
export default class BenchmarkFront extends Router {
  async fetch(request) {
    if (new URL(request.url).pathname.startsWith("/__benchmark/")) return routeLoadRequest(request, this.env);
    return super.fetch(request);
  }
  async tail(events) { await archiveTail(events, this.env); }
}
