import importlib.util
import json
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
spec = importlib.util.spec_from_file_location('campaign', BASE / 'build-and-measure.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)


def main():
    environment = os.environ.copy()
    for label, build in [('ordinary-unprofiled-first', campaign.ORDINARY), ('diagnostic-unprofiled', BASE / 'diagnostic-build'), ('ordinary-unprofiled-return', campaign.ORDINARY)]:
        print(json.dumps({'phase': label, 'status': 'starting'}), flush=True)
        environment['ML_DSA_TEST_BUILD_ROOT'] = str(build)
        campaign.run(['node', str(BASE / 'window.e2e.mjs'), str(BASE / 'fixtures'), str(BASE / f'{label}.json'), '--passive-preparation-observer'], ROOT, f'{label}.log', environment)
        print(json.dumps({'phase': label, 'status': 'passed'}), flush=True)


if __name__ == '__main__':
    main()
