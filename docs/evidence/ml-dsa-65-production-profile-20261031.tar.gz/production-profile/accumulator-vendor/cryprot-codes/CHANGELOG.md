# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.5](https://github.com/robinhundt/CryProt/compare/cryprot-codes-v0.2.4...cryprot-codes-v0.2.5) - 2026-05-27

### Other

- update Cargo.toml dependencies

## [0.2.4](https://github.com/robinhundt/CryProt/compare/cryprot-codes-v0.2.3...cryprot-codes-v0.2.4) - 2026-05-15

### Other

- *(deps)* update libote-codes

## [0.2.3](https://github.com/robinhundt/CryProt/compare/cryprot-codes-v0.2.2...cryprot-codes-v0.2.3) - 2026-04-05

### Other

- update Cargo.toml dependencies

## [0.2.2](https://github.com/robinhundt/CryProt/compare/cryprot-codes-v0.2.1...cryprot-codes-v0.2.2) - 2026-03-05

### Other

- *(rand)* update rand and rand_core to 0.10

## [0.2.1](https://github.com/robinhundt/CryProt/compare/cryprot-codes-v0.2.0...cryprot-codes-v0.2.1) - 2026-01-21

### Other
- update dependencies
