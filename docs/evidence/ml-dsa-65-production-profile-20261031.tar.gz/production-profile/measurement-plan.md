# Production preparation profile — October 31, 2026

Measure real four-candidate preparation before changing its conversion or encoder.
The prior matched hosted campaign leaves host/compiler causes unresolved.
This campaign measures local workerd only. Local samples cannot explain hosted CPU variation without hosted validation.

## Fixed boundaries

- Frozen production source: 24a3dd453. Its runtime source matches the prior hosted campaign.
- Use the existing durable Worker E2E and freshly generated disposable canonical-key fixtures.
- Prepare four candidates, consume two, retain thirty-two candidate capacity and sixteen candidate admission minimum.
- Retain separate role keys, wallet-seed recovery, standard FIPS export, secret erasure, and one-use correlation order.
- No cloud deployment, credential upload, production setting, or production runtime change in this profiling stage.
- Do not delete the previous hosted Workers without the pending explicit deletion approval.

## Ordered measurement

1. Finish native fixture generation and all diagnostic compilation before timing.
2. Run the ordinary production Worker lifecycle with the existing calibrated preparation profiler.
3. Run the temporary no-inline diagnostic copy with the same harness and fixtures.
4. Repeat the ordinary build as a return control if the diagnostic profile or any proposed change informs a conclusion.
5. Preserve failed probes, version/source/build hashes, calibrated profiles, and actual publication/signature artifacts.
6. Attribute samples with exact matching Wasm symbol maps. Separate waits and idle samples from active stack categories.
7. Compare the diagnostic full-reserve boundary with both ordinary controls. Treat diagnostic category shares as perturbed if boundaries change execution.
8. Select a single bounded candidate only if the real profile supports its cost. Verify complete outputs and E2E behavior before hosted qualification.

## Instrument limits

V8 samples contain function stacks and counts. They contain no memory snapshots.
Sampling and no-inline boundaries can change compiler behavior and execution.
Profiler counts are neither billed CPU nor stage durations.
Parent-inclusive categories can conceal erasure in inlined callers.
A local gain is not a hosted throughput gain.

## Failed setup retained

- First baseline launch: historical default fixture directory absent. Classification: environment_or_infrastructure_failure.
- Second launch: historical fixture storage keys removed by earlier cleanup. Classification: environment_or_infrastructure_failure.
- Neither attempt reaches a Worker runtime. Regenerate fixtures through the existing native E2E.

## Independent review control

The independent reviewer requires unprofiled ordinary/diagnostic/ordinary-return controls as well.
Run these after the profiled sequence, without other local compilation or benchmarks.
Report exclusive and inclusive sample totals separately. Never add their overlapping categories.
Preserve the complete profiles rather than only the top-forty leaf summary.

## Accumulator candidate gate, fixed before timing

Ordinary samples place the encoder near one quarter of observed samples.
Its accumulator leaf is the largest distinct encoder function.
Test one isolated Wasm candidate against frozen current production `24a3dd453`.
The candidate adds a dominating public length check, then removes redundant checks from the proven main accumulator branch.
The checked tail, matrix generator, update order, code dimensions, and secret erasure remain unchanged.

Require complete Block/byte equality over the existing shape/seed/configuration corpus.
Require safe rejection of every default dimension below twenty-five in both baseline and candidate.
The initial unsafe prototype lacked this precondition. Independent review rejected it before compilation or timing.
Retain that rejected patch for the review record only.

Run two isolated timing repetitions with alternating per-pair order and the current production control.
Advance to complete Worker comparisons only if both kernel medians improve by at least ten percent.
A smaller kernel difference does not justify additional unsafe production code or a hosted campaign here.
Passing this screen would establish kernel performance only. Hosted complete-job improvement remains required before retaining production code.
