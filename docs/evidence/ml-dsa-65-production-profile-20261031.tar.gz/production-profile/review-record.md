# Independent source review

Reviewer: `/root/review_producer_measurements`, required by `docs/debugging-method.md`.
The reviewer inspected sources and metadata without running competing CPU workloads.

The profiling patch adds no logs, exports, secret operands, or memory snapshots.
Its no-inline boundaries can change optimization. Unprofiled controls are required.
Exact build symbol maps and raw profiles must remain in the evidence.
Exclusive sample categories and inclusive function membership must stay separate.

The initial accumulator prototype has a genuine unsafe-proof defect.
Dimensions below twenty-five can underflow the unchecked main split in release.
The candidate could write beyond its slice where the safe baseline traps.
The defect was found before compilation or timing. Production source is unchanged.
The retained rejected patch reconstructs that uncompiled source for review only.

The repaired candidate asserts `len > accumulator_size` before subtraction.
For the modified fixed-24 branch, `main = len - 25` is defined.
The unchecked branch requires `i < main`.
Clearing low bits preserves a mask containing bits zero through twenty-four only.
Therefore, `offset <= i + 25 < len`. The checked tail still wraps once.
Public matrix state controls every address and branch. Secret values only enter XOR results.
The reviewer accepts this source proof for benchmarking, without claiming JIT constant-time behavior or performance.

The copied screen initially inherits an older baseline default.
The measured control is changed to frozen current production `24a3dd453`.
This prevents crediting an already-retained accumulator optimization to the new candidate.
One hundred rejection checks cover sizes zero through twenty-four, both paths, and Block/byte coefficients.
The existing full-output corpus covers transition sizes, refill boundaries, production dimensions, seeds, and one/two-pass configurations.

## Result review

The reviewer independently replays both exact Wasm artifacts.
All 463 complete Block/byte cases and 100 fresh-instance short-input rejections pass for each artifact.
Both raw median pairs and the failed ten-percent gate reproduce exactly.
All six raw role profiles reproduce against their actual matching Wasm bytes and symbol maps.
The focused harness preserves 22,892 prefix bytes after its declared path substitutions.

The first offline verifier covers fifteen top-level signatures.
Review finds six more nested signatures from retained-material recovery.
The final verifier requires both recovery records in each full campaign and covers all twenty-one distinct signatures.
It also checks the three parallel-refill duplicates against their already-verified top-level records.
Operation identifiers can repeat across independent runs. Distinctness uses signature bytes instead.

The first draft rejects “warmup alone” too broadly.
The final claim rejects only one cold invocation or initial schedule-cache miss as a sole explanation.
Persistent first-touch and compiler-history effects remain unresolved.
