import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent
LABELS = ['ordinary-first', 'diagnostic', 'ordinary-return', 'ordinary-unprofiled-first', 'diagnostic-unprofiled', 'ordinary-unprofiled-return']


def read(path):
    return json.loads(path.read_text())


def main():
    manifest = read(BASE / 'manifest.json')
    for name, expected in manifest['member_sha256'].items():
        assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == expected, name
    source = read(BASE / 'window-source.json')
    original_bytes = (BASE / 'original-harness.mjs').read_bytes()
    window_bytes = (BASE / 'window.e2e.mjs').read_bytes()
    assert hashlib.sha256(original_bytes).hexdigest() == source['production_harness_sha256']
    assert hashlib.sha256(window_bytes).hexdigest() == source['window_harness_sha256']
    root = source['root']
    original = original_bytes.decode()
    original = original.replace("from '../helpers/", f"from '{root}/tests/helpers/")
    original = original.replace("from './ml-dsa-", f"from '{root}/tests/e2e/ml-dsa-")
    original = original.replace("from '../../crates/", f"from '{root}/crates/")
    original = original.replace("const root = resolve(import.meta.dirname, '../..');", f'const root = {root!r};')
    expected_prefix = original[:original.index('  if (!parallelOnly) await runDurableCases(emptyInput);')]
    actual = window_bytes.decode()
    actual_prefix = actual[:actual.index('  observations.initialWindowInventory =')]
    assert expected_prefix == actual_prefix
    expected = read(BASE / 'analysis.json')
    subprocess.run(['python3', str(BASE / 'analyze.py')], check=True, capture_output=True, text=True)
    assert read(BASE / 'analysis.json') == expected
    signatures = read(BASE / 'signature-verification.json')
    subprocess.run(['node', str(BASE / 'verify-signatures.mjs'), *LABELS], check=True, capture_output=True, text=True)
    assert read(BASE / 'signature-verification.json') == signatures
    gains = []
    checks = []
    for label in ['kernel-first', 'kernel-repeat']:
        record = read(BASE / f'{label}.json')
        assert record['baseline_revision'].startswith('24a3dd453')
        medians = []
        for mode in [0, 1]:
            times = [sample['elapsedMs'] for sample in record['samples'] if sample['mode'] == mode]
            assert len(times) == 20
            medians.append(statistics.median(times))
        assert medians == record['medians']
        gains.append(1 - medians[1] / medians[0])
        wasm = BASE / label / 'screen.wasm'
        assert hashlib.sha256(wasm.read_bytes()).hexdigest() == record['wasmSha256']
        with tempfile.TemporaryDirectory(prefix='ml-dsa-profile-replay-') as directory:
            result = Path(directory) / 'checks.json'
            subprocess.run(['node', str(BASE / label / 'run.mjs'), str(wasm), str(result)], check=True, capture_output=True, text=True)
            replayed = read(result)
            assert replayed['passed'] and replayed['checks'] == record['checks'] == 463
            assert replayed['shortInputRejections'] == record['shortInputRejections'] == 100
            assert replayed['wasmSha256'] == record['wasmSha256']
            original = [(row['mode'], row['repetition'], row['checksum']) for row in record['samples']]
            repeated = [(row['mode'], row['repetition'], row['checksum']) for row in replayed['samples']]
            assert original == repeated
        checks.append({'label': label, 'complete_output_cases': 463, 'short_input_rejections': 100})
    decision = read(BASE / 'kernel-decision.json')
    assert gains == decision['gains']
    assert all(gain >= 0.10 for gain in gains) == decision['advance']
    assert decision['advance'] is False
    print(json.dumps({'passed': True, 'member_hashes': len(manifest['member_sha256']), 'standard_signatures': sum(row['signatures'] for row in signatures['results']), 'altered_messages_rejected': sum(row['alteredMessagesRejected'] for row in signatures['results']), 'kernel_checks': checks, 'candidate_retained': False}))


if __name__ == '__main__':
    main()
