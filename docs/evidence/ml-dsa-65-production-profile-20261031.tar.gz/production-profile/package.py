import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
STAGE = BASE / 'evidence/production-profile'
LABELS = ['ordinary-first', 'diagnostic', 'ordinary-return', 'ordinary-unprofiled-first', 'diagnostic-unprofiled', 'ordinary-unprofiled-return']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(name):
    original = BASE / name
    target = STAGE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if original.is_dir():
        shutil.copytree(original, target, dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__'))
    else:
        shutil.copy2(original, target)


def main():
    STAGE.mkdir(parents=True, exist_ok=False)
    names = [
        'measurement-plan.md', 'review-record.md', 'source.json', 'builds.json', 'package.py',
        'boundary-profiling.patch', 'boundary-symbol-check.json', 'boundary-symbol-check-corrected.json', 'analysis.json',
        'analyze.py', 'research', 'symbols', 'verify-signatures.mjs', 'signature-verification.json',
        'native.json', 'native.log', 'bloat.log',
        'prepare.py', 'build-and-measure.py', 'run.log',
        'prepare-window.py', 'original-harness.mjs', 'window.e2e.mjs', 'window-source.json', 'run-unprofiled.py', 'unprofiled.log',
        'prepare-accumulator.py', 'extend-accumulator-screen.py', 'run-accumulator-screen.py',
        'accumulator-candidate.patch', 'accumulator-source.json', 'accumulator-vendor/cryprot-codes',
        'rejected-uncompiled-accumulator.patch', 'rejected-uncompiled-ex-conv.rs',
        'kernel-first.json', 'kernel-first.log', 'kernel-first',
        'kernel-repeat.json', 'kernel-repeat.log', 'kernel-repeat',
        'run-kernel.py', 'kernel.log', 'kernel-decision.json', 'replay.py',
        'README.md', 'independent-results-review.md',
        'baseline.log', 'baseline-fixture-retry.log',
    ]
    for label in LABELS:
        names.extend([f'{label}.json', f'{label}.log'])
    for path in BASE.glob('*.cpuprofile'):
        names.append(path.name)
    for name in names:
        copy(name)
    # Preserve public reference sources; follow no participant key directories.
    private_values = []
    for role in ['a', 'b']:
        raw = (BASE / 'fixtures' / f'{role}-kek').read_text().strip()
        private_values.extend([raw.encode(), raw.rsplit(':', 1)[-1].encode()])
    files = sorted(path for path in STAGE.rglob('*') if path.is_file())
    for path in files:
        value = path.read_bytes()
        assert all(secret not in value for secret in private_values), str(path)
    removed = []
    for role in ['a', 'b']:
        key_path = BASE / 'fixtures' / f'{role}-kek'
        removed.append({'path': str(key_path), 'sha256': digest(key_path)})
        key_path.unlink()
        assert not key_path.exists()
    cleanup = {'scope': 'Only this local campaign disposable storage keys. The earlier hosted fleet and its credentials remain unchanged.',
               'removed_files': removed, 'all_removed': True}
    cleanup_bytes = (json.dumps(cleanup, indent=2) + '\n').encode()
    assert all(secret not in cleanup_bytes for secret in private_values)
    (STAGE / 'local-key-cleanup.json').write_bytes(cleanup_bytes)
    (BASE / 'local-key-cleanup.json').write_bytes(cleanup_bytes)
    files = sorted(path for path in STAGE.rglob('*') if path.is_file())
    manifest = {
        'schema': 'seams.ml-dsa-production-profile-evidence.v1',
        'scope': 'Local workerd preparation profiles and discarded Node-Wasm encoder candidate. No hosted gain or production runtime change.',
        'private_storage_key_scan_matches': 0,
        'member_sha256': {str(path.relative_to(STAGE)): digest(path) for path in files},
    }
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-production-profile-20261031.tar.gz'
    with tarfile.open(archive, 'w:gz') as bundle:
        bundle.add(STAGE, arcname=STAGE.name)
    summary = {
        'schema': manifest['schema'],
        'archive': {'name': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size, 'member_files': len(files) + 1},
        'source_revision': json.loads((BASE / 'source.json').read_text())['revision'],
        'runtime_source_unchanged': True,
        'profiled_runs_passed': 3,
        'unprofiled_windows_passed': 3,
        'standard_signatures_verified': sum(row['signatures'] for row in json.loads((BASE / 'signature-verification.json').read_text())['results']),
        'kernel': json.loads((BASE / 'kernel-decision.json').read_text()),
        'local_first_reserve_ms': {group: {label: row['initial_reserve_refill_ms'] for label, row in rows.items()} for group, rows in json.loads((BASE / 'analysis.json').read_text()).items() if group in ['profiled', 'unprofiled']},
        'limits': ['Samples are not billed CPU.', 'Diagnostic boundaries can perturb compilation and hide inlined work.', 'Kernel improvement misses the predeclared gate and establishes no complete-job or hosted gain.', 'No cloud resources are changed; earlier eight-Worker deletion approval remains pending.'],
    }
    (BASE / 'ml-dsa-65-production-profile-20261031.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary['archive']))


if __name__ == '__main__':
    main()
