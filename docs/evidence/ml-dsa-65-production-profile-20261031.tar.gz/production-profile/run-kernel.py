import json
import os
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')


def main():
    # All Worker timing controls must finish before this CPU workload starts.
    assert json.loads((BASE / 'ordinary-return.json').read_text())['passed']
    assert json.loads((BASE / 'ordinary-unprofiled-return.json').read_text())['passed']
    for label in ['kernel-first', 'kernel-repeat']:
        command = ['python3', str(BASE / 'run-accumulator-screen.py'), str(BASE / f'{label}.json'), '--baseline', '24a3dd453']
        with (BASE / f'{label}.log').open('w') as log:
            subprocess.run(command, cwd=ROOT, env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT, check=True)
        result = json.loads((BASE / f'{label}.json').read_text())
        assert result['passed'] and result['shortInputRejections'] == 100
        print(json.dumps({'phase': label, 'medians_ms': result['medians'], 'passed': True}), flush=True)
    records = [json.loads((BASE / f'{label}.json').read_text()) for label in ['kernel-first', 'kernel-repeat']]
    gains = [1 - result['medians'][1] / result['medians'][0] for result in records]
    decision = {'gate': 'Advance only when both current-control kernel median improvements are at least 10 percent',
                'gains': gains, 'advance': all(gain >= 0.10 for gain in gains),
                'production_source_changed': False, 'hosted_gain_established': False}
    (BASE / 'kernel-decision.json').write_text(json.dumps(decision, indent=2) + '\n')
    print(json.dumps(decision), flush=True)


if __name__ == '__main__':
    main()
