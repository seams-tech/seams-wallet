import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
SOURCE = BASE / 'source'
ORDINARY = Path('/private/tmp/ml-dsa-quiet-producer-20261030/build')


def run(command, cwd, log, environment):
    with (BASE / log).open('w') as output:
        subprocess.run(command, cwd=cwd, env=environment, stdout=output, stderr=subprocess.STDOUT, check=True)


def main():
    # Invoke only after the separately recorded A build exits successfully.
    assert (BASE / 'diagnostic-build/deriver-a/index_bg.wasm').exists()
    environment = os.environ.copy()
    environment['RUSTFLAGS'] = '-C target-feature=+simd128'
    environment['CARGO_TARGET_DIR'] = str(BASE / 'target')
    run(['worker-build', '--release', '--out-dir', str(BASE / 'diagnostic-build/deriver-b'), '--features', 'strict-worker-deriver-b-entrypoint,ml-dsa'],
        SOURCE / 'crates/router-ab-cloudflare', 'build-b.log', environment)
    for role in ['deriver-a', 'deriver-b']:
        run(['node', str(ROOT / 'crates/router-ab-cloudflare/scripts/strip-wasm-debug.mjs'), str(BASE / 'diagnostic-build' / role / 'index_bg.wasm')],
            ROOT, f'strip-{role}.log', environment)
    shutil.copytree(ORDINARY / 'router', BASE / 'diagnostic-build/router')
    artifacts = {}
    for label, build in [('ordinary', ORDINARY), ('diagnostic', BASE / 'diagnostic-build')]:
        artifacts[label] = {}
        for role in ['router', 'deriver-a', 'deriver-b']:
            path = build / role / 'index_bg.wasm'
            artifacts[label][role] = {'wasm_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
    (BASE / 'builds.json').write_text(json.dumps(artifacts, indent=2) + '\n')
    environment.pop('RUSTFLAGS')
    environment.pop('CARGO_TARGET_DIR')
    for label, build in [('ordinary-first', ORDINARY), ('diagnostic', BASE / 'diagnostic-build'), ('ordinary-return', ORDINARY)]:
        print(json.dumps({'phase': label, 'status': 'starting'}), flush=True)
        environment['ML_DSA_TEST_BUILD_ROOT'] = str(build)
        run(['node', 'tests/e2e/ml-dsa-durable-worker.e2e.mjs', str(BASE / 'fixtures'), str(BASE / f'{label}.json'), '--profile-preparation', '--passive-preparation-observer'],
            ROOT, f'{label}.log', environment)
        run(['python3', 'tools/ml-dsa-investigation/research/summarize_preparation_profile.py', str(BASE / f'{label}.json'), str(build), str(BASE / f'{label}-samples.json')],
            ROOT, f'{label}-summary.log', environment)
        print(json.dumps({'phase': label, 'status': 'passed'}), flush=True)


if __name__ == '__main__':
    main()
