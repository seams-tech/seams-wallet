# Production preparation profile replay

Run `python3 replay.py` from this extracted directory.
Python3 and Node with ML-DSA and Wasm SIMD support are required.
The replay makes no external calls and needs no credentials.

The replay verifies every archived member hash.
It reconstructs exclusive sample categories and inclusive function memberships from complete profiles and exact symbol maps.
It independently verifies twenty-one standard signatures and rejects twenty-one altered messages.
It recomputes both original kernel medians and the predeclared advancement gate from raw samples.
It executes both exact compiled Wasm screens again, including complete output comparisons and invalid-dimension rejection.
New replay timings are ignored. They describe the replay host, rather than the original measurements.

Three full profiled Worker lifecycle E2Es pass.
Three focused unprofiled windows use the same activation-through-first-reserve prefix.
Their post-window checks perform real owner-admitted signing, duplicate replay, altered-message rejection, reserve restoration, and participant stock agreement.
`window-source.json` records the adaptation and original source hash.
The full lifecycle fault cases run separately from the first-reserve profiling window.

Each first reserve contains sixteen pairs, or thirty-two candidates.
It uses four-candidate preparation and two-candidate consumption.
These local pool-fill times are neither single-job latency nor hosted registration or signing latency.
The profile contains real protocol work, setup, orchestration, waits, and some idle samples.
Sample percentages are neither elapsed durations nor billed CPU.
No-inline boundaries can change optimization. Two intended boundaries remain merged by the final compiler.
Inlined erasure and copying can remain inside other categories.

The accumulator candidate passes complete output comparisons and short-input checks.
Its two kernel gains fall below the ten-percent gate. It is discarded without a production source change or hosted test.
`rejected-uncompiled-*` preserves the first prototype's missing-length-check counterexample for review only.
That earlier version was never compiled or measured.
The repaired candidate adds a dominating public length check before unchecked access.

The archived source revision and build hashes identify the measured production code.
The production Worker bytes are identified by their recorded hashes and symbol maps, rather than included again here.
Both exact standalone kernel Wasm files are included for output replay.
The copied setup/build scripts retain their original local paths as provenance.
Rebuilding the Worker lifecycle requires the matching repository source and freshly generated disposable fixtures.
Use the existing `prepared-keygen` command with `ML_DSA_WORKER_FIXTURE_DIRECTORY`, then the existing `ml-dsa-durable-worker.e2e.mjs` harness.

No cloud resource changes occur in this campaign.
The earlier eight temporary Workers still await explicit deletion approval.
No participant storage keys or access tokens belong in this archive.

The two local test storage-key files are removed after the archive scan. `local-key-cleanup.json` records only paths and hashes.
