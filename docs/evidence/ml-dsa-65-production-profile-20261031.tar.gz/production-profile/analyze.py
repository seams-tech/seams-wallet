import collections
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'research'))
from summarize_registration_profile import symbol


def category(stack):
    text = '\n'.join(stack)
    if 'zeroize[' in text or ('silent::SecretBlocks as ' in text and '::drop' in text):
        return 'secret_erasure'
    if '::gate_aes::' in text or '::correlation_aes::CorrelationAes' in text:
        return 'private_aes'
    if 'cryprot_codes[' in text:
        if '::fast_aes_rng::' in text:
            return 'encoder_public_rng'
        if '::expander_modd::' in text:
            return 'encoder_public_index_generation'
        if '::expand_simple' in text or '::expander::' in text:
            return 'encoder_expansion_other'
        if '::accumulate' in text:
            return 'encoder_accumulation_other'
        return 'encoder_other'
    if '::silent::triples' in text:
        return 'triple_conversion_other'
    if '::silent::pprf::' in text:
        return 'pprf_other'
    if 'curve25519_dalek[' in text:
        return 'curve_arithmetic'
    if '::prepared::build_layout' in text:
        return 'public_topology'
    if '::prepared::prepare_batch' in text:
        return 'preparation_other'
    if stack[0] == '(idle)':
        return 'idle'
    return 'other'


def summarize(item, symbols):
    profile = item['profile']
    nodes = {node['id']: node for node in profile['nodes']}
    parents = {child: node['id'] for node in nodes.values() for child in node.get('children', [])}
    names = {key: symbol(node['callFrame'], symbols['functions']) for key, node in nodes.items()}
    exclusive = collections.Counter()
    inclusive = collections.Counter()
    leaves = collections.Counter()
    for sample in profile['samples']:
        stack = []
        current = sample
        while current is not None:
            stack.append(names[current])
            current = parents.get(current)
        exclusive[category(stack)] += 1
        leaves[stack[0]] += 1
        # Count membership once per sample, including recursive function names.
        for name in set(stack):
            inclusive[name] += 1
    total = len(profile['samples'])
    return {
        'title': item['title'],
        'total_samples': total,
        'exclusive_categories': {name: {'samples': count, 'percent_all_samples': 100 * count / total} for name, count in exclusive.most_common()},
        'exclusive_leaves': dict(leaves.most_common()),
        'inclusive_functions': dict(inclusive.most_common()),
        'scope': 'Disjoint stack-precedence categories. Inclusive membership overlaps categories and must never be summed. Counts are samples, not CPU milliseconds.',
    }


def main():
    report = {
        'scope': 'Local workerd first-full-reserve window. Diagnostic compiler boundaries can perturb costs. No hosted attribution, speedup, or throughput conclusion.',
        'profiled': {},
        'unprofiled': {},
    }
    for label in ['ordinary-first', 'diagnostic', 'ordinary-return']:
        path = BASE / f'{label}.json'
        record = json.loads(path.read_text())
        assert record['passed'] and record['profilerCalibration']['passed']
        build = BASE / 'symbols' / ('diagnostic' if label == 'diagnostic' else 'ordinary')
        profiles = []
        for item in record['preparationProfile']['profiles']:
            role = item['title'][-1]
            assert role in ['a', 'b']
            wasm = build / f'deriver-{role}' / 'index_bg.wasm'
            symbols = json.loads(Path(str(wasm) + '.names.json').read_text())
            assert symbols['wasmSha256'] == record['workerWasmSha256'][f'deriver-{role}']
            profiles.append(summarize(item, symbols))
        report['profiled'][label] = {
            'artifact_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'initial_reserve_refill_ms': record['initialReserveRefillMs'],
            'activation_to_full_reserve_ms': record['activationToFullReserveMs'],
            'profiles': profiles,
        }
    for label in ['ordinary-unprofiled-first', 'diagnostic-unprofiled', 'ordinary-unprofiled-return']:
        path = BASE / f'{label}.json'
        record = json.loads(path.read_text())
        assert record['passed'] and not record['profilePreparation']
        report['unprofiled'][label] = {
            'artifact_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'initial_reserve_refill_ms': record['initialReserveRefillMs'],
            'activation_to_full_reserve_ms': record['activationToFullReserveMs'],
        }
    (BASE / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
    for group in ['profiled', 'unprofiled']:
        for label, record in report[group].items():
            print(label, round(record['initial_reserve_refill_ms'], 1))
            for profile in record.get('profiles', []):
                print(profile['title'], json.dumps(profile['exclusive_categories']))


if __name__ == '__main__':
    main()
