import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
VENDOR = ROOT / 'crates/ed25519-yao/vendor'
candidate = BASE / 'accumulator-vendor'
candidate.mkdir()
shutil.copytree(VENDOR / 'cryprot-codes', candidate / 'cryprot-codes')
(candidate / 'cryprot-core').symlink_to(VENDOR / 'cryprot-core', target_is_directory=True)
source = candidate / 'cryprot-codes/src/ex_conv.rs'
original = source.read_text()
needle = '''                x[offset] ^= xi;
                remaining &= remaining - 1;
'''
assert original.count(needle) == 1
replacement = '''                if RANGE_CHECK {
                    x[offset] ^= xi;
                } else {
                    // SAFETY: the main loop has i < x.len() - 25. The mask has
                    // bits 0..=24 only, so offset <= i + 25 < x.len().
                    unsafe { *x.get_unchecked_mut(offset) ^= xi };
                }
                remaining &= remaining - 1;
'''
updated = original.replace(needle, replacement)
main_line = '        let main = x.len() - 1 - self.conf.accumulator_size;'
assert updated.count(main_line) == 1
updated = updated.replace(main_line, '        assert!(x.len() > self.conf.accumulator_size, "accumulator exceeds code length");\n' + main_line)
source.write_text(updated)
subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', str(source)], check=True)
patch = subprocess.run(['git', 'diff', '--no-index', '--', str(VENDOR / 'cryprot-codes/src/ex_conv.rs'), str(source)], capture_output=True, text=True)
assert patch.returncode == 1
(BASE / 'accumulator-candidate.patch').write_text(patch.stdout)
script_path = ROOT / 'tools/ml-dsa-investigation/research/run_encoding_screen.py'
script = script_path.read_text()
script = script.replace('ROOT = Path(__file__).resolve().parents[3]', f'ROOT = {str(ROOT)!r}\nROOT = Path(ROOT)')
script = script.replace('VENDOR = ROOT / "crates/ed25519-yao/vendor"', f'VENDOR = Path({str(candidate)!r})')
script = script.replace('SOURCE = VENDOR / "cryprot-codes/src/ex_conv.rs"', 'SOURCE = ROOT / "crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv.rs"')
script = script.replace('"production_source_sha256"] = digest(SOURCE)', '"production_source_sha256"] = digest(VENDOR / "cryprot-codes/src/ex_conv.rs")')
script = script.replace('str(path.relative_to(SOURCE.with_suffix("")))', 'str(path.relative_to(VENDOR / "cryprot-codes/src/ex_conv"))')
script = script.replace('sorted(SOURCE.with_suffix("").rglob("*.rs"))', 'sorted((VENDOR / "cryprot-codes/src/ex_conv").rglob("*.rs"))')
# Retain exact compiled bytes, harness and lock after the temporary directory closes.
needle = '        result = json.loads(args.output.read_text())\n'
assert script.count(needle) == 1
script = script.replace(needle, '''        archive = args.output.with_suffix("")
        archive.mkdir()
        shutil.copy2(wasm, archive / "screen.wasm")
        for name in ["Cargo.toml", "Cargo.lock", "run.mjs"]:
            shutil.copy2(work / name, archive / name)
        shutil.copytree(work / "src", archive / "src")
''' + needle)
script = script.replace('import subprocess\n', 'import subprocess\nimport shutil\n')
(BASE / 'run-accumulator-screen.py').write_text(script)
(BASE / 'accumulator-source.json').write_text(json.dumps({
    'baseline_revision': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
    'candidate_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'harness_sha256': hashlib.sha256(script.encode()).hexdigest(),
    'scope': 'Temporary Wasm-only prototype. Remove the redundant bounds check in the existing main accumulator branch. Tail checks, fixed public matrix, coefficient order, and code dimensions remain unchanged. No production source change.',
}, indent=2) + '\n')
print('Prepared bounded accumulator prototype; no compilation or timing started.')
