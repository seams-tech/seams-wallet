import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
original = ROOT / 'tests/e2e/ml-dsa-durable-worker.e2e.mjs'
source = original.read_text()
source = source.replace("from '../helpers/", f"from '{ROOT}/tests/helpers/")
source = source.replace("from './ml-dsa-", f"from '{ROOT}/tests/e2e/ml-dsa-")
source = source.replace("from '../../crates/", f"from '{ROOT}/crates/")
source = source.replace("const root = resolve(import.meta.dirname, '../..');", f'const root = {str(ROOT)!r};')
start = source.index('  if (!parallelOnly) await runDurableCases(emptyInput);')
end = source.index('  observations.standardSignaturesVerifiedByRouter', start)
source = source[:start] + '''  observations.initialWindowInventory = await inventories();
  await runWindowSignature();
  await waitReady(policy.refill_target_batches);
  await waitForTerminalProducerSettlement();
  observations.finalWindowInventory = await inventories();
  for (const inventory of observations.finalWindowInventory) {
    assert.equal(inventory.ready.length, policy.refill_target_batches);
    assert.equal(inventory.reserved.length, 0);
  }
  assert.deepEqual(observations.finalWindowInventory[0].ready.map(batchId).sort(), observations.finalWindowInventory[1].ready.map(batchId).sort());
  observations.preparationResources = preparationResourceEvidence();
''' + source[end:]
source += '''
async function runWindowSignature() {
  for (let index = 0; index < 4; index += 1) {
    await waitReady(policy.refill_target_batches);
    const message = digest(Array.from(Buffer.from(`ML-DSA preparation profile verification ${index}`)));
    const owner = await admission.mlDsaOwnerFixture(records[0], new Uint8Array(message), `profile-${index}`);
    assert.equal(owner.admitted.kind, 'prepared');
    const prepared = owner.admitted.operation;
    const input = JSON.parse(prepared.encode());
    const router = clients.workers.get('router');
    const started = performance.now();
    const response = await admission.dispatchMlDsaOwnerOperation(new OwnerRouterProxy(router), prepared);
    assert.equal(response.status, 200, await response.clone().text());
    const result = await response.json();
    const elapsedMs = performance.now() - started;
    const duplicate = await admission.dispatchMlDsaOwnerOperation(new OwnerRouterProxy(router), prepared);
    assert.equal(duplicate.status, 200);
    assert.deepEqual(await duplicate.json(), result);
    if (result.operation.state === 'failed') {
      observations.failedOperations.push({ operationHex: batchId(input.request.operation), elapsedMs });
      continue;
    }
    assert.equal(result.operation.state, 'succeeded');
    verifyStandardSignature(records[0].public_key, message, input.context, result.operation.signature);
    observations.signatures.push({
      operationHex: batchId(input.request.operation), elapsedMs,
      messageHex: Buffer.from(message).toString('hex'),
      contextHex: Buffer.from(input.context).toString('hex'),
      signatureHex: Buffer.from(result.operation.signature).toString('hex'),
      duplicateReturnedSameSignature: true,
    });
    return;
  }
  assert.fail('No signature succeeded in four profile verification operations');
}
'''
(BASE / 'window.e2e.mjs').write_text(source)
link = BASE / 'node_modules'
if not link.exists():
    link.symlink_to(ROOT / 'node_modules', target_is_directory=True)
(BASE / 'window-source.json').write_text(json.dumps({
    'root': str(ROOT),
    'production_harness_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
    'window_harness_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'scope': 'The original activation-through-first-reserve window remains byte-identical apart from absolute import/root paths. After that boundary, replace unrelated fault scenarios with a real owner-admitted signature, duplicate replay, altered-message rejection, full reserve restoration, participant stock agreement, and settled jobs.',
}, indent=2) + '\n')
