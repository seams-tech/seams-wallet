import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent
path=BASE/'run-accumulator-screen.py'
s=path.read_text()
s=s.replace('default="a60af34e"','default="24a3dd453"')
needle='#[unsafe(no_mangle)]\npub extern "C" fn measure('
assert s.count(needle)==1
check='''#[unsafe(no_mangle)]
pub extern "C" fn reject_short(mode: u32, size: usize, bytes: bool) {
    if bytes {
        let mut values = vec![0u8; 2 * size];
        if mode == 0 {
            baseline::ExConvCode::new(size).dual_encode(&mut values);
        } else {
            cryprot_codes::ExConvCode::new(size).dual_encode(&mut values);
        }
        core::hint::black_box(values);
    } else {
        let mut values = vec![Block::ZERO; 2 * size];
        if mode == 0 {
            baseline::ExConvCode::new(size).dual_encode(&mut values);
        } else {
            cryprot_codes::ExConvCode::new(size).dual_encode(&mut values);
        }
        core::hint::black_box(values);
    }
}

'''
s=s.replace(needle,check+needle)
needle='const medians = [];'
assert s.count(needle)==1
check='''let shortInputRejections = 0;
for (let size = 0; size < 25; size += 1) {
  for (const mode of [0, 1]) {
    for (const bytes of [false, true]) {
      const isolated = await WebAssembly.instantiate(module, imports);
      assert.throws(isolated.exports.reject_short.bind(null, mode, size, bytes), WebAssembly.RuntimeError);
      shortInputRejections += 1;
    }
  }
}
'''
s=s.replace(needle,check+needle)
s=s.replace('passed: true, checks, node:', 'passed: true, checks, shortInputRejections, node:')
path.write_text(s)
r=json.loads((BASE/'accumulator-source.json').read_text())
r['harness_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
r['timing_control']='24a3dd453 current production, including the existing trailing-bit accumulator optimization'
(BASE/'accumulator-source.json').write_text(json.dumps(r,indent=2)+'\n')
