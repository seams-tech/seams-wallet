import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    SOURCE.mkdir(exist_ok=False)
    files = subprocess.check_output(['git', 'ls-files', '-z', '--', 'crates', 'tools', 'wasm', '.cargo'], cwd=ROOT).decode().split('\0')
    copied = {}
    for name in files:
        if not name:
            continue
        original = ROOT / name
        target = SOURCE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, target)
        copied[name] = digest(original)
    schedules = ROOT / 'crates/ed25519-yao-cloudflare-bench/src/ml_dsa_schedules'
    for original in schedules.glob('*.bin'):
        name = str(original.relative_to(ROOT))
        target = SOURCE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, target)
        copied[name] = digest(original)
    probes = {
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent.rs': ['fn triples('],
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs': ['    pub(super) fn encrypt('],
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/pprf.rs': ['fn expand_level('],
        'crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv.rs': ['    fn accumulate_fixed<'],
        'crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv/expander.rs': ['    fn expand_simple<'],
        'crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv/expander_modd.rs': ['    fn refill('],
        'crates/ed25519-yao/vendor/cryprot-codes/src/ex_conv/fast_aes_rng.rs': ['    pub(crate) fn refill('],
    }
    patches = []
    for name, needles in probes.items():
        target = SOURCE / name
        text = target.read_text()
        for needle in needles:
            assert text.count(needle) == 1, (name, needle)
            text = text.replace(needle, '    #[inline(never)]\n' + needle)
        target.write_text(text)
        patch = subprocess.run(['git', 'diff', '--no-index', '--', str(ROOT / name), str(target)], capture_output=True, text=True)
        assert patch.returncode == 1
        patches.append(patch.stdout)
    (BASE / 'boundary-profiling.patch').write_text(''.join(patches))
    record = {
        'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'scope': 'Temporary no-inline boundaries only. This build can perturb compiler optimization and is diagnostic, not production performance.',
        'copied_sha256': copied,
        'patched_sha256': {name: digest(SOURCE / name) for name in probes},
    }
    (BASE / 'source.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'files': len(copied), 'patched': len(probes)}))


if __name__ == '__main__':
    main()
