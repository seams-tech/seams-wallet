import assert from 'node:assert/strict';
import {createPublicKey, verify} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';

const labels = process.argv.slice(2);
assert.ok(labels.length > 0);
const results = [];
const fullRuns = new Set(['ordinary-first', 'diagnostic', 'ordinary-return']);
const uniqueSignatures = new Set();

function parallelSample(sample) {
  return sample.source === 'parallel_refill';
}

function verifySample(key, messageHex, signatureHex) {
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  assert.equal(verify(null, message, key, signature), true);
  assert.equal(verify(null, Buffer.concat([message, Buffer.from([1])]), key, signature), false);
  assert.equal(uniqueSignatures.has(signatureHex), false);
  uniqueSignatures.add(signatureHex);
}

for (const label of labels) {
  const campaign = JSON.parse(await readFile(new URL(`${label}.json`, import.meta.url), 'utf8'));
  const key = createPublicKey({
    key: Buffer.concat([
      Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
      Buffer.from(campaign.publicKeyHex, 'hex'),
    ]),
    format: 'der',
    type: 'spki',
  });
  let reportedSignatures = 0;
  let recoverySignatures = 0;
  for (const sample of campaign.signatures) {
    assert.equal(sample.contextHex, '');
    verifySample(key, sample.messageHex, sample.signatureHex);
    reportedSignatures += 1;
  }
  if (fullRuns.has(label)) {
    const reported = campaign.signatures.find(parallelSample);
    assert.ok(reported);
    assert.equal(campaign.parallelRefill.signatureHex, reported.signatureHex);
    assert.equal(campaign.parallelRefill.messageHex, reported.messageHex);
    assert.equal(campaign.parallelRefill.contextHex, reported.contextHex);
    for (const field of ['unopenedAfterFailure', 'truncatedMaterialDelivery']) {
      const sample = campaign[field];
      assert.equal(sample.freshSignatureVerifiedByOpenSsl, true);
      verifySample(key, sample.messageHex, sample.signatureHex);
      recoverySignatures += 1;
    }
  }
  assert.ok(reportedSignatures > 0);
  const signatures = reportedSignatures + recoverySignatures;
  results.push({
    label,
    lifecyclePassed: campaign.passed,
    reportedSignatures,
    recoverySignatures,
    signatures,
    alteredMessagesRejected: signatures,
  });
}
await writeFile(
  new URL('signature-verification.json', import.meta.url),
  JSON.stringify({passed: true, results}, null, 2) + '\n',
);
console.log(JSON.stringify({passed: true, results}));
