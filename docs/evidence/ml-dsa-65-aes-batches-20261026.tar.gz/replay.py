"""Reproduce the retained hosted evidence without network access."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
BASE = Path(__file__).resolve().parent
PHASES = ['precondition', 'control', 'candidate', 'software-precondition', 'software-batches']


def command(arguments, expected_code=0):
    result = subprocess.run(arguments, cwd=BASE, capture_output=True, text=True)
    assert result.returncode == expected_code, (arguments, result.stdout, result.stderr)


def reproduce(script, output, arguments):
    expected = json.loads((BASE / output).read_text())
    runtime = 'node' if script.endswith('.mjs') else sys.executable
    command([runtime, str(BASE / script), *arguments])
    assert json.loads((BASE / output).read_text()) == expected, script


def main():
    manifest = json.loads((BASE / 'manifest.json').read_text())
    for relative, digest in manifest['files'].items():
        assert hashlib.sha256((BASE / relative).read_bytes()).hexdigest() == digest, relative
    trace = BASE / 'cloud-driver/qualified-closed-final/traces.json'
    checks = []
    for phase in PHASES:
        folder = BASE / 'cloud-driver' / phase
        target = folder / 'traces.json'
        if not target.exists():
            os.link(trace, target)
        summary = folder / 'qualification-replay.json'
        command([sys.executable, str(BASE / 'frozen-measurement-qualified/tools/ml-dsa-investigation/research/summarize_capacity.py'),
                 str(folder / 'client.json'), str(trace), str(BASE / (phase + '-campaign.json')), str(summary)])
        assert json.loads(summary.read_text()) == json.loads((folder / 'summary.json').read_text()), phase
        expected = json.loads((folder / 'reserve-cycle.json').read_text())
        command([sys.executable, str(BASE / 'reserve_cycle.py'), phase], 0 if expected['qualified'] else 1)
        assert json.loads((folder / 'reserve-cycle.json').read_text()) == expected, phase
        checks.append({'phase': phase, 'qualified': expected['qualified']})
    for script, output, arguments in [
        ('verify_hosted.mjs', 'hosted-signature-verification.json', []),
        ('collect_failed_material.py', 'failed-operation-materials.json', []),
        ('audit_material.py', 'material-audit.json', []),
        ('profile_failures.py', 'failure-profiles.json', []),
        ('analyze_readiness_losses.py', 'readiness-losses.json', []),
        ('analyze_parallel.py', 'parallel-comparison.json', [str(BASE), *PHASES]),
    ]:
        reproduce(script, output, arguments)
        checks.append({'script': script, 'matched': True})
    for script in ['verify_registration_bindings.py', 'verify_bridge_ciphertexts.mjs']:
        command(['node' if script.endswith('.mjs') else sys.executable, str(BASE / script)])
        checks.append({'script': script, 'passed': True})
    result = {'passed': True, 'checks': checks}
    (BASE / 'replay-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
