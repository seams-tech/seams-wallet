"""Measure matched finite-load cycles without increasing prepared stock."""
import hashlib,json,subprocess,time
from pathlib import Path
from run_control import BASE,ROOT,FROZEN,SCOPE,ENV,control,run
from authority_gate import wait_for_authority
from audit_starting_lifetimes import audit


def versions():
    result={}
    for worker in SCOPE['workers']:
        command=['pnpm','exec','wrangler','deployments','list','--config',str(BASE/(worker['role']+'.json')),'--json']
        response=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,check=True)
        deployment=max(json.loads(response.stdout),key=lambda row:row['created_on'])
        assert len(deployment['versions'])==1 and deployment['versions'][0]['percentage']==100
        result[worker['role']]=deployment['versions'][0]['version_id']
    return result


def measure(name,expected,duration,audit_initial):
    folder=BASE/'cloud-driver'/name
    wait_for_authority(BASE,FROZEN,name,expected['router'])
    control('stock',name+'-initial',8,int(time.time()*1000))
    control('traces',name+'-initial')
    if audit_initial:
        audit(BASE,name)
    (BASE/'cloud-driver/versions.json').write_text(json.dumps(expected,indent=2)+'\n')
    control('start',name,8,duration)
    start=json.loads((folder/'start.json').read_text())
    campaign=dict(SCOPE,build_root=str(BASE/('candidate-build' if name.startswith('candidate') else 'baseline-build')))
    (BASE/(name+'-campaign.json')).write_text(json.dumps(campaign,indent=2)+'\n')
    print(json.dumps({'stage':'load_started','phase':name,'end_at_ms':start['endAtMs']}),flush=True)
    while time.time()*1000<start['endAtMs']+45000:
        time.sleep(30)
        control('status',name)
        progress=json.loads((folder/'progress.json').read_text())
        print(json.dumps({'stage':'progress','phase':name,'wallets':progress}),flush=True)
    command=['node',str(FROZEN/'tests/e2e/ml-dsa-cloud-load.e2e.mjs'),'collect',str(BASE),name]
    with (folder/'collect.log').open('w') as log:
        result=subprocess.run(command,cwd=FROZEN,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode in (0,1)
    control('stock',name+'-final',8,start['endAtMs'])
    control('traces',name)
    summary_command=['python3',str(FROZEN/'tools/ml-dsa-investigation/research/summarize_capacity.py'),str(folder/'client.json'),str(folder/'traces.json'),str(BASE/(name+'-campaign.json')),str(folder/'summary.json')]
    with (folder/'summary.log').open('w') as log:
        subprocess.run(summary_command,cwd=FROZEN,stdout=log,stderr=subprocess.STDOUT)
    client=json.loads((folder/'client.json').read_text())
    print(json.dumps({'stage':'load_collected','phase':name,'functional_passed':client['functionalPassed'],'verified_signatures':client['successfulSignatures']}),flush=True)


def main():
    assert all(row['passed'] for row in json.loads((BASE/'release-receipt.json').read_text()))
    expected=json.loads((BASE/'versions.json').read_text())
    (BASE/'cloud-driver/versions.json').write_text(json.dumps(expected,indent=2)+'\n')
    for index in range(1,9):
        artifact=BASE/f'registration-{index}.json'
        if not artifact.exists():
            print(json.dumps({'stage':'registration','wallet':index}),flush=True)
            ENV['ML_DSA_TEST_WALLET_ID']=f"{SCOPE['prefix']}-wallet-{index}"
            run(['node','tests/e2e/ml-dsa-registration-worker.e2e.mjs',str(BASE/f'wallet-{index}'),str(artifact)],BASE/f'registration-{index}.log')
        record=json.loads(artifact.read_text())
        assert record['registrationChecksPassed'] and record['recoveryPreservesCanonicalKey']
        assert record['policy']==SCOPE['policy']
        print(json.dumps({'stage':'registered','wallet':index,'canonical_recovery':True}),flush=True)
    # Retain this first finite-load cohort. It also consumes short-lived registration stock.
    measure('precondition',expected,600000,False)
    measure('control',expected,360000,True)
    wait_for_authority(BASE,FROZEN,'control-before-upgrade',expected['router'])
    manifest=json.loads((BASE/'candidate-manifest.json').read_text())
    for item in manifest['configs']:
        config=BASE/item['config']
        assert hashlib.sha256(config.read_bytes()).hexdigest()==item['config_sha256']
        wasm=Path(json.loads(config.read_text())['main']).parent.parent/'index_bg.wasm'
        assert hashlib.sha256(wasm.read_bytes()).hexdigest()==item['wasm_sha256']
        run(['pnpm','exec','wrangler','deploy','--config',str(config)],BASE/('candidate-deploy-'+item['role']+'.log'))
    candidate_versions=versions()
    (BASE/'candidate-policy-ready.json').write_text(json.dumps({'versions':candidate_versions,'policy':SCOPE['policy']},indent=2)+'\n')
    measure('candidate',candidate_versions,360000,True)
    print(json.dumps({'stage':'comparison_complete'}),flush=True)


if __name__=='__main__':
    main()
