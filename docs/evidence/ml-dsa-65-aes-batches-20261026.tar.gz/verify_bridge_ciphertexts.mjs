import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
const base = new URL('./', import.meta.url);
const report = JSON.parse(await readFile(new URL('bridge-parity.json', base), 'utf8'));
const keys = [193502124791825095790518994062991136444n, 91389970179024809574621370423327856399n, 297966570818470707816499469807199042980n];
for (const [path, digest] of Object.entries(report.sourceSha256)) {
  const source = await readFile(new URL(`native-prototype-sources/${path}`, base));
  assert.equal(createHash('sha256').update(source).digest('hex'), digest);
}
let verified = 0;
for (const record of report.observations) {
  if (!Object.hasOwn(record, 'ciphertextSha256')) continue;
  const key = Buffer.alloc(16);
  key.writeBigUInt64LE(keys[record.key] & ((1n << 64n) - 1n), 0);
  key.writeBigUInt64LE(keys[record.key] >> 64n, 8);
  const input = Buffer.alloc(record.count * 16);
  for (let block = 0; block < record.count; block += 1) {
    input.writeBigUInt64LE(BigInt(block), block * 16);
    for (let byte = 0; byte < 8; byte += 1) input[block * 16 + 8 + byte] = (block * 17 + byte * 29) & 255;
  }
  const cipher = createCipheriv('aes-128-ecb', key, null);
  cipher.setAutoPadding(false);
  const output = Buffer.concat([cipher.update(input), cipher.final()]);
  assert.equal(output.length, record.bytes);
  assert.equal(createHash('sha256').update(output).digest('hex'), record.ciphertextSha256);
  verified += 1;
}
assert.equal(verified, 42);
assert.equal(report.passed, true);
console.log(JSON.stringify({verifiedCiphertextHashes: verified, sourceHashesVerified: true}));
