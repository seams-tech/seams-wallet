import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { readFile, writeFile, cp } from 'node:fs/promises';
import { join } from 'node:path';
const { Miniflare } = await import(process.env.MINIFLARE_MODULE ?? 'miniflare');
const base = import.meta.dirname;
const keys = [193502124791825095790518994062991136444n, 91389970179024809574621370423327856399n, 297966570818470707816499469807199042980n];
const counts = [4, 8, 512, 1023, 1024, 1025, 2048];
const observations = [];
function hash(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function keyBytes(value) {
  const bytes = Buffer.alloc(16);
  bytes.writeBigUInt64LE(value & ((1n << 64n) - 1n), 0);
  bytes.writeBigUInt64LE(value >> 64n, 8);
  return bytes;
}
function expected(index, count) {
  const input = Buffer.alloc(count * 16);
  for (let block = 0; block < count; block++) {
    input.writeBigUInt64LE(BigInt(block), block * 16);
    for (let byte = 0; byte < 8; byte++) input[block * 16 + 8 + byte] = (block * 17 + byte * 29) & 255;
  }
  const cipher = createCipheriv('aes-128-ecb', keyBytes(keys[index]), null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(input), cipher.final()]);
}
function entry() {
  return `import compiled from './ml_dsa_aes_bridge_probe_bg.wasm';
import * as bindings from './ml_dsa_aes_bridge_probe_bg.js';
const instance = new WebAssembly.Instance(compiled, {'./ml_dsa_aes_bridge_probe_bg.js': bindings});
bindings.__wbg_set_wasm(instance.exports);
instance.exports.__wbindgen_start();
const encrypt_fixture = bindings.encrypt_fixture;
export default { async fetch(request) {
  const { key, count } = await request.json();
  try { return new Response(encrypt_fixture(key, count)); }
  catch (error) { return Response.json({error:String(error)}, {status:500}); }
}};`;
}
const provenance = JSON.parse(await readFile(join(base, 'production-source-sha256.json')));
for (const [path, digest] of Object.entries(provenance)) {
  assert.equal(hash(await readFile(join(base, '../native-prototype-sources', path))), digest);
}
for (const variant of ['software', 'native']) {
  const directory = join(base, variant);
  await writeFile(join(directory, 'entry.mjs'), entry());
  const runtime = new Miniflare({modules:true, modulesRoot:directory, scriptPath:join(directory, 'entry.mjs'),
    compatibilityDate:'2026-06-12', compatibilityFlags:['nodejs_compat'],
    modulesRules:[{type:'ESModule', include:['**/*.js'], fallthrough:true}, {type:'CompiledWasm', include:['**/*.wasm'], fallthrough:true}]});
  try {
    for (let key = 0; key < keys.length; key++) {
      for (const count of counts) {
        const response = await runtime.dispatchFetch('http://probe/', {method:'POST', body:JSON.stringify({key,count})});
        assert.equal(response.status, 200);
        const result = Buffer.from(await response.arrayBuffer());
        assert.deepEqual(result, expected(key,count));
        observations.push({variant,key,count,bytes:result.length,ciphertextSha256:hash(result)});
      }
    }
  } finally { await runtime.dispose(); }
}
await cp(join(base,'native'),join(base,'fault'),{recursive:true});
const faultDirectory = join(base,'fault');
const files = await (await import('node:fs/promises')).readdir(join(faultDirectory,'snippets'),{recursive:true});
const target = files.find(file => file.endsWith('workers_aes.mjs'));
assert.ok(target);
const faultModule = join(faultDirectory,'snippets',target);
let faultSource = await readFile(faultModule,'utf8');
assert.ok(faultSource.startsWith("const { createCipheriv } = globalThis.process.getBuiltinModule('node:crypto');"));
faultSource = faultSource.replace("const { createCipheriv } = globalThis.process.getBuiltinModule('node:crypto');", "function createCipheriv() { throw new Error('Injected native AES failure'); }");
await writeFile(faultModule,faultSource);
const runtime = new Miniflare({modules:true,modulesRoot:faultDirectory,scriptPath:join(faultDirectory,'entry.mjs'),compatibilityDate:'2026-06-12',compatibilityFlags:['nodejs_compat'],modulesRules:[{type:'ESModule',include:['**/*.js'],fallthrough:true},{type:'CompiledWasm',include:['**/*.wasm'],fallthrough:true}]});
try {
  const response = await runtime.dispatchFetch('http://probe/',{method:'POST',body:JSON.stringify({key:0,count:1024})});
  assert.equal(response.status,500);
  assert.deepEqual(await response.json(),{error:'Encryption failed'});
  observations.push({variant:'injected_native_failure',count:1024,status:500,rustErrorObserved:true});
} finally { await runtime.dispose(); }
const report={scope:'Local workerd, verbatim production AES Rust and JS source in a bounded Wasm probe. Public protocol keys and deterministic public inputs only. Exact ciphertext equality with Node AES-128-ECB, plus a separately identified injected provider failure. No hosted timing or provider-internal erasure claim.',sourceSha256:provenance,wasmBindgen:'0.2.123',observations,passed:true};
await writeFile(join(base,'../bridge-parity.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:true,exactCases:observations.length-1,fullNativeBatches:observations.filter(row=>row.variant==='native'&&row.count>=1024).length,errorPropagation:true}));
