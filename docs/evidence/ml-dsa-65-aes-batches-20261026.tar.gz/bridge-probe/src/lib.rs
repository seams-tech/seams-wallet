#![forbid(unsafe_code)]
use wasm_bindgen::prelude::*;
use zeroize::Zeroizing;
#[derive(Debug)]
enum RuntimeError { Encryption }
type Result<T> = core::result::Result<T, RuntimeError>;
mod correlation_aes;
#[wasm_bindgen]
pub fn encrypt_fixture(key_index: u32, count: usize) -> core::result::Result<Vec<u8>, JsValue> {
    if !(1..=2048).contains(&count) { return Err(JsValue::from_str("Invalid public count")); }
    let key = match key_index {
        0 => 193502124791825095790518994062991136444_u128.to_le_bytes(),
        1 => 91389970179024809574621370423327856399_u128.to_le_bytes(),
        2 => 297966570818470707816499469807199042980_u128.to_le_bytes(),
        _ => return Err(JsValue::from_str("Invalid public key index")),
    };
    let mut blocks = Zeroizing::new(vec![[0u8; 16]; count]);
    for (index, block) in blocks.iter_mut().enumerate() {
        block[..8].copy_from_slice(&(index as u64).to_le_bytes());
        for (byte_index, byte) in block[8..].iter_mut().enumerate() {
            *byte = (index.wrapping_mul(17).wrapping_add(byte_index * 29) & 255) as u8;
        }
    }
    correlation_aes::CorrelationAes::new(&key).encrypt(&mut blocks)
        .map_err(|_| JsValue::from_str("Encryption failed"))?;
    Ok(blocks.iter().flatten().copied().collect())
}
