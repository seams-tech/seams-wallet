const { createCipheriv } = globalThis.process.getBuiltinModule('node:crypto');

// The caller owns both views. This function retains no input or cipher state.
export function encryptBlocks(key, blocks) {
  if (key.byteLength !== 16 || blocks.byteLength !== 16384) {
    throw new Error('Invalid ML-DSA AES batch length');
  }
  const cipher = createCipheriv('aes-128-ecb', key, new Uint8Array(0));
  try {
    cipher.setAutoPadding(false);
    const output = cipher.update(blocks);
    try {
      const tail = cipher.final();
      try {
        if (output.byteLength !== blocks.byteLength || tail.byteLength !== 0) {
          throw new Error('Invalid ML-DSA AES output length');
        }
        blocks.set(output);
      } finally {
        tail.fill(0);
      }
    } finally {
      output.fill(0);
    }
  } finally {
    cipher.destroy();
  }
}
