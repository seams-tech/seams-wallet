import compiled from './ml_dsa_aes_bridge_probe_bg.wasm';
import * as bindings from './ml_dsa_aes_bridge_probe_bg.js';
const instance = new WebAssembly.Instance(compiled, {'./ml_dsa_aes_bridge_probe_bg.js': bindings});
bindings.__wbg_set_wasm(instance.exports);
instance.exports.__wbindgen_start();
const encrypt_fixture = bindings.encrypt_fixture;
export default { async fetch(request) {
  const { key, count } = await request.json();
  try { return new Response(encrypt_fixture(key, count)); }
  catch (error) { return Response.json({error:String(error)}, {status:500}); }
}};