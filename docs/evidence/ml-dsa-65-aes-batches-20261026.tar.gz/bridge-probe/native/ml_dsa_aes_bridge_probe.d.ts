/* tslint:disable */
/* eslint-disable */

export function encrypt_fixture(key_index: number, count: number): Uint8Array;
