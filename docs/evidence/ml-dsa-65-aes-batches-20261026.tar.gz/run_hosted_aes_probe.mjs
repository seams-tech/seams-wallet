import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { readFile, writeFile } from 'node:fs/promises';
const base=import.meta.dirname;
const scope=JSON.parse(await readFile(base+'/scope.json','utf8'));
const token=(await readFile(base+'/gateway-token','utf8')).trim();
const rows=[];
const modes=['wasm','native-fresh','native-reused'];
async function call(input) {
  const requestId=randomBytes(16).toString('hex');
  const startAtMs=Date.now();
  const response=await fetch(scope.router_url+'/__benchmark/aes?run_id='+requestId,{
    method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':token,'x-ml-dsa-request-id':requestId},
    body:JSON.stringify(input),signal:AbortSignal.timeout(60000),
  });
  assert.equal(response.status,200);
  const result=await response.json();
  const row={requestId,startAtMs,completedAtMs:Date.now(),clientElapsedMs:Date.now()-startAtMs,input,result};
  rows.push(row);
  await writeFile(base+'/hosted-aes-probe.json',JSON.stringify({scope:'Bounded public-input microprobe on the approved temporary front Worker after all load measurements. It uses no wallet key or share. Whole-invocation CPU comes from the direct front tail. Product parity and private protocol speedup are not established by this probe.',rows},null,2)+'\n');
  await delay(250);
  return result;
}
for(const batch of [256,1024]) {
  for(const seed of [0,55,231]) {
    for(const mode of ['native-fresh','native-reused']) {
      assert.equal((await call({mode,batch,seed,action:'verify'})).exactOutputMatched,true);
    }
  }
}
for(let sample=0;sample<4;sample++) {
  for(const batch of [256,1024]) {
    let expected;
    const order=sample%2===0?modes:[...modes].reverse();
    for(const mode of order) {
      const result=await call({mode,batch,seed:55,action:'measure'});
      assert.equal(result.blocks,1048576);
      if(expected===undefined)expected=result.checksum;
      assert.equal(result.checksum,expected);
    }
  }
}
console.log(JSON.stringify({passed:true,exactCases:12,measurements:24}));
