from pathlib import Path
import hashlib,json,shutil
base=Path(__file__).resolve().parent
root=Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
old=Path('/private/tmp/ml-dsa-refill-retry-20261026')
frozen=base/'frozen-measurement-qualified'
assert not frozen.exists()
for source in (root/'tools/ml-dsa-investigation/research').glob('*.py'):
 target=frozen/source.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for name in ['ml-dsa-cloud-load.e2e.mjs','ml-dsa-cloud-load-worker.mjs']:
 target=frozen/'tests/e2e'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'tests/e2e'/name,target)
files={str(path.relative_to(frozen)):hashlib.sha256(path.read_bytes()).hexdigest() for path in frozen.rglob('*') if path.is_file()}
(base/'frozen-measurement.json').write_text(json.dumps(files,indent=2)+'\n')
for name in ['authority_gate.py','audit_starting_lifetimes.py','analyze_parallel.py','audit_material.py','verify_hosted.mjs','reserve_cycle.py']:
 shutil.copyfile(old/name,base/name)
# The previous runner is reused only for its small, existing command helpers.
source=(old/'run_control.py').read_text()
source=source[:source.index('\ndef main():')]
(base/'run_control.py').write_text(source)
roles={'router':'router','a':'deriver-a','b':'deriver-b','preparer-a':'deriver-a','preparer-b':'deriver-b','preparer-a-secondary':'deriver-a','preparer-b-secondary':'deriver-b'}
scope=json.loads((base/'scope.json').read_text())
configs=[]
for worker in scope['workers']:
 role=worker['role']
 if role=='front':continue
 config=json.loads((base/(role+'.json')).read_text())
 config['main']=str(base/'candidate-build'/roles[role]/'worker/shim.mjs')
 path=base/('candidate-'+role+'.json');path.write_text(json.dumps(config,indent=2)+'\n')
 configs.append({'role':role,'config':path.name,'config_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'wasm_sha256':hashlib.sha256((base/'candidate-build'/roles[role]/'index_bg.wasm').read_bytes()).hexdigest()})
sources={}
for pattern in ['crates/ml-dsa-threshold/src/**/*.rs','crates/ml-dsa-threshold/src/**/*.mjs','crates/router-ab-cloudflare/src/**/*.rs']:
 for path in root.glob(pattern):sources[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'base_revision':scope['source_commit'],'source_sha256':sources,'configs':configs}
(base/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'frozen_files':len(files),'candidate_configs':len(configs)}))
