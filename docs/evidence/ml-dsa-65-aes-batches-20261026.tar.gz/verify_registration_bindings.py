"""Recompute registration pair identities from the retained public registration receipt."""
import hashlib
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
expected = json.loads((BASE / 'registration-stock-bindings.json').read_text())['bindings']
observed = set()
for index in range(1, 9):
    record = json.loads((BASE / f'registration-{index}.json').read_text())
    for case in record['cases']:
        preparation = bytes.fromhex(case['initialSigningPreparationId'])
        for ordinal in range(case['initialSigningBatches']):
            encoded = json.dumps([list(preparation), ordinal], separators=(',', ':')).encode()
            pair = hashlib.sha256(b'seams/ml-dsa/registration-signing-stock/v1' + encoded).hexdigest()
            assert pair in expected
            binding = expected[pair]
            assert binding['epoch'] == case['epoch']
            assert binding['expires_at_ms'] == case['initialSigningStockExpiresAtMs']
            assert binding['key'] == bytes(case['key']['public_key_digest']).hex()
            observed.add(pair)
assert observed == set(expected)
print(json.dumps({'verified_registration_pair_bindings': len(observed)}))
