"""Compare unaccounted pair disappearance with its recorded readiness deadline."""
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
PHASES = ['precondition', 'control', 'candidate', 'software-precondition', 'software-batches']


def main():
    rows = json.loads((BASE / 'cloud-driver/qualified-closed-final/traces.json').read_text())['records']
    bindings = json.loads((BASE / 'registration-stock-bindings.json').read_text())['bindings']
    deadlines = dict(bindings)
    for row in rows:
        job = row['refill_job']
        if job:
            for pair in job['batches']:
                value = {'key': job['key'], 'epoch': job['epoch'], 'expires_at_ms': job['material_expires_at_ms']}
                if pair in deadlines:
                    assert all(deadlines[pair][key] == item for key, item in value.items())
                else:
                    deadlines[pair] = value
    losses = []
    for name in PHASES:
        cycle = json.loads((BASE / f'cloud-driver/{name}/reserve-cycle.json').read_text())
        for pair in cycle['complete_cycle_ledger']['unaccounted_pairs']:
            binding = deadlines[pair]
            inventory = [item for row in rows for item in row['inventories']
                         if (item['key'], item['epoch']) == (binding['key'], binding['epoch'])
                         and cycle['start_at_ms'] <= item['log_timestamp_ms'] <= cycle['restored_at_ms']]
            present = [item['log_timestamp_ms'] for item in inventory if pair in item['ready_a'] or pair in item['ready_b'] or pair in item['reserved_a'] or pair in item['reserved_b']]
            assert present
            last = max(present)
            absent = [item['log_timestamp_ms'] for item in inventory if item['log_timestamp_ms'] > last
                      and pair not in item['ready_a'] and pair not in item['ready_b']
                      and pair not in item['reserved_a'] and pair not in item['reserved_b']]
            assert absent
            first = min(absent)
            losses.append({'phase': name, 'pair': pair, **binding, 'last_present_at_ms': last,
                           'first_absent_after_last_presence_at_ms': first,
                           'remaining_ms_at_first_absence': binding['expires_at_ms'] - first,
                           'fits_thirty_second_readiness_margin': 0 <= binding['expires_at_ms'] - first <= 30000})
    result = {'limit': 'Temporal fit supports readiness loss. It does not prove physical expiry pruning or its time. These IDs stay unaccounted in the primary ledger.', 'pairs': losses}
    (BASE / 'readiness-losses.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'unaccounted_pairs': len(losses), 'readiness_margin_fits': sum(item['fits_thirty_second_readiness_margin'] for item in losses)}))


if __name__ == '__main__':
    main()
