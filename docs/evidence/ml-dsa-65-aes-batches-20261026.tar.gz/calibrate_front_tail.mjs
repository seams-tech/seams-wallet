import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const startedAtMs = Date.now();
const response = await fetch(scope.router_url + '/__benchmark/wallet/trace-calibration', {
  method: 'POST',
  headers: {'content-type': 'application/json', 'x-router-ab-internal-service-auth': token},
  body: JSON.stringify({index:-1}),
  signal: AbortSignal.timeout(60000),
});
assert.equal(response.status, 500);
await response.arrayBuffer();
const result = {scope:'An invalid benchmark start supplies no wallet key and starts no signing operation. It calibrates the direct front-Worker error tail.',startedAtMs,completedAtMs:Date.now(),httpStatus:response.status,passed:true};
await writeFile(base + '/front-tail-calibration.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
