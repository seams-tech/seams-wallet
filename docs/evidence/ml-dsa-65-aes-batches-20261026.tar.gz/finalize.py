"""Scan the public staging set, delete only approved Workers, then create the archive."""
import json
from pathlib import Path
import subprocess
import sys
import package_public
BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')


def checked(arguments, log):
    with (BASE / log).open('w') as output:
        subprocess.run(arguments, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)


def main():
    secrets = package_public.patterns()
    package_public.prepare()
    # Check the staged sources and records before deleting the credential payloads.
    for path in package_public.STAGE.rglob('*'):
        if path.is_file():
            data = path.read_bytes()
            assert not any(secret in data for secret in secrets), str(path.relative_to(package_public.STAGE))
    checked([sys.executable, str(BASE / 'deploy.py'), 'delete'], 'delete.log')
    checked([sys.executable, str(BASE / 'verify_deletion.py')], 'verify-deletion.log')
    checked([sys.executable, str(BASE / 'save_report.py')], 'save-report.log')
    package_public.finish(secrets)
    print(json.dumps({'approved_workers_deleted': 8, 'archive_ready': True}))


if __name__ == '__main__':
    main()
