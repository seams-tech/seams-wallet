import assert from 'node:assert/strict';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json','utf8'));
const token = (await readFile(base + '/gateway-token','utf8')).trim();
const snapshotResponse = await fetch(scope.router_url + '/__benchmark/wallet/software-batches-7',{
  headers:{'x-router-ab-internal-service-auth':token},signal:AbortSignal.timeout(60000),
});
assert.equal(snapshotResponse.status,200);
const snapshot = await snapshotResponse.json();
assert.equal(snapshot.state.state,'failed');
const input = snapshot.state.operation;
assert.ok(input);
const row = snapshot.requests.at(-1);
assert.deepEqual(row.signingRequest,input.request);
assert.equal(row.messageHex,Buffer.from(input.message).toString('hex'));
assert.equal(row.contextHex,Buffer.from(input.context).toString('hex'));
const response = await fetch(scope.router_url + '/router-ab/ml-dsa/status',{
  method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':token},
  body:JSON.stringify(input.request),signal:AbortSignal.timeout(60000),
});
assert.equal(response.status,200);
const status = await response.json();
let standardSignatureVerified=false;
if (status?.state==='succeeded') {
  const registration = JSON.parse(await readFile(base + '/registration-8.json','utf8'));
  const publicKeyHex=registration.cases.at(-1).publicKeyHex;
  const key=createPublicKey({key:Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100','hex'),Buffer.from(publicKeyHex,'hex')]),format:'der',type:'spki'});
  assert.equal(verify(null,Buffer.from(input.message),key,Buffer.from(status.signature)),true);
  standardSignatureVerified=true;
}
const result={scope:'Exact retained benchmark request, ordinary read-only status lookup, and independent verification if the server succeeded. No signing mutation is repeated. A recovered result does not change the original client load outcome.',capturedAtMs:Date.now(),snapshot,httpStatus:response.status,status,standardSignatureVerified};
await writeFile(base + '/software-failed-driver-status.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({request:row.requestId,operation:Buffer.from(input.request.operation).toString('hex'),status,standardSignatureVerified}));
