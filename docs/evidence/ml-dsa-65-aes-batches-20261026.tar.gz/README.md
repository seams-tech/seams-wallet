# ML-DSA larger AES batches

The archive retains five hosted phases, their raw public role traces, deployment provenance, local lifecycle evidence, and rejected native AES sources.
It excludes credential payloads, raw authenticated request tails, and private fixture stores.
Run `python3 replay.py` after extraction with Python3 and Node.js24 or later.
The replay uses retained data and requires no Cloudflare access.
It reproduces signatures, altered-message refusals, stock accounting, observed non-reuse, producer profiles, and failure retirement attribution.
A failed or unqualified original run remains failed or unqualified during replay.

The native bridge was an experiment. Its exact sources are under native-prototype-sources.
The bridge ciphertext calculation can replay against those snapshots with the retained compiled Wasm and Miniflare.
Set MINIFLARE_MODULE to an installed Miniflare entry file URL, then run node bridge-probe/check.mjs.
The default offline replay independently recomputes the 42 retained ciphertext hashes without Miniflare.
Native provider erasure and constant-time behavior remain outside this screen.
The public hosted AES microprobe lacks complete exact-request CPU capture. Its checksums remain useful. Its timings do not qualify a speedup.

The load targets eight synthetic wallets, one admitted operation per wallet per minute, and two independent preparation slots.
Each wallet retains sixteen prepared pairs, with two candidates per pair.
The runtime default remains one preparation slot. Refill material retains its one-hour policy.
Successful HTTP latency excludes earlier pool and cooldown waits. Demand latency includes those waits.
These private Router measurements exclude the browser and public Gateway approval.
A finite load plus full reserve restoration gives an observed throughput, not a maximum-capacity guarantee.
A qualified cycle meets the version, capture, and availability-accounting checks. It does not mean every request succeeds.

Retired records prove unavailability for the inspected key. Inspection combines Consumed, Burned, and wrong-key states.
Failed-operation retirements without recorded takes remain an availability-cost bucket. A crash can hide a durable take.
