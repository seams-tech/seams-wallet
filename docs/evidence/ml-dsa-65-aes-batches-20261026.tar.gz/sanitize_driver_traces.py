"""Retain public milestones and exact interrupted-request frontend invocations."""
import importlib.util
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
PARSER = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/tools/ml-dsa-investigation/research/collect_worker_traces.py')


def main():
    spec = importlib.util.spec_from_file_location('trace_parser', PARSER)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    requests = set()
    for name in ['candidate-failed-driver-status.json', 'software-failed-driver-status.json']:
        result = json.loads((BASE / name).read_text())
        requests.add(result['snapshot']['requests'][-1]['requestId'])
    rows = parser.records(BASE / 'front-live-private.jsonl', 'front')
    selected = [{key: row[key] for key in ['role', 'http_request', 'path', 'version', 'event_timestamp_ms',
                                          'outcome', 'cpu_ms', 'wall_ms', 'benchmark_requests', 'logs_truncated']}
                for row in rows if row['benchmark_requests'] or row['http_request'] in requests]
    report = {'limit': 'Direct front tail can be incomplete. Retained milestones show progress. Absent milestones do not prove absence of execution.', 'records': selected}
    (BASE / 'driver-stage-public.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'public_driver_records': len(selected), 'matched_front_requests': [row['http_request'] for row in selected if row['http_request'] in requests]}))


if __name__ == '__main__':
    main()
