"""Keep the selected software cipher and isolate larger public batches."""
import hashlib,json
from run_control import BASE,ROOT,FROZEN,SCOPE,run
from run_comparison import measure,versions
from authority_gate import wait_for_authority


def main():
    assert (BASE/'cloud-driver/candidate/client.json').exists()
    ready=BASE/'software-policy-ready.json'
    if not ready.exists():
        previous=json.loads((BASE/'candidate-policy-ready.json').read_text())['versions']
        wait_for_authority(BASE,FROZEN,'candidate-before-software',previous['router'])
        run(['pnpm','exec','wrangler','deploy','--config',str(BASE/'front.json')],BASE/'software-restore-front.log')
        manifest=json.loads((BASE/'software-batch-manifest.json').read_text())
        for item in manifest['configs']:
            path=BASE/item['config']
            assert hashlib.sha256(path.read_bytes()).hexdigest()==item['config_sha256']
            run(['pnpm','exec','wrangler','deploy','--config',str(path)],BASE/('software-deploy-'+item['role']+'.log'))
        actual=versions()
        ready.write_text(json.dumps({'versions':actual,'policy':SCOPE['policy']},indent=2)+'\n')
    actual=json.loads(ready.read_text())['versions']
    measure('software-precondition',actual,600000,False,BASE/'software-batch-build')
    measure('software-batches',actual,360000,True,BASE/'software-batch-build')
    print(json.dumps({'stage':'software_batch_comparison_complete'}),flush=True)


if __name__=='__main__':
    main()
