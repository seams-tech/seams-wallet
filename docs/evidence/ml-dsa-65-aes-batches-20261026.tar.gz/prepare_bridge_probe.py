import hashlib,json,pathlib,shutil
base=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
probe=base/'bridge-probe';(probe/'src/runtime/boolean_mpc/silent').mkdir(parents=True,exist_ok=True)
files={
 'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs':'src/correlation_aes.rs',
 'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/workers_aes.mjs':'src/runtime/boolean_mpc/silent/workers_aes.mjs',
}
provenance={}
for source,destination in files.items():
 shutil.copyfile(root/source,probe/destination)
 provenance[source]=hashlib.sha256((probe/destination).read_bytes()).hexdigest()
(probe/'production-source-sha256.json').write_text(json.dumps(provenance,indent=2)+'\n')
(probe/'Cargo.toml').write_text('''[package]
name = "ml-dsa-aes-bridge-probe"
version = "0.0.0"
edition = "2021"
[lib]
crate-type = ["cdylib"]
[features]
workers-aes = []
[dependencies]
wasm-bindgen = "=0.2.123"
zeroize = { version = "=1.9.0", features = ["zeroize_derive"] }
two-party-primitives = { path = "/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/crates/two-party-primitives", features = ["simd"] }
[profile.release]
lto = true
codegen-units = 1
opt-level = 3
''')
(probe/'src/lib.rs').write_text('''#![forbid(unsafe_code)]
use wasm_bindgen::prelude::*;
use zeroize::Zeroizing;
#[derive(Debug)]
enum RuntimeError { Encryption }
type Result<T> = core::result::Result<T, RuntimeError>;
mod correlation_aes;
#[wasm_bindgen]
pub fn encrypt_fixture(key_index: u32, count: usize) -> core::result::Result<Vec<u8>, JsValue> {
    if !(1..=2048).contains(&count) { return Err(JsValue::from_str("Invalid public count")); }
    let key = match key_index {
        0 => 193502124791825095790518994062991136444_u128.to_le_bytes(),
        1 => 91389970179024809574621370423327856399_u128.to_le_bytes(),
        2 => 297966570818470707816499469807199042980_u128.to_le_bytes(),
        _ => return Err(JsValue::from_str("Invalid public key index")),
    };
    let mut blocks = Zeroizing::new(vec![[0u8; 16]; count]);
    for (index, block) in blocks.iter_mut().enumerate() {
        for (byte_index, byte) in block.iter_mut().enumerate() {
            *byte = (index.wrapping_mul(17).wrapping_add(byte_index * 29) & 255) as u8;
        }
    }
    correlation_aes::CorrelationAes::new(&key).encrypt(&mut blocks)
        .map_err(|_| JsValue::from_str("Encryption failed"))?;
    Ok(blocks.iter().flatten().copied().collect())
}
''')
print(probe)
