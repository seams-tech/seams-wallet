import { Miniflare } from '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/node_modules/miniflare/dist/src/index.js';
const runtime = new Miniflare({modules: true, compatibilityDate: '2026-06-12', compatibilityFlags: ['nodejs_compat'],
  script: `const nativeCrypto = globalThis.process.getBuiltinModule('node:crypto');
    export default {fetch() {const cipher = nativeCrypto.createCipheriv('aes-128-ecb', new Uint8Array(16), new Uint8Array(0));
      cipher.setAutoPadding(false); const value = cipher.update(new Uint8Array(16));
      const tail = cipher.final(); cipher.destroy();
      return Response.json({ciphertext: Array.from(value), tailBytes:tail.byteLength});}};`});
try { const response = await runtime.dispatchFetch('http://probe/'); console.log(response.status, await response.text()); }
finally { await runtime.dispose(); }
