from pathlib import Path
b=Path(__file__).resolve().parent
phases="['precondition', 'control', 'candidate', 'software-precondition', 'software-batches']"
p=b/'collect_failed_material.py'
s=p.read_text().replace("PHASES=['precondition','control','candidate']",'PHASES='+phases)
s=s.replace("taken_union=set(taken['a'])|set(taken['b'])", """for candidate in rows:
            side=candidate['role']
            if side not in taken:
                continue
            staged={item['value']['material_id'] for item in candidate['material_stages']
                    if item['operation']==operation and item['value']['stage']=='taken'}
            taken[side]=sorted(set(taken[side])|staged)
        taken_union=set(taken['a'])|set(taken['b'])""")
s=s.replace("'unused_failed_pairs'", "'failed_retired_without_observed_take'")
s=s.replace("'roles_released':settled", "'roles_released':settled,'released_at_ms':next(item['at_ms'] for item in router[0]['milestones'] if item['stage']=='roles_released')")
s=s.replace('Failed settlement burns untouched reserved material. Independent participant inspection must confirm durable retirement; provider loadShed causes remain unknown.', 'Both signing traces and incremental material stages contribute observed takes. Independent participant inspection must confirm retirement. Retired collapses Consumed, Burned, and wrong-key states. A crash can hide a durable take. This is an availability-cost bucket, not proof of a physical burn or zero consumption. Provider loadShed causes remain unknown.')
p.write_text(s)
p=b/'inspect_failed_material.mjs';s=p.read_text().replace('unused_failed_pairs','failed_retired_without_observed_take').replace('exact unused failed-operation IDs','exact failed-operation IDs with no recorded take');p.write_text(s)
p=b/'reserve_cycle.py';s=p.read_text()
needle="ledger = {'initial_pairs':"
insert="""# Availability accounting includes failed-operation retirement without an observed take.
# Inspection does not distinguish a burned record from an unlogged consumed record.
failed = json.loads((BASE / 'failed-operation-materials.json').read_text())['phases']
inspections = json.loads((BASE / 'failed-material-inspection.json').read_text())['results']
retired_ids = set()
observed_taken = set(consumed_ids)
for phase in failed:
    if phase['phase'] != name:
        continue
    for operation in phase['failed_operations']:
        assert operation['released_at_ms'] <= restored
        observed_taken.update(operation['actual_takes']['a'])
        observed_taken.update(operation['actual_takes']['b'])
        identities = set(operation['failed_retired_without_observed_take'])
        for side in ['a', 'b']:
            matches = [item for item in inspections if item['phase'] == name
                       and item['operation'] == operation['operation'] and item['role'] == side]
            if identities:
                assert len(matches) == 1
                assert set(matches[0]['pairs']) == identities
                assert matches[0]['httpStatus'] == 200
                assert all(state == 'retired' for state in matches[0]['states'])
        retired_ids.update(identities)
assert not (retired_ids & (observed_taken | final_ids))
accounted_ids = observed_taken | retired_ids | final_ids
"""
s=s.replace(needle,insert+needle)
s=s.replace("'consumed_pairs': len(consumed_ids)","'summary_consumed_pairs': len(consumed_ids), 'observed_taken_pairs': len(observed_taken), 'failed_retired_without_observed_take_pairs': len(retired_ids)")
s=s.replace('(consumed_ids | final_ids)', 'accounted_ids').replace('not (consumed_ids & final_ids)', 'not (observed_taken & final_ids)')
s=s.replace("'complete': not", "'retirement_limit': 'Retired proves unavailability, not burn versus unlogged consumption.', 'complete': not")
p.write_text(s)
p=b/'close_measurements.py';s=p.read_text().replace("PHASES = ['precondition', 'control', 'candidate']",'PHASES = '+phases)
s=s.replace("stderr=subprocess.STDOUT, check=name != 'precondition')", "stderr=subprocess.STDOUT, check=False)")
p.write_text(s)
p=b/'verify_hosted.mjs';s=p.read_text().replace("['precondition', 'control', 'candidate']",phases)
s=s.replace("const local = JSON.parse(await readFile(new URL('worker-native-aes-e2e.json', base), 'utf8'));", "for (const localName of ['worker-native-aes-e2e.json', 'worker-software-batch-e2e.json']) {\nconst local = JSON.parse(await readFile(new URL(localName, base), 'utf8'));")
s=s.replace("const result = {verified:","}\nconst result = {verified:")
p.write_text(s)
p=b/'audit_material.py';s=p.read_text().replace("PHASES = ['precondition', 'control', 'candidate']",'PHASES = '+phases)
s=s.replace("    if name != 'precondition':\n        assert exact_takes_match, (name, 'participant take mismatch')", """    successful_operations = {bytes(request['operation']).hex() for request in client['requests'] if request.get('verified')}
    for operation in successful_operations:
        left = {pair for pair, operations in takes['a'].items() if operation in operations}
        right = {pair for pair, operations in takes['b'].items() if operation in operations}
        assert left == right and left, (name, operation, 'successful participant take mismatch')""")
s=s.replace("    if name != 'precondition':\n        assert summary_takes_match, (name, 'take/summary mismatch')", "    assert consumed <= (set(takes['a']) | set(takes['b'])), (name, 'unobserved summary take')")
s=s.replace("if name != 'precondition':", "if name in ['control', 'candidate', 'software-batches']:")
s=s.replace("'no_observed_reuse': True", "'successful_operations_have_matching_takes': True, 'no_observed_reuse': True")
p.write_text(s)
