from pathlib import Path
import json,statistics
base=Path(__file__).resolve().parent
source=(base/'front-probe-repeat-private.jsonl').read_text();decoder=json.JSONDecoder();position=0;events=[]
while position<len(source):
    while position<len(source) and source[position].isspace():
        position+=1
    if position==len(source):
        break
    try:
        event,position=decoder.raw_decode(source,position)
    except json.JSONDecodeError:
        break
    events.append(event)
probe=json.loads((base/'hosted-aes-probe.json').read_text());rows=[]
for sample in probe['rows']:
    found=[event for event in events if event.get('event',{}).get('request',{}).get('headers',{}).get('x-ml-dsa-request-id')==sample['requestId']]
    assert len(found)==1,(sample['requestId'],len(found))
    row=found[0]
    rows.append(dict(sample,provider_cpu_ms=row.get('cpuTime'),provider_wall_ms=row.get('wallTime'),provider_outcome=row.get('outcome'),version=row.get('scriptVersion',{}).get('id')))
report={'scope':probe['scope'],'rows':rows,'groups':{}}
for batch in [256,1024]:
    for mode in ['wasm','native-fresh','native-reused']:
        values=[row['provider_cpu_ms'] for row in rows if row['input']['action']=='measure' and row['input']['batch']==batch and row['input']['mode']==mode]
        assert len(values)==4 and all(type(value) is int and value>0 for value in values)
        report['groups'][f'{batch}/{mode}']={'count':len(values),'cpu_ms_min':min(values),'cpu_ms_median':statistics.median(values),'cpu_ms_max':max(values)}
(base/'hosted-aes-probe-profile.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['groups']))
