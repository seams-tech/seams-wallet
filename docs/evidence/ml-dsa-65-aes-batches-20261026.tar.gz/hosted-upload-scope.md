# ML-DSA large AES batch benchmark credential scope

Create the eight temporary Workers below and upload these exact fresh benchmark credentials.
A Workers receive only the A storage key. B Workers receive only the B storage key.
Credentials protect synthetic wallets. They contain no production wallet or account credentials.
Both comparison arms retain two preparation slots, two-at-once consumption, sixteen pairs per wallet, and the sixty-second wallet cooldown.
Preparation stays on Workers. Wallet-seed recovery and standard FIPS export remain required.
The control uses preserved ac133fa5 Worker binaries. The candidate changes local AES batching and its Workers backend. Cryptographic outputs, wire formats, and pool capacity remain fixed.
All eight temporary Workers will be removed after measurements. Local private fixtures will be retained.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-aes-1026-b89d7d-router | f722167d89a79409bf1554588ed27be998306bdef4236c24df17dd55b8459ca1 |
| ml-dsa-aes-1026-b89d7d-a | 61e8837a46da6e8e34baff3e4c2b41995fa9fd96168321dd0a2ea81612c1cecf |
| ml-dsa-aes-1026-b89d7d-b | 3f61859a2083a7414342b916495783279e949ec3da2798745c53d298eebab45b |
| ml-dsa-aes-1026-b89d7d-preparer-a | 61e8837a46da6e8e34baff3e4c2b41995fa9fd96168321dd0a2ea81612c1cecf |
| ml-dsa-aes-1026-b89d7d-preparer-b | 3f61859a2083a7414342b916495783279e949ec3da2798745c53d298eebab45b |
| ml-dsa-aes-1026-b89d7d-preparer-a-secondary | 61e8837a46da6e8e34baff3e4c2b41995fa9fd96168321dd0a2ea81612c1cecf |
| ml-dsa-aes-1026-b89d7d-preparer-b-secondary | 3f61859a2083a7414342b916495783279e949ec3da2798745c53d298eebab45b |
| ml-dsa-aes-1026-b89d7d-front | f722167d89a79409bf1554588ed27be998306bdef4236c24df17dd55b8459ca1 |
