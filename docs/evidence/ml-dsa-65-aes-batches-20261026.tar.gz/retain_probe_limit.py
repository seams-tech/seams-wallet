"""Retain incomplete public microprobe CPU capture without a speed comparison."""
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent


def decode_events(source):
    decoder = json.JSONDecoder()
    position = 0
    events = []
    while position < len(source):
        while position < len(source) and source[position].isspace():
            position += 1
        if position == len(source):
            break
        try:
            event, position = decoder.raw_decode(source, position)
        except json.JSONDecodeError:
            break
        events.append(event)
    return events


def main():
    events = decode_events((BASE / 'front-probe-repeat-private.jsonl').read_text())
    probe = json.loads((BASE / 'hosted-aes-probe.json').read_text())
    rows = []
    for sample in probe['rows']:
        matches = [event for event in events if event.get('event', {}).get('request', {}).get('headers', {}).get('x-ml-dsa-request-id') == sample['requestId']]
        assert len(matches) <= 1
        event = matches[0] if matches else {}
        rows.append({'request': sample['requestId'], 'captured': bool(matches), 'cpu_ms': event.get('cpuTime'),
                     'wall_ms': event.get('wallTime'), 'outcome': event.get('outcome'), 'version': event.get('scriptVersion', {}).get('id')})
    result = {'qualified': False, 'expected_requests': len(rows), 'captured_requests': sum(row['captured'] for row in rows),
              'limit': 'Exact request capture is incomplete. No qualified hosted CPU comparison. Incomplete direct tail cause remains unknown.', 'rows': rows}
    (BASE / 'public-aes-capture-limit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}))


if __name__ == '__main__':
    main()
