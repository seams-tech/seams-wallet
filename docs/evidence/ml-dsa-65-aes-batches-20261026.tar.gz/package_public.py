"""Package a public whitelist and scan fresh credentials before deleting payload files."""
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
STAGE = BASE / 'public-archive'
PHASES = ['precondition', 'control', 'candidate', 'software-precondition', 'software-batches']
ROLES = ['router', 'a', 'b', 'preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary', 'front']


def copy(relative):
    source = BASE / relative
    assert source.is_file(), relative
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def retain(value, values):
    if isinstance(value, dict):
        for item in value.values():
            retain(item, values)
        return
    if isinstance(value, list):
        for item in value:
            retain(item, values)
        return
    if not isinstance(value, str) or len(value) < 24:
        return
    values.add(value.encode())
    try:
        nested = json.loads(value)
    except (ValueError, TypeError):
        nested = None
    if isinstance(nested, (dict, list)):
        retain(nested, values)
    if re.fullmatch(r'[0-9a-fA-F]+', value) and len(value) % 2 == 0:
        raw = bytes.fromhex(value)
        if len(raw) >= 16:
            values.add(raw)
            values.add(value.lower().encode())
            values.add(value.upper().encode())
            values.add(base64.b64encode(raw))
    try:
        decoded = base64.b64decode(value, validate=True)
        if len(decoded) >= 16:
            values.add(decoded)
            values.add(decoded.hex().encode())
    except ValueError:
        pass

def patterns():
    values = set()
    for role in ROLES:
        for value in json.loads((BASE / (role + '-secrets.json')).read_text()).values():
            retain(value, values)
    retain((BASE / 'gateway-token').read_text().strip(), values)
    for index in range(1, 9):
        left = (BASE / f'wallet-{index}/a-kek').read_text().strip()
        right = (BASE / f'wallet-{index}/b-kek').read_text().strip()
        assert left != right
        retain(left, values)
        retain(right, values)
    for path in sorted(BASE.glob('*/a-kek')) + sorted(BASE.glob('*/b-kek')):
        retain(path.read_text().strip(), values)
    assert values
    return values


def prepare():
    assert not STAGE.exists(), 'Prepare once from the final closed capture'
    STAGE.mkdir()
    files = [
        'scope.json', 'hosted-upload-scope.md', 'source-start.json', 'preflight-receipt.json',
        'bootstrap-receipt.json', 'credentials-receipt.json', 'release-receipt.json', 'versions.json',
        'baseline-build-sources.json', 'candidate-manifest.json', 'candidate-policy-ready.json',
        'software-prototype-source-sha256.json', 'software-batch-manifest.json', 'software-policy-ready.json', 'frozen-measurement.json',
        'native-prototype-source-sha256.json', 'native-prototype.patch',
        'native-baseline-correlations.json', 'native-batched-correlations.json', 'bridge-parity.json',
        'worker-native-aes-e2e.json', 'worker-software-batch-e2e.json',
        'local-registration.json', 'local-registration-repeat.json', 'local-registration-final.json', 'local-registration-selected.json',
        'local-failed-setup-outcome.json', 'local-final-source-sha256.json',
        'setup-failed-operation.json', 'setup-failed-status.json', 'registration-stock-bindings.json',
        'software-failed-driver-status.json', 'driver-stage-public.json', 'candidate-driver-reconciliation.json', 'candidate-failed-driver-status.json',
        'readiness-losses.json', 'failed-paired-job.json', 'material-audit-first-failure.log', 'failure-profiles.json', 'failed-operation-materials.json', 'failed-material-inspection.json', 'b-live-errors-public.json',
        'front-tail-calibration.json', 'front-inspection-scope.json',
        'hosted-aes-probe.json', 'hosted-aes-probe-unprofiled.json', 'hosted-aes-probe-spaced-incomplete.json',
        'public-aes-capture-limit.json', 'capture-stability.json', 'material-audit.json',
        'parallel-comparison.json', 'hosted-signature-verification.json', 'bloat-final.log', 'rustfmt-final.log',
        'README.md', 'selection.json',
        'cloud-driver/qualified-closed-final/traces.json',
        'cloud-driver/software-initial-age-rejection/starting-lifetimes.json',
    ]
    files.extend(path.name for path in BASE.glob('*.py'))
    files.extend(path.name for path in BASE.glob('*.mjs'))
    files.extend(f'{role}.json' for role in ROLES)
    files.extend(f'{prefix}-{role}.json' for prefix in ['candidate', 'software'] for role in ROLES if role != 'front')
    files.extend(f'registration-{index}.json' for index in range(1, 9))
    files.extend(f'cloud-driver/qualified-closed-final/{role}-raw.jsonl' for role in ROLES if role != 'front')
    for phase in PHASES:
        files.extend([f'{phase}-campaign.json', f'{phase}-authority-gate.json'])
        files.extend(f'cloud-driver/{phase}/{name}.json' for name in ['start', 'client', 'driver-snapshots', 'summary', 'reserve-cycle'])
        files.extend(f'cloud-driver/{phase}-{boundary}/stock.json' for boundary in ['initial', 'final'])
    files.extend(f'cloud-driver/{phase}-initial/starting-lifetimes.json' for phase in ['control', 'candidate', 'software-batches'])
    for prefix in ['frozen-measurement-qualified', 'native-prototype-sources', 'software-prototype-sources', 'local-final-sources']:
        files.extend(str(path.relative_to(BASE)) for path in (BASE / prefix).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
    files.extend('bridge-probe/' + relative for relative in ['Cargo.toml', 'Cargo.lock', 'check.mjs', 'production-source-sha256.json'])
    for prefix in ['bridge-probe/src', 'bridge-probe/software', 'bridge-probe/native', 'cloud-driver/public-aes']:
        files.extend(str(path.relative_to(BASE)) for path in (BASE / prefix).rglob('*') if path.is_file())
    for relative in sorted(set(files)):
        copy(relative)
    for relative in [
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent.rs',
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs',
        'crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/pprf.rs',
        'crates/router-ab-cloudflare/src/ml_dsa/pool.rs',
        'crates/router-ab-cloudflare/src/ml_dsa/workers/coordinator.rs',
        'tests/e2e/ml-dsa-cloud-load-worker.mjs', 'tests/e2e/ml-dsa-durable-worker.e2e.mjs',
        'tests/helpers/mlDsaGatewayRegistration.fixtures.ts', 'tests/helpers/mlDsaLifecycle.e2e.mjs',
        'tools/ml-dsa-investigation/research/collect_worker_traces.py',
    ]:
        target = STAGE / 'current-sources' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, target)


def finish(secret_patterns):
    for relative in ['delete-receipt.json', 'deletion-verification.json', 'final-report.md']:
        copy(relative)
    files = sorted(path for path in STAGE.rglob('*') if path.is_file() and path.name != 'manifest.json')
    for path in files:
        data = path.read_bytes()
        assert not any(value in data for value in secret_patterns), str(path.relative_to(STAGE))
    manifest = {'files': {str(path.relative_to(STAGE)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
                'secret_exclusion': {'method': 'Public whitelist plus exact literals, nested role keys, hex variants, and decoded credential bytes. Private tails and fixture stores excluded.',
                                     'patterns_checked': len(secret_patterns), 'fixture_key_files_checked': len(list(BASE.glob('*/a-kek'))) + len(list(BASE.glob('*/b-kek'))), 'matches': 0}}
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-aes-batches-20261026.tar.gz'
    with archive.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(mode='w', fileobj=compressed) as bundle:
                for path in sorted(path for path in STAGE.rglob('*') if path.is_file()):
                    data = path.read_bytes()
                    info = tarfile.TarInfo(str(path.relative_to(STAGE)))
                    info.size = len(data)
                    info.mode = 0o644
                    bundle.addfile(info, io.BytesIO(data))
    receipt = {'path': archive.name, 'bytes': archive.stat().st_size,
               'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': len(files) + 1,
               'secret_exclusion': manifest['secret_exclusion']}
    (BASE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
