import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json','utf8'));
const token = (await readFile(base + '/gateway-token','utf8')).trim();
function digest(bytes) { return Array.from(createHash('sha256').update(bytes).digest()); }
const message = digest(Buffer.from('ML-DSA registered Worker key'));
const record = JSON.parse(await readFile(base + '/registration-3.json','utf8'));
const results = [];
for (const entry of record.cases) {
  if (!entry.initialStockSign.failed) continue;
  const request = {key:entry.key,operation:entry.initialStockSign.operation,message_digest:digest(Buffer.from(message)),context_digest:digest(Buffer.alloc(0))};
  const response = await fetch(scope.router_url + '/router-ab/ml-dsa/status', {
    method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':token},
    body:JSON.stringify(request),signal:AbortSignal.timeout(60000),
  });
  assert.equal(response.status,200);
  const status = await response.json();
  results.push({wallet:3,epoch:entry.epoch,request,httpStatus:response.status,status});
}
await writeFile(base + '/setup-failed-status.json',JSON.stringify({scope:'Read-only ordinary status lookup. The exact request is reconstructed from its retained operation/key and the unchanged deterministic setup message in the recorded registration E2E source. No signing request is submitted.',capturedAtMs:Date.now(),results},null,2)+'\n');
console.log(JSON.stringify(results.map(entry=>({wallet:entry.wallet,epoch:entry.epoch,status:entry.status}))));
