"""Compare matched hosted refill phases without treating protocol overlap as CPU overlap."""
import argparse
import json
from pathlib import Path
from statistics import median


def distribution(values):
    values = sorted(value for value in values if value is not None)
    return {'count': len(values), 'minimum': min(values), 'median': median(values), 'maximum': max(values)} if values else {'count': 0}


def stage_interval(row, job, start, end):
    stages = [item for item in row['preparation_stages'] if item['job'] == job]
    starts = [item['at_ms'] for item in stages if item['stage'] == start and item['at_ms'] is not None]
    ends = [item['at_ms'] for item in stages if item['stage'] == end and item['at_ms'] is not None]
    return max(ends) - min(starts) if starts and ends else None


def job_profile(job, rows):
    role = job['worker_role']
    a = [row for row in rows if row['role'] == role and row['producer_alarm']
         and any(item['batch'] == job['batch'] and item['stage'] == 'running' for item in row['producer_jobs'])]
    b = [row for row in rows if row['role'] == role.replace('preparer-a', 'preparer-b')
         and row['refill_job'] and row['refill_job']['batch'] == job['batch']]
    assert len(a) == 1
    assert len(b) <= 1
    receipts = [item for item in a[0]['refill'] if item['batch'] == job['batch']]
    if any(item['published'] for item in receipts):
        publication_status = 'published'
    elif any(item['published'] is False for item in receipts):
        publication_status = 'failed'
    else:
        publication_status = 'unknown'
    result = dict(job, roles={}, publication_status=publication_status)
    for side, matching in [('a', a), ('b', b)]:
        if not matching:
            continue
        row = matching[0]
        cache = [item for item in row.get('preparation_cache', []) if item['job'] == job['batch']]
        started = [item for item in cache if item['stage'] == 'started']
        prepared = [item for item in cache if item['stage'] == 'prepared']
        assert len(started) <= 1 and len(prepared) <= 1
        modules = sorted({item['module_instance'] for item in row['preparation_stages'] if item['module_instance']})
        memory = [item['wasm_linear_memory_bytes'] for item in row['preparation_stages'] if item['wasm_linear_memory_bytes'] is not None]
        result['roles'][side] = {
            'worker': row['worker'], 'version': row['version'], 'outcome': row['outcome'],
            'cpu_ms': row['cpu_ms'], 'wall_ms': row['wall_ms'], 'module_ids': modules,
            'request_colo': row.get('request_colo'), 'cache_started': started[0] if started else None,
            'cache_prepared': prepared[0] if prepared else None,
            'maximum_observed_wasm_bytes': max(memory) if memory else None,
            'correlations_ms': stage_interval(row, job['batch'], 'crypto_started', 'correlations_completed'),
            'commitments_ms': stage_interval(row, job['batch'], 'commitment_started', 'crypto_completed'),
            'serialized_to_publication_ms': stage_interval(row, job['batch'], 'serialized', 'published'),
            'transport': row['preparation_transport'], 'logs_truncated': row['logs_truncated'],
        }
    return result


def profiles(jobs):
    result = {}
    for size in [2, 4]:
        for role in ['preparer-a', 'preparer-a-secondary']:
            selected = [job for job in jobs if job['candidates'] == size and job['worker_role'] == role]
            if not selected:
                continue
            groups = {'all': selected}
            for status in ['published', 'failed', 'unknown']:
                groups[status] = [job for job in selected if job['publication_status'] == status]
            for state, group in groups.items():
                if not group:
                    continue
                entry = {}
                for side in ['a', 'b']:
                    values = [job['roles'][side] for job in group if side in job['roles']]
                    warm = [value for value in values if value['cache_prepared'] and value['cache_prepared']['topology_builds'] == 0 and value['cache_prepared']['topology_hits'] > 0]
                    cold = [value for value in values if value['cache_prepared'] and value['cache_prepared']['topology_builds'] > 0]
                    entry[side] = {
                        'count': len(values),
                        **{field: distribution(value[field] for value in values) for field in ['cpu_ms', 'wall_ms', 'correlations_ms', 'commitments_ms', 'serialized_to_publication_ms']},
                        'warm_cpu_ms': distribution(value['cpu_ms'] for value in warm),
                        'cold_cpu_ms': distribution(value['cpu_ms'] for value in cold),
                        'module_ids': sorted({identity for value in values for identity in value['module_ids']}),
                        'request_colos': sorted({value['request_colo'] for value in values if value['request_colo']}),
                        'load_shed_jobs': sum(value['outcome'] == 'loadShed' for value in values),
                    }
                result[f'{role}/{size}/{state}'] = entry
    return result


def union_ms(intervals):
    total = 0
    end = None
    for start, finish in sorted(intervals):
        if finish <= start:
            continue
        if end is None or start >= end:
            total += finish - start
        elif finish > end:
            total += finish - end
        end = max(finish, end) if end is not None else finish
    return total


def slot_activity(jobs, start, end):
    by_slot = {}
    all_intervals = []
    for slot in ['preparer-a', 'preparer-a-secondary']:
        selected = [job for job in jobs if job['worker_role'] == slot and job['published_at_ms'] is not None]
        intervals = [(max(start, job['started_at_ms']), min(end, job['published_at_ms'])) for job in selected]
        occupied = union_ms(intervals)
        by_slot[slot] = {'successful_jobs': len(selected), 'published_pairs': sum(len(job['batches']) for job in selected),
                         'protocol_occupied_ms': occupied, 'window_fraction': occupied / (end - start)}
        all_intervals += intervals
    combined = union_ms(all_intervals)
    return {'scope': 'Successful producer invocation start to publication, clipped to the load window. Intervals include waits and are not CPU utilization.',
            'by_slot': by_slot, 'either_slot_ms': combined,
            'both_slots_ms': sum(slot['protocol_occupied_ms'] for slot in by_slot.values()) - combined}


def phase(base, name):
    folder = base / 'cloud-driver' / name
    client = json.loads((folder / 'client.json').read_text())
    window = json.loads((folder / 'start.json').read_text())
    summary = json.loads((folder / 'summary.json').read_text())
    cycle = json.loads((folder / 'reserve-cycle.json').read_text())
    raw = json.loads((folder / 'traces.json').read_text())['records']
    rows = [row for row in raw if row['version'] == client['deploymentVersions'].get(row['role'])]
    jobs = [job_profile(job, rows) for job in summary['producer_profiles']['jobs'] if job['active_wallet']]
    overlaps = []
    for index, left in enumerate(jobs):
        if left['published_at_ms'] is None:
            continue
        for right in jobs[index + 1:]:
            if right['published_at_ms'] is None or left['worker_role'] == right['worker_role']:
                continue
            overlap = min(left['published_at_ms'], right['published_at_ms']) - max(left['started_at_ms'], right['started_at_ms'])
            if overlap > 0:
                assert (left['key'], left['epoch']) != (right['key'], right['epoch'])
                overlaps.append({'jobs': [left['batch'], right['batch']], 'overlap_ms': overlap})
    all_cache = [item for job in jobs for value in job['roles'].values() for item in [value['cache_started'], value['cache_prepared']] if item]
    return {
        'phase': name, 'policy': client['policy'], 'deployment_versions': client['deploymentVersions'],
        'authority_version_coverage': summary.get('authority_version_coverage', {'complete': False, 'reason': 'not_measured'}),
        'cycle_qualified': cycle.get('qualified', False),
        'signatures': client['successfulSignatures'], 'under_five_seconds': client['successfulSignaturesUnderFiveSeconds'],
        'under_eight_seconds': sum(row.get('verified') is True and row['elapsedMs'] < 8000 for row in client['requests']),
        'successful_http_ms': summary['successful_http_ms'], 'successful_demand_ms': summary['successful_demand_ms'],
        'admission_waits': summary['admission_waits'], 'censored_demands': summary['censored_demands'],
        'reserve_cycle': cycle, 'stock_ledger_complete': summary['stock_ledger_complete'],
        'pool_target_respected': summary['configured_pool_target_respected'],
        'trace_coverage_complete': summary['trace_coverage']['complete'],
        'post_starting_stock': summary['after_starting_stock_disposal_bound'],
        'unused_material_audit': summary['unused_material_audit'],
        'job_profiles': profiles(jobs), 'jobs': jobs, 'successful_cross_slot_overlaps': overlaps,
        'slot_activity': slot_activity(jobs, window['startAtMs'], window['endAtMs']),
        'cache_controls': {'events': len(all_cache), 'maximum_builds': max((item['topology_builds'] for item in all_cache), default=None),
                           'maximum_hits': max((item['topology_hits'] for item in all_cache), default=None),
                           'maximum_module_active_crypto': max((item['active_crypto'] for item in all_cache), default=None)},
        'limits': 'Wall intervals include waits. Cache and active computation counters belong to one Wasm module. Boundary Wasm memory excludes JS heap and transient peaks. Successful-call latency excludes prior admission waits.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('phases', nargs='+')
    args = parser.parse_args()
    result = [phase(args.directory, name) for name in args.phases]
    (args.directory / 'parallel-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([{'phase': row['phase'], 'signatures': row['signatures'],
                      'cycle_signatures_per_minute': row['reserve_cycle']['signatures_per_minute'],
                      'parallel_overlaps': len(row['successful_cross_slot_overlaps'])} for row in result]))


if __name__ == '__main__':
    main()
