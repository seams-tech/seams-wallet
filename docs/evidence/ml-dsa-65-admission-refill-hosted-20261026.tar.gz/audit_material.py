"""Reconcile exact takes, producer outcomes, and starting pair deadlines."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
PHASES = ['warmup', 'completion']
ROWS = json.loads((BASE / 'cloud-driver/qualified-closed-final/traces.json').read_text())['records']


def observe_takes(row, takes):
    if row['role'] not in takes:
        return
    for trace in row['signing_traces']:
        for batch in trace['batches']:
            if batch['value']['stage'] == 'taken':
                takes[row['role']][batch['value']['material_id']].add(trace['operation'])
    for item in row['material_stages']:
        if item['value']['stage'] == 'taken':
            takes[row['role']][item['value']['material_id']].add(item['operation'])


def phase(name):
    folder = BASE / 'cloud-driver' / name
    client = json.loads((folder / 'client.json').read_text())
    window = json.loads((folder / 'start.json').read_text())
    cycle = json.loads((folder / 'reserve-cycle.json').read_text())
    summary = json.loads((folder / 'summary.json').read_text())
    takes = {'a': defaultdict(set), 'b': defaultdict(set)}
    paired = set()
    deadlines = defaultdict(set)
    initial_stock = json.loads((BASE / 'registration-stock-bindings.json').read_text())['bindings']
    for pair, binding in initial_stock.items():
        deadlines[pair].add((binding['key'], binding['epoch'], binding['expires_at_ms']))
    scopes = {(hashlib.sha256(bytes.fromhex(wallet['publicKeyHex'])).hexdigest(), wallet['key']['epoch']) for wallet in client['wallets']}
    for row in ROWS:
        job = row['refill_job']
        if job:
            for pair in job['batches']:
                deadlines[pair].add((job['key'], job['epoch'], job['material_expires_at_ms']))
        if row['event_timestamp_ms'] is None or not window['startAtMs'] <= row['event_timestamp_ms'] <= cycle['restored_at_ms']:
            continue
        for item in row['inventories']:
            if (item['key'], item['epoch']) in scopes:
                paired.update(set(item['ready_a']) & set(item['ready_b']))
                paired.update(set(item['reserved_a']) & set(item['reserved_b']))
        observe_takes(row, takes)
    for role in takes:
        assert all(len(operations) == 1 for operations in takes[role].values()), (name, role, 'reuse')
    exact_takes_match = takes['a'] == takes['b']
    successful_operations = {bytes(request['operation']).hex() for request in client['requests'] if request.get('verified')}
    for operation in successful_operations:
        left = {pair for pair, operations in takes['a'].items() if operation in operations}
        right = {pair for pair, operations in takes['b'].items() if operation in operations}
        assert left == right and left, (name, operation, 'successful participant take mismatch')
    consumed = {pair for wallet in summary['wallets'] for outcome in wallet['consumption'] for pair in outcome.get('batches', [])}
    summary_takes_match = consumed == set(takes['a'])
    assert consumed <= (set(takes['a']) | set(takes['b'])), (name, 'unobserved summary take')
    initial = []
    stock = json.loads((BASE / 'cloud-driver' / (name + '-initial') / 'stock.json').read_text())
    for item in stock['observations']:
        for pair in sorted(set(item['ready_a']) & set(item['ready_b'])):
            bindings = deadlines[pair]
            initial.append({'pair': pair, 'key': item['key'], 'epoch': item['epoch'],
                            'recorded_deadlines': sorted(bindings),
                            'remaining_ms_at_load': next(iter(bindings))[2] - window['startAtMs'] if len(bindings) == 1 else None})
    if name in ['completion']:
        assert len(initial) == len(client['wallets']) * client['policy']['refill_target_batches']
        assert all(len(item['recorded_deadlines']) == 1 and item['recorded_deadlines'][0][:2] == (item['key'], item['epoch']) for item in initial)
        assert min(item['remaining_ms_at_load'] for item in initial) >= 900000
    jobs = []
    for job in summary['producer_profiles']['jobs']:
        if not job['active_wallet']:
            continue
        receipts = [item for row in ROWS for item in row['refill'] if item['batch'] == job['batch']]
        failure = any(item['published'] is False for item in receipts)
        success = any(item['published'] is True for item in receipts)
        assert success != failure, (name, job['batch'], 'missing or conflicting receipt')
        reported_failed_with_material = failure and bool(set(job['batches']) & (paired | consumed))
        jobs.append({'batch': job['batch'], 'pairs': job['batches'], 'published': success,
                     'a_cpu_ms': job['a_cpu_ms'], 'b_cpu_ms': job['b_cpu_ms'],
                     'a_outcome': job['outcome'], 'reported_failed_with_material': reported_failed_with_material})
    return {'exact_participant_takes_equal': exact_takes_match, 'summary_takes_equal': summary_takes_match, 'distinct_taken_pairs': len(consumed),
            'successful_operations_have_matching_takes': True, 'no_observed_reuse': True, 'initial_pairs': initial,
            'initial_pairs_without_unique_deadline': sum(len(item['recorded_deadlines']) != 1 for item in initial),
            'minimum_initial_remaining_ms': min((item['remaining_ms_at_load'] for item in initial if item['remaining_ms_at_load'] is not None), default=None),
            'failed_jobs': sum(not job['published'] for job in jobs),
            'successful_jobs': sum(job['published'] for job in jobs),
            'reported_failed_jobs_with_paired_or_taken_material': [job for job in jobs if job['reported_failed_with_material']], 'jobs': jobs,
            'cycle_qualified': cycle['qualified'], 'cycle_ledger': cycle['complete_cycle_ledger']}


def main():
    result = {name: phase(name) for name in PHASES}
    global_takes = {'a': defaultdict(set), 'b': defaultdict(set)}
    for row in ROWS:
        observe_takes(row, global_takes)
    assert all(len(operations) == 1 for role in global_takes.values() for operations in role.values()), 'Cross-phase material reuse'
    failed = json.loads((BASE / 'failed-operation-materials.json').read_text())['phases']
    retired = [pair for phase in failed for operation in phase['failed_operations']
               for pair in operation['failed_retired_without_observed_take']]
    assert len(retired) == len(set(retired)), 'Retirement counted in multiple operations'
    assert not set(retired) & (set(global_takes['a']) | set(global_takes['b'])), 'Retired bucket has an observed take'
    result['global_observed_takes'] = {'no_reuse': True, 'distinct_a_pairs': len(global_takes['a']), 'distinct_b_pairs': len(global_takes['b']),
                                      'scope': 'Every retained setup and load take event. Missing take or retirement events remain an observation limit.'}
    (BASE / 'material-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({name: {key: value for key, value in result[name].items() if key not in ['initial_pairs', 'jobs', 'cycle_ledger']} for name in PHASES}))


if __name__ == '__main__':
    main()
