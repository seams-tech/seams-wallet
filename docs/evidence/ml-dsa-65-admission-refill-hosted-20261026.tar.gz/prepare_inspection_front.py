from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent
source=(base/'cloud-driver/entry.mjs').read_text()
anchor='''  async fetch(request) {
'''
addition='''  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === '/__benchmark/inspect/a' || path === '/__benchmark/inspect/b') {
      if (request.headers.get('x-router-ab-internal-service-auth') !== this.env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) {
        return new Response('Unauthorized', {status:401});
      }
      if (request.method !== 'POST') return new Response('POST required', {status:405});
      const encoded = await request.arrayBuffer();
      if (encoded.byteLength > 16384) return new Response('Inspection request too large', {status:413});
      const input = JSON.parse(new TextDecoder().decode(encoded));
      if (!input || !Array.isArray(input.batches) || input.batches.length < 1 || input.batches.length > 16) {
        return new Response('Invalid inspection batch count', {status:400});
      }
      const service = path === '/__benchmark/inspect/a' ? this.env.INSPECT_A : this.env.INSPECT_B;
      return service.fetch('https://ml-dsa-role.internal/router-ab/ml-dsa/role', {
        method:'POST', headers:{'content-type':'application/json','x-router-ab-internal-service-auth':this.env.INTERNAL_AUTH},
        body:JSON.stringify({command:'inspect',key:input.key,batches:input.batches}),
      });
    }
'''
assert source.count(anchor)==1
entry=base/'cloud-driver/inspection-entry.mjs';entry.write_text(source.replace(anchor,addition))
config=json.loads((base/'front.json').read_text());config['main']=str(entry)
scope=json.loads((base/'scope.json').read_text())
for role,binding in [('a','INSPECT_A'),('b','INSPECT_B')]:
 worker=next(worker for worker in scope['workers'] if worker['role']==role)
 config['services'].append({'binding':binding,'service':worker['name']})
path=base/'front-inspection.json';path.write_text(json.dumps(config,indent=2)+'\n')
(base/'front-inspection-scope.json').write_text(json.dumps({'purpose':'Read-only batch-state inspection after all signing measurements. Same approved front and participants; no new Worker, secret, storage key, or write command. Raw key scope is validated by the existing participant parser.','worker':config['name'],'entry_sha256':hashlib.sha256(entry.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},indent=2)+'\n')
