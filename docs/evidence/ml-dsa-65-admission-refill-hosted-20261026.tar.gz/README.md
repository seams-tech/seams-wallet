# ML-DSA admission and refill evidence

Run python3 replay.py with Python 3 and Node.js 26.4.0. The replay is offline.
It checks manifest hashes, signatures, altered messages, material accounting, and phase summaries.
Four targets passed canonical enrollment and recovery. Three preserved setup failures prevented the planned eight-wallet cohort.
Both accounting ledgers balance. Warm-up retains one server signing failure. Two completion calls exceed eight seconds.
The driver functionalPassed flag does not certify that every operation succeeded.
No maximum-capacity or eight-wallet-capacity claim follows from this run.

The candidate recovers untouched expired reservations only after exact Declined authority.
It publishes each bounded role job in one transaction. Both changes preserve cryptographic bytes and FIPS seed recovery.
The local before/after scenario proves reclamation. No hosted reclamation event occurred naturally.
Both participant inspections confirm 13retired IDs after the admitted failure; no retained take event exists for them.
Retired state does not distinguish a physical burn from an unlogged take.

The test retains 16pairs per wallet, 2candidate consumption, 4candidate ordinary preparation, 2preparation slots, and 60second cooldown.
The runtime default remains one preparation slot. Initial registration and refill material retain their established lifetimes.
All temporary deployments are deleted after closure. Credential payloads and private fixtures are excluded.
