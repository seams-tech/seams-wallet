"""Reconcile producer completion receipts with observed durable publication."""
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent


def main():
    rows=json.loads((BASE/'cloud-driver/qualified-closed-final/traces.json').read_text())['records']
    paired=set()
    taken=set()
    role_takes={'a':set(),'b':set()}
    for row in rows:
        for inventory in row['inventories']:
            paired.update(set(inventory['ready_a']) & set(inventory['ready_b']))
            paired.update(set(inventory['reserved_a']) & set(inventory['reserved_b']))
        for stage in row['material_stages']:
            if stage['value']['stage']=='taken':
                taken.add(stage['value']['material_id'])
                if row['role'] in role_takes:role_takes[row['role']].add(stage['value']['material_id'])
    running_counts={}
    for row in rows:
        for job in row['producer_jobs']:
            if job['stage']=='running':running_counts[job['batch']]=running_counts.get(job['batch'],0)+1
    receipts={}
    reconciliations=[]
    for row in rows:
        for receipt in row['refill']:
            key=receipt['batch']
            value={'role':row['role'],'version':row['version'],**receipt}
            assert key not in receipts or receipts[key]==value
            receipts[key]=value
        for event in row['refill_recovery']:
            if event['stage']=='paired_publication_confirmed':
                stages=[item['stage'] for item in row['producer_jobs'] if item['batch']==event['batch']]
                reconciliations.append({'batch':event['batch'],'producer_stages':stages,'role':row['role'],'version':row['version']})
    contradictions=[]
    complete_publication=paired | (role_takes['a'] & role_takes['b'])
    for receipt in receipts.values():
        if receipt['published'] is False:
            exposed=set(receipt['batches']) & (paired | taken)
            if exposed:
                contradictions.append({'receipt':receipt,'observed_pairs':sorted(exposed),
                                       'all_pairs_have_publication_evidence':set(receipt['batches'])<=complete_publication})
    inactive_jobs=[]
    for phase in ['warmup','completion']:
        summary=json.loads((BASE/f'cloud-driver/{phase}/summary.json').read_text())
        inactive_jobs.extend({'phase':phase,'job':job} for job in summary['producer_profiles']['jobs'] if not job['active_wallet'])
    result={'scope':'Retained hosted setup and load records. Missing logs do not prove absence. Local fault injection validates paths that may not occur naturally here.',
            'reconciled_job_execution_counts':{item['batch']:running_counts.get(item['batch'],0) for item in reconciliations},
            'non_target_preparation_jobs':inactive_jobs,'completion_receipts':len(receipts),'published_receipts':sum(item['published'] is True for item in receipts.values()),
            'failed_receipts':sum(item['published'] is False for item in receipts.values()),
            'interrupted_receipts':sum(item['published'] is None for item in receipts.values()),
            'confirmed_publication_reconciliations':reconciliations,'reported_failures_with_paired_or_taken_material':contradictions}
    (BASE/'publication-outcomes.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key not in ['scope','confirmed_publication_reconciliations','reported_failures_with_paired_or_taken_material']}))


if __name__=='__main__':
    main()
