"""Run canonical enrollment/recovery and sustained signing at unchanged capacity."""
import json
import subprocess
from run_control import BASE, ROOT, SCOPE, ENV, run
from run_comparison import measure


def main():
    assert all(item['passed'] for item in json.loads((BASE / 'release-receipt.json').read_text()))
    versions = json.loads((BASE / 'versions.json').read_text())
    overrides = json.loads((BASE / 'registration-overrides.json').read_text())
    for index in range(1, 9):
        artifact = BASE / f'registration-{index}.json'
        if not artifact.exists():
            ENV['ML_DSA_TEST_WALLET_ID'] = overrides.get(str(index), f"{SCOPE['prefix']}-wallet-{index}")
            print(json.dumps({'stage': 'registration', 'wallet': index}), flush=True)
            with (BASE / f'registration-{index}.log').open('w') as output:
                process = subprocess.run(['node', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs',
                                          str(BASE / f'wallet-{index}'), str(artifact)],
                                         cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT)
            assert process.returncode in (0, 1) and artifact.is_file()
            # Preserve a failed setup signature while continuing independent wallets.
            # Canonical enrollment/recovery checks below remain mandatory.

        record = json.loads(artifact.read_text())
        assert record['registrationChecksPassed'] and record['recoveryPreservesCanonicalKey']
        assert record['policy'] == SCOPE['policy']
        print(json.dumps({'stage': 'registered', 'wallet': index, 'canonical_recovery': True,
                          'setup_functional_passed': record['functionalPassed']}), flush=True)
    measure('warmup', versions, 600000, False, BASE / 'candidate-build')
    measure('completion', versions, 360000, True, BASE / 'candidate-build')
    print(json.dumps({'stage': 'hosted_complete'}), flush=True)


if __name__ == '__main__':
    main()
