"""Describe exact-window provider failures without assigning an unknown cause."""
from collections import Counter
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
PHASES = ['warmup', 'completion']


def profile(name):
    folder = BASE / 'cloud-driver' / name
    window = json.loads((folder / 'start.json').read_text())
    rows = json.loads((folder / 'traces.json').read_text())['records']
    selected = [row for row in rows if row['event_timestamp_ms'] is not None
                and window['startAtMs'] <= row['event_timestamp_ms'] <= window['endAtMs']]
    failures = [row for row in selected if row['outcome'] == 'loadShed']
    result = []
    for row in failures:
        stages = row['preparation_stages']
        result.append({'role': row['role'], 'version': row['version'], 'path': row['path'],
                       'at_ms': row['event_timestamp_ms'], 'cpu_ms': row['cpu_ms'], 'wall_ms': row['wall_ms'],
                       'preparation_last_stages': [item['stage'] for item in stages[-3:]],
                       'observed_wasm_bytes': sorted({item['wasm_linear_memory_bytes'] for item in stages if item['wasm_linear_memory_bytes'] is not None}),
                       'signing_operation': row['signing_operation'], 'refill_job': row['refill_job'],
                       'exception_categories': row['exception_categories']})
    failed_sizes = {size for row in result for size in row['observed_wasm_bytes']}
    successful_sizes = {item['wasm_linear_memory_bytes'] for row in selected if row['outcome'] == 'ok'
                        for item in row['preparation_stages'] if item['wasm_linear_memory_bytes'] is not None}
    return {'phase': name, 'load_shed_by_role': dict(Counter(row['role'] for row in failures)),
            'failed_wasm_sizes_also_seen_in_success': sorted(failed_sizes & successful_sizes), 'failures': result}


def main():
    result = {'limits': 'Exact invocation windows and retained public records only. Wasm boundary sizes exclude transient peaks, JS heap, and native allocations. loadShed is a provider outcome, not an established root cause.',
              'phases': [profile(name) for name in PHASES]}
    (BASE / 'failure-profiles.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([{'phase': row['phase'], 'load_shed_by_role': row['load_shed_by_role']} for row in result['phases']]))


if __name__ == '__main__':
    main()
