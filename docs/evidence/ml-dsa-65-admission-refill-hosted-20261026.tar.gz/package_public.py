"""Package retained public evidence and exclude synthetic credentials."""
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
BASE=Path(__file__).resolve().parent
STAGE=BASE/'public-archive'
PHASES=['warmup','completion']
ROLES=['router','a','b','preparer-a','preparer-b','preparer-a-secondary','preparer-b-secondary','front']


def retain(value,values):
    if isinstance(value,dict):
        for item in value.values():retain(item,values)
    elif isinstance(value,list):
        for item in value:retain(item,values)
    elif isinstance(value,str) and len(value)>=24:
        values.add(value.encode())
        try:
            nested=json.loads(value)
            if isinstance(nested,(dict,list)):retain(nested,values)
        except ValueError:pass
        if re.fullmatch('[0-9a-fA-F]+',value) and len(value)%2==0:
            raw=bytes.fromhex(value)
            if len(raw)>=16:
                values.update([raw,value.lower().encode(),value.upper().encode(),base64.b64encode(raw)])
        try:
            raw=base64.b64decode(value,validate=True)
            if len(raw)>=16:values.update([raw,raw.hex().encode()])
        except ValueError:pass


def patterns():
    values=set()
    for role in ROLES:retain(json.loads((BASE/f'{role}-secrets.json').read_text()),values)
    retain((BASE/'gateway-token').read_text().strip(),values)
    for path in list(BASE.glob('wallet-*/*-kek')):
        retain(path.read_text().strip(),values)
    for role in ['a','b']:
        retain(Path(f'/private/tmp/ml-dsa-aes-batches-20261026/worker-role-fixtures/{role}-kek').read_text().strip(),values)
    assert values
    return values


def copy(name):
    source=BASE/name
    assert source.is_file(),name
    target=STAGE/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)


def prepare():
    assert not STAGE.exists()
    STAGE.mkdir()
    files=['scope.json','hosted-upload-scope.md','source-manifest.json','preflight-receipt.json',
           'bootstrap-receipt.json','credentials-receipt.json','release-receipt.json','versions.json',
           'local-before-corrected.json','local-after-final.json','bloat.log','cohort-scope.json',
           'frozen-measurement.json','capture-stability.json','parallel-comparison.json','material-audit.json',
           'failure-profiles.json','publication-outcomes.json','readiness-losses.json',
           'registration-stock-bindings.json','hosted-signature-verification.json','client-reconciliation.json',
           'failed-operation-materials.json','failed-material-inspection.json','registration-overrides.json',
           'failed-registration-4.json','failed-registration-5.json','failed-registration-5-retry.json',
           'registration-preparation-failure.json','front-inspection-scope.json',
           'README.md','cloud-driver/qualified-closed-final/traces.json']
    files.extend(path.name for path in BASE.glob('*.py'))
    files.extend(path.name for path in BASE.glob('*.mjs'))
    files.extend(f'{role}.json' for role in ROLES)
    files.extend(f'registration-{index}.json' for index in range(1,5))
    files.extend(f'cloud-driver/qualified-closed-final/{role}-raw.jsonl' for role in ROLES if role!='front')
    for phase in PHASES:
        files.extend([f'{phase}-campaign.json',f'{phase}-authority-gate.json'])
        files.extend(f'cloud-driver/{phase}/{name}.json' for name in ['start','client','driver-snapshots','summary','reserve-cycle'])
        files.extend(f'cloud-driver/{phase}-{boundary}/stock.json' for boundary in ['initial','final'])
    files.append('cloud-driver/completion-initial/starting-lifetimes.json')
    for folder in ['frozen-measurement-qualified','current-sources']:
        files.extend(str(p.relative_to(BASE)) for p in (BASE/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for name in sorted(set(files)):copy(name)


def finish(secrets):
    for name in ['delete-receipt.json','deletion-verification.json','final-report.md']:copy(name)
    files=sorted(p for p in STAGE.rglob('*') if p.is_file() and p.name!='manifest.json')
    for path in files:
        data=path.read_bytes()
        assert not any(secret in data for secret in secrets),str(path.relative_to(STAGE))
    manifest={'files':{str(p.relative_to(STAGE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
              'secret_exclusion':{'method':'Explicit public whitelist and recursive credential literal/decoded-byte scan. Private fixtures excluded.','patterns':len(secrets),'matches':0}}
    (STAGE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=BASE/'ml-dsa-65-admission-refill-hosted-20261026.tar.gz'
    with archive.open('wb') as target:
        with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0,compresslevel=6) as compressed:
            with tarfile.open(mode='w',fileobj=compressed) as bundle:
                for path in sorted(p for p in STAGE.rglob('*') if p.is_file()):
                    data=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(STAGE)))
                    info.size=len(data);info.mode=0o644;bundle.addfile(info,io.BytesIO(data))
    receipt={'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+1,'secret_exclusion':manifest['secret_exclusion']}
    (BASE/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))
