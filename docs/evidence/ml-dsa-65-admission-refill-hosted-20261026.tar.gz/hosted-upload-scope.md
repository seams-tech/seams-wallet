# ML-DSA admission and refill benchmark credential scope

Create the eight temporary Workers below and upload these exact fresh benchmark credentials.
A Workers receive only the A storage key. B Workers receive only the B storage key.
Credentials protect synthetic wallets. They contain no production wallet or account credentials.
The rerun retains two preparation slots, two-at-once consumption, sixteen pairs per wallet, and the sixty-second wallet cooldown.
Preparation stays on Workers. Wallet-seed recovery and standard FIPS export remain required.
Both participants recover untouched expired reservations only after exact Router Declined authority. Publication stores the complete one- or two-pair role job per transaction. The Router uses the unchanged verified bundle. Cryptographic protocol bytes, standard FIPS formats, and pool capacity stay unchanged.
All eight temporary Workers will be removed after measurements. Local private fixtures will be retained.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-admit-1026-9834c2-router | 0df6b25c7e72a5022ef2a20b365d2f268ea0eaf2bd66cedcb19b6293895607a7 |
| ml-dsa-admit-1026-9834c2-a | 923c7bb7915707364721272cd7c18fdc82aa51a6934af0c23de489f225bd35ee |
| ml-dsa-admit-1026-9834c2-b | fea3d50daa65de81975954ec67e8d685f3c042a5171d89ea120a3458a2e5f160 |
| ml-dsa-admit-1026-9834c2-preparer-a | 923c7bb7915707364721272cd7c18fdc82aa51a6934af0c23de489f225bd35ee |
| ml-dsa-admit-1026-9834c2-preparer-b | fea3d50daa65de81975954ec67e8d685f3c042a5171d89ea120a3458a2e5f160 |
| ml-dsa-admit-1026-9834c2-preparer-a-secondary | 923c7bb7915707364721272cd7c18fdc82aa51a6934af0c23de489f225bd35ee |
| ml-dsa-admit-1026-9834c2-preparer-b-secondary | fea3d50daa65de81975954ec67e8d685f3c042a5171d89ea120a3458a2e5f160 |
| ml-dsa-admit-1026-9834c2-front | 0df6b25c7e72a5022ef2a20b365d2f268ea0eaf2bd66cedcb19b6293895607a7 |
