"""Measure refill with the four fully verified wallets; preserve all failed setup attempts."""
import json
from run_control import BASE
from run_comparison import measure

versions = json.loads((BASE / 'versions.json').read_text())
for index in range(1, 5):
    record = json.loads((BASE / f'registration-{index}.json').read_text())
    assert record['registrationChecksPassed'] and record['recoveryPreservesCanonicalKey']
measure('warmup', versions, 600000, False, BASE / 'candidate-build', 4)
measure('completion', versions, 360000, True, BASE / 'candidate-build', 4)
print(json.dumps({'stage': 'four_wallet_refill_complete'}), flush=True)
