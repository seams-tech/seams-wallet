"""Bind failed dispatches to their exact claimed public inventory."""
import hashlib,json
from pathlib import Path

BASE=Path(__file__).resolve().parent
PHASES=['warmup', 'completion']


def operation_hex(request):
    return bytes(request['operation']).hex()


def collect_phase(name):
    folder=BASE/'cloud-driver'/name
    if not (folder/'client.json').exists():
        return None
    client=json.loads((folder/'client.json').read_text())
    rows=json.loads((folder/'traces.json').read_text())['records']
    results=[]
    for request in client['requests']:
        if request.get('state')!='failed':
            continue
        operation=operation_hex(request)
        found=[row for row in rows if row['role']=='router'
               and any(trace['operation']==operation for trace in row['router_traces'])
               and any(stock['operation']==operation and stock['stage']=='claimed' for stock in row['admission_stock'])]
        assert len(found)==1,(name,operation,'Missing unique claimed Router invocation')
        row=found[0]
        claims=[stock for stock in row['admission_stock'] if stock['operation']==operation and stock['stage']=='claimed']
        assert len(claims)==1
        key=request['signingRequest']['key']
        digest=bytes(key['public_key_digest']).hex()
        inventories=[item for item in row['inventories'] if (item['key'],item['epoch'])==(digest,key['epoch'])]
        assert inventories
        inventory=inventories[-1]
        reserved=sorted(set(inventory['ready_a'])&set(inventory['ready_b']))
        assert len(reserved)==claims[0]['paired']
        traces=[trace for candidate in rows for trace in candidate['signing_traces'] if trace['operation']==operation]
        taken={side:sorted({item['value']['material_id'] for trace in traces if trace['role']==side
                           for item in trace['batches'] if item['value']['stage']=='taken'}) for side in ['a','b']}
        for candidate in rows:
            side=candidate['role']
            if side not in taken:
                continue
            staged={item['value']['material_id'] for item in candidate['material_stages']
                    if item['operation']==operation and item['value']['stage']=='taken'}
            taken[side]=sorted(set(taken[side])|staged)
        taken_union=set(taken['a'])|set(taken['b'])
        assert taken_union<=set(reserved)
        outcomes=[item['outcome'] for candidate in rows for item in candidate['signing'] if item['operation']==operation]
        assert len(outcomes)==1
        router=[trace for trace in row['router_traces'] if trace['operation']==operation]
        assert len(router)==1
        settled=any(item['stage']=='roles_released' for item in router[0]['milestones'])
        assert settled
        participants=[{field:candidate[field] for field in ['role','path','outcome','event_timestamp_ms','exception_categories']}
                      for candidate in rows if candidate['role']=='b' and candidate['signing_operation']==operation]
        results.append({'wallet':request['wallet'],'operation':operation,'request':request['signingRequest'],
                        'claimed_at_ms':claims[0]['log_timestamp_ms'],'claimed_inventory':inventory,
                        'reserved_pairs':reserved,'actual_takes':taken,'failed_retired_without_observed_take':sorted(set(reserved)-taken_union),
                        'router_outcome':outcomes[0],'roles_released':settled,'released_at_ms':next(item['at_ms'] for item in router[0]['milestones'] if item['stage']=='roles_released'),'participant_b_requests':participants})
    return {'phase':name,'failed_operations':results}


def main():
    phases=[result for name in PHASES if (result:=collect_phase(name)) is not None]
    report={'scope':'Claimed IDs derive from the last paired inventory in the exact Router request and reserve_pair selecting its full intersection. Both signing traces and incremental material stages contribute observed takes. Independent participant inspection must confirm retirement. Retired collapses Consumed, Burned, and wrong-key states. A crash can hide a durable take. This is an availability-cost bucket, not proof of a physical burn or zero consumption. Provider loadShed causes remain unknown.',
            'source_files':['crates/router-ab-cloudflare/src/ml_dsa/workers/coordinator.rs','crates/router-ab-cloudflare/src/ml_dsa/pool.rs'],
            'phases':phases}
    (BASE/'failed-operation-materials.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps([{'phase':phase['phase'],'failed_operations':len(phase['failed_operations']),
                       'failed_retired_without_observed_take':sum(len(item['failed_retired_without_observed_take']) for item in phase['failed_operations'])} for phase in phases]))


if __name__=='__main__':
    main()
