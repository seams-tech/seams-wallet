import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(base + '/scope.json','utf8'));
const token = (await readFile(base + '/gateway-token','utf8')).trim();
const evidence = JSON.parse(await readFile(base + '/failed-operation-materials.json','utf8'));
const results = [];
function batchBytes(identity) {
  assert.match(identity,/^[0-9a-f]{64}$/);
  return Array.from(Buffer.from(identity,'hex'));
}
for (const phase of evidence.phases) {
  for (const operation of phase.failed_operations) {
    for (const role of ['a','b']) {
      const worker = scope.workers.find(matchRole.bind(undefined,role));
      assert.ok(worker);
      const url = scope.router_url + '/__benchmark/inspect/' + role;
      for (let offset=0;offset<operation.failed_retired_without_observed_take.length;offset+=16) {
        const ids = operation.failed_retired_without_observed_take.slice(offset,offset+16);
        const response = await fetch(url, {
          method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':token},
          body:JSON.stringify({key:operation.request.key,batches:ids.map(batchBytes)}),
          signal:AbortSignal.timeout(60000),
        });
        assert.equal(response.status,200);
        const states = await response.json();
        assert.equal(states.length,ids.length);
        assert.ok(states.every(retired));
        results.push({phase:phase.phase,role,operation:operation.operation,key:operation.request.key,
          pairs:ids,states,httpStatus:response.status,observedAtMs:Date.now()});
      }
    }
  }
}
function matchRole(role,worker) { return worker.role===role; }
function retired(state) { return state==='retired'; }
await writeFile(base + '/failed-material-inspection.json',JSON.stringify({scope:'Read-only direct participant inspection. These exact failed-operation IDs with no recorded take must be permanently retired at both participants. Inspection returns no private ciphertext or signing share.',passed:true,results},null,2)+'\n');
console.log(JSON.stringify({passed:true,inspections:results.length,pairsPerRole:results.filter(isA).reduce(sumPairs,0)}));
function isA(item) { return item.role==='a'; }
function sumPairs(count,item) { return count+item.pairs.length; }
