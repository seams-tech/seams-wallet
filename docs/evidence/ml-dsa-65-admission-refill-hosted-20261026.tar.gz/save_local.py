"""Save the focused local reproduction with credential exclusion."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
spec = importlib.util.spec_from_file_location('scan', '/private/tmp/ml-dsa-publication-completion-20261026/package_public.py')
scan = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scan)
secrets = set()
for path in BASE.glob('*-secrets.json'):
    scan.retain(json.loads(path.read_text()), secrets)
for role in ['a', 'b']:
    for path in [BASE / 'wallet-1' / (role + '-kek'), Path('/private/tmp/ml-dsa-aes-batches-20261026/worker-role-fixtures') / (role + '-kek')]:
        scan.retain(path.read_text().strip(), secrets)
before = json.loads((BASE / 'local-before-corrected.json').read_text())
after = json.loads((BASE / 'local-after-final.json').read_text())
assert before['passed'] is False and 'Unadmitted material was lost' in before['error']
assert after['passed'] is True
assert after['expiredUnadmittedRecovery']['recoveredPairs'] == 16
assert after['expiredUnadmittedRecovery']['verifiedReuseOperation']
assert after['standardSignaturesVerifiedByOpenSsl'] == 3
payload = json.dumps({'before': before, 'after': after}, separators=(',', ':')).encode()
assert not any(secret in payload for secret in secrets)
name = 'ml-dsa-65-admission-refill-local-20261026.json.gz'
archive = gzip.compress(payload, mtime=0)
(ROOT / 'docs/evidence' / name).write_bytes(archive)
index = {
    'scope': 'Real Worker bundles in local workerd. Old bundles reproduce expired unadmitted material loss. Candidate preserves sixteen pairs, and a fresh verified signature consumes reclaimed material. This does not establish hosted throughput.',
    'baseline_expected_failure': before['error'],
    'candidate_passed': after['passed'],
    'recovered_pairs': after['expiredUnadmittedRecovery']['recoveredPairs'],
    'verified_reuse_operation': after['expiredUnadmittedRecovery']['verifiedReuseOperation'],
    'verified_signatures': after['standardSignaturesVerifiedByOpenSsl'],
    'worker_wasm_sha256': after['workerWasmSha256'],
    'provenance': after['provenance'],
    'native_e2e': 'cargo test --manifest-path crates/router-ab-cloudflare/Cargo.toml --features ml-dsa --test ml_dsa_durable_pool_e2e: passed',
    'archive': {'file': name, 'sha256': hashlib.sha256(archive).hexdigest()},
    'credential_scan_matches': 0,
    'hosted': 'pending_explicit_deployment_and_credential_approval',
}
(ROOT / 'docs/evidence/ml-dsa-65-admission-refill-local-20261026.json').write_text(json.dumps(index, indent=2) + '\n')
report = '''# ML-DSA admission and refill optimization

The candidate preserves untouched material after an expired, unadmitted operation.
It also publishes a complete role job through one bounded request and transaction.
Hosted performance remains unmeasured. The exact eight-Worker deployment awaits approval.

## Performance purpose

The preceding hosted run lost twelve pairs around a canceled admission. That equals 24 candidates or six four-candidate refill jobs.
Its two slow A publication calls took 26.668 and 21.604 seconds, with only 91 and 111 milliseconds of CPU.
Their authorization, transaction, storage, and response waits remain unresolved.
One publication request removes a serial dispatch and commit. Its larger transaction could increase blocking or memory use.

## Changes and validation

Reservations retain their exact request binding. Inventory checks expired reservations against Router authority before reclaiming them.
Only Declined permits reclamation. The local transaction fences delayed use and releases untouched reservations.
Admitted terminal failures retain conservative retirement. Recovery errors leave material unavailable for later recovery.
Key, epoch, material lifetime, and single-use checks remain enforced.

The old Worker bundles fail the composed scenario because unadmitted material is lost.
The candidate retains all sixteen reserved pairs. A fresh verified signature consumes reclaimed material.
Replay requests after Declined are refused. This does not inject an already-authorized delayed reservation response.
All three signatures verify. Restart, lost publication replies, interrupted producers, and consumed-material refusal also pass.
The existing native durable-pool E2E passes.

The first fixture attempt did not intercept Router admission. Its result is excluded from the before/after evidence.
Independent review found a cross-key counting error in the candidate. The corrected code keeps recovery and readiness scoped to the requested key.
The review also identified an extra inventory transaction and metadata scan. Hosted measurements must include this overhead.

## Hosted comparison

Measure successful signatures with full reserve restoration, lost pairs, publication waits, and empty-pool waits.
Retain eight wallets, two preparation slots, sixteen pairs per wallet, and the sixty-second wallet cooldown.
Keep two-at-once consumption, wallet-seed recovery, standard FIPS export, and preparation on Workers.
GPU work remains deferred. No temporary Worker was created after the automatic approval rejection.
The required bloat check remains at the inherited 13,972 duplicated Rust lines against a 13,754-line baseline.

[Local evidence](../evidence/ml-dsa-65-admission-refill-local-20261026.json) and [full artifact](../evidence/ml-dsa-65-admission-refill-local-20261026.json.gz).
'''
(ROOT / 'docs/router-ab/ml-dsa-65-admission-refill-report.md').write_text(report)
p = ROOT / 'docs/router-ab/ml-dsa-65-investigation-plan.md'
s = p.read_text()
needle = 'Current priority: canceled-admission retirement, primary-B loadShed, and long publication waits.'
assert needle in s
s = s.replace(needle, '''Current priority: measure the admission and refill performance candidate on Cloudflare.
The [candidate](ml-dsa-65-admission-refill-report.md) reclaims untouched expired reservations only after exact Declined authority.
It publishes each role's complete refill job in one bounded transaction. Consumption remains two candidates at a time.
The real-Worker before/after test reproduces the old loss and retains all sixteen pairs with the candidate.
A fresh verified signature consumes reclaimed material. All three signatures and the native lifecycle E2E pass.
The hosted run awaits explicit approval for its eight new Workers and fresh test credentials.
No hosted speed improvement is claimed. Measure the larger publication transaction and extra inventory scan before selecting them.''')
p.write_text(s)
print(json.dumps({'baseline_reproduced': True, 'candidate_passed': True, 'recovered_pairs': 16, 'verified_signatures': 3, 'credential_scan_matches': 0, 'archive_bytes': len(archive)}))
