import assert from 'node:assert/strict';
import {createHash,createPublicKey,verify} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
const base=import.meta.dirname;
const scope=JSON.parse(await readFile(base+'/scope.json','utf8'));
const token=(await readFile(base+'/gateway-token','utf8')).trim();
const results=[];
function matchWallet(index,wallet) {return wallet.index===index;}
for (const phase of ['warmup','completion']) {
  const client=JSON.parse(await readFile(`${base}/cloud-driver/${phase}/client.json`,'utf8'));
  for (const request of client.requests) {
    if (request.status!=='client_error_unknown_server_outcome') continue;
    assert(request.signingRequest);
    assert.deepEqual(request.signingRequest.operation,request.operation);
    assert.deepEqual(Buffer.from(request.signingRequest.message_digest),createHash('sha256').update(Buffer.from(request.messageHex,'hex')).digest());
    assert.deepEqual(Buffer.from(request.signingRequest.context_digest),createHash('sha256').update(Buffer.from(request.contextHex,'hex')).digest());
    const response=await fetch(scope.router_url+'/router-ab/ml-dsa/status',{
      method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':token},
      body:JSON.stringify(request.signingRequest),signal:AbortSignal.timeout(60000),
    });
    assert.equal(response.status,200);
    const status=await response.json();
    let verified=false;
    if(status?.state==='succeeded') {
      const wallet=client.wallets.find(matchWallet.bind(null,request.wallet));
      assert(wallet);
      const key=createPublicKey({key:Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100','hex'),Buffer.from(wallet.publicKeyHex,'hex')]),format:'der',type:'spki'});
      assert(verify(null,Buffer.from(request.messageHex,'hex'),key,Buffer.from(status.signature)));
      verified=true;
    }
    results.push({phase,wallet:request.wallet,requestId:request.requestId,operation:request.operation,status,verified});
  }
}
await writeFile(base+'/client-reconciliation.json',JSON.stringify({scope:'Read-only status lookup. Original client failures remain unchanged. No signing request is resubmitted.',results},null,2)+'\n');
console.log(JSON.stringify({interrupted:results.length,recoveredVerified:results.filter(isVerified).length}));
function isVerified(item) {return item.verified;}
