"""Find the first fresh set of full-pool observations after the load cutoff."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'frozen-measurement-qualified/tools/ml-dsa-investigation/research'))
from summarize_capacity import authority_version_coverage, producer_profiles
from summarize_multi_wallet import batch_scopes
from summarize_refill import paired, timestamp
name = sys.argv[1]
folder = BASE / 'cloud-driver' / name
start = json.loads((folder / 'start.json').read_text())
client = json.loads((folder / 'client.json').read_text())
rows = json.loads((BASE / 'cloud-driver' / 'qualified-closed-final' / 'traces.json').read_text())['records']
scopes = {(hashlib.sha256(bytes.fromhex(wallet['publicKeyHex'])).hexdigest(), wallet['key']['epoch']) for wallet in client['wallets']}
receipt = json.loads((BASE / 'cloud-driver' / (name + '-final') / 'stock.json').read_text())
observation_end_ms = max(item['log_timestamp_ms'] for item in receipt['observations'])
events = []
for row in rows:
    if row['version'] != client['deploymentVersions'].get(row['role']):
        continue
    for item in row['inventories']:
        at = item['log_timestamp_ms'] or row['event_timestamp_ms']
        key = (item['key'], item['epoch'])
        if key in scopes and start['endAtMs'] <= at <= observation_end_ms:
            events.append((at, key, item))
events.sort(key=lambda event: event[0])
latest = {}
restored = None
for at, key, item in events:
    latest[key] = (at, item)
    if len(latest) != len(scopes):
        continue
    full = True
    for observed, snapshot in latest.values():
        paired_ids = set(snapshot['ready_a']) & set(snapshot['ready_b'])
        if len(paired_ids) != client['policy']['refill_target_batches'] or snapshot['reserved_a'] or snapshot['reserved_b'] or at - observed > 45_000:
            full = False
            break
    if full:
        restored = at
        break
assert restored is not None, 'No simultaneous fresh full-reserve observations'
authority = authority_version_coverage(client, rows, start['startAtMs'], restored)
cycle_jobs = producer_profiles(client, rows, start['startAtMs'], restored)['jobs']
serial_slots_valid = client['policy'].get('max_active_preparations', 1) != 1 or all(job['worker_role'] == 'preparer-a' for job in cycle_jobs)
summary = json.loads((folder / 'summary.json').read_text())
initial_ids = {identity for wallet in summary['wallets'] for identity in wallet['initial_ids_including_prestarted_producers']}
consumed_ids = {identity for wallet in summary['wallets'] for outcome in wallet['consumption'] for identity in outcome.get('batches', [])}
final_ids = {identity for observed, snapshot in latest.values() for identity in paired(snapshot)}
scoped = batch_scopes(rows)
receipted_ids = {identity for row in rows for item in row['refill'] if item['published']
           and start['startAtMs'] < timestamp(row, item) <= restored
           for identity in item['batches'] if scoped.get(identity) in scopes}
observed_ids = {identity for row in rows for item in row['inventories']
                if (item['key'], item['epoch']) in scopes and start['startAtMs'] < timestamp(row, item) <= restored
                for identity in paired(item) + paired(item, 'reserved')}
new_ids = (receipted_ids | observed_ids) - initial_ids
# Availability accounting includes failed-operation retirement without an observed take.
# Inspection does not distinguish a burned record from an unlogged consumed record.
failed = json.loads((BASE / 'failed-operation-materials.json').read_text())['phases']
inspections = json.loads((BASE / 'failed-material-inspection.json').read_text())['results']
retired_ids = set()
observed_taken = set(consumed_ids)
for phase in failed:
    if phase['phase'] != name:
        continue
    for operation in phase['failed_operations']:
        assert operation['released_at_ms'] <= restored
        observed_taken.update(operation['actual_takes']['a'])
        observed_taken.update(operation['actual_takes']['b'])
        identities = set(operation['failed_retired_without_observed_take'])
        for side in ['a', 'b']:
            matches = [item for item in inspections if item['phase'] == name
                       and item['operation'] == operation['operation'] and item['role'] == side]
            if identities:
                assert len(matches) == 1
                assert set(matches[0]['pairs']) == identities
                assert matches[0]['httpStatus'] == 200
                assert all(state == 'retired' for state in matches[0]['states'])
        retired_ids.update(identities)
assert not (retired_ids & (observed_taken | final_ids))
accounted_ids = observed_taken | retired_ids | final_ids
ledger = {'initial_pairs': len(initial_ids), 'new_paired_pairs': len(new_ids),
          'completion_receipted_pairs_before_restoration': len(receipted_ids - initial_ids),
          'paired_before_completion_receipt': sorted(observed_ids - receipted_ids - initial_ids),
          'summary_consumed_pairs': len(consumed_ids), 'observed_taken_pairs': len(observed_taken), 'failed_retired_without_observed_take_pairs': len(retired_ids), 'final_pairs': len(final_ids),
          'unaccounted_pairs': sorted((initial_ids | new_ids) - accounted_ids),
          'unexplained_pairs': sorted(accounted_ids - (initial_ids | new_ids)),
          'retirement_limit': 'Retired proves unavailability, not burn versus unlogged consumption.', 'complete': not (observed_taken & final_ids)
                      and (initial_ids | new_ids) == accounted_ids}
result = {'scope': 'Finite load plus the earliest captured set of full reserve observations, each no older than 45 seconds. Observation delay is included. This is not a maximum-capacity claim.',
          'start_at_ms': start['startAtMs'], 'restored_at_ms': restored,
          'restoration_observation_bound_ms': observation_end_ms,
          'after_load_ms': restored - start['endAtMs'],
          'verified_signatures': client['successfulSignatures'],
          'cycle_ms': restored - start['startAtMs'],
          'signatures_per_minute': client['successfulSignatures'] * 60_000 / (restored - start['startAtMs']),
          'authority_version_coverage': authority, 'serial_slots_valid': serial_slots_valid,
          'client_functional_passed': client['functionalPassed'],
          'qualified': client['functionalPassed'] and authority['complete'] and serial_slots_valid and ledger['complete'], 'complete_cycle_ledger': ledger,
          'observations': [item for observed, item in latest.values()]}
(folder / 'reserve-cycle.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'observations'}))

assert result['qualified'], 'Full-cycle qualification failed; inspect client, policy, and material ledger'
