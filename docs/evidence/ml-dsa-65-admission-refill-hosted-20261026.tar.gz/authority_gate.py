"""Require the effective admission version and no observed live refill lease."""
import json
from pathlib import Path
import subprocess
import time


def wait_for_authority(base, frozen, name, expected):
    deadline = time.time() + 900
    observations = []
    folder = base / 'cloud-driver' / (name + '-authority')
    while time.time() < deadline:
        with (base / (name + '-authority.log')).open('a') as log:
            subprocess.run(['node', str(frozen / 'tests/e2e/ml-dsa-cloud-load.e2e.mjs'),
                'traces', str(base), name + '-authority'], cwd=frozen, stdout=log,
                stderr=subprocess.STDOUT, check=True)
        rows = json.loads((folder / 'traces.json').read_text())['records']
        now = int(time.time() * 1000)
        recent = [row for row in rows if row['role'] == 'router'
                  and row['path'] in ('/control', '/check')
                  and row['event_timestamp_ms'] is not None
                  and now - 60000 <= row['event_timestamp_ms'] <= now]
        settled = {item['batch'] for row in rows for item in row['refill_wakes']
                   if item['event'] == 'ml_dsa_refill_settled_v1'}
        live = {item['batch'] for row in rows for item in row['refill_claims']
                if item['status'] == 'acquired' and item['expires_at_ms'] > now
                and item['batch'] not in settled}
        versions = sorted({row['version'] for row in recent})
        observed = {'at_ms': now, 'expected_version': expected, 'recent_versions': versions,
                    'recent_authority_invocations': len(recent), 'unsettled_live_jobs': sorted(live)}
        observations.append(observed)
        (base / (name + '-authority-gate.json')).write_text(json.dumps(observations, indent=2)+'\n')
        print(json.dumps({'stage': 'authority_gate', 'phase': name, **observed}), flush=True)
        if versions == [expected] and not live:
            return
        time.sleep(30)
    raise RuntimeError('Effective admission version did not settle before the deadline')
