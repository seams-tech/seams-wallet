from pathlib import Path
p=Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/tests/e2e/ml-dsa-durable-worker.e2e.mjs')
s=p.read_text()
s=s.replace('function delayAuthorization(resolve) { setTimeout(resolve, 200); }','function delayAuthorization(resolve) { setTimeout(resolve, 200); }\nfunction expireAdmission(resolve) { setTimeout(resolve, 1500); }')
needle='''    if (new URL(request.url).pathname === '/calibrate') {'''
s=s.replace(needle,'''    if (new URL(request.url).pathname === '/lose-admission') {
      await this.state.storage.put('lose_admission', true);
      return new Response('Armed');
    }
    if (new URL(request.url).pathname === '/lost-admission') {
      return Response.json(await this.state.storage.get('lost_admission') ?? null);
    }
'''+needle)
needle="    if (command.command === 'lookup') {"
s=s.replace(needle,'''    if (command.command === 'admit' && await this.state.storage.get('lose_admission')) {
      await this.state.storage.delete('lose_admission');
      await this.state.storage.put('lost_admission', command);
      await new Promise(expireAdmission);
      return new Response('Admission interrupted after paired reservation', {status:503});
    }
'''+needle)
needle='''  observations.duplicateSurvivesWorkerRestart = true;
  const stalled = {'''
s=s.replace(needle,'''  observations.duplicateSurvivesWorkerRestart = true;
  observations.expiredUnadmittedRecovery = await checkExpiredUnadmittedRecovery(lastSuccessful.input.request);
  const stalled = {''')
marker='async function admissionCheck(command) {'
func='''async function checkExpiredUnadmittedRecovery(template) {
  await waitReady(policy.refill_target_batches);
  const request = {...template, operation: Array.from(randomBytes(32))};
  const barrier = await admissionBarrier();
  assert.equal((await barrier.fetch('https://fault.internal/lose-admission')).status, 200);
  const interrupted = await raw('router', '/router-ab/ml-dsa/admit', request, gatewayAuth);
  assert.notEqual(interrupted.status, 200);
  const attempted = await (await barrier.fetch('https://fault.internal/lost-admission')).json();
  assert.deepEqual(attempted.claim.request, request);
  assert.equal(attempted.batches.length, policy.refill_target_batches);
  const status = await post('router', '/router-ab/ml-dsa/status', request, gatewayAuth);
  assert.equal(status.state, 'declined');
  const inventoriesAfterRecovery = await inventories();
  for (const role of inventoriesAfterRecovery) {
    const ready = new Set(role.ready.map(batchId));
    assert.ok(attempted.batches.every(batchInSet.bind(null, ready)), 'Unadmitted material was lost');
  }
  const forgedPermit = {request, expires_at_ms: attempted.claim.expires_at_ms, batches: attempted.batches};
  for (const role of ['a', 'b']) {
    assert.notEqual((await raw(role, '/router-ab/ml-dsa/role', {
      command:'reserve', claim:attempted.claim, batches:attempted.batches,
    }, serviceAuth)).status, 200);
    assert.notEqual((await raw(role, '/router-ab/ml-dsa/role', {
      command:'take', permit:forgedPermit, batch:attempted.batches[0],
    }, serviceAuth)).status, 200);
  }
  assert.equal((await post('router', '/router-ab/ml-dsa/admit', request, gatewayAuth)).operation.state, 'declined');
  return {request, batches:attempted.batches, status, recoveredPairs:attempted.batches.length,
    delayedReservationRejected:true, unadmittedTakeRejected:true};
}
function batchInSet(ids, batch) { return ids.has(batchId(batch)); }

'''
assert marker in s;s=s.replace(marker,func+marker)
p.write_text(s)
