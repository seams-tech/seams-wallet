"""Bind each observed starting pair to one exact producer deadline."""
import hashlib
import json
from pathlib import Path
import time


def audit(base: Path, phase: str) -> None:
    stock_path = base / 'cloud-driver' / (phase + '-initial') / 'stock.json'
    stock = json.loads(stock_path.read_text())
    bindings = {}
    sources = {}
    for path in sorted((base / 'cloud-driver').glob('*/traces.json')):
        sources[str(path.relative_to(base))] = hashlib.sha256(path.read_bytes()).hexdigest()
        for row in json.loads(path.read_text())['records']:
            job = row['refill_job']
            if job is None:
                continue
            for pair in job['batches']:
                bindings.setdefault(pair, set()).add((job['key'], job['epoch'], job['material_expires_at_ms']))
    now = int(time.time() * 1000)
    records = []
    for observation in stock['observations']:
        pairs = set(observation['ready_a']) & set(observation['ready_b'])
        assert len(pairs) == 16
        for pair in sorted(pairs):
            found = bindings.get(pair, set())
            assert len(found) == 1, f'Missing or conflicting producer binding: {pair}'
            key, epoch, deadline = next(iter(found))
            assert (key, epoch) == (observation['key'], observation['epoch'])
            records.append({'pair': pair, 'key': key, 'epoch': epoch, 'material_expires_at_ms': deadline,
                            'remaining_ms_at_check': deadline - now, 'inventory_at_ms': observation['log_timestamp_ms']})
    minimum = min(row['remaining_ms_at_check'] for row in records)
    result = {'checked_at_ms': now, 'minimum_required_remaining_ms': 900000,
              'minimum_observed_remaining_ms': minimum, 'passed': minimum >= 900000,
              'stock_sha256': hashlib.sha256(stock_path.read_bytes()).hexdigest(),
              'trace_sha256': sources, 'pairs': records}
    target = base / 'cloud-driver' / (phase + '-initial') / 'starting-lifetimes.json'
    target.write_text(json.dumps(result, indent=2) + '\n')
    assert result['passed'], f'Starting stock has only {minimum}ms remaining'
