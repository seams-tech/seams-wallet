"""Confirm the exact temporary Worker names no longer exist."""
import json
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
scope = json.loads((base / 'scope.json').read_text())
results = []
for worker in scope['workers']:
    process = subprocess.run(['pnpm', 'exec', 'wrangler', 'deployments', 'list', '--config',
        str(base / (worker['role'] + '.json')), '--json'], cwd=scope['root'], capture_output=True, text=True)
    output = process.stdout + process.stderr
    (base / (worker['role'] + '-verify-deletion.log')).write_text(output)
    absent = process.returncode != 0 and any(marker in output for marker in ['10007', 'Worker does not exist', 'Could not find Worker'])
    results.append({'worker': worker['name'], 'absent': absent, 'exit_code': process.returncode})
    (base / 'deletion-verification.json').write_text(json.dumps(results, indent=2)+'\n')
    assert absent, worker['name']
    print(worker['role'], 'absent', flush=True)
