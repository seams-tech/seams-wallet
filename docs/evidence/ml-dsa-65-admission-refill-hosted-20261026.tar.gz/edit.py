from pathlib import Path
R=Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
p=R/'crates/router-ab-cloudflare/src/ml_dsa/pool.rs'
s=p.read_text().replace('fn batch_name(batch: &[u8; 32]) -> String {','''fn reservation_name(request_digest: &[u8; 32]) -> String {
    format!("reservation/{}", hex(request_digest))
}

pub(super) struct ExpiredReservation {
    pub request: SigningRequest,
    pub batches: Vec<[u8; 32]>,
}

/// Recovery uses the exact request to distinguish an unadmitted claim from signing.
pub(super) async fn expired_reservations(
    store: &impl Store,
    key: &KeyScope,
    now: u64,
) -> Result<Vec<ExpiredReservation>> {
    check_key(store, key).await?;
    let mut expired: Vec<ExpiredReservation> = Vec::new();
    for id in index(store).await? {
        let record = store.get::<Record>(&batch_name(&id)).await?
            .ok_or_else(|| invalid("Missing preparation record"))?;
        let State::Reserved { request_digest, expires_at_ms } = record.state else { continue; };
        if record.binding.key != *key || expires_at_ms > now { continue; }
        let Some(request) = store.get::<SigningRequest>(&reservation_name(&request_digest)).await? else {
            // Persisted reservations without a request retain conservative retirement.
            continue;
        };
        if request.key != *key || request.digest()? != request_digest {
            return Err(invalid("ML-DSA reservation request changed"));
        }
        if let Some(existing) = expired.iter_mut().find(|item| item.request == request) {
            existing.batches.push(id);
        } else {
            expired.push(ExpiredReservation { request, batches: vec![id] });
        }
    }
    Ok(expired)
}

/// The host first obtains an authoritative terminal status. Declined means no permit existed.
pub(super) async fn settle_expired(
    store: &impl Store,
    reservation: &ExpiredReservation,
    settlement: Settlement,
) -> Result<()> {
    let consumed = fence(store, &reservation.request, &reservation.batches).await?;
    release(store, &reservation.request, &reservation.batches, settlement, &consumed).await
}

fn batch_name(batch: &[u8; 32]) -> String {''')
old='''        if matches!(record.state, State::Reserved { expires_at_ms, .. } if expires_at_ms <= now_ms)
        {
            // The peer may already have consumed its half. An expired pair is burned.
            record.state = State::Burned;
            erase(store, &mut record).await?;
            continue;
        }'''
new='''        if let State::Reserved { request_digest, expires_at_ms } = &record.state {
            if *expires_at_ms <= now_ms {
                if store.get::<SigningRequest>(&reservation_name(request_digest)).await?.is_some() {
                    // Keep ciphertext unavailable until authoritative recovery settles it.
                    // This also covers a claim that expires after the recovery snapshot.
                    reserved.push(id);
                    retained.push(id);
                    continue;
                }
                // Old persisted reservations lack the request needed for safe recovery.
                record.state = State::Burned;
                erase(store, &mut record).await?;
                continue;
            }
        }'''
assert old in s;s=s.replace(old,new)
s=s.replace('''    let binding = request.digest()?;
    for id in batches {''','''    let binding = request.digest()?;
    store.put(&reservation_name(&binding), request).await?;
    for id in batches {''')
p.write_text(s)
p=R/'crates/router-ab-cloudflare/src/ml_dsa/workers.rs';s=p.read_text()
s=s.replace('''        let waking = matches!(command, RoleCommand::WakeRefill { .. });''','''        if let RoleCommand::Inventory { key, .. } = &command {
            recover_expired_reservations(&self.env, &self.state, key).await.map_err(protocol_error)?;
        }
        let waking = matches!(command, RoleCommand::WakeRefill { .. });''')
marker='async fn role_transaction(\n'
new='''/// Network authority checks stay outside storage transactions and preserve unexposed material.
async fn recover_expired_reservations(env: &Env, state: &State, key: &KeyScope) -> Result<()> {
    let key = key.clone();
    let now = crate::cloudflare_now_unix_ms_v1()?;
    let expired = transaction(state, move |store| async move {
        pool::expired_reservations(&store, &key, now).await
    }).await?;
    for reservation in expired {
        let status: Option<Status> = service_call(env, CallAuthority::Internal,
            &AdmissionCommand::Lookup { request: reservation.request.clone() }).await?;
        let settlement = match status {
            Some(Status::Declined) => pool::Settlement::Declined,
            // Once admitted, peer consumption can be unknown. Preserve conservative retirement.
            Some(Status::Failed | Status::Succeeded { .. }) => pool::Settlement::Failed,
            _ => continue,
        };
        let operation = reservation.request.operation;
        let batches = reservation.batches.clone();
        transaction(state, move |store| async move {
            pool::settle_expired(&store, &reservation, settlement).await
        }).await?;
        worker::console_log!("{}", serde_json::json!({
            "event": "ml_dsa_expired_reservation_v1", "operation": hex(&operation),
            "settlement": settlement, "batches": batches.iter().map(hex).collect::<Vec<_>>(),
        }));
    }
    Ok(())
}

'''
assert marker in s;s=s.replace(marker,new+marker)
# Reuse the existing bounded job identities instead of adding a second delivery format.
s=s.replace('''    Put {
        job: refill::Job,
        binding: Binding,
        sealed: Sealed,
    },''','''    Put {
        job: refill::Job,
        batches: Vec<(Binding, Sealed)>,
    },''')
s=s.replace('''            Self::Put { binding, .. } => &binding.key.wallet,
            Self::StartRefill { job } | Self::PublicationRecorded { job } => &job.key.wallet,''','''            Self::Put { job, .. } | Self::StartRefill { job } | Self::PublicationRecorded { job } => &job.key.wallet,''')
old='''        RoleCommand::Put {
            job,
            binding,
            sealed,
        } => {
            if binding.role != role {
                return Err(invalid("ML-DSA material belongs to another role"));
            }
            refill::publish_role(store, &job, binding, sealed, now).await?;
            json(true)
        }'''
new='''        RoleCommand::Put { job, batches } => {
            let expected = job.batch_ids();
            if batches.len() != expected.len() || batches.iter().zip(&expected).any(|((binding, _), id)| binding.batch != *id || binding.role != role) {
                return Err(invalid("ML-DSA publication differs from its complete role job"));
            }
            // The transaction publishes the bounded job together or rolls back every pair.
            for (binding, sealed) in batches {
                refill::publish_role(store, &job, binding, sealed, now).await?;
            }
            json(true)
        }'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=R/'crates/router-ab-cloudflare/src/ml_dsa/workers/preparation.rs';s=p.read_text()
s=s.replace('''    let a: pool::Inventory = serde_json::from_value(''','''    recover_expired_reservations(env, state, &key).await.map_err(protocol_error)?;
    let a: pool::Inventory = serde_json::from_value(''',1)
a=s.index('    for (binding, sealed) in prepared {',s.index('async fn publish('));b=s.index('\n    Ok(())',a)
s=s[:a]+'''    let response = local_call(env, &RoleCommand::Put {
        job: job.clone(), batches: prepared,
    }, None).await?;
    if response.status_code() != 200 {
        return Err(invalid(match participant {
            Participant::A => "ML-DSA preparation storage failed",
            Participant::B => "ML-DSA peer preparation storage failed",
        }));
    }
    for batch in job.batch_ids() {
        log_stage(job, participant, batch, "published");
    }'''+s[b:];p.write_text(s)
p=R/'crates/router-ab-cloudflare/src/ml_dsa/workers/durable_trace.rs';s=p.read_text();needle='''            RoleCommand::Install { .. } => ("install_pool", None, None),'''
s=s.replace(needle,needle+'''
            RoleCommand::Put { job, .. } => ("publish_refill", Some(job.batch), None),
            RoleCommand::Reserve { claim, .. } => ("reserve", None, Some(claim.request.operation)),''');p.write_text(s)
p=R/'tests/e2e/ml-dsa-durable-worker.e2e.mjs';s=p.read_text();a=s.index('function finalPublication(command)');b=s.index('\nexport class PublicationBarrier',a);s=s[:a]+s[b:];s=s.replace(' && finalPublication(command)','');p.write_text(s)
