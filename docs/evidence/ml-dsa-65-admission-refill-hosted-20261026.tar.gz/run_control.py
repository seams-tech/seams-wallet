"""Run the preserved two-slot control before changing the Worker runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE=Path(__file__).resolve().parent
SCOPE=json.loads((BASE/'scope.json').read_text())
ROOT=Path(SCOPE['root'])
FROZEN=BASE/'frozen-measurement-qualified'
if not FROZEN.exists():
    for source in (ROOT/'tools/ml-dsa-investigation/research').glob('*.py'):
        target=FROZEN/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    for name in ['ml-dsa-cloud-load.e2e.mjs','ml-dsa-cloud-load-worker.mjs']:
        source=ROOT/'tests/e2e'/name
        target=FROZEN/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    files={str(source.relative_to(FROZEN)):hashlib.sha256(source.read_bytes()).hexdigest() for source in FROZEN.rglob('*') if source.is_file()}
    (BASE/'frozen-measurement.json').write_text(json.dumps(files,indent=2)+'\n')
ENV=dict(os.environ,ML_DSA_TEST_BUILD_ROOT=SCOPE['build_root'],
    ML_DSA_REGISTRATION_ROUTER_URL=SCOPE['router_url'],
    ML_DSA_GATEWAY_TOKEN_FILE=str(BASE/'gateway-token'),
    ML_DSA_TEST_CANDIDATE_GROUP_SIZE='2',ML_DSA_TEST_PREPARATION_GROUP_SIZE='4',
    ML_DSA_TEST_PREPARATION_JOBS='2',ML_DSA_TEST_COOLDOWN_MS='60000')
CONTROL=['node',str(FROZEN/'tests/e2e/ml-dsa-cloud-load.e2e.mjs')]


def run(arguments,log,working_directory=ROOT):
    with log.open('w') as output:
        result=subprocess.run(arguments,cwd=working_directory,env=ENV,stdout=output,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'Command failed with exit {result.returncode}; inspect {log}')


def control(action,name,*arguments):
    run(CONTROL+[action,str(BASE),name,*map(str,arguments)],BASE/'cloud-driver'/f'{name}-{action}.log',FROZEN)

