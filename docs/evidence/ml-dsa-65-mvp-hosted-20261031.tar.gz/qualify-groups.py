import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

phase = Path(sys.argv[1])
label = sys.argv[2]
scope = json.loads((phase / 'scope.json').read_text())
count = scope['policy']['service_groups']
wallet_count = scope['measurement']['activeWallets']
folder = phase / 'cloud-driver' / label
window = json.loads((folder / 'start.json').read_text())
report = json.loads((folder / 'analysis.json').read_text())
rows = json.loads((folder / 'traces.json').read_text())['records']
stock = json.loads((folder / 'initial-stock.json').read_text())
actors = json.loads((folder / 'actors.json').read_text())['actors']
placements = {bytes(v['key']['public_key_digest']).hex(): v['group'] for v in stock['final']}
assert len(placements) == wallet_count
assert set(placements.values()) == set(range(count))
assert Counter(placements.values()) == Counter({group: wallet_count // count for group in range(count)})
assert len(actors) == count
actor_owner = {}
for actor in actors:
    for slot in ['primary', 'secondary']:
        assert actor[slot] not in actor_owner
        actor_owner[actor[slot]] = (actor['group'], slot)
for index in range(1, wallet_count + 1):
    registration = json.loads((phase / ('registration-' + str(index) + '.json')).read_text())
    assert registration['registrationChecksPassed'] and registration['recoveryPreservesCanonicalKey']
    assert len({v['serviceGroup'] for v in registration['cases']}) == 1
metadata = {}
for row in rows:
    for job in row['producer_jobs']:
        if job['key'] not in placements:
            continue
        assert job['producer'] in actor_owner
        assert actor_owner[job['producer']][0] == placements[job['key']]
        metadata[job['batch']] = job
start = report['start_at_ms']
end = report['cycle_end_at_ms']
selected = [row for row in rows if start <= row['event_timestamp_ms'] <= end]
statuses = Counter(row['outcome'] for row in selected)
by_group = defaultdict(lambda: {'published_jobs': 0, 'paired_candidates': 0})
stages = defaultdict(list)
for row in rows:
    for stage in row['preparation_stages']:
        stages[stage['job']].append(stage)
for job in report['preparation_jobs']:
    identity = job['job']
    assert identity in metadata
    group = placements[metadata[identity]['key']]
    for role in ['a', 'b']:
        role_stages = [v for v in stages[identity] if v['role'] == role]
        assert len([v for v in role_stages if v['stage'] == 'crypto_started']) == 1
        assert {v['batch'] for v in role_stages if v['stage'] == 'published'} == set(metadata[identity]['batches'])
    by_group[group]['published_jobs'] += 1
    by_group[group]['paired_candidates'] += len(metadata[identity]['batches']) * 2
resource = []
activity = []
for row in selected:
    resource.extend(v['wasm_linear_memory_bytes'] for v in row['preparation_stages'] if isinstance(v.get('wasm_linear_memory_bytes'), int))
    activity.extend(v['active_crypto'] for v in row['preparation_cache'] if isinstance(v.get('active_crypto'), int))
assert activity and max(activity) == 1
qualified = {'groups': count, 'wallet_count': len(placements), 'placements': placements, 'actors': actors,
    'per_group_preparation': dict(by_group), 'provider_outcomes': dict(statuses),
    'maximum_recorded_active_crypto': max(activity), 'maximum_recorded_wasm_bytes': max(resource) if resource else None,
    'whole_cycle_signatures_per_minute': report['whole_cycle_signatures_per_minute'],
    'scope': 'Growing active-wallet complete-cycle screen at the recorded offered load. Recorded Wasm bytes exclude JS heap. Whole invocation CPU includes setup, serialization, and other active processing. Network and storage waiting is outside CPU time; wall spans include waits.',
    'passed': True}
(folder / 'group-qualification.json').write_text(json.dumps(qualified, indent=2) + '\n')
print(json.dumps(qualified))
