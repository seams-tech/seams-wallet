import json
import subprocess
from pathlib import Path

base = Path(__file__).resolve().parent
results = []
for group, label in [('one-group', 'capacity'), ('two-groups', 'capacity-eight'), ('idle-return', 'idle-return')]:
    directory = base / 'capacity' / group
    report_path = directory / 'cloud-driver' / label / 'analysis.json'
    expected = json.loads(report_path.read_text())
    command = subprocess.run(
        ['python3', str(base / 'analyze-capacity.py'), str(directory), label],
        capture_output=True, text=True,
    )
    assert command.returncode == 0, command.stderr
    assert json.loads(report_path.read_text()) == expected, group
    for script in ['qualify-stock-expiry.py', 'qualify-job-chains.py']:
        command = subprocess.run(
            ['python3', str(base / script), str(directory), label],
            capture_output=True, text=True,
        )
        assert command.returncode == 0, (group, script, command.stderr)
    balance = 'not_tested_for_idle_return'
    if group != 'idle-return':
        command = subprocess.run(
            ['python3', str(base / 'qualify-groups.py'), str(directory), label],
            capture_output=True, text=True,
        )
        if group == 'one-group':
            assert command.returncode == 0, command.stderr
            balance = 'passed'
        else:
            assert command.returncode != 0, 'The retained 5/3 cohort must fail the strict balanced qualifier'
            assert 'Counter(placements.values())' in command.stderr, command.stderr
            balance = 'failed_5_3_distribution'
    results.append({
        'phase': group,
        'exactRetainedAnalysisReproduced': True,
        'completeMaterialLedgerBalanced': expected['ledger_balanced'],
        'groupBalanceQualification': balance,
    })
print(json.dumps({'passed': True, 'results': results}))
