import hashlib
import json
from pathlib import Path
import sys

base=Path(sys.argv[1])
label=sys.argv[2]
folder=base/'cloud-driver'/label
initial=json.loads((folder/'initial-stock.json').read_text())
window=json.loads((folder/'start.json').read_text())
rows=json.loads((folder/'traces.json').read_text())['records']
origins={}


def record(key,epoch,batch,expiry,kind):
    identity=(key,epoch,batch)
    value={'expiresAtMs':expiry,'origin':kind}
    if identity in origins:
        assert origins[identity]==value,identity
    else:
        origins[identity]=value


for wallet in window['wallets']:
    artifact=base/('registration-'+str(wallet['index']+1)+'.json')
    registration=json.loads(artifact.read_text())
    for case in registration['cases']:
        key=bytes(case['key']['public_key_digest']).hex()
        job=list(bytes.fromhex(case['initialSigningPreparationId']))
        for ordinal in range(case['initialSigningBatches']):
            encoded=json.dumps([job,ordinal],separators=(',',':')).encode()
            batch=hashlib.sha256(b'seams/ml-dsa/registration-signing-stock/v1'+encoded).hexdigest()
            record(key,case['key']['epoch'],batch,case['initialSigningStockExpiresAtMs'],'registration')
for row in rows:
    claims=[claim for claim in row['refill_claims'] if claim['status']=='acquired']
    if row['refill_job']:
        claims.append(row['refill_job'])
    for claim in claims:
        for batch in claim['batches']:
            record(claim['key'],claim['epoch'],batch,claim['material_expires_at_ms'],'refill')
checked=[]
for wallet in initial['final']:
    key=bytes(wallet['key']['public_key_digest']).hex()
    epoch=wallet['key']['epoch']
    for batch in wallet['paired']:
        identity=(key,epoch,batch)
        assert identity in origins,identity
        origin=origins[identity]
        checked.append({'key':key,'epoch':epoch,'batch':batch,**origin,
                        'coversWindow':origin['expiresAtMs']>=window['endAtMs'],
                        'remainingAtStartMs':origin['expiresAtMs']-window['startAtMs']})
assert len(checked)==16*len(window['wallets'])
report={'passed':True,'allStartingPairsHaveExactOrigins':True,
        'startingPairs':len(checked),'allStartingPairsCoverWindow':all(row['coversWindow'] for row in checked),
        'minimumRemainingAtStartMs':min(row['remainingAtStartMs'] for row in checked),
        'pairs':checked,
        'scope':'Immutable material expiry, derived from registration identity or published refill claims. Expiry plus disappearance does not establish its retirement cause.'}
(folder/'stock-expiry-qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='pairs'}))
