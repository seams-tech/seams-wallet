import json
from pathlib import Path
import sys

base=Path(sys.argv[1])
label=sys.argv[2]
folder=base/'cloud-driver'/label
window=json.loads((folder/'start.json').read_text())
report=json.loads((folder/'analysis.json').read_text())
rows=json.loads((folder/'traces.json').read_text())['records']
active={(bytes(wallet['key']['public_key_digest']).hex(),wallet['key']['epoch']) for wallet in window['wallets']}
claims={}
producer={}
stages={}
settlements={}
for row in rows:
    for claim in row['refill_claims']:
        if claim['status']=='acquired' and (claim['key'],claim['epoch']) in active:
            claims.setdefault(claim['batch'],[]).append(claim)
    for job in row['producer_jobs']:
        if (job['key'],job['epoch']) in active:
            producer.setdefault(job['batch'],[]).append(job)
    for stage in row['preparation_stages']:
        stages.setdefault(stage['job'],[]).append(stage)
    for event in row['refill_wakes']:
        if event['event']=='ml_dsa_refill_settled_v1':
            settlements.setdefault(event['batch'],[]).append(event)
qualified=[]
for job in report['preparation_jobs']:
    identity=job['job']
    expected=set(job['batches'])
    acquired=claims.get(identity,[])
    queued=producer.get(identity,[])
    assert acquired,identity
    assert all(set(value['batches'])==expected and value['key']==job['key'] and value['epoch']==job['epoch'] for value in acquired),identity
    assert any(value['stage']=='queued' for value in queued),identity
    assert any(value['stage']=='running' for value in queued),identity
    for role in ('a','b'):
        own=[event for event in stages.get(identity,[]) if event['role']==role]
        assert sum(event['stage']=='crypto_started' for event in own)==1,(identity,role)
        assert {event['batch'] for event in own if event['stage']=='published'}==expected,(identity,role)
    settled=settlements.get(identity,[])
    assert any(event['outcome']=='published' for event in settled),identity
    qualified.append({'job':identity,'claimObservations':len(acquired),'queuedObservations':sum(value['stage']=='queued' for value in queued),'runningObservations':sum(value['stage']=='running' for value in queued),'pairedPublicationCount':len(expected),'publishedSettlements':sum(value['outcome']=='published' for value in settled)})
selected=[row for row in rows if report['start_at_ms']<=row['event_timestamp_ms']<=report['cycle_end_at_ms']]
unknown=[{'role':row['role'],'atMs':row['event_timestamp_ms'],'outcome':row['outcome']} for row in selected if 'unclassified' in row['exception_categories']]
result={'passed':not unknown,'publishedJobCount':len(qualified),'jobs':qualified,'unknownExceptions':unknown,'scope':'Exact claim, queued/running producer, one crypto start per participant, paired publication, and published settlement for measured completed jobs. Known failed attempts remain in the capacity report.'}
(folder/'job-chain-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['passed'],'Unknown provider exceptions prevent qualification'
print(json.dumps({key:value for key,value in result.items() if key!='jobs'}))
