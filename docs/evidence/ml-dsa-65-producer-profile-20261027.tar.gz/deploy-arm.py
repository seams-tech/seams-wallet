import copy,json,shutil,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
root=Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
mode,mapping=sys.argv[1:3]
routing_only=sys.argv[3:]==["routing-only"]
assert mode in ['baseline','candidate','chunked','baseline-full'] and mapping in ['normal','swapped']
roles=['a'] if mode=='baseline' or routing_only else ['a','b','preparer-a','preparer-b','preparer-a-secondary','preparer-b-secondary']
if mode=='candidate' and not (base/'candidate-build').exists():
 shutil.copytree(root/'crates/router-ab-cloudflare/build/ml-dsa',base/'candidate-build')
receipts=[]
for role in roles:
 cfg=json.loads((base/f'{role}.json').read_text())
 if mode in ['candidate','chunked','baseline-full']:
  part='deriver-a' if role=='a' or role.startswith('preparer-a') else 'deriver-b'
  build_folder={'candidate':'candidate-build','chunked':'chunked-build','baseline-full':'baseline-build'}[mode]
  cfg['main']=str(base/build_folder/part/'worker/shim.mjs')
 if role=='a' and mapping=='swapped':
  for binding in cfg['durable_objects']['bindings']:
   if binding['name']=='ML_DSA_PRODUCER_DO':binding['script_name']=cfg['name'][:-1]+'preparer-a-secondary'
 original_main=cfg['main']
 wrapper=base/f'entry-{mode}-{mapping}-{role}.mjs'
 wrapper.write_text('export * from '+json.dumps(original_main)+';\nimport worker from '+json.dumps(original_main)+';\nconsole.log('+json.dumps('Synthetic producer profiling arm '+mode+' '+mapping)+');\nexport default worker;\n')
 cfg['main']=str(wrapper)
 path=base/f'{mode}-{mapping}-{role}.json';path.write_text(json.dumps(cfg,indent=2)+'\n')
 with (base/f'{mode}-{mapping}-{role}-deploy.log').open('w') as log:
  result=subprocess.run([str(root/'node_modules/.bin/wrangler'),'deploy','--config',str(path)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 receipts.append({'role':role,'passed':result.returncode==0})
 (base/f'{mode}-{mapping}-deploy.json').write_text(json.dumps(receipts,indent=2)+'\n')
 if result.returncode:raise SystemExit(f'Arm deployment failed: {role}')
print(json.dumps({'mode':mode,'mapping':mapping,'roles':len(roles)}))
