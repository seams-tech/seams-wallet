import assert from 'node:assert/strict';
import { createHash, createPublicKey, randomBytes, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
const base = '/private/tmp/ml-dsa-refactor-201';
const scope = JSON.parse(await readFile(base + '/hosted-scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const native = JSON.parse(await readFile(base + '/native-hosted-installation.json', 'utf8'));
const registration = JSON.parse(await readFile(base + '/registration-1.json', 'utf8'));
const cases = [
  { name: 'native', key: native.key, publicKey: native.publicKey },
  { name: 'recovered', key: registration.cases.at(-1).key, publicKey: Array.from(Buffer.from(registration.cases.at(-1).publicKeyHex, 'hex')) },
];
const report = { scope: 'Hosted private Router path with synthetic wallets. Standard OpenSSL verification. Excludes public SDK, human approval and NEAR finality.', cases: [], passed: false };
function digest(value) {
  return Array.from(createHash('sha256').update(Buffer.from(value)).digest());
}
for (const value of cases) {
  const message = Array.from(Buffer.from('ML-DSA bulk correlation hosted evidence ' + value.name));
  const operation = Array.from(randomBytes(32));
  const input = { request: { key: value.key, operation, message_digest: digest(message), context_digest: digest([]) }, message, context: [] };
  const row = { name: value.name, key: value.key, publicKey: value.publicKey, message, operation, startedAtMs: Date.now(), verified: false };
  report.cases.push(row);
  await writeFile(base + '/chunked-hosted-signatures.json', JSON.stringify(report, null, 2) + '\n');
  const start = performance.now();
  const response = await fetch('https://' + scope.prefix + '-front.n6378056.workers.dev/router-ab/ml-dsa/sign', { method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token }, body: JSON.stringify(input), signal: AbortSignal.timeout(60000) });
  row.elapsedMs = performance.now() - start;
  row.httpStatus = response.status;
  const result = await response.json();
  row.result = result;
  await writeFile(base + '/chunked-hosted-signatures.json', JSON.stringify(report, null, 2) + '\n');
  assert.equal(response.status, 200);
  assert.equal(result.status, 'existing');
  assert.equal(result.operation.state, 'succeeded');
  const publicKey = createPublicKey({ key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), Buffer.from(value.publicKey)]), type: 'spki', format: 'der' });
  row.verified = verify(null, Buffer.from(message), publicKey, Buffer.from(result.operation.signature));
  assert.ok(row.verified);
}
report.passed = true;
await writeFile(base + '/chunked-hosted-signatures.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: report.passed, cases: report.cases.map(value => ({ name: value.name, elapsedMs: value.elapsedMs, verified: value.verified })) }));
