# Offline replay

From this directory, run:

```sh
python3 summarize_producer_variation.py hosted-traces.json replay.json windows/baseline-primary-native/result.json windows/baseline-secondary-native/result.json windows/baseline-concurrent-corrected/result.json windows/candidate-primary-native/result.json windows/candidate-secondary-native/result.json windows/chunked-concurrent/result.json windows/baseline-return-concurrent/result.json windows/chunked-repeat-concurrent/result.json
python3 summarize_producer_variation.py historical/traces.json historical-replay.json historical/warmup/window.json historical/completion/window.json
```

Compare the outputs with final-profiles.json and producer-variation.json. The trace SHA values bind every summary to its input.
The excluded baseline-concurrent window has stale swapped routing. Its data remains in hosted-traces.json and its window remains under windows/.
Deployment records and provider history qualify actual versions. Producer CPU totals exclude dispatch, pool, and Router CPU.
Inventory polling runs every five seconds. Use logged publication checkpoints to distinguish actual publication from client detection.
The public recovery evidence intentionally contains disposable, deterministic test seeds. It contains no benchmark credentials or private fixture files.
Ephemeral hosted scripts require new deployments and credentials before another live campaign. The eight campaign Workers were deleted.
The candidate-build symbol folder belongs to the rejected AES experiment. The chunked-build metadata belongs to the retained loop change.

With a Node/OpenSSL build that supports ML-DSA, run `node verify-signatures-offline.mjs` to verify both signatures and reject altered messages.
