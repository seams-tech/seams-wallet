"""Reproduce public loadShed controls from the retained eight-wallet trace."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('traces', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
rows = json.loads(args.traces.read_text())['records']
peers = sorted((row for row in rows if row['role'] == 'preparer-b' and row['refill_job']), key=lambda row: row['event_timestamp_ms'])
failed = [row for row in peers if row['outcome'] == 'loadShed']
assert failed
start = min(row['event_timestamp_ms'] for row in failed)
end = max(row['event_timestamp_ms'] + row['wall_ms'] for row in failed)
before = [row for row in peers if row['outcome'] == 'ok' and row['event_timestamp_ms'] < start]
after = [row for row in peers if row['outcome'] == 'ok' and row['event_timestamp_ms'] > end]
controls = []
for row in before[-1:] + failed + after[:1]:
    stages = row['preparation_stages']
    controls.append({'job': row['refill_job']['batch'], 'start_ms': row['event_timestamp_ms'],
                     'end_ms': row['event_timestamp_ms'] + row['wall_ms'], 'outcome': row['outcome'],
                     'cpu_ms': row['cpu_ms'], 'module': stages[-1]['module_instance'],
                     'last_stage': stages[-1]['stage'], 'last_wasm_bytes': stages[-1]['wasm_linear_memory_bytes']})
overlaps = []
for left, right in zip(peers, peers[1:]):
    overlap = left['event_timestamp_ms'] + left['wall_ms'] - right['event_timestamp_ms']
    if overlap > 0:
        overlaps.append({'ms': overlap, 'previous': left['refill_job']['batch'], 'current': right['refill_job']['batch']})
report = {'failure_count': len(failed), 'burst_start_ms': start, 'burst_end_ms': end, 'burst_ms': end - start,
          'distinct_failed_module_ids': len({row['preparation_stages'][-1]['module_instance'] for row in failed}),
          'controls': controls, 'b_invocation_overlaps': overlaps,
          'limits': 'Recorded Wasm boundaries exclude JS heap and allocation peaks. Provider outcome does not identify root cause.'}
args.output.write_text(json.dumps(report, indent=2) + '\n')
