# Parallel ML-DSA benchmark credential scope

Upload these fresh benchmark credentials to the eight named temporary Workers.
Each A preparer receives only the A storage key; each B preparer receives only the B storage key.
Both slots use separate A/B Worker deployments. They share the existing role-local pools and the Router admission authority.
These credentials protect synthetic wallets only. They contain no production wallet or account credentials.
The test varies only the Router preparation limit between one and two. Each wallet retains32 candidates, two-at-once consumption, and a60-second cooldown.
Wallet-seed recovery and FIPS export remain unchanged. All temporary Workers will be deleted after evidence capture.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-par-1025-b30118-router | e0d47fd0df589201bb4a185f7e24b2a9bd45e5d096e9c8a60b42f146de306671 |
| ml-dsa-par-1025-b30118-a | e4b44a1c9f9f90b058247bbf6c16a1ae8e0456c542bf843a68cb354ad9725641 |
| ml-dsa-par-1025-b30118-b | 82a0068bdd0cf861775137a37bcf04d6029469e8246990b9ec5cc6a6e0cfda46 |
| ml-dsa-par-1025-b30118-preparer-a | e4b44a1c9f9f90b058247bbf6c16a1ae8e0456c542bf843a68cb354ad9725641 |
| ml-dsa-par-1025-b30118-preparer-b | 82a0068bdd0cf861775137a37bcf04d6029469e8246990b9ec5cc6a6e0cfda46 |
| ml-dsa-par-1025-b30118-preparer-a-secondary | e4b44a1c9f9f90b058247bbf6c16a1ae8e0456c542bf843a68cb354ad9725641 |
| ml-dsa-par-1025-b30118-preparer-b-secondary | 82a0068bdd0cf861775137a37bcf04d6029469e8246990b9ec5cc6a6e0cfda46 |
| ml-dsa-par-1025-b30118-front | e0d47fd0df589201bb4a185f7e24b2a9bd45e5d096e9c8a60b42f146de306671 |
