import { readFile } from 'node:fs/promises';
import { createPublicKey, verify } from 'node:crypto';
import assert from 'node:assert/strict';
const base = new URL('./', import.meta.url);
const registrations = [];
for (const index of [1, 2]) {
  registrations.push(JSON.parse(await readFile(new URL('local-registration-' + index + '.json', base), 'utf8')));
}
function checkSignature(publicKeyHex, record) {
  const publicKey = createPublicKey({
    key: Buffer.concat([
      Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
      Buffer.from(publicKeyHex, 'hex'),
    ]), format: 'der', type: 'spki',
  });
  const message = Buffer.from(record.messageHex, 'hex');
  const signature = Buffer.from(record.signatureHex, 'hex');
  assert(verify(null, message, publicKey, signature));
  message[0] ^= 1;
  assert.equal(verify(null, message, publicKey, signature), false);
}
let verified = 0;
for (const registration of registrations) {
  for (const result of registration.cases) {
    if (!result.initialStockSign.verified) continue;
    checkSignature(result.publicKeyHex, result.initialStockSign);
    verified += 1;
  }
}
for (const name of ['local-load.json', 'local-load-sustained.json', 'local-load-staggered.json']) {
  const load = JSON.parse(await readFile(new URL(name, base), 'utf8'));
  assert.equal(load.environment, 'local_workerd');
  for (const wallet of load.reports) {
    for (const request of wallet.snapshot.requests) {
      if (request.state !== 'succeeded') continue;
      checkSignature(registrations[wallet.index].cases.at(-1).publicKeyHex, request);
      verified += 1;
    }
  }
}
console.log(JSON.stringify({environment: 'local_workerd', verified, alteredMessagesRejected: verified}));
