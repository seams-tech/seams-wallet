"""Summarize the local two-wallet Worker lifecycle without hosted latency claims."""
import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
source = Path(sys.argv[1]) if len(sys.argv) > 1 else BASE / 'local-public-events.json'
rows = []
if source.suffix == '.json':
    rows = json.loads(source.read_text())
else:
    for line in source.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict) and row.get('event', '').startswith('ml_dsa_'):
            rows.append(row)
cache = [row for row in rows if row['event'] == 'ml_dsa_preparation_cache_v1']
completed = {row['batch']: row for row in rows if row['event'] == 'ml_dsa_refill_completed_v1'}
claims = {}
for row in rows:
    if row['event'] == 'ml_dsa_refill_claim_v1' and row['claim']['status'] == 'acquired':
        job = row['claim']['job']
        claims[bytes(job['batch']).hex()] = job
intervals = []
for row in cache:
    if row['role'] != 'a' or row['stage'] != 'started':
        continue
    finish = next((item for item in cache if item['role'] == 'a' and item['stage'] == 'prepared' and item['job'] == row['job']), None)
    if finish and completed[row['job']]['published']:
        intervals.append({'job': row['job'], 'slot': row['producer_slot'],
                          'module': row['module_instance'], 'start_ms': row['at_ms'],
                          'end_ms': finish['at_ms'], 'key': claims[row['job']]['key']})
overlaps = []
for i, left in enumerate(intervals):
    for right in intervals[i + 1:]:
        overlap = min(left['end_ms'], right['end_ms']) - max(left['start_ms'], right['start_ms'])
        if overlap > 0 and left['slot'] != right['slot']:
            assert left['key'] != right['key'] and left['module'] != right['module']
            overlaps.append({'jobs': [left['job'], right['job']], 'overlap_ms': overlap})
assert overlaps
assert max(row['topology_builds'] for row in cache) > 0
assert max(row['topology_hits'] for row in cache) > 0
wallets = []
for index in [1, 2]:
    path = BASE / f'local-registration-{index}.json'
    registration = json.loads(path.read_text())
    assert registration['functionalPassed'] and registration['recoveryPreservesCanonicalKey']
    key = bytes(registration['cases'][-1]['key']['public_key_digest']).hex()
    inventories = [row for row in rows if row['event'] == 'ml_dsa_inventory_v1' and row['key'] == key and row['epoch'] == 2]
    final = inventories[-1]
    assert len(set(final['ready_a']) & set(final['ready_b'])) == 16
    assert all(len(row['ready_a']) <= 16 and len(row['ready_b']) <= 16 for row in inventories)
    wallets.append({'index': index, 'registration_and_recovery_passed': True,
                    'verified_signatures': sum(case['initialStockSign'].get('verified', False) for case in registration['cases']),
                    'canonical_epochs': [case['epoch'] for case in registration['cases'] if case['canonicalKeyVerified']],
                    'final_paired_ready': 16, 'registration_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
report = {'environment': 'local_workerd', 'hosted_performance_qualified': False,
          'scope': 'Eight local Worker scripts, two wallets, two refill slots. Remote-client mode in the registration artifacts points to localhost. Overlap intervals include protocol waits and do not prove simultaneous CPU execution. This is a functional check only.',
          'wallets': wallets, 'successful_parallel_overlaps': overlaps,
          'cache_events': len(cache), 'maximum_builds': max(row['topology_builds'] for row in cache),
          'maximum_hits': max(row['topology_hits'] for row in cache),
          'maximum_module_active_crypto': max(row['active_crypto'] for row in cache),
          'published_jobs': sum(row['published'] for row in completed.values()),
          'failed_jobs': sum(not row['published'] for row in completed.values()),
          'policy': json.loads((BASE / 'local-runtime.json').read_text())['policy'],
          'verified_load_signatures': sum(row['verified'] for name in ['local-load.json', 'local-load-sustained.json', 'local-load-staggered.json'] for row in json.loads((BASE / name).read_text())['reports'])}
(BASE / 'local-parallel.json').write_text(json.dumps(report, indent=2) + '\n')
(BASE / 'local-public-events.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'wallets': len(wallets), 'parallel_overlaps': len(overlaps), 'published_jobs': report['published_jobs']}))
