import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

base=Path(__file__).resolve().parent
label=sys.argv[1]
folder=base/'cloud-driver'/label
client=json.loads((folder/'client.json').read_text())
rows=json.loads((folder/'traces.json').read_text())['records']
outcomes={}
caller_spans=defaultdict(list)
traces=defaultdict(list)
execute_cpu={}
for row in rows:
    for item in row['signing']:
        outcomes[item['operation']]=item['outcome']
    for item in row['stage_traces']:
        if item['context']['kind']=='take_caller':
            caller_spans[(item['operation'],item['role'])].append(item)
    for item in row['signing_traces']:
        if item['completed']:
            traces[(item['operation'],item['role'])].append(item)
            identity=(item['operation'],item['role'])
            assert identity not in execute_cpu
            execute_cpu[identity]=row['cpu_ms']
operations=[]
for request in client['requests']:
    if request.get('state')!='succeeded':continue
    operation=bytes(request['operation']).hex()
    outcome=outcomes[operation]
    assert outcome['status']=='signed'
    pairs=outcome['consumed_batches']
    roles={}
    for role in ['a','b']:
        headers=[]
        decoding=[]
        total=[]
        for span in caller_spans[(operation,role)]:
            marks={mark['stage']:mark['at_ms'] for mark in span['marks']}
            assert span['completed'] and all(name in marks for name in ['started','response_headers','completed'])
            headers.append(marks['response_headers']-marks['started'])
            decoding.append(marks['completed']-marks['response_headers'])
            total.append(marks['completed']-marks['started'])
        assert len(total)==pairs-1, (operation,role,pairs,len(total))
        role_traces=traces[(operation,role)]
        assert len(role_traces)==1
        roles[role]={'later_takes':len(total),'reported_take_ms':sum(total),'reported_header_wait_ms':sum(headers),'reported_body_decode_ms':sum(decoding),'schedule_cache_hit':role_traces[0]['schedule_cache_hit'],'module_instance':role_traces[0]['module_instance'],'execute_invocation_cpu_ms':execute_cpu[(operation,role)]}
    operations.append({'operation':operation,'wallet':request['wallet'],'pairs':pairs,'final_call_ms':request['elapsedMs'],'roles':roles})
groups=[]
for pairs in sorted({item['pairs'] for item in operations}):
    values=[item for item in operations if item['pairs']==pairs]
    groups.append({'pairs':pairs,'samples':len(values),'final_call_median_ms':statistics.median(item['final_call_ms'] for item in values),'final_call_maximum_ms':max(item['final_call_ms'] for item in values),'roles':{role:{'take_sum_median_ms':statistics.median(item['roles'][role]['reported_take_ms'] for item in values),'header_sum_median_ms':statistics.median(item['roles'][role]['reported_header_wait_ms'] for item in values),'body_decode_sum_median_ms':statistics.median(item['roles'][role]['reported_body_decode_ms'] for item in values)} for role in ['a','b']}})
warm_groups=[]
cold=[]
for item in operations:
    if not all(item['roles'][role]['schedule_cache_hit'] for role in ['a','b']):cold.append(item['operation'])
for pairs in sorted({item['pairs'] for item in operations}):
    values=[item for item in operations if item['pairs']==pairs and item['operation'] not in cold]
    if not values:continue
    warm_groups.append({'pairs':pairs,'samples':len(values),'final_call_median_ms':statistics.median(item['final_call_ms'] for item in values),'roles':{role:{'execute_invocation_cpu_median_ms':statistics.median(item['roles'][role]['execute_invocation_cpu_ms'] for item in values),'reported_take_sum_median_ms':statistics.median(item['roles'][role]['reported_take_ms'] for item in values)} for role in ['a','b']}})
report={'label':label,'scope':'Stage-clock intervals include scheduling, transfer and processing. They can omit CPU and do not isolate database or serialization cost. Compare equal pair counts, with both roles separate.','operations':operations,'groups':groups,'cold_operations':cold,'warm_groups':warm_groups}
(folder/'signing-cost.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'label':label,'operations':len(operations),'groups':groups}))
