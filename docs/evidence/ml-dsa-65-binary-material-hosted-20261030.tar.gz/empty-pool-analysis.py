import json
from collections import defaultdict
from pathlib import Path

base = Path(__file__).resolve().parent
folder = base / 'cloud-driver/binary30'
client = json.loads((folder / 'client.json').read_text())
rows = json.loads((folder / 'traces.json').read_text())['records']
stocks = defaultdict(list)
taken = defaultdict(set)
for row in rows:
    for event in row['admission_stock']: stocks[event['operation']].append(event)
    for event in row['material_stages']:
        if event['role'] == 'a' and event['value']['stage'] == 'taken':
            taken[event['operation']].add(event['value']['material_id'])
empty = defaultdict(list)
for request in client['requests']:
    if request.get('reason') == 'empty_pool': empty[bytes(request['operation']).hex()].append(request)
report = {'scope': 'Measured complete operations with empty-pool responses. First-empty-to-success includes capacity and signing waits.', 'operations': []}
for operation, requests in empty.items():
    first = min(request['startAtMs'] for request in requests)
    previous = [request for request in client['requests'] if request['wallet'] == requests[0]['wallet'] and request.get('state') == 'succeeded' and request['completedAtMs'] < first]
    previous.sort(key=lambda item: item['completedAtMs'])
    preceding = previous[-1]
    previous_id = bytes(preceding['operation']).hex()
    current = [request for request in client['requests'] if bytes(request['operation']).hex() == operation]
    successes = [request for request in current if request.get('state') == 'succeeded']
    assert len(successes) == 1
    observations = sorted(stocks[operation], key=lambda item: item['log_timestamp_ms'])
    scarce = [item for item in observations if item['paired'] < item['minimum']]
    admitted = [item for item in observations if item['stage'] == 'claimed']
    assert scarce and admitted
    report['operations'].append({
        'operation': operation, 'wallet': requests[0]['wallet'],
        'empty_responses': len(requests),
        'preceding_operation': previous_id,
        'preceding_pairs_consumed': len(taken[previous_id]),
        'first_empty_start_ms': min(request['startMs'] for request in requests),
        'first_empty_to_success_ms': successes[0]['completedAtMs'] - first,
        'scarce_pair_counts': sorted({item['paired'] for item in scarce}),
        'minimum_pairs': scarce[0]['minimum'],
        'admitted_pairs': admitted[0]['paired'],
        'service_capacity_responses_after_first_empty': sum(request.get('reason') == 'service_capacity' and request['startAtMs'] >= first for request in current),
        'request_timeline': [{key: request[key] for key in ['startAtMs', 'completedAtMs', 'elapsedMs', 'status', 'reason', 'retryAtMs', 'state'] if key in request} for request in current],
    })
assert sum(item['empty_responses'] for item in report['operations']) == 7
(base / 'empty-pool-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps([{key: value for key, value in item.items() if key != 'request_timeline'} for item in report['operations']]))
