import json
import subprocess
import sys
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-material-delivery-20261030')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
label = sys.argv[1]
assert label and all(letter.islower() or letter.isdigit() or letter == '-' for letter in label)
folder = base / 'cloud-driver' / label
window = json.loads((folder / 'start.json').read_text())
deadline = window['endAtMs'] + 920000
while time.time() * 1000 < deadline:
    path = folder / 'restoration.json'
    if path.exists():
        try:
            observation = json.loads(path.read_text())
        except json.JSONDecodeError:
            time.sleep(1)
            continue
        if observation['complete'] and 'endedAtMs' in observation:
            break
        if 'endedAtMs' in observation:
            raise SystemExit('The restoration observer ended without a qualified reserve')
    time.sleep(5)
else:
    raise SystemExit('The restoration observer did not complete')
receipts = []
commands = [
    ('collect', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'collect', str(base), label]),
    ('traces', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(base), label]),
    ('analysis', ['python3', str(base / 'analyze-capacity.py'), str(base), label]),
]
for stage, command in commands:
    with (folder / (stage + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    receipts.append({'stage': stage, 'exit_code': result.returncode, 'at_ms': round(time.time() * 1000)})
    (folder / 'completion-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps({'label': label, **receipts[-1]}), flush=True)
if any(row['exit_code'] for row in receipts):
    raise SystemExit('A qualification check failed; all artifacts and logs remain intact')
