import { routeLoadRequest, archiveTail, LoadWallet, LoadTraceArchive } from '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/tests/e2e/ml-dsa-cloud-load-worker.mjs';
export { LoadWallet, LoadTraceArchive };

async function fetch(request, env) {
  const path = new URL(request.url).pathname;
  if (path.startsWith('/__benchmark/refill/')) {
    if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) {
      return new Response('Unauthorized', { status: 401 });
    }
    if (path === '/__benchmark/refill/actors' && request.method === 'GET') {
      return Response.json({
        primary: env.TEST_PRODUCER.idFromName('ml-dsa-producer-v1').toString(),
        secondary: env.TEST_SECONDARY_PRODUCER.idFromName('ml-dsa-producer-v1').toString(),
      });
    }
    if (request.method !== 'POST') return new Response('POST required', { status: 405 });
    const text = await request.text();
    if (text.length > 16384) return new Response('Oversized control request', { status: 400 });
    const body = JSON.parse(text);
    const headers = { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': env.INTERNAL_AUTH };
    if (path === '/__benchmark/refill/admission') {
      if (!['claim_refill', 'pending_refills', 'withdraw_refill', 'check_refill', 'finish_refill'].includes(body.command)) {
        return new Response('Unsupported test command', { status: 400 });
      }
      if (body.command === 'finish_refill' && !['unused', 'failed'].includes(body.outcome)) {
        return new Response('Unsupported test settlement', { status: 400 });
      }
      const stub = env.TEST_ADMISSION.get(env.TEST_ADMISSION.idFromName('ml-dsa-admission-v1'));
      return stub.fetch(new Request('https://admission/check', { method: 'POST', headers, body: text }));
    }
    if (path === '/__benchmark/refill/queue') {
      let namespace;
      switch (body.producer_slot) {
        case 'primary': namespace = env.TEST_PRODUCER; break;
        case 'secondary': namespace = env.TEST_SECONDARY_PRODUCER; break;
        default: return new Response('Invalid producer slot', { status: 400 });
      }
      const stub = namespace.get(namespace.idFromName('ml-dsa-producer-v1'));
      return stub.fetch(new Request('https://producer/router-ab/ml-dsa/prepare', { method: 'POST', headers, body: text }));
    }
    return new Response('Unknown test route', { status: 404 });
  }
  if (path.startsWith('/__benchmark/')) return routeLoadRequest(request, env);
  return env.ROUTER.fetch(request);
}

export default { fetch, tail: archiveTail };
