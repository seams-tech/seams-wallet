import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

archive = Path(__file__).resolve().parent
manifest = json.loads((archive / 'manifest.json').read_text())
for name, entry in manifest.items():
    source = archive / name
    assert source.stat().st_size == entry['bytes'], name
    assert hashlib.sha256(source.read_bytes()).hexdigest() == entry['sha256'], name
with tempfile.TemporaryDirectory(prefix='ml-dsa-fair-refill-replay-') as directory:
    work = Path(directory)
    provider = archive / 'provider'
    args = ['python3', str(archive / 'collect_worker_traces.py'), str(provider / 'a-raw.jsonl'), str(provider / 'b-raw.jsonl'), str(work / 'traces.json'), '--router', str(provider / 'router-raw.jsonl'), '--preparer-a', str(provider / 'preparer-a-raw.jsonl'), '--preparer-b', str(provider / 'preparer-b-raw.jsonl'), '--preparer-a-secondary', str(provider / 'preparer-a-secondary-raw.jsonl'), '--preparer-b-secondary', str(provider / 'preparer-b-secondary-raw.jsonl')]
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL)
    shutil.copy2(archive / 'qualify-phase.py', work / 'qualify-phase.py')
    shutil.copy2(archive / 'empty-pool-analysis.py', work / 'empty-pool-analysis.py')
    shutil.copy2(archive / 'analyze-signing-cost.py', work / 'analyze-signing-cost.py')
    for label in ['json30', 'binary30']:
        source = archive / 'cloud-driver' / label
        target = work / 'cloud-driver' / label
        shutil.copytree(source, target)
        shutil.copy2(work / 'traces.json', target / 'traces.json')
        shutil.copy2(archive / (label + '-depletion.json'), work / (label + '-depletion.json'))
        subprocess.run(['python3', str(archive / 'analyze-capacity.py'), str(work), label], check=True, stdout=subprocess.DEVNULL)
        assert json.loads((source / 'analysis.json').read_text()) == json.loads((target / 'analysis.json').read_text())
        subprocess.run(['python3', str(work / 'qualify-phase.py'), label], check=True, stdout=subprocess.DEVNULL)
        assert json.loads((source / 'qualification.json').read_text()) == json.loads((target / 'qualification.json').read_text())
        subprocess.run(['python3', str(work / 'analyze-signing-cost.py'), label], check=True, stdout=subprocess.DEVNULL)
        assert json.loads((source / 'signing-cost.json').read_text()) == json.loads((target / 'signing-cost.json').read_text())
    subprocess.run(['python3', str(work / 'empty-pool-analysis.py')], check=True, stdout=subprocess.DEVNULL)
    assert json.loads((archive / 'empty-pool-analysis.json').read_text()) == json.loads((work / 'empty-pool-analysis.json').read_text())
subprocess.run(['node', str(archive / 'verify-signatures.mjs'), str(archive)], check=True)
print(json.dumps({'manifest': True, 'both_analyses_equal': True, 'both_qualifications_equal': True, 'empty_pool_replay_equal': True}))
