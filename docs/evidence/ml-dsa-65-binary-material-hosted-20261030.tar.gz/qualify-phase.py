import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

base = Path(__file__).resolve().parent
label = sys.argv[1]
folder = base / 'cloud-driver' / label
report = json.loads((folder / 'analysis.json').read_text())
window = json.loads((folder / 'start.json').read_text())
rows = json.loads((folder / 'traces.json').read_text())['records']
initial = json.loads((folder / 'initial-stock.json').read_text())
final = json.loads((folder / 'restoration.json').read_text())
assert report['functional_passed'] and report['ledger_balanced'] and not report['errors']
assert not report['missing_consumed_ids'] and not report['unaccounted_lost_ids'] and not report['unexpected_final_ids']
initial_ids = set(batch for stock in initial['final'] for batch in stock['paired'])
final_ids = set(bytes(batch).hex() for stock in final['final'] for batch in stock['a']['ready'])
assert len(initial_ids) == len(final_ids) == 64 and not initial_ids & final_ids
start = report['start_at_ms']
end = report['cycle_end_at_ms']
expected_versions = {item['role']: item['version'] for item in window['versions']}
metadata = {}
stages = defaultdict(list)
crypto_rows = defaultdict(list)
claims = set()
queued = set()
running = set()
settled = set()
wakes = []
for row in rows:
    for job in row['producer_jobs']:
        metadata[job['batch']] = job
        if start <= job['log_timestamp_ms'] <= end:
            if job['stage'] == 'queued': queued.add(job['batch'])
            if job['stage'] == 'running': running.add(job['batch'])
    for event in row['refill_claims']:
        if event['status'] == 'acquired' and start <= event['log_timestamp_ms'] <= end:
            claims.add(event['batch'])
    for event in row['refill_wakes']:
        if start <= event['at_ms'] <= end:
            if event['event'] == 'ml_dsa_refill_settled_v1': settled.add(event['batch'])
            if event['event'] == 'ml_dsa_refill_alarm_v1': wakes.append(event)
    for event in row['preparation_stages']:
        stages[event['job']].append(event)
    identities = {event['job'] for event in row['preparation_transport']}
    assert len(identities) <= 1
    for identity in identities: crypto_rows[identity].append(row)

published = {job['job'] for job in report['preparation_jobs']}
assert claims == queued == running == published == settled, {
    'claims': len(claims), 'queued': len(queued), 'running': len(running),
    'published': len(published), 'settled': len(settled),
}
for identity in published:
    for role in ['a', 'b']:
        starts = [event for event in stages[identity] if event['role'] == role and event['stage'] == 'crypto_started']
        assert len(starts) == 1, (identity, role, len(starts))

phase = [row for row in rows if start <= row['event_timestamp_ms'] <= end]
canceled = [row for row in phase if row['outcome'] == 'canceled']
acknowledged_overdue = [event for event in wakes if event['after_ms'] is not None and event['after_ms'] <= event['at_ms']]
qualification = {
    'label': label, 'passed': True, 'all_initial_pairs_consumed': True,
    'claims': len(claims), 'queued': len(queued), 'running': len(running),
    'published': len(published), 'settled': len(settled),
    'one_crypto_execution_per_job_per_role': True,
    'provider_canceled_events': len(canceled),
    'provider_canceled_cpu_ms': sum(row['cpu_ms'] for row in canceled),
    'provider_canceled_with_crypto_start': sum(any(event['stage'] == 'crypto_started' for event in row['preparation_stages']) for row in canceled),
    'acknowledged_overdue_wakes': acknowledged_overdue,
    'preparation_cpu_ms_per_consumed_candidate': report['preparation_cpu_ms'] / report['candidates_consumed'],
}

depletion = json.loads((base / (label + '-depletion.json')).read_text())
assert depletion['complete']
key = bytes(window['wallets'][0]['key']['public_key_digest']).hex()
dep_start = depletion['depletionStartedAtMs']
dep_end = depletion['final']['atMs']
selected = {}
for identity, events in stages.items():
    starts = [event['at_ms'] for event in events if event['role'] == 'a' and event['stage'] == 'crypto_started']
    if not starts or not dep_start <= min(starts) <= dep_end: continue
    assert len(starts) == 1
    job = metadata[identity]
    if job['key'] != key: continue
    expected = set(job['batches'])
    assert len(expected) == 2
    publications = {}
    for role in ['a', 'b']:
        pubs = {event['batch'] for event in events if event['role'] == role and event['stage'] == 'published' and event['at_ms'] <= dep_end}
        assert pubs == expected
        publications[role] = pubs
    invocation_rows = crypto_rows[identity]
    assert invocation_rows
    roles = {row['role'] for row in invocation_rows}
    assert len(roles) == 2
    for row in invocation_rows: assert row['version'] == expected_versions[row['role']]
    ends = [event['at_ms'] for event in events if event['role'] == 'a' and event['stage'] == 'crypto_completed']
    assert len(ends) == 1
    selected[identity] = {
        'job': identity, 'producer': job['producer'], 'batches': sorted(expected),
        'roles': sorted(roles), 'crypto_start_at_ms': starts[0], 'crypto_end_at_ms': ends[0],
        'paired_crypto_invocation_cpu_ms': sum(row['cpu_ms'] for row in invocation_rows),
    }
assert len(selected) == 8
fresh_ids = set(batch for job in selected.values() for batch in job['batches'])
assert len(fresh_ids) == 16
assert fresh_ids == {bytes(batch).hex() for batch in depletion['final']['a']['ready']}
assert fresh_ids.isdisjoint(bytes(batch).hex() for batch in depletion['retired'])
events = []
for job in selected.values():
    events.extend([(job['crypto_start_at_ms'], 1), (job['crypto_end_at_ms'], -1)])
active = 0
maximum = 0
for at, change in sorted(events):
    active += change
    maximum = max(maximum, active)
assert active == 0
assert maximum == 2
qualification['depletion'] = {
    'scope': 'Observed restoration from deliberate depletion through exact paired stock. Crypto lifetimes can overlap without proving simultaneous CPU execution.',
    'observed_restoration_ms': depletion['observedRestorationMs'],
    'whole_script_ms': depletion['endedAtMs'] - depletion['startedAtMs'],
    'fresh_pairs': len(fresh_ids), 'four_candidate_jobs': len(selected),
    'distinct_producers': len({job['producer'] for job in selected.values()}),
    'maximum_overlapping_crypto_lifetimes': maximum,
    'paired_crypto_invocation_cpu_ms': sum(job['paired_crypto_invocation_cpu_ms'] for job in selected.values()),
    'median_paired_crypto_invocation_cpu_ms_per_job': statistics.median(job['paired_crypto_invocation_cpu_ms'] for job in selected.values()),
    'jobs': list(selected.values()),
}
(folder / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps({key: value for key, value in qualification.items() if key not in ['depletion', 'acknowledged_overdue_wakes']}))
print(json.dumps({key: value for key, value in qualification['depletion'].items() if key != 'jobs'}))
