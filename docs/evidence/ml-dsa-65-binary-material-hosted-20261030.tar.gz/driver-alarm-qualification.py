import json
import sys
from pathlib import Path

base=Path(sys.argv[1])
report={}
for label in ['json30','binary30']:
    client=json.loads((base/'cloud-driver'/label/'client.json').read_text())
    values=[]
    for index,row in enumerate(client['requests']):
        if row['alarmLatenessMs']>1000:
            values.append({'request_index':index,'wallet':row['wallet'],'demand':row['demand'],'alarm_lateness_ms':row['alarmLatenessMs'],'start_at_ms':row['startAtMs'],'elapsed_ms':row['elapsedMs'],'demand_elapsed_ms':row['demandElapsedMs'],'status':row['status'],'state':row.get('state'),'reason':row.get('reason')})
    report[label]=values
client=json.loads((base/'cloud-driver/binary30/client.json').read_text())
first=client['requests'][25]
last=client['requests'][26]
assert first['wallet']==last['wallet']==0 and first['demand']==last['demand']==14
parts={'cooldown_response_ms':first['elapsedMs'],'scheduled_wait_ms':first['retryAtMs']-first['completedAtMs'],'driver_alarm_lateness_ms':last['alarmLatenessMs'],'successful_call_ms':last['elapsedMs']}
assert sum(parts.values())==41857
report['binary_maximum_demand_decomposition']=parts
expected=json.loads((base/'driver-alarm-qualification.json').read_text())
assert report==expected
print(json.dumps({'driver_alarm_qualification_reproduced':True}))
