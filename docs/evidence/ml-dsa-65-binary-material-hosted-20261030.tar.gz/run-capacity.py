import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
label = sys.argv[1]
assert re.fullmatch('[a-z0-9-]+', label)
receipts = []

def run(stage, command):
    started = round(time.time() * 1000)
    with (base / (label + '-' + stage + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    receipt = {'stage': stage, 'exit_code': result.returncode, 'started_at_ms': started, 'ended_at_ms': round(time.time() * 1000)}
    receipts.append(receipt)
    (base / (label + '-receipts.json')).write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps({'label': label, **receipt}), flush=True)
    assert result.returncode == 0, stage

# Require the complete local real-protocol campaign to finish before timing.
deadline = time.time() + 900
while time.time() < deadline:
    artifact = base / 'local-binary-worker-proof.json'
    log = base / 'local-binary-worker-proof.log'
    if artifact.exists():
        result = json.loads(artifact.read_text())
        assert result['passed'], result.get('error')
        lines = log.read_text().splitlines()
        try:
            last = json.loads(lines[-1])
        except (json.JSONDecodeError, IndexError):
            last = {}
        if last.get('passed') is True and 'artifact' in last:
            break
    time.sleep(5)
else:
    raise SystemExit('Complete local campaign did not finish. No hosted load started.')

run('depletion', ['node', str(base / 'depleted-wallet.mjs'), label])
run('initial-stock', ['node', str(base / 'snapshot-stock.mjs'), label])
run('start', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'start', str(base), label, '4', '720000'])
folder = base / 'cloud-driver' / label
shutil.copy2(base / (label + '-initial-stock.json'), folder / 'initial-stock.json')
with (folder / 'observer.log').open('w') as output:
    observer = subprocess.Popen(['node', str(base / 'observe-restoration.mjs'), label], cwd=root, stdout=output, stderr=subprocess.STDOUT)
    run('finish', ['python3', str(base / 'finish-phase.py'), label])
    assert observer.wait(timeout=60) == 0
print(json.dumps({'label': label, 'completed': True}), flush=True)
