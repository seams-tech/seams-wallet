import hashlib
import json
import os
import subprocess
from pathlib import Path

base = Path(__file__).resolve().parent
manifest = json.loads((base/'manifest.json').read_text())
for name, expected in manifest.items():
    assert hashlib.sha256((base/name).read_bytes()).hexdigest() == expected, name
provider = base/'provider'
command = ['python3', str(base/'collect_worker_traces.py'), str(provider/'a-raw.jsonl'), str(provider/'b-raw.jsonl'), str(base/'traces.json'), '--router', str(provider/'router-raw.jsonl')]
for role in ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
    command += ['--'+role, str(provider/(role+'-raw.jsonl'))]
subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
for count, label in [(1,'capacity'),(2,'capacity-g2'),(4,'capacity-g4')]:
    phase = base/('groups-'+str(count))
    folder = phase/'cloud-driver'/label
    target = folder/'traces.json'
    os.link(base/'traces.json', target)
    commands = [('analysis.json',['python3',str(base/'analyze-capacity.py'),str(phase),label]),
                ('group-qualification.json',['python3',str(base/'qualify-groups.py'),str(count),label]),
                ('producer-variation.json',['python3',str(base/'analyze-producers.py'),str(count),label]),
                ('driver-qualification.json',['node',str(base/'analyze-driver.mjs'),str(count),label])]
    for name, arguments in commands:
        expected=json.loads((folder/name).read_text())
        subprocess.run(arguments,check=True,stdout=subprocess.DEVNULL)
        assert json.loads((folder/name).read_text()) == expected, (count,name)
    target.unlink()
(base/'traces.json').unlink()
subprocess.run(['node',str(base/'verify-signatures.mjs')],check=True)
print(json.dumps({'passed':True,'manifest_members':len(manifest),'all_three_cycle_analyses_reproduced':True}))
