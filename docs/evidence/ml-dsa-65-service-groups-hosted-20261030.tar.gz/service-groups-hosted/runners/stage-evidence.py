import hashlib
import json
import shutil
import subprocess
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
stage = base / 'public-evidence'
stage.mkdir(exist_ok=True)
profiles = [(1, 'capacity'), (2, 'capacity-g2'), (4, 'capacity-g4')]
reports = {count: json.loads((base / ('groups-' + str(count)) / 'cloud-driver' / label / 'analysis.json').read_text()) for count, label in profiles}
first = reports[1]['start_at_ms'] - 30000
last = reports[4]['cycle_end_at_ms'] + 30000
provider = stage / 'provider'
provider.mkdir(exist_ok=True)
selection = {'first_included_ms': first, 'last_included_ms': last,
             'rule': 'Keep a complete invocation when any log timestamp or metadata/wall envelope intersects the continuous experiment interval. Keep unknown timestamps. Never select by success, status, or version.', 'roles': {}}
source = base / 'groups-4/cloud-driver/final-capture'
for path in source.glob('*-raw.jsonl'):
    total = 0
    kept = 0
    with path.open() as reader, (provider / path.name).open('w') as writer:
        for line in reader:
            if not line.strip(): continue
            total += 1
            row = json.loads(line)
            times = [value['timestamp'] for value in row.get('logs', []) if isinstance(value.get('timestamp'), (int, float))]
            at = row.get('eventTimestamp')
            if isinstance(at, (int, float)):
                times.append(at)
                if isinstance(row.get('wallTime'), (int, float)): times.append(at + row['wallTime'])
            if times and (max(times) < first or min(times) > last): continue
            writer.write(line)
            kept += 1
    selection['roles'][path.stem] = {'input_invocations': total, 'included_invocations': kept}
(stage / 'provider-selection.json').write_text(json.dumps(selection, indent=2) + '\n')
collector = root / 'tools/ml-dsa-investigation/research/collect_worker_traces.py'
shutil.copy2(collector, stage / 'collect_worker_traces.py')
arguments = ['python3', str(stage / 'collect_worker_traces.py'), str(provider / 'a-raw.jsonl'), str(provider / 'b-raw.jsonl'), str(stage / 'traces.json'), '--router', str(provider / 'router-raw.jsonl')]
for role in ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']:
    arguments += ['--' + role, str(provider / (role + '-raw.jsonl'))]
with (stage / 'collection.log').open('w') as output:
    subprocess.run(arguments, stdout=output, stderr=subprocess.STDOUT, check=True)
rows = json.loads((stage / 'traces.json').read_text())['records']
fingerprints = Counter(hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest() for row in rows)
for name in ['qualify-groups.py', 'analyze-producers.py', 'analyze-driver.mjs']:
    shutil.copy2(base / name, stage / name)
shutil.copy2(base / 'groups-1/analyze-capacity.py', stage / 'analyze-capacity.py')
closed = {}
for count, label in profiles:
    phase = base / ('groups-' + str(count))
    original = phase / 'cloud-driver' / label
    destination = stage / ('groups-' + str(count)) / 'cloud-driver' / label
    destination.mkdir(parents=True, exist_ok=True)
    for name in ['start.json', 'initial-stock.json', 'restoration.json', 'client.json', 'driver-snapshots.json', 'analysis.json', 'actors.json', 'completion-receipts.json', 'group-qualification.json', 'producer-variation.json', 'driver-qualification.json']:
        shutil.copy2(original / name, destination / name)
    for index in range(1, 5):
        shutil.copy2(phase / ('registration-' + str(index) + '.json'), destination.parents[1] / ('registration-' + str(index) + '.json'))
    before = json.loads((original / 'analysis.json').read_text())
    old_rows = json.loads((original / 'traces.json').read_text())['records']
    expected = Counter(hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest() for row in old_rows if before['start_at_ms'] <= row['event_timestamp_ms'] <= before['cycle_end_at_ms'])
    assert not expected - fingerprints, 'Closed-window provider records changed for group ' + str(count)
    closed[count] = {'closed_window_records': sum(expected.values()), 'fingerprints_preserved': True}
    shutil.copy2(stage / 'traces.json', destination / 'traces.json')
    commands = [('analysis.json', ['python3', str(stage / 'analyze-capacity.py'), str(stage / ('groups-' + str(count))), label]),
                ('group-qualification.json', ['python3', str(stage / 'qualify-groups.py'), str(count), label]),
                ('producer-variation.json', ['python3', str(stage / 'analyze-producers.py'), str(count), label]),
                ('driver-qualification.json', ['node', str(stage / 'analyze-driver.mjs'), str(count), label])]
    for name, command in commands:
        expected_result = json.loads((destination / name).read_text())
        with (destination / (name + '.replay.log')).open('w') as output:
            subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT, check=True)
        actual = json.loads((destination / name).read_text())
        assert actual == expected_result, name + ' changed in final capture for group ' + str(count)
    (destination / 'traces.json').unlink()
    for name in ['scope.json', 'deployments.json', 'prior-placements.json', 'driver-name-collision.json', 'registration-1-setup-qualification.json']:
        if (phase / name).exists(): shutil.copy2(phase / name, destination.parents[1] / name)
    for path in phase.glob('registration-*-setup-qualification.json'):
        shutil.copy2(path, destination.parents[1] / path.name)
(stage / 'closed-windows.json').write_text(json.dumps(closed, indent=2) + '\n')
(stage / 'traces.json').unlink()
for name in ['hosted-scope.json', 'hosted-upload-scope.md', 'front.mjs', 'initial-stock.mjs', 'final-state.mjs', 'final-admission-state.json']:
    shutil.copy2(base / name, stage / name)
for name in ['deletions.json', 'absence.json']:
    target = stage / 'cleanup' / name
    target.parent.mkdir(exist_ok=True)
    shutil.copy2(base / 'cleanup' / name, target)
# Preserve setup failure traces separately from the continuous timed capture.
setup = stage / 'setup'
setup.mkdir(exist_ok=True)
shutil.copy2(base / 'groups-1/cloud-driver/setup/traces.json', setup / 'candidate-exhaustion-traces.json')
shutil.copy2(base / 'groups-2/start.log', setup / 'driver-name-collision.log')
shutil.copy2(base / 'final-state-first-attempt.log', setup / 'idle-maintenance-first-check.log')
print(json.dumps({'included_provider_records': len(rows), 'closed_windows': closed, 'all_replayed_results_equal': True}), flush=True)
