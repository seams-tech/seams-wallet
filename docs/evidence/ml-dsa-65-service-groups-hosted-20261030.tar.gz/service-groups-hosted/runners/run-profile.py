import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
count = int(sys.argv[1])
assert count in [1, 2, 4]
phase = base / ('groups-' + str(count))
label = sys.argv[2]
assert label and all(letter.islower() or letter.isdigit() or letter == '-' for letter in label)
receipts = []

def run(stage, command):
    started = round(time.time() * 1000)
    with (phase / (stage + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    record = {'stage': stage, 'exit_code': result.returncode, 'started_at_ms': started, 'ended_at_ms': round(time.time() * 1000)}
    receipts.append(record)
    (phase / 'profile-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit('Profile stage failed: ' + stage)

run('initial-stock', ['node', str(base / 'initial-stock.mjs'), str(phase), label])
run('start', ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'start', str(phase), label, '4', '360000'])
folder = phase / 'cloud-driver' / label
shutil.copy2(phase / (label + '-initial-stock.json'), folder / 'initial-stock.json')
shutil.copy2(phase / (label + '-actors.json'), folder / 'actors.json')
with (folder / 'observer.log').open('w') as output:
    observer = subprocess.Popen(['node', str(phase / 'observe-restoration.mjs'), label], cwd=root, stdout=output, stderr=subprocess.STDOUT)
    try:
        run('finish', ['python3', str(phase / 'finish-phase.py'), label])
        if observer.wait(timeout=60) != 0:
            raise SystemExit('Reserve observer failed')
    finally:
        if observer.poll() is None:
            observer.terminate()
print(json.dumps({'groups': count, 'complete': True}), flush=True)
