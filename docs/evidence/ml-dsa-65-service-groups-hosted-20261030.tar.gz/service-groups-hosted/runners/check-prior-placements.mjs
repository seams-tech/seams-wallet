import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
const base = import.meta.dirname;
const current = Number(process.argv[2]);
assert.ok([2, 4].includes(current));
const scope = JSON.parse(await readFile(join(base, "scope.json"), "utf8"));
const token = (await readFile(join(base, "gateway-token"), "utf8")).trim();
const records = [];
for (const count of [1, 2]) {
  if (count >= current) continue;
  for (let index = 1; index <= 4; index += 1) {
    const registration = JSON.parse(
      await readFile(
        join(base, "groups-" + count, "registration-" + index + ".json"),
        "utf8",
      ),
    );
    const latest = registration.cases.at(-1);
    const response = await fetch(
      scope.router_url + "/__benchmark/refill/placement",
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-router-ab-internal-service-auth": token,
        },
        body: JSON.stringify({ wallet: latest.key.wallet }),
        signal: AbortSignal.timeout(30000),
      },
    );
    assert.equal(response.status, 200);
    const placement = await response.json();
    assert.deepEqual(placement.wallet, latest.key.wallet);
    assert.equal(placement.group, latest.serviceGroup);
    records.push({ wallet: latest.key.wallet, group: placement.group });
  }
}
await writeFile(
  join(base, "groups-" + current, "prior-placements.json"),
  JSON.stringify({ passed: true, records }, null, 2) + "\n",
);
console.log(
  JSON.stringify({ passed: true, retainedAssignments: records.length }),
);
