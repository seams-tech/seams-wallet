import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
count = int(sys.argv[1])
assert count in [1, 2, 4]
phase = base / ('groups-' + str(count))
scope = json.loads((phase / 'scope.json').read_text())
assert scope['policy']['service_groups'] == count
assert len(json.loads((phase / 'deployments.json').read_text())) == 8
shutil.copy2(base / 'gateway-token', phase / 'gateway-token')
shutil.copy2(base / 'router-secrets.json', phase / 'router-secrets.json')
def qualify_exhausted_setup(index, artifact):
    report = json.loads(artifact.read_text())
    assert report['registrationChecksPassed'] and report['recoveryPreservesCanonicalKey']
    assert report['cases'][-1]['initialStockSign'].get('verified') is True
    label = 'setup-wallet-' + str(index)
    folder = phase / 'cloud-driver' / label
    folder.mkdir()
    with (phase / (label + '-traces.log')).open('w') as log:
        trace_result = subprocess.run(['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(phase), label], cwd=root, stdout=log, stderr=subprocess.STDOUT)
    assert trace_result.returncode == 0
    rows = json.loads((folder / 'traces.json').read_text())['records']
    failures = []
    for case in report['cases']:
        signing = case['initialStockSign']
        if signing.get('verified') is True:
            continue
        assert signing.get('failed') is True
        operation = bytes(signing['operation']).hex()
        outcomes = [event['outcome'] for row in rows for event in row['signing'] if event['operation'] == operation]
        assert outcomes and all(value['status'] == 'exhausted' for value in outcomes)
        failures.append({'operation': operation, 'epoch': case['epoch'], 'outcome': outcomes[0], 'elapsed_ms': signing['elapsedMs']})
    assert failures
    record = {'wallet': index, 'registration_and_recovery_passed': True, 'initial_stock_failures': failures,
              'scope': 'Original E2E functional failure retained. Capacity screening continues from a canonically recovered key with a verified latest-epoch signature and full reserves.'}
    (phase / ('registration-' + str(index) + '-setup-qualification.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'wallet': index, 'preserved_exhausted_setup_operations': len(failures)}), flush=True)

first = int(sys.argv[2]) if len(sys.argv) > 2 else 1
assert 1 <= first <= 4
for index in range(first, 5):
    directory = phase / ('wallet-' + str(index))
    directory.mkdir()
    for name in ['a-kek', 'b-kek', 'publics.json']:
        shutil.copy2(base / 'hosted-keys' / name, directory / name)
    environment = os.environ.copy()
    environment.update({'ML_DSA_REGISTRATION_ROUTER_URL': scope['router_url'], 'ML_DSA_GATEWAY_TOKEN_FILE': str(base / 'gateway-token'), 'ML_DSA_TEST_BUILD_ROOT': str(base / 'build'), 'ML_DSA_TEST_PREPARATION_JOBS': '2', 'ML_DSA_TEST_SERVICE_GROUPS': str(count), 'ML_DSA_TEST_COOLDOWN_MS': '5000', 'ML_DSA_TEST_WALLET_ID': scope['prefix'] + '-g' + str(count) + '-w' + str(index)})
    artifact = phase / ('registration-' + str(index) + '.json')
    with (phase / ('registration-' + str(index) + '.log')).open('w') as log:
        result = subprocess.run(['node', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs', str(directory), str(artifact)], cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        qualify_exhausted_setup(index, artifact)
    registration = json.loads(artifact.read_text())
    assert registration['registrationChecksPassed'] and registration['recoveryPreservesCanonicalKey']
    groups = {case['serviceGroup'] for case in registration['cases']}
    assert len(groups) == 1
    print(json.dumps({'groups': count, 'wallet': index, 'service_group': groups.pop(), 'canonical_recovery_verified': True}), flush=True)
for name in ['snapshot-stock.mjs', 'observe-restoration.mjs', 'finish-phase.py']:
    text = (Path('/private/tmp/ml-dsa-material-delivery-20261030') / name).read_text().replace('/private/tmp/ml-dsa-material-delivery-20261030', str(phase))
    (phase / name).write_text(text)
shutil.copy2('/private/tmp/ml-dsa-material-delivery-20261030/analyze-capacity.py', phase / 'analyze-capacity.py')
