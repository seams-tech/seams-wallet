import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
count = int(sys.argv[1])
assert count in [1, 2, 4]
label = 'groups-' + str(count)
scope = json.loads((base / 'scope.json').read_text())
assert scope['prefix'] == 'ml-dsa-groups-1030-3cd638'
folder = base / label
folder.mkdir(exist_ok=False)
scope['policy']['service_groups'] = count
receipts = []
for item in scope['workers']:
    role = item['role']
    config = json.loads((base / (role + '.json')).read_text())
    config['vars']['ML_DSA_ADMISSION_POLICY'] = json.dumps(scope['policy'], separators=(',', ':'))
    path = folder / (role + '.json')
    path.write_text(json.dumps(config, indent=2) + '\n')
    started = round(time.time() * 1000)
    result = subprocess.run([str(root / 'node_modules/.bin/wrangler'), 'deploy', '--config', str(path)], cwd=root, capture_output=True, text=True)
    (folder / (role + '-deploy.log')).write_text(result.stdout + result.stderr)
    version = re.search(r'Current Version ID: ([0-9a-f-]{36})', result.stdout)
    receipts.append({'role': role, 'worker': item['name'], 'exit_code': result.returncode, 'version': version.group(1) if version else None, 'started_at_ms': started, 'completed_at_ms': round(time.time() * 1000), 'config_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    (folder / 'deployments.json').write_text(json.dumps(receipts, indent=2) + '\n')
    if result.returncode or not version:
        raise SystemExit('Deployment failed for ' + role + '; retained log: ' + str(folder / (role + '-deploy.log')))
(folder / 'scope.json').write_text(json.dumps(scope, indent=2) + '\n')
(folder / 'cloud-driver').mkdir()
(folder / 'cloud-driver/versions.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps({'groups': count, 'workers': len(receipts), 'directory': str(folder)}))
