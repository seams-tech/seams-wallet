import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

base = Path(__file__).resolve().parent
count = int(sys.argv[1])
label = sys.argv[2]
folder = base / ('groups-' + str(count)) / 'cloud-driver' / label
report = json.loads((folder / 'analysis.json').read_text())
qualification = json.loads((folder / 'group-qualification.json').read_text())
rows = json.loads((folder / 'traces.json').read_text())['records']
owner = {}
for actor in qualification['actors']:
    for slot in ['primary', 'secondary']:
        owner[actor[slot]] = (actor['group'], slot)
metadata = {entry['batch']: entry for row in rows for entry in row['producer_jobs']}
slots = defaultdict(list)
for job in report['preparation_jobs']:
    metadata_job = metadata[job['job']]
    group, slot = owner[metadata_job['producer']]
    cpu = sum(job['crypto_invocation_cpu_ms'].values())
    slots[group, slot].append({'job': job['job'], 'candidates': job['candidates'], 'paired_cpu_ms': cpu,
                              'wall_ms': job['wall_ms'], 'started_at_ms': job['started_at_ms']})
output = []
for (group, slot), jobs in sorted(slots.items()):
    candidates = sum(job['candidates'] for job in jobs)
    four = [job['wall_ms'] for job in jobs if job['candidates'] == 4]
    output.append({'group': group, 'slot': slot, 'jobs': len(jobs), 'candidates': candidates,
                   'paired_cpu_ms_per_candidate': sum(job['paired_cpu_ms'] for job in jobs) / candidates,
                   'four_candidate_wall_median_ms': statistics.median(four) if four else None,
                   'four_candidate_wall_maximum_ms': max(four) if four else None})
result = {'groups': count, 'scope': 'Whole paired crypto-containing invocation CPU per published candidate. Does not isolate the cryptographic kernel or establish a host/tiering cause.', 'slots': output}
(folder / 'producer-variation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
