# ML-DSA optional service-group scaling: exact upload scope

Eight new temporary Workers. Synthetic wallets only. No production wallet or account credentials.

Use one frozen build for one-, two-, and four-group profiles. Keep thirty-two candidates per wallet and consume two at a time.
Each profile uses four new wallets, two refill slots per group, and a five-second benchmark cooldown for demand headroom.
Production defaults remain one group, one refill slot, and a sixty-second cooldown.

## Credential uploads

| Worker | Secret bindings | Exact JSON payload SHA-256 |
| --- | --- | --- |
| ml-dsa-groups-1030-3cd638-router | INTERNAL_AUTH, ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET | 25650ed70562b8283b1eefa8be7d3a6c697ef3887decf9174848d3269d95d8fd |
| ml-dsa-groups-1030-3cd638-a | INTERNAL_AUTH, ROLE_KEK | 67bfee09f9af2f7482970ee9bfa2220c01298f270835fe31e4a035b02f4b8f0e |
| ml-dsa-groups-1030-3cd638-b | INTERNAL_AUTH, ROLE_KEK | 2a9caf8a6334e5d8ba5c13e53adb2228b0a1d54d53eff6ceeee07aa4da82b6df |
| ml-dsa-groups-1030-3cd638-preparer-a | INTERNAL_AUTH, ROLE_KEK | 67bfee09f9af2f7482970ee9bfa2220c01298f270835fe31e4a035b02f4b8f0e |
| ml-dsa-groups-1030-3cd638-preparer-b | INTERNAL_AUTH, ROLE_KEK | 2a9caf8a6334e5d8ba5c13e53adb2228b0a1d54d53eff6ceeee07aa4da82b6df |
| ml-dsa-groups-1030-3cd638-preparer-a-secondary | INTERNAL_AUTH, ROLE_KEK | 67bfee09f9af2f7482970ee9bfa2220c01298f270835fe31e4a035b02f4b8f0e |
| ml-dsa-groups-1030-3cd638-preparer-b-secondary | INTERNAL_AUTH, ROLE_KEK | 2a9caf8a6334e5d8ba5c13e53adb2228b0a1d54d53eff6ceeee07aa4da82b6df |
| ml-dsa-groups-1030-3cd638-front | INTERNAL_AUTH, ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET | 25650ed70562b8283b1eefa8be7d3a6c697ef3887decf9174848d3269d95d8fd |

Participant A receives only its own holder key. Participant B receives only its own holder key.
The Router and front receive benchmark tokens only. All eight Workers and private payloads are removed after qualification.

## Workload

Compare complete consumption/refill cycles and final reserve restoration. Record queue growth, material waits, driver lateness, verified signatures, failed jobs, and total preparation CPU.
The same four-wallet count isolates group concurrency. This screen does not establish proportional scaling for a growing wallet population.
Capture actual wallet placement and producer IDs. Preserve existing assignments when enabling later groups. Do not claim linear scaling from successful-call latency alone.
