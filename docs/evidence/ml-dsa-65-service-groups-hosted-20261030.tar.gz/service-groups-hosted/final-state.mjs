import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
const base = import.meta.dirname;
const scope = JSON.parse(await readFile(join(base, "scope.json"), "utf8"));
const token = (await readFile(join(base, "gateway-token"), "utf8")).trim();
const report = { observedAtMs: Date.now(), wallets: [], passed: false };
for (const count of [1, 2, 4]) {
  for (let index = 1; index <= 4; index += 1) {
    const record = JSON.parse(
      await readFile(
        join(base, "groups-" + count, "registration-" + index + ".json"),
        "utf8",
      ),
    );
    const key = record.cases.at(-1).key;
    const response = await fetch(
      scope.router_url + "/__benchmark/refill/admission",
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-router-ab-internal-service-auth": token,
        },
        body: JSON.stringify({ command: "pending_refills", key }),
        signal: AbortSignal.timeout(30000),
      },
    );
    assert.equal(response.status, 200);
    const pending = await response.json();
    if (count === 4) assert.deepEqual(pending, []);
    report.wallets.push({ key, pending, cohort: count, scope: count === 4 ? 'latest measured cohort' : 'earlier idle cohort, expiry maintenance may resume' });
  }
}
report.passed = true;
await writeFile(
  join(base, "final-admission-state.json"),
  JSON.stringify(report, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    passed: true,
    wallets: report.wallets.length,
    pendingJobs: report.wallets.reduce(pendingCount, 0),
  }),
);

function pendingCount(total, wallet) { return total + wallet.pending.length; }
