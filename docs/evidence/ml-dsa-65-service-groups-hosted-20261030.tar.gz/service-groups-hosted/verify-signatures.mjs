import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { createPublicKey, verify } from "node:crypto";
const base = import.meta.dirname;
let loadSignatures = 0;
let setupSignatures = 0;
for (const [count, label] of [
  [1, "capacity"],
  [2, "capacity-g2"],
  [4, "capacity-g4"],
]) {
  const phase = join(base, "groups-" + count);
  const client = JSON.parse(
    await readFile(join(phase, "cloud-driver", label, "client.json"), "utf8"),
  );
  for (const row of client.requests) {
    if (row.state !== "succeeded") continue;
    const wallet = client.wallets.find(matchesIndex.bind(null, row.wallet));
    check(
      wallet.publicKeyHex,
      row.messageHex,
      row.contextHex,
      row.signatureHex,
    );
    loadSignatures += 1;
  }
  for (let index = 1; index <= 4; index += 1) {
    const registration = JSON.parse(
      await readFile(join(phase, "registration-" + index + ".json"), "utf8"),
    );
    assert.equal(registration.registrationChecksPassed, true);
    assert.equal(registration.recoveryPreservesCanonicalKey, true);
    assert.equal(new Set(registration.cases.map(publicKey)).size, 1);
    assert.equal(new Set(registration.cases.map(serviceGroup)).size, 1);
    for (const record of registration.cases) {
      if (record.initialStockSign.verified !== true) continue;
      check(
        record.publicKeyHex,
        record.initialStockSign.messageHex,
        record.initialStockSign.contextHex,
        record.initialStockSign.signatureHex,
      );
      setupSignatures += 1;
    }
  }
}
assert.equal(loadSignatures, 312);
assert.equal(setupSignatures, 23);
console.log(
  JSON.stringify({
    passed: true,
    loadSignatures,
    setupSignatures,
    alteredMessagesRejected: loadSignatures + setupSignatures,
  }),
);
function matchesIndex(index, wallet) {
  return wallet.index === index;
}
function publicKey(record) {
  return record.publicKeyHex;
}
function serviceGroup(record) {
  return record.serviceGroup;
}
function check(publicKeyHex, messageHex, contextHex, signatureHex) {
  assert.equal(contextHex, "");
  const key = createPublicKey({
    key: Buffer.concat([
      Buffer.from("308207b2300b0609608648016503040312038207a100", "hex"),
      Buffer.from(publicKeyHex, "hex"),
    ]),
    format: "der",
    type: "spki",
  });
  const message = Buffer.from(messageHex, "hex");
  const signature = Buffer.from(signatureHex, "hex");
  assert.equal(verify(null, message, key, signature), true);
  assert.equal(
    verify(null, Buffer.concat([message, Buffer.from([1])]), key, signature),
    false,
  );
}
