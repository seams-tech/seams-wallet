import {
  routeLoadRequest,
  archiveTail,
  LoadWallet,
  LoadTraceArchive,
} from "/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/tests/e2e/ml-dsa-cloud-load-worker.mjs";
export { LoadWallet, LoadTraceArchive };

async function fetch(request, env) {
  const path = new URL(request.url).pathname;
  if (path.startsWith("/__benchmark/refill/")) {
    if (
      request.headers.get("x-router-ab-internal-service-auth") !==
      env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET
    ) {
      return new Response("Unauthorized", { status: 401 });
    }
    if (path === "/__benchmark/refill/placement" && request.method === "POST") {
      const stub = env.TEST_ADMISSION.get(
        env.TEST_ADMISSION.idFromName("ml-dsa-admission-v1"),
      );
      return stub.fetch(
        new Request("https://admission/routing", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-router-ab-internal-service-auth": env.INTERNAL_AUTH,
          },
          body: await request.text(),
        }),
      );
    }
    if (path === "/__benchmark/refill/actors" && request.method === "GET") {
      const count = Number(
        new URL(request.url).searchParams.get("groups") ?? 1,
      );
      if (![1, 2, 4].includes(count))
        return new Response("Invalid group count", { status: 400 });
      const actors = [];
      for (let group = 0; group < count; group += 1) {
        const suffix = group === 0 ? "" : "-group-" + group;
        actors.push({
          group,
          admission: env.TEST_ADMISSION.idFromName(
            "ml-dsa-admission-v1" + suffix,
          ).toString(),
          primary: env.TEST_PRODUCER.idFromName(
            "ml-dsa-producer-v1" + suffix,
          ).toString(),
          secondary: env.TEST_SECONDARY_PRODUCER.idFromName(
            "ml-dsa-producer-v1" + suffix,
          ).toString(),
        });
      }
      return Response.json({ actors });
    }
    if (request.method !== "POST")
      return new Response("POST required", { status: 405 });
    const text = await request.text();
    if (text.length > 16384)
      return new Response("Oversized control request", { status: 400 });
    const body = JSON.parse(text);
    const wallet = body.key?.wallet ?? body.job?.key?.wallet;
    const directory = env.TEST_ADMISSION.get(
      env.TEST_ADMISSION.idFromName("ml-dsa-admission-v1"),
    );
    const resolved = await directory.fetch(
      new Request("https://admission/routing", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-router-ab-internal-service-auth": env.INTERNAL_AUTH,
        },
        body: JSON.stringify({ wallet }),
      }),
    );
    if (resolved.status !== 200) return resolved;
    const placement = await resolved.json();
    const group = placement.group;
    if (!Number.isInteger(group) || group < 0 || group >= 64)
      return new Response("Invalid placement", { status: 500 });
    const admissionName =
      group === 0
        ? "ml-dsa-admission-v1"
        : `ml-dsa-admission-v1-group-${group}`;
    const producerName =
      group === 0 ? "ml-dsa-producer-v1" : `ml-dsa-producer-v1-group-${group}`;
    const headers = {
      "content-type": "application/json",
      "x-router-ab-internal-service-auth": env.INTERNAL_AUTH,
    };
    if (path === "/__benchmark/refill/admission") {
      if (
        ![
          "claim_refill",
          "pending_refills",
          "withdraw_refill",
          "check_refill",
          "finish_refill",
        ].includes(body.command)
      ) {
        return new Response("Unsupported test command", { status: 400 });
      }
      if (
        body.command === "finish_refill" &&
        !["unused", "failed"].includes(body.outcome)
      ) {
        return new Response("Unsupported test settlement", { status: 400 });
      }
      const stub = env.TEST_ADMISSION.get(
        env.TEST_ADMISSION.idFromName(admissionName),
      );
      return stub.fetch(
        new Request("https://admission/check", {
          method: "POST",
          headers,
          body: text,
        }),
      );
    }
    if (path === "/__benchmark/refill/queue") {
      let namespace;
      switch (body.producer_slot) {
        case "primary":
          namespace = env.TEST_PRODUCER;
          break;
        case "secondary":
          namespace = env.TEST_SECONDARY_PRODUCER;
          break;
        default:
          return new Response("Invalid producer slot", { status: 400 });
      }
      const stub = namespace.get(namespace.idFromName(producerName));
      return stub.fetch(
        new Request("https://producer/router-ab/ml-dsa/prepare", {
          method: "POST",
          headers,
          body: text,
        }),
      );
    }
    return new Response("Unknown test route", { status: 404 });
  }
  if (path.startsWith("/__benchmark/")) return routeLoadRequest(request, env);
  return env.ROUTER.fetch(request);
}

export default { fetch, tail: archiveTail };
