import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
const count = Number(process.argv[2]);
const label = process.argv[3];
const folder = join(
  import.meta.dirname,
  "groups-" + count,
  "cloud-driver",
  label,
);
const input = JSON.parse(await readFile(join(folder, "client.json"), "utf8"));
const seen = new Set();
const first = [];
const retries = [];
for (let index = 0; index < input.requests.length; index += 1) {
  const request = input.requests[index];
  const identity = request.wallet + ":" + request.demand;
  const record = {
    requestIndex: index,
    wallet: request.wallet,
    demand: request.demand,
    rawLatenessMs: request.alarmLatenessMs,
    elapsedMs: request.elapsedMs,
    demandElapsedMs: request.demandElapsedMs,
    status: request.status,
    reason: request.reason ?? null,
  };
  if (seen.has(identity)) retries.push(record);
  else first.push(record);
  seen.add(identity);
}
const result = {
  groups: count,
  firstDemandRequests: first.length,
  retryRequests: retries.length,
  maximumFirstDemandRawLatenessMs: Math.max(...first.map(lateness)),
  maximumRetryRawLatenessMs: Math.max(...retries.map(lateness)),
  retryLatenessOverOneSecond: retries.filter(overOneSecond),
  qualification:
    "New-demand raw lateness includes prior cadence debt because stored nextAt can precede the actual alarm deadline. Retry values include driver storage and scheduling. Neither counter isolates provider alarm service time or public SDK behavior. Keep whole rates and demand durations unchanged.",
};
assert.equal(
  result.firstDemandRequests + result.retryRequests,
  input.requests.length,
);
await writeFile(
  join(folder, "driver-qualification.json"),
  JSON.stringify(result, null, 2) + "\n",
);
console.log(JSON.stringify(result));
function lateness(value) {
  return value.rawLatenessMs;
}
function overOneSecond(value) {
  return value.rawLatenessMs > 1000;
}
