import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
const base = resolve(process.argv[2]);
const label = process.argv[3];
const scope = JSON.parse(await readFile(join(base, "scope.json"), "utf8"));
const internal = JSON.parse(
  await readFile(join(base, "router-secrets.json"), "utf8"),
).INTERNAL_AUTH;
const gateway = (await readFile(join(base, "gateway-token"), "utf8")).trim();
const keys = [];
for (let index = 1; index <= 4; index += 1) {
  const record = JSON.parse(
    await readFile(join(base, "registration-" + index + ".json"), "utf8"),
  );
  assert.equal(record.registrationChecksPassed, true);
  assert.equal(record.recoveryPreservesCanonicalKey, true);
  keys.push(record.cases.at(-1).key);
}
const startedAtMs = Date.now();
const deadline = startedAtMs + 900000;
let final;
while (Date.now() < deadline) {
  final = [];
  for (const key of keys) {
    const a = await inventory("a", key);
    const b = await inventory("b", key);
    const paired = a.ready
      .map(hex)
      .filter(inPeer.bind(null, new Set(b.ready.map(hex))))
      .sort();
    const placement = await front("/__benchmark/refill/placement", {
      wallet: key.wallet,
    });
    const pending = await front("/__benchmark/refill/admission", {
      command: "pending_refills",
      key,
    });
    final.push({
      key,
      a,
      b,
      paired,
      group: placement.group,
      pending: pending.length,
    });
  }
  const complete = final.every(full);
  await writeFile(
    join(base, label + "-initial-stock.json"),
    JSON.stringify(
      { startedAtMs, endedAtMs: Date.now(), complete, final },
      null,
      2,
    ) + "\n",
  );
  if (complete) break;
  console.log(JSON.stringify({ waiting: final.map(stockCount) }));
  await delay(2000);
}
assert.ok(final.every(full), "Initial reserve did not restore");
const actors = await front(
  "/__benchmark/refill/actors?groups=" + scope.policy.service_groups,
);
await writeFile(
  join(base, label + "-actors.json"),
  JSON.stringify(actors, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    complete: true,
    groups: final.map(group),
    pairedPerWallet: 16,
  }),
);
function hex(value) {
  return Buffer.from(value).toString("hex");
}
function inPeer(peer, value) {
  return peer.has(value);
}
function full(value) {
  return (
    value.paired.length === 16 &&
    value.a.ready.length === 16 &&
    value.b.ready.length === 16 &&
    value.a.reserved.length === 0 &&
    value.b.reserved.length === 0 &&
    value.pending === 0
  );
}
function stockCount(value) {
  return {
    group: value.group,
    paired: value.paired.length,
    pending: value.pending,
  };
}
function group(value) {
  return value.group;
}
async function front(path, body) {
  const response = await fetch(scope.router_url + path, {
    method: body ? "POST" : "GET",
    headers: {
      "content-type": "application/json",
      "x-router-ab-internal-service-auth": gateway,
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(60000),
  });
  assert.equal(response.status, 200, await response.clone().text());
  return response.json();
}
async function inventory(role, key) {
  const url = new URL(scope.router_url);
  const prefix = scope.prefix + "-front.";
  assert.ok(url.hostname.startsWith(prefix));
  url.hostname =
    scope.prefix + "-" + role + "." + url.hostname.slice(prefix.length);
  url.pathname = "/router-ab/ml-dsa/role";
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-router-ab-internal-service-auth": internal,
    },
    body: JSON.stringify({
      command: "inventory",
      key,
      target: 16,
      ready_until_ms: Date.now() + 30000,
    }),
    signal: AbortSignal.timeout(60000),
  });
  assert.equal(response.status, 200, await response.clone().text());
  return response.json();
}
