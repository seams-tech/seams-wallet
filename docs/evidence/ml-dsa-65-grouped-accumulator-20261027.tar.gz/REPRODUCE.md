# Offline replay

Run these commands from the extracted archive:

```sh
python3 source/tools/ml-dsa-investigation/research/collect_worker_traces.py hosted/a-raw.jsonl hosted/b-raw.jsonl normalized.json --router hosted/router-raw.jsonl --preparer-a hosted/preparer-a-raw.jsonl --preparer-b hosted/preparer-b-raw.jsonl --preparer-a-secondary hosted/preparer-a-secondary-raw.jsonl --preparer-b-secondary hosted/preparer-b-secondary-raw.jsonl
python3 source/tools/ml-dsa-investigation/research/summarize_producer_variation.py hosted/traces.json replay.json windows/baseline-1/result.json windows/candidate-1/result.json windows/baseline-2/result.json
node verify-signatures-offline.mjs
```

Compare replay.json with final-profiles.json. Compare normalized records with hosted/traces.json; normalization records its current creation time.
The signatures require a Node/OpenSSL build that supports ML-DSA. The verifier also rejects altered messages.
The complete paired publication IDs equal the final ready IDs. Retired IDs never reappear.
Inventory polling runs every five seconds. Publication checkpoints separate this detection lag from completion.
Producer invocation CPU excludes dispatch, Router, and pool-actor CPU.

The source base is cc18f24e505f3dd2d168859c419b392436d88a35 on ml-dsa.
grouped-loop-variant.patch is the rejected v1 measured on Workers.
rejected-grouped-unrolled.patch is the rejected v2, measured only in Node. It includes dependency changes.
Apply either patch separately to that source base in an isolated checkout to repeat its encoder screen.
measured-run-encoding-screen.py records the exact script used for the quiet v1 and v2 screens.
The retained tool removes the unused experimental zeroize dependency after production restoration.
Build A and B with scripts/build-strict-worker.sh under crates/router-ab-cloudflare, selecting ml-dsa.
Use the repository's durable Worker E2E with the resulting build root for complete lifecycle checks.

Local and native evidence intentionally contains deterministic disposable test seeds and ordinary test key exports.
No production wallet or account key participates. No private benchmark credentials or encrypted fixture files are included.
Hosted scripts require new credentials and deployments for another live run. All eight campaign Workers were deleted and independently checked absent.
The fresh local baseline fault scenario failed after conservative expiry and cannot support a complete-flow speed comparison.
The first hosted registration returned HTTP 500. Its root cause remains unknown. The successful retry proves no repair.
This retirement/refill screen does not qualify four-wallet signatures per minute or public SDK latency.
