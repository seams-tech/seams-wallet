import {readFile,writeFile,mkdir} from 'node:fs/promises';
const base='/private/tmp/ml-dsa-code-matrix-20261027';
const scope=JSON.parse(await readFile(base+'/hosted-scope.json','utf8'));
const secret=JSON.parse(await readFile(base+'/router-secrets.json','utf8')).ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET;
const folder=base+'/'+(process.argv[2]??'capture');await mkdir(folder,{recursive:true});
for(const worker of scope.workers){
 if(worker.role==='front')continue;
 let cursor=null;const rows=[];
 do{
  const url='https://'+scope.prefix+'-front.n6378056.workers.dev/__benchmark/traces/'+worker.role+(cursor?'?cursor='+encodeURIComponent(cursor):'');
  const response=await fetch(url,{headers:{'x-router-ab-internal-service-auth':secret},signal:AbortSignal.timeout(30000)});
  if(response.status!==200)throw Error('Trace read failed: '+worker.role+' '+response.status);
  const page=await response.json();rows.push(...page.rows);cursor=page.cursor;
 }while(cursor);
 await writeFile(folder+'/'+worker.role+'-raw.jsonl',rows.map(row=>JSON.stringify(row)).join('\n')+'\n');
 console.log(worker.role,rows.length,'events',rows.filter(row=>row.outcome!=='ok').map(row=>row.outcome));
}
