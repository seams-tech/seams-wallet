import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {performance} from 'node:perf_hooks';
const base='/private/tmp/ml-dsa-code-matrix-20261027';
const [name,selection]=process.argv.slice(2);
assert.ok(name&&['native','registered','both'].includes(selection));
const scope=JSON.parse(await readFile(base+'/hosted-scope.json','utf8'));
const secrets=JSON.parse(await readFile(base+'/router-secrets.json','utf8'));
const native=JSON.parse(await readFile(base+'/native-hosted-installation.json','utf8'));
let keys;
switch (selection) {
  case 'native':
    keys = [native.key];
    break;
  case 'registered':
  case 'both': {
    const registration = JSON.parse(await readFile(base + '/registration-1.json', 'utf8'));
    assert.ok(registration.registrationChecksPassed && registration.recoveryPreservesCanonicalKey);
    keys = selection === 'registered' ? [registration.cases.at(-1).key] : [native.key, registration.cases.at(-1).key];
    break;
  }
  default:
    throw new Error('Unknown wallet selection');
}
const folder=base+'/'+name;await mkdir(folder,{recursive:true});
async function roleCall(role,body){
 const response=await fetch('https://'+scope.prefix+'-'+role+'.n6378056.workers.dev/router-ab/ml-dsa/role',{method:'POST',headers:{'content-type':'application/json','x-router-ab-internal-service-auth':secrets.INTERNAL_AUTH},body:JSON.stringify(body),signal:AbortSignal.timeout(30000)});
 assert.equal(response.status,200,'Role command failed: '+role+' '+body.command+' '+response.status);
 return response.json();
}
async function inventory(key){
 const request={command:'inventory',key,target:16,ready_until_ms:Date.now()+30000};
 const [a,b]=await Promise.all([roleCall('a',request),roleCall('b',request)]);
 const paired=a.ready.filter(id=>b.ready.some(peer=>Buffer.from(peer).equals(Buffer.from(id))));
 return {a,b,paired};
}
async function full(keys){
 const started=performance.now();
 while(performance.now()-started<480000){
  const stocks=await Promise.all(keys.map(inventory));
  if(stocks.every(stock=>stock.paired.length===16))return stocks;
  await delay(5000);
 }
 throw Error('Reserve restoration timed out');
}
await full(keys);
const initial=await full(keys);await delay(3000);
const report={scope:'Synthetic retirement/refill cost screen. Native selection uses one wallet and cannot qualify concurrent multi-wallet throughput. Deliberately retired ready pairs are accounted for; no pool capacity increase.',name,keys,policy:scope.policy,startAtMs:Date.now(),retired:[],snapshots:[],passed:false};
await writeFile(folder+'/start.json',JSON.stringify(report,null,2)+'\n');
try{
 for(let index=0;index<keys.length;index++){
  const key=keys[index];const batches=initial[index].paired;
  await Promise.all(['a','b'].map(role=>roleCall(role,{command:'retire_unpaired',key,batches})));
  report.retired.push({key,batches});
 }
 await Promise.all(keys.map(key=>roleCall('a',{command:'wake_refill',key})));
 const started=performance.now();
 while(performance.now()-started<480000){
  const stocks=await Promise.all(keys.map(inventory));
  report.snapshots.push({atMs:Date.now(),paired:stocks.map(stock=>stock.paired.length)});
  if(stocks.every(stock=>stock.paired.length===16)){
   report.finalReady=stocks.map(stock=>stock.paired);report.passed=true;break;
  }
  await delay(5000);
 }
 assert.ok(report.passed,'Reserve restoration timed out');
}finally{
 report.endAtMs=Date.now();await writeFile(folder+'/result.json',JSON.stringify(report,null,2)+'\n');
}
console.log(JSON.stringify({name,passed:report.passed,elapsedMs:report.endAtMs-report.startAtMs,retiredPairs:report.retired.reduce((sum,row)=>sum+row.batches.length,0)}));
