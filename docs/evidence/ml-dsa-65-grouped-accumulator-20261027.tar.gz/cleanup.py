import concurrent.futures
import json
import subprocess
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
scope = json.loads((base / 'hosted-scope.json').read_text())
assert scope['prefix'] == 'ml-dsa-matrix-1027-ed4409'
assert {worker['role'] for worker in scope['workers']} == {
    'router', 'a', 'b', 'preparer-a', 'preparer-b',
    'preparer-a-secondary', 'preparer-b-secondary', 'front',
}
wrangler = str(root / 'node_modules/.bin/wrangler')


def remove(worker):
    role = worker['role']
    name = worker['name']
    assert name == scope['prefix'] + '-' + role
    config = base / (role + '.json')
    assert json.loads(config.read_text())['name'] == name
    attempts = []
    for attempt in range(2):
        result = subprocess.run(
            [wrangler, 'delete', name, '--config', str(config), '--force'],
            cwd=root, capture_output=True, text=True,
        )
        text = result.stdout + result.stderr
        (base / f'cleanup-{role}-{attempt + 1}.log').write_text(text)
        attempts.append({'attempt': attempt + 1, 'exit_code': result.returncode})
        if result.returncode == 0:
            break
        if '10013' not in text:
            break
    return {'role': role, 'name': name, 'attempts': attempts,
            'delete_exit_code': result.returncode}


def absent(worker):
    role = worker['role']
    result = subprocess.run(
        [wrangler, 'deployments', 'list', '--config', str(base / (role + '.json')), '--json'],
        cwd=root, capture_output=True, text=True,
    )
    text = result.stdout + result.stderr
    (base / ('absence-' + role + '.log')).write_text(text)
    return {'role': role, 'name': worker['name'], 'exit_code': result.returncode,
            'confirmed_absent': result.returncode != 0 and '10007' in text}


removed = [remove(worker) for worker in scope['workers']]
report = {'workers': removed,
          'all_deleted': all(row['delete_exit_code'] == 0 for row in removed),
          'd1_databases_created': 0, 'r2_buckets_created': 0}
(base / 'cleanup.json').write_text(json.dumps(report, indent=2) + '\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    absence = list(executor.map(absent, scope['workers']))
report['independent_absence_checks'] = absence
report['all_absent'] = all(row['confirmed_absent'] for row in absence)
(base / 'cleanup.json').write_text(json.dumps(report, indent=2) + '\n')
assert report['all_deleted'] and report['all_absent']
print(json.dumps({'all_deleted': True, 'all_absent': True, 'workers': len(removed)}))
