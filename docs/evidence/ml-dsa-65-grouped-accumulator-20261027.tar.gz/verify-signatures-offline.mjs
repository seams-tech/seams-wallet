import assert from 'node:assert/strict';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const evidence = JSON.parse(await readFile(new URL('./grouped-hosted-signatures.json', import.meta.url), 'utf8'));
assert.equal(evidence.passed, true);
for (const item of evidence.cases) {
  const bytes = Buffer.from(item.publicKey);
  assert.ok(createHash('sha256').update(bytes).digest().equals(Buffer.from(item.key.public_key_digest)));
  const key = createPublicKey({
    key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes]),
    type: 'spki',
    format: 'der',
  });
  const message = Buffer.from(item.message);
  const signature = Buffer.from(item.result.operation.signature);
  assert.equal(verify(null, message, key, signature), true);
  const altered = Buffer.from(message);
  altered[0] ^= 1;
  assert.equal(verify(null, altered, key, signature), false);
}
console.log(JSON.stringify({
  verifiedSignatures: evidence.cases.length,
  alteredMessagesRejected: true,
  node: process.version,
  openssl: process.versions.openssl,
}));
