# Independent review

Reviewer: `/root/review_producer_measurements`. Read-only review on October 27, 2026.

Rejecting the grouped accumulator is supported. No correctness or material-accounting failure appears in the three qualified windows.
The reviewer independently reproduces the trace hash, exact windows, counts, summaries, and CPU totals from all 5,041 records.

| Arm | Paired producer CPU | All producer CPU | All captured invocation CPU | Last paired publication | Client restoration |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline 1 | 147,130 ms | 147,210 ms | 153,932 ms | 93.304 s | 94.522 s |
| Candidate | 152,518 ms | 152,596 ms | 158,574 ms | 91.480 s | 95.848 s |
| Baseline 2 | 144,925 ms | 145,001 ms | 150,961 ms | 86.893 s | 89.804 s |

All captured invocation CPU includes benchmark inventory traffic, Router CPU, and pool/controller CPU.
Candidate CPU exceeds both controls. Its publication falls between the controls.
Client detection delays are 1.218, 4.368, and 2.911 seconds. Client restoration alone cannot establish a publication gain.

Every producer event matches its arm receipt and provider deployment history.
Online A remains `01478d5f…`, online B `10220a5c…`, and Router `fde55fde…` throughout.
Each arm runs eight jobs on each physical pair with the intended primary/secondary routing.
Candidate entries import the frozen candidate-build binaries. The later unbuilt unroll has no hosted claim.
Candidate record 4843 contains job `e1af9b400b9b136c47946fa66e59e61235ed6899c9477604dcece8b58322e86d`, matching its A receipt.

Each arm publishes exactly thirty-two unique fresh pairs, equal to final paired ready sets at both participants.
Retired IDs never return. Every publication finishes inside its window.
Policy retains thirty-two candidates per wallet, a sixteen-candidate admission minimum, four-candidate preparation, two-at-once consumption, and two preparation slots.

Each job sends 3,967,488 bytes from A and receives 1,434,560 bytes, with 556 pending events.
B has reverse byte totals and 1,558 pending events.
Observed correlation-stage Wasm memory remains 94,502,912 bytes for A and 94,371,840 for B.
Those readings exclude transient peaks and JavaScript memory.

Qualified windows contain no exception, load shedding, truncated record, or unsuccessful cryptographic invocation.
Canceled alarm/control events remain counted.
No outside-start invocation overlaps a window using either reported wall intervals or retained event timestamps.
The full capture contains three unsuccessful invocations before the first window:

- Record 76: A registration actor exceeded wall time at 1793103135011, version `38fd527c…`, 46 ms CPU.
- Record 3098: Router `/control` exception at 1793104248149, call `f1209f1a25d80b8c6115a15100000025`.
- Record 3299: Router `/control` exception at 1793104366927, call `75c7261cc3257f2bbe229b7400000026`.

The full capture contains zero truncated records. Failed setup records must remain archived.

Both candidate signatures pass independent standard OpenSSL verification, public-key digest checks, and altered-message rejection.
Native operation `a17d8be9…` takes 8.51 seconds and consumes four pairs.
Recovered operation `a0fb961f…` takes 1.83 seconds and consumes one pair.
A/B take sequences match. All five pairs come from the candidate window's fresh published reserve.

The experiment supports rejection without attributing the result to a Cloudflare cause.
It does not qualify signature throughput, public SDK latency, or the preparation targets.
The local encoder gain remains a component result. No source files were changed by the reviewer.
