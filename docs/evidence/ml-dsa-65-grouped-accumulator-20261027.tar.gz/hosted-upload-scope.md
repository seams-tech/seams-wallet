# Producer profiling upload scope

Compare the grouped public-matrix accumulator with the committed baseline. Only the four producer Workers change between timed arms. Controllers, Router, and signing participants stay fixed. No production wallets or resources.

Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.
A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.
Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.
All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-matrix-1027-ed4409-router | 14e7eac2d4c5212acc53fd680093d8c18e224b9511d5f3f0d0aae0cd06d070af |
| ml-dsa-matrix-1027-ed4409-a | b3692c033734c1ddb1261147638a52daa25e89973bed4b914411af678ddee87b |
| ml-dsa-matrix-1027-ed4409-b | a77a2f5b2560fe52a521157cf34a5610567826707f4ed2886027e3352539b5dc |
| ml-dsa-matrix-1027-ed4409-preparer-a | b3692c033734c1ddb1261147638a52daa25e89973bed4b914411af678ddee87b |
| ml-dsa-matrix-1027-ed4409-preparer-b | a77a2f5b2560fe52a521157cf34a5610567826707f4ed2886027e3352539b5dc |
| ml-dsa-matrix-1027-ed4409-preparer-a-secondary | b3692c033734c1ddb1261147638a52daa25e89973bed4b914411af678ddee87b |
| ml-dsa-matrix-1027-ed4409-preparer-b-secondary | a77a2f5b2560fe52a521157cf34a5610567826707f4ed2886027e3352539b5dc |
| ml-dsa-matrix-1027-ed4409-front | 14e7eac2d4c5212acc53fd680093d8c18e224b9511d5f3f0d0aae0cd06d070af |
