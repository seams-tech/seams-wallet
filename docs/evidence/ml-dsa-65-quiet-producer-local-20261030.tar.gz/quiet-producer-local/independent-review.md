# Independent review of the quiet producer instrument

The independent reviewer checked the local raw artifacts and instrument sources.
Three signatures verify and three altered messages fail verification.
All eighteen public samples match the retained references.
The B guard refusal and later idle probe share the real preparation's Rust module identity.
No direct secret exposure was found in this focused review.

The review identified these limitations and required controls:

1. The AES probe encrypts a bulk buffer. Production conversion repeatedly uses batches of sixteen at A and eight at B.
   Label this probe bulk AES calibration. Match those batches before attributing private AES cost.
2. The live block runner proves publication and settlement, rather than timing qualification.
   Check final complete invocations for versions, exceptions, truncation, duplicate starts, and extra unselected work before applying the ratio gate.
3. Validate distinct authoritative service groups before retiring material for a two-wallet overlap block.
4. Wasm exposes a thirty-two-bit checksum. The independent reference exposes a full ciphertext hash.
   Checksum agreement does not establish a full-byte comparison of Wasm output.
5. Wasm allocation excludes JavaScript heap and native memory.

The plan and report retain these limits. The block runner now checks distinct groups before mutation.
The final-capture qualifier implements the requested execution checks and passes an existing real two-job hosted record.
The diagnostic source remains an isolated test copy. No production cryptographic source changes are retained.
Ordinary hosted controls still require approval for the eight new Worker destinations and fresh test credentials.
