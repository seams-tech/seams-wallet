import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';

const root = '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa';
const base = '/private/tmp/ml-dsa-quiet-producer-20261030';
const require = createRequire(root + '/package.json');
const { Miniflare } = require('miniflare');
const events = [];
const artifact = { scope: 'Local real workerd instrument validation. This is not hosted performance.',
  samples: [], rejectedRequests: [], passed: false };
const workers = [];
for (const role of ['a', 'b']) {
  const worker = {
    name: 'preparer-' + role, modules: true, modulesRoot: base,
    scriptPath: base + '/preparer-' + role + '-entry.mjs',
    modulesRules: [{ type: 'ESModule', include: ['**/*.js', '**/*.mjs'] },
      { type: 'CompiledWasm', include: ['**/*.wasm'] }],
    compatibilityDate: '2026-06-12',
    bindings: { INTERNAL_AUTH: 'public-local-control',
      ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING: 'INTERNAL_AUTH' },
  };
  if (role === 'a') {
    worker.durableObjects = { PRODUCER: { className: 'RouterAbMlDsaProducerDurableObject', useSQLite: true } };
    worker.serviceBindings = { DERIVER_B: 'preparer-b' };
  }
  workers.push(worker);
}
const runtime = new Miniflare({ workers, handleRuntimeStdio });

function handleRuntimeStdio(stdout, stderr) {
  createInterface({ input: stdout }).on('line', captureLine);
  createInterface({ input: stderr }).on('line', captureLine);
}

function captureLine(message) {
  events.push(String(message));
}

function nextWord(state) {
  state.value ^= state.value << 13;
  state.value ^= state.value >>> 17;
  state.value ^= state.value << 5;
  return state.value >>> 0;
}

function expectedAes(seed) {
  const data = Buffer.alloc(16 + 262144 * 16);
  const state = { value: seed };
  for (let offset = 0; offset < data.length; offset += 4) data.writeUInt32LE(nextWord(state), offset);
  const cipher = createCipheriv('aes-128-ecb', data.subarray(0, 16), null);
  cipher.setAutoPadding(false);
  const output = Buffer.concat([cipher.update(data.subarray(16)), cipher.final()]);
  let checksum = 0;
  for (const byte of output) checksum = (Math.imul(checksum, 31) + byte) >>> 0;
  return { checksum, fullOutputSha256: createHash('sha256').update(output).digest('hex') };
}

async function request(path, body, secret = 'public-local-control') {
  const namespace = await runtime.getDurableObjectNamespace('PRODUCER', 'preparer-a');
  const producer = namespace.get(namespace.idFromName('ml-dsa-producer-v1-group-1'));
  return producer.fetch('https://probe' + path, { method: 'POST', headers: {
    'content-type': 'application/json', 'x-router-ab-internal-service-auth': secret,
    'x-ml-dsa-request-id': 'public-local-check',
  }, body: typeof body === 'string' ? body : JSON.stringify(body) });
}

try {
  await runtime.ready;
  for (const [body, secret, expected] of [
    [{ kind: 1, seed: 1 }, 'invalid-local-control', 403],
    [{ kind: 1, seed: 2 }, 'public-local-control', 400],
    [{ kind: 99, seed: 1 }, 'public-local-control', 400],
    [{ kind: 1, seed: 1, payload: 'unexpected' }, 'public-local-control', 400],
    ['{', 'public-local-control', 400],
    ['x'.repeat(257), 'public-local-control', 400],
  ]) {
    const response = await request('/__benchmark/calibration', body, secret);
    assert.equal(response.status, expected);
    artifact.rejectedRequests.push({ expected, actual: response.status });
    await response.arrayBuffer();
  }
  const references = [];
  for (const seed of [1, 17, 65537]) {
    const aes = expectedAes(seed);
    references.push({ seed, aes });
    for (const kind of [0, 1, 2]) {
      const results = [];
      for (const role of ['a', 'b']) {
        const response = await request('/__benchmark/calibration' + (role === 'a' ? '' : '-peer'), { kind, seed });
        assert.equal(response.status, 200, await response.clone().text());
        const result = await response.json();
        assert.equal(result.active_crypto, 0);
        assert.ok(result.memory_bytes < 128 * 1024 * 1024);
        assert.ok(result.module_instance);
        assert.equal(result.kind, kind);
        assert.equal(result.seed, seed);
        if (kind === 0) assert.equal(result.checksum, seed);
        if (kind === 1) assert.equal(result.checksum, aes.checksum);
        artifact.samples.push({ role, result });
        results.push(result);
      }
      assert.equal(results[0].checksum, results[1].checksum);
      assert.notEqual(results[0].module_instance, results[1].module_instance);
    }
  }
  for (const role of ['a', 'b']) {
    const samples = artifact.samples.filter(belongsTo.bind(null, role));
    assert.equal(new Set(samples.map(coreIdentity)).size, 1);
  }
  const native = new Map();
  for (const line of (await readFile(base + '/native-reference.txt', 'utf8')).trim().split('\n')) {
    const [kind, seed, checksum] = line.split(' ').map(Number);
    native.set(kind + '/' + seed, checksum);
  }
  for (const sample of artifact.samples) {
    const result = sample.result;
    assert.equal(result.checksum, native.get(result.kind + '/' + result.seed));
  }
  artifact.nativeReferenceMatched = true;
  artifact.reference = references;
  artifact.builds = {};
  for (const role of ['a', 'b']) artifact.builds[role] = createHash('sha256')
    .update(await readFile(base + '/probe-build/deriver-' + role + '/index_bg.wasm')).digest('hex');
  artifact.passed = true;
} finally {
  await runtime.dispose();
  artifact.events = events;
  await writeFile(base + '/local-calibration.json', JSON.stringify(artifact, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: artifact.passed, samples: artifact.samples.length,
  rejectedRequests: artifact.rejectedRequests.length }));

function belongsTo(role, sample) { return sample.role === role; }
function coreIdentity(sample) { return sample.result.module_instance + '/' + sample.result.core_epoch; }
