from pathlib import Path

root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
base = Path(__file__).resolve().parent
source = (root / 'tests/e2e/ml-dsa-service-groups.e2e.mjs').read_text()
source = source.replace("const root = resolve(import.meta.dirname, '../..');", f'const root = {str(root)!r};')
needle = "  result.serviceBindings = { DERIVER_B: preparing ? 'preparer-b' : 'b' };\n"
assert source.count(needle) == 1
source = source.replace(needle, needle + f"  if (preparing) result.scriptPath = {str(base)!r} + '/preparer-' + role + '-entry.mjs';\n")
needle = '  await Promise.all([retirePairGroup(original.key), retirePairGroup(added.key)]);\n'
assert source.count(needle) == 1
source = source.replace(needle, needle + '  await verifyActiveProbeRefused(parallelStart);\n')
needle = '  observations.preparationResources = {\n'
assert source.count(needle) == 1
source = source.replace(needle, '  await verifyIdleProbes();\n' + needle)
source += '''
async function verifyActiveProbeRefused(start) {
  const deadline = Date.now() + 30000;
  const attempts = [];
  while (Date.now() < deadline) {
    const active = events.slice(start).find(peerCryptoStarted);
    if (active) {
      const peer = clients.workers.get('preparer-b');
      const response = await peer.fetch('https://probe/__benchmark/calibration', {
        method: 'POST', headers: { 'content-type': 'application/json',
          'x-router-ab-internal-service-auth': auth }, body: JSON.stringify({ kind: 2, seed: 1 }),
      });
      attempts.push({ status: response.status, observedAtMs: Date.now(),
        preparationModule: active.module_instance });
      if (response.status === 409) {
        await response.arrayBuffer();
        observations.probeRefusedDuringPreparation = { passed: true, attempts };
        return;
      }
      assert.equal(response.status, 200);
      attempts.at(-1).result = await response.json();
    }
    await delay(50);
  }
  observations.probeRefusedDuringPreparation = { passed: false, attempts };
  assert.fail('The local core probe was not observed refusing live preparation');
}
function peerCryptoStarted(event) {
  return event.event === 'ml_dsa_preparation_stage_v1' && event.role === 'b' && event.stage === 'crypto_started';
}
async function verifyIdleProbes() {
  const response = await clients.workers.get('preparer-b').fetch('https://probe/__benchmark/calibration', {
    method: 'POST', headers: { 'content-type': 'application/json',
      'x-router-ab-internal-service-auth': auth }, body: JSON.stringify({ kind: 2, seed: 1 }),
  });
  assert.equal(response.status, 200);
  const probe = await response.json();
  assert.equal(probe.active_crypto, 0);
  assert.ok(probe.memory_bytes < 128 * 1024 * 1024);
  const sameInstance = events.filter(matchesProbeModule.bind(null, probe.module_instance));
  assert.ok(sameInstance.some(cryptoStarted), 'Probe did not share a real preparation module');
  observations.postPreparationProbe = probe;
}
function matchesProbeModule(identity, event) { return event.module_instance === identity; }
'''
(base / 'local-protocol.e2e.mjs').write_text(source)
link = base / 'node_modules'
if not link.exists():
    link.symlink_to(root / 'node_modules', target_is_directory=True)
print(base / 'local-protocol.e2e.mjs')
