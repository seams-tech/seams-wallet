import hashlib
import json
import shutil
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    stage = BASE / 'public-evidence' / 'quiet-producer-local'
    stage.mkdir(parents=True, exist_ok=True)
    names = [
        'prepare-source.py', 'public-calibration.rs', 'calibration-export.rs',
        'calibration.mjs', 'calibration-a.mjs', 'calibration-b.mjs',
        'preparer-a-entry.mjs', 'preparer-b-entry.mjs',
        'prepare-local-e2e.py', 'local-protocol.e2e.mjs', 'local-calibration.mjs',
        'local-protocol.json', 'local-protocol.log', 'local-calibration.json',
        'native-reference.txt', 'source.json', 'instrumentation.patch',
        'build-probe-a.log', 'build-probe-a-second.log', 'build-probe-b.log',
        'measurement-plan.md', 'quiet-block.mjs', 'calibration-route.mjs',
        'qualify-block.py', 'independent-review.md',
        'front.mjs', 'load-worker.mjs', 'prepare-hosted.py', 'deploy-preparers.py',
        'fleet.py', 'register.py', 'cleanup.py', 'replay.mjs', 'package-local.py',
        'dry-run/receipts.json', 'preparer-deployments/local-dry-run/receipts.json',
        'historical-qualification-control/result.json',
        'historical-qualification-control/versions.json',
        'historical-qualification-control/raw.json',
        'historical-qualification-control/timing-qualification.json',
        'historical-qualification-control/replay.log',
    ]
    private_values = []
    for path in BASE.glob('*-secrets.json'):
        for value in json.loads(path.read_text()).values():
            private_values.append(value.encode())
    for path in (BASE / 'hosted-keys').glob('*-kek'):
        private_values.append(path.read_text().strip().encode())
    members = []
    for name in names:
        original = BASE / name
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = original.read_bytes()
        assert not any(value and value in data for value in private_values), 'Private credential in ' + name
        shutil.copy2(original, destination)
        members.append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
    manifest = {'schema': 'ml-dsa-quiet-producer-local-v1', 'files': members,
                'scope': 'Local instrument correctness and lifecycle evidence. No hosted performance claim.',
                'private_credential_matches': 0}
    (stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = BASE / 'ml-dsa-65-quiet-producer-local-20261030.tar.gz'
    with tarfile.open(archive, 'w:gz') as output:
        output.add(stage, arcname=stage.name)
    calibration = json.loads((BASE / 'local-calibration.json').read_text())
    lifecycle = json.loads((BASE / 'local-protocol.json').read_text())
    evidence = {'schema': 'ml-dsa-quiet-producer-local-summary-v1',
                'revision': json.loads((BASE / 'source.json').read_text())['revision'],
                'hosted_execution': 'awaiting_new_destination_credential_approval',
                'production_cryptographic_source_changed': False,
                'public_samples_matched': len(calibration['samples']),
                'request_refusals': len(calibration['rejectedRequests']),
                'standard_signatures': len(lifecycle['signatures']),
                'live_probe_refused': lifecycle['probeRefusedDuringPreparation']['passed'],
                'post_preparation_probe': lifecycle['postPreparationProbe'],
                'resources': lifecycle['preparationResources'],
                'lifecycle_assertions': lifecycle['assertions'],
                'archive': {'name': archive.name, 'bytes': archive.stat().st_size,
                            'sha256': digest(archive.read_bytes()), 'files': len(members) + 1},
                'private_credential_matches': 0,
                'replay': 'Extract the archive and run node quiet-producer-local/replay.mjs.',
                'limits': ['No new hosted throughput or speedup measurement.',
                           'The AES probe is bulk calibration; production uses smaller batches.',
                           'Wasm returns a 32-bit checksum; full ciphertext hashes belong to the reference.',
                           'Native encoder agreement uses the same pinned implementation.',
                           'Wasm allocation excludes JavaScript heap and native memory.',
                           'Local workerd timing does not predict hosted latency.']}
    (BASE / 'ml-dsa-65-quiet-producer-local-20261030.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'files': len(members) + 1}))


if __name__ == '__main__':
    main()
