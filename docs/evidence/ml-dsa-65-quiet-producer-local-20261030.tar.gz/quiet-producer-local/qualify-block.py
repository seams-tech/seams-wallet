import argparse
import hashlib
import json
from pathlib import Path


def events(row):
    return [json.loads(message) for log in row.get('logs', []) for message in log.get('message', [])]


def overlaps(row, start, end):
    times = [row['eventTimestamp'], row['eventTimestamp'] + row['wallTime']]
    for log in row.get('logs', []):
        if isinstance(log.get('timestamp'), (int, float)):
            times.append(log['timestamp'])
    for event in events(row):
        for name in ['at_ms', 'resource_observed_at_ms']:
            if isinstance(event.get(name), (int, float)):
                times.append(event[name])
    return min(times) <= end and max(times) >= start


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('block')
    parser.add_argument('versions')
    parser.add_argument('final_traces')
    args = parser.parse_args()
    block = Path(args.block)
    result = json.loads((block / 'result.json').read_text())
    assert result['passed'] is True
    receipts = json.loads(Path(args.versions).read_text())
    versions = {row['worker']: row['version'] for row in receipts}
    assert all(versions.values())
    raw = json.loads(Path(args.final_traces).read_text())
    unique = {}
    for row in raw:
        digest = hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()
        unique[digest] = row
    rows = list(unique.values())
    selected = {bytes(job['batch']).hex(): job for job in result['jobs']}
    seen = {}
    for row in rows:
        starts = [event for event in events(row) if event.get('event') == 'ml_dsa_preparation_stage_v1'
                  and event.get('stage') == 'crypto_started']
        for event in starts:
            job_id = event['job']
            if job_id not in selected:
                assert not overlaps(row, result['startedAtMs'], result['endedAtMs']), 'Unselected cryptographic work overlaps this block'
                continue
            assert len(starts) == 1, 'More than one cryptographic job in a measured invocation'
            assert row['scriptVersion']['id'] == versions[row['scriptName']], 'Unexpected measured version'
            assert row['outcome'] == 'ok', 'Failed measured invocation'
            assert row['truncated'] is False, 'Unknown or truncated measured invocation'
            assert row.get('exceptions') == [], 'Measured invocation has exceptions'
            assert isinstance(row['cpuTime'], (int, float)) and row['cpuTime'] > 0
            assert isinstance(row['wallTime'], (int, float)) and row['wallTime'] >= 0
            role = event['role']
            assert role in ['a', 'b']
            identity = (job_id, role)
            assert identity not in seen, 'Duplicate crypto execution for the selected role/job'
            own = [entry for entry in events(row) if entry.get('event') == 'ml_dsa_preparation_stage_v1'
                   and entry.get('job') == job_id and entry.get('role') == role]
            assert sum(entry['stage'] == 'crypto_completed' for entry in own) == 1
            expected = {job_id, hashlib.sha256(b'seams/ml-dsa/preparation-second-pair/v1' + bytes.fromhex(job_id)).hexdigest()}
            published = [entry['batch'] for entry in own if entry['stage'] == 'published']
            assert len(published) == 2 and set(published) == expected
            modules = {entry['module_instance'] for entry in own}
            assert len(modules) == 1
            transport = [entry for entry in events(row) if entry.get('event') == 'ml_dsa_preparation_transport_v1'
                         and entry.get('job') == job_id and entry.get('role') == role]
            assert len(transport) == 1
            seen[identity] = {'worker': row['scriptName'], 'version': row['scriptVersion']['id'],
                              'cpu_ms': row['cpuTime'], 'wall_ms': row['wallTime'],
                              'module_instance': next(iter(modules)), 'transport': transport[0]}
    jobs = []
    for job_id, job in selected.items():
        a, b = seen[(job_id, 'a')], seen[(job_id, 'b')]
        assert a['transport']['sent_bytes'] == b['transport']['received_bytes']
        assert b['transport']['sent_bytes'] == a['transport']['received_bytes']
        assert job['groups'] == 'two'
        jobs.append({'job': job_id, 'a': a, 'b': b, 'candidates': 4,
                     'paired_cpu_ms': a['cpu_ms'] + b['cpu_ms']})
    qualified = {'passed': True, 'timing_qualified': True, 'label': result['label'], 'jobs': jobs,
                 'final_trace_sha256': hashlib.sha256(Path(args.final_traces).read_bytes()).hexdigest(),
                 'scope': 'Whole matching crypto-containing invocations. No isolated kernel CPU claim.'}
    (block / 'timing-qualification.json').write_text(json.dumps(qualified, indent=2) + '\n')
    print(json.dumps({'passed': True, 'jobs': len(jobs), 'label': result['label']}))


if __name__ == '__main__':
    main()
