import assert from 'node:assert/strict';
import { createCipheriv, createHash, createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';

const base = import.meta.dirname;
const manifest = JSON.parse(await readFile(base + '/manifest.json', 'utf8'));
for (const member of manifest.files) {
  const bytes = await readFile(base + '/' + member.path);
  assert.equal(bytes.length, member.bytes, member.path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), member.sha256, member.path);
}
const calibration = JSON.parse(await readFile(base + '/local-calibration.json', 'utf8'));
assert.equal(calibration.passed, true);
assert.equal(calibration.nativeReferenceMatched, true);
assert.equal(calibration.samples.length, 18);
const native = new Map();
for (const line of (await readFile(base + '/native-reference.txt', 'utf8')).trim().split('\n')) {
  const [kind, seed, checksum] = line.split(' ').map(Number);
  native.set(kind + '/' + seed, checksum);
}
for (const sample of calibration.samples) {
  const result = sample.result;
  assert.equal(result.checksum, native.get(result.kind + '/' + result.seed));
  assert.equal(result.active_crypto, 0);
  assert.ok(result.memory_bytes < 128 * 1024 * 1024);
}
for (const reference of calibration.reference) {
  const aes = expectedAes(reference.seed);
  assert.equal(aes.checksum, reference.aes.checksum);
  assert.equal(aes.fullOutputSha256, reference.aes.fullOutputSha256);
}
const lifecycle = JSON.parse(await readFile(base + '/local-protocol.json', 'utf8'));
assert.equal(lifecycle.passed, true);
assert.equal(lifecycle.initialPolicy.candidate_group_size, 2);
assert.equal(lifecycle.initialPolicy.preparation_group_size, 4);
assert.equal(lifecycle.initialPolicy.refill_target_batches, 16);
assert.equal(lifecycle.initialPolicy.minimum_ready_batches, 8);
assert.equal(lifecycle.probeRefusedDuringPreparation.passed, true);
assert.ok(lifecycle.probeRefusedDuringPreparation.attempts.some(refused));
const probe = lifecycle.postPreparationProbe;
assert.equal(probe.active_crypto, 0);
assert.equal(probe.checksum, native.get('2/1'));
assert.ok(lifecycle.events.some(probeSharesProduction.bind(null, probe.module_instance)));
assert.equal(lifecycle.preparationResources.maximumActiveCrypto, 1);
assert.ok(lifecycle.preparationResources.maximumWasmBytes < 128 * 1024 * 1024);
let signatures = 0;
for (const sample of lifecycle.signatures) {
  const key = createPublicKey({ format: 'der', type: 'spki', key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'),
    Buffer.from(sample.publicKeyHex, 'hex'),
  ]) });
  const message = Buffer.from(sample.messageHex, 'hex');
  const signature = Buffer.from(sample.signatureHex, 'hex');
  assert.equal(verify(null, message, key, signature), true);
  assert.equal(verify(null, Buffer.concat([message, Buffer.from([1])]), key, signature), false);
  signatures += 1;
}
assert.equal(signatures, 3);
for (const [assertion, passed] of Object.entries(lifecycle.assertions)) {
  assert.ok(passed, assertion);
}
execFileSync('python3', [base + '/qualify-block.py', base + '/historical-qualification-control',
  base + '/historical-qualification-control/versions.json', base + '/historical-qualification-control/raw.json'],
  { stdio: 'pipe' });
console.log(JSON.stringify({ passed: true, checkedFiles: manifest.files.length,
  publicSamples: calibration.samples.length, signatures, alteredMessagesRejected: signatures,
  scope: 'Offline replay of retained local workerd evidence. Hosted performance remains unmeasured.' }));

function refused(attempt) { return attempt.status === 409; }
function probeSharesProduction(identity, event) {
  return event.event === 'ml_dsa_preparation_stage_v1' && event.stage === 'crypto_started' &&
    event.module_instance === identity;
}
function nextWord(state) {
  state.value ^= state.value << 13;
  state.value ^= state.value >>> 17;
  state.value ^= state.value << 5;
  return state.value >>> 0;
}
function expectedAes(seed) {
  const data = Buffer.alloc(16 + 262144 * 16);
  const state = { value: seed };
  for (let offset = 0; offset < data.length; offset += 4) data.writeUInt32LE(nextWord(state), offset);
  const cipher = createCipheriv('aes-128-ecb', data.subarray(0, 16), null);
  cipher.setAutoPadding(false);
  const output = Buffer.concat([cipher.update(data.subarray(16)), cipher.final()]);
  let checksum = 0;
  for (const byte of output) checksum = (Math.imul(checksum, 31) + byte) >>> 0;
  return { checksum, fullOutputSha256: createHash('sha256').update(output).digest('hex') };
}
