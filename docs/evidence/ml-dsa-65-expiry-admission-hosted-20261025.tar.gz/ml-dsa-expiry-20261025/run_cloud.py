"""Run bounded durable cloud loads after the exact deployment is released."""
import json
import hashlib
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
SCOPE = json.loads((BASE / 'scope.json').read_text())
ROOT = Path(SCOPE['root'])
CONTROL = ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs']
ENV = dict(os.environ,
    ML_DSA_TEST_BUILD_ROOT=SCOPE['build_root'],
    ML_DSA_REGISTRATION_ROUTER_URL=SCOPE['router_url'],
    ML_DSA_GATEWAY_TOKEN_FILE=str(BASE / 'gateway-token'),
    ML_DSA_TEST_CANDIDATE_GROUP_SIZE='2',
    ML_DSA_TEST_PREPARATION_GROUP_SIZE='4',
    ML_DSA_TEST_COOLDOWN_MS='60000')


def run(arguments, log, environment=ENV):
    with log.open('w') as output:
        result = subprocess.run(arguments, cwd=ROOT, env=environment,
                                stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'Command failed ({result.returncode}); inspect {log}')


def control(action, name, *arguments):
    log = BASE / 'cloud-driver' / f'{name}-{action}.log'
    run(CONTROL + [action, str(BASE), name, *map(str, arguments)], log)


assert (BASE / 'release-receipt.json').exists()
versions = json.loads((BASE / 'versions.json').read_text())
(BASE / 'cloud-driver/versions.json').write_text(json.dumps(versions, indent=2) + '\n')
for cohort in SCOPE['cohorts']:
    count = cohort['wallets']
    name = f'{count}-wallets'
    if (BASE / 'cloud-driver' / name / 'reserve-cycle.json').exists():
        continue
    for index in range(1, count + 1):
        artifact = BASE / f'registration-{index}.json'
        if not artifact.exists():
            print(json.dumps({'stage': 'registration', 'wallet': index}), flush=True)
            environment = dict(ENV, ML_DSA_TEST_WALLET_ID=f"{SCOPE['prefix']}-wallet-{index}")
            run(['node', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs',
                 str(BASE / f'wallet-{index}'), str(artifact)],
                BASE / f'registration-{index}.log', environment)
        registration = json.loads(artifact.read_text())
        assert registration['registrationChecksPassed']
        assert registration['recoveryPreservesCanonicalKey']
        if not registration['functionalPassed']:
            reviews = json.loads((BASE / 'reviewed-setup-failures.json').read_text())
            reviewed = reviews[artifact.name]
            assert reviewed['sha256'] == hashlib.sha256(artifact.read_bytes()).hexdigest()
            assert reviewed['classification'] == 'expected_candidate_exhaustion'
            assert registration['cases'][-1]['initialStockSign']['verified']
            print(json.dumps({'stage': 'retained_setup_exhaustion', 'wallet': index}), flush=True)
        assert registration['policy'] == SCOPE['policy']
    print(json.dumps({'stage': 'initial_reserve', 'wallets': count}), flush=True)
    control('stock', name + '-initial', count, int(time.time() * 1000))
    control('start', name, count, cohort['duration_ms'])
    folder = BASE / 'cloud-driver' / name
    start = json.loads((folder / 'start.json').read_text())
    print(json.dumps({'stage': 'load', 'wallets': count, 'end_at_ms': start['endAtMs']}), flush=True)
    while time.time() * 1000 < start['endAtMs'] + 45_000:
        time.sleep(30)
        control('status', name)
        rows = json.loads((folder / 'progress.json').read_text())
        print(json.dumps({'stage': 'progress', 'wallets': count, 'rows': rows}), flush=True)
        if any(row['error'] is not None for row in rows):
            raise RuntimeError('Durable load driver failed; inspect progress')
    control('collect', name)
    control('traces', name)
    run(['python3', 'tools/ml-dsa-investigation/research/summarize_capacity.py',
         str(folder / 'client.json'), str(folder / 'traces.json'),
         str(BASE / 'scope.json'), str(folder / 'summary.json')], folder / 'summary.log')
    print(json.dumps({'stage': 'restore_reserve', 'wallets': count}), flush=True)
    control('stock', name + '-final', count, start['endAtMs'])
    final = json.loads((BASE / 'cloud-driver' / (name + '-final') / 'stock.json').read_text())
    restoration = max(item['log_timestamp_ms'] for item in final['observations'])
    client = json.loads((folder / 'client.json').read_text())
    cycle = {'scope': 'Finite load and full reserve restoration with unchanged capacity.',
             'start_at_ms': start['startAtMs'], 'restored_at_ms': restoration,
             'verified_signatures': client['successfulSignatures'],
             'cycle_ms': restoration - start['startAtMs'],
             'signatures_per_minute': client['successfulSignatures'] * 60_000 / (restoration - start['startAtMs'])}
    (folder / 'reserve-cycle.json').write_text(json.dumps(cycle, indent=2) + '\n')
    print(json.dumps({'stage': 'complete', 'wallets': count, 'cycle': cycle}), flush=True)
