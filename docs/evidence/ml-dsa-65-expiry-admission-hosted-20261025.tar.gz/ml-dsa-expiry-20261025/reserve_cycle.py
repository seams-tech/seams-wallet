"""Find the first fresh set of full-pool observations after the load cutoff."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
name = sys.argv[1]
folder = BASE / 'cloud-driver' / name
start = json.loads((folder / 'start.json').read_text())
client = json.loads((folder / 'client.json').read_text())
rows = json.loads((BASE / 'cloud-driver' / (name + '-final') / 'traces.json').read_text())['records']
scopes = {(hashlib.sha256(bytes.fromhex(wallet['publicKeyHex'])).hexdigest(), wallet['key']['epoch']) for wallet in client['wallets']}
events = []
for row in rows:
    if row['version'] != client['deploymentVersions'].get(row['role']):
        continue
    for item in row['inventories']:
        at = item['log_timestamp_ms'] or row['event_timestamp_ms']
        key = (item['key'], item['epoch'])
        if key in scopes and at >= start['endAtMs']:
            events.append((at, key, item))
events.sort(key=lambda event: event[0])
latest = {}
restored = None
for at, key, item in events:
    latest[key] = (at, item)
    if len(latest) != len(scopes):
        continue
    full = True
    for observed, snapshot in latest.values():
        paired = set(snapshot['ready_a']) & set(snapshot['ready_b'])
        if len(paired) != client['policy']['refill_target_batches'] or snapshot['reserved_a'] or snapshot['reserved_b'] or at - observed > 45_000:
            full = False
            break
    if full:
        restored = at
        break
assert restored is not None, 'No simultaneous fresh full-reserve observations'
result = {'scope': 'Finite load plus the earliest captured set of full reserve observations, each no older than 45 seconds. Observation delay is included. This is not a maximum-capacity claim.',
          'start_at_ms': start['startAtMs'], 'restored_at_ms': restored,
          'after_load_ms': restored - start['endAtMs'],
          'verified_signatures': client['successfulSignatures'],
          'cycle_ms': restored - start['startAtMs'],
          'signatures_per_minute': client['successfulSignatures'] * 60_000 / (restored - start['startAtMs']),
          'observations': [item for observed, item in latest.values()]}
(folder / 'reserve-cycle.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'observations'}))
