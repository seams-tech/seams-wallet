import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
const base = import.meta.dirname;
let verified = 0;
let alteredMessagesRejected = 0;
function verifySample(publicKeyHex, messageHex, signatureHex) {
  const key = createPublicKey({
    key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), Buffer.from(publicKeyHex, 'hex')]),
    format: 'der', type: 'spki',
  });
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  assert.equal(verify(null, message, key, signature), true);
  verified += 1;
  const altered = Buffer.from(message);
  altered[0] ^= 1;
  assert.equal(verify(null, altered, key, signature), false);
  alteredMessagesRejected += 1;
}
for (let index = 1; index <= 8; index += 1) {
  const registration = JSON.parse(await readFile(join(base, `registration-${index}.json`), 'utf8'));
  for (const sample of registration.cases) {
    if (sample.initialStockSign.verified)
      verifySample(sample.publicKeyHex, sample.initialStockSign.messageHex, sample.initialStockSign.signatureHex);
  }
}
for (const count of [4, 8]) {
  const client = JSON.parse(await readFile(join(base, 'cloud-driver', `${count}-wallets`, 'client.json'), 'utf8'));
  for (const request of client.requests) {
    if (request.verified) verifySample(client.wallets[request.wallet].publicKeyHex, request.messageHex, request.signatureHex);
  }
}
const result = { verified, alteredMessagesRejected, node: process.version, openssl: process.versions.openssl };
await writeFile(join(base, 'signature-verification.json'), JSON.stringify(result, null, 2) + '\n');
console.log(result);
