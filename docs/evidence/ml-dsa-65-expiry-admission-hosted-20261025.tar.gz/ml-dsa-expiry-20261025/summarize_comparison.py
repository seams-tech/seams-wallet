"""Compare finite hosted campaigns without treating initial stock as throughput."""
import json
import statistics
from pathlib import Path

BASE = Path(__file__).resolve().parent
OLD = Path('/private/tmp/ml-dsa-sustained-20261025/cloud-driver')


def load(path):
    return json.loads(path.read_text())


def completed_refills(summary):
    result = []
    for candidates in [2, 4]:
        jobs = [job for job in summary['producer_profiles']['jobs']
                if job['active_wallet'] and job['candidates'] == candidates and job['published_at_ms'] is not None]
        if not jobs:
            continue
        row = {'candidates': candidates, 'completed_jobs': len(jobs)}
        for field in ['a_cpu_ms', 'a_wall_ms', 'b_cpu_ms', 'b_wall_ms']:
            values = [job[field] for job in jobs if job[field] is not None]
            row[field] = {'minimum': min(values), 'median': statistics.median(values), 'maximum': max(values)}
        result.append(row)
    return result


def metrics(client, summary):
    audit = summary['unused_material_audit']
    return {
        'verified_signatures': client['successfulSignatures'],
        'per_wallet': client['successesPerWallet'],
        'successful_http_ms': summary['successful_http_ms'],
        'successful_demand_ms': summary['successful_demand_ms'],
        'under_five_seconds': summary['successful_under_five_seconds'],
        'pending_demands': len(summary['censored_demands']),
        'wait_responses': summary['admission_waits']['by_reason'],
        'demands_with_empty_pool': summary['admission_waits']['demands_with_empty_pool'],
        'empty_pool_wait_ms': summary['admission_waits']['empty_pool_http_and_sleep_ms'],
        'matched_consumed_pairs': summary['distinct_consumed_batches'],
        'unaccounted_pairs': audit['count'],
        'new_unaccounted_pairs': audit['newly_prepared_pairs'],
        'unexpected_early_disappearance': audit['early_disappearances'],
        'ledger_complete': summary['stock_ledger_complete'],
        'capacity_respected': summary['configured_pool_target_respected'],
        'peak_pairs_per_role_wallet': summary['peak_observed_batches_per_role_and_wallet'],
        'trace_coverage_complete': summary['trace_coverage']['complete'],
        'truncated_invocations': summary['trace_coverage']['truncated_invocations'],
        'non_ok_load_invocations': len(summary['service_non_ok_invocations']),
        'producer_profiles': summary['producer_profiles']['profiles'],
        'completed_refills': completed_refills(summary),
        'after_starting_stock': {key: value for key, value in summary['after_starting_stock_disposal_bound'].items() if key != 'pair_bounds'},
    }


def empty_claims(client, rows):
    indexed = {}
    for row in rows:
        if row['role'] == 'router' and row['version'] == client['deploymentVersions']['router']:
            indexed.setdefault(row['http_request'], []).append(row)
    requests = [request for request in client['requests'] if request.get('reason') == 'empty_pool']
    claimed = []
    for request in requests:
        matching = indexed[request['requestId']]
        assert len(matching) == 1
        if any(event['stage'] == 'claimed' for event in matching[0]['admission_stock']):
            claimed.append(request['requestId'])
    return {'empty_pool_responses': len(requests), 'empty_pool_responses_with_claim': len(claimed), 'claimed_request_ids': claimed}


result = {'scope': 'Same pool limits and workloads. Historical baseline; no randomized contemporaneous control. Finite observations do not establish production percentiles or maximum capacity.', 'cohorts': []}
for count, old_name in [(4, 'four-sustained'), (8, 'eight-sustained')]:
    folder = BASE / 'cloud-driver' / f'{count}-wallets'
    if not (folder / 'summary.json').exists():
        continue
    client = load(folder / 'client.json')
    summary = load(folder / 'summary.json')
    old_client = load(OLD / old_name / 'client.json')
    old_summary = load(OLD / old_name / 'summary.json')
    row = {'wallets': count, 'baseline': metrics(old_client, old_summary), 'candidate': metrics(client, summary),
           'admission_preflight': summary['admission_stock'],
           'empty_response_claims': empty_claims(client, load(folder / 'traces.json')['records'])}
    row['admission_preflight'] = {key: value for key, value in row['admission_preflight'].items() if key != 'checks'}
    if (folder / 'reserve-cycle.json').exists():
        row['observed_reserve_cycle'] = load(folder / 'reserve-cycle.json')
    result['cohorts'].append(row)
(BASE / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
