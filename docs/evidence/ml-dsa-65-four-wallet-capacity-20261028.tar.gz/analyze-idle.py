import json
import sys
from pathlib import Path

base = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
control = json.loads((base / 'idle-control.json').read_text())
rows = json.loads((base / 'cloud-driver/idle/traces.json').read_text())['records']
results = []
for case in control['cases']:
    for index, before in enumerate(case['initial']):
        after = case['final'][index]
        initial = {bytes(value).hex() for value in before['paired']}
        retired = {bytes(value).hex() for value in before['paired'][:2]}
        final = {bytes(value).hex() for value in after['paired']}
        assert len(initial) == 16 and len(final) == 16
        assert retired.isdisjoint(final)
        assert initial - retired <= final
        fresh = final - initial
        assert len(fresh) == 2
        candidates = {}
        for row in rows:
            metadata = row['refill_job']
            if metadata and set(metadata['batches']) == fresh:
                candidates[metadata['batch']] = metadata
        assert len(candidates) == 1
        identity, metadata = next(iter(candidates.items()))
        cpu = {}
        wall = {}
        outcomes = {}
        publication = {'a': {}, 'b': {}}
        for row in rows:
            if any(value['job'] == identity for value in row['preparation_transport']):
                assert row['role'] not in cpu
                cpu[row['role']] = row['cpu_ms']
                wall[row['role']] = row['wall_ms']
                outcomes[row['role']] = row['outcome']
            for event in row['preparation_stages']:
                if event['job'] == identity and event['stage'] == 'published':
                    publication[event['role']][event['batch']] = event['at_ms']
        assert set(publication['a']) == fresh and set(publication['b']) == fresh
        assert len(cpu) == 2 and all(outcome == 'ok' for outcome in outcomes.values())
        results.append({'case': case['name'], 'job': identity, 'slot': metadata['producer_slot'],
                        'retired_pairs': sorted(retired), 'fresh_pairs': sorted(fresh),
                        'cpu_ms_by_role': cpu, 'wall_ms_by_role': wall,
                        'both_participants_published': True})
report = {'scope': control['scope'], 'jobs': results, 'passed': True, 'deliberately_retired_candidates': 16,
          'replacement_candidates': 16, 'ledger_balanced': True}
(base / 'idle-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'jobs': [{k: row[k] for k in ['case','slot','cpu_ms_by_role','wall_ms_by_role']} for row in results]}))
