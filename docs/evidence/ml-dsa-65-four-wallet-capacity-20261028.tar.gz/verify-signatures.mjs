import assert from 'node:assert/strict';
import { createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const base = resolve(process.argv[2] ?? import.meta.dirname);
const client = JSON.parse(await readFile(base + '/cloud-driver/sustained/client.json', 'utf8'));
let signatures = 0;
let alteredMessagesRejected = 0;

function publicKey(bytes) {
  return createPublicKey({
    key: Buffer.concat([Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes]),
    format: 'der',
    type: 'spki',
  });
}

function check(messageHex, signatureHex, publicKeyHex) {
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  const key = publicKey(Buffer.from(publicKeyHex, 'hex'));
  assert.equal(signature.length, 3309);
  assert.ok(message.length > 0);
  assert.equal(verify(null, message, key, signature), true);
  const altered = Buffer.from(message);
  altered[0] ^= 0x80;
  assert.equal(verify(null, altered, key, signature), false);
  signatures += 1;
  alteredMessagesRejected += 1;
}

for (const row of client.requests) {
  if (row.state !== 'succeeded') continue;
  assert.equal(row.contextHex, '');
  const wallet = client.wallets.find(value => value.index === row.wallet);
  assert.ok(wallet);
  check(row.messageHex, row.signatureHex, wallet.publicKeyHex);
}
assert.equal(signatures, 38);
for (let index = 1; index <= 4; index++) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.registrationChecksPassed, true);
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  assert.equal(registration.cases.length, 2);
  assert.equal(registration.cases[0].publicKeyHex, registration.cases[1].publicKeyHex);
  for (const value of registration.cases) {
    assert.equal(value.canonicalKeyVerified, true);
    const signature = value.initialStockSign;
    assert.equal(signature.verified, true);
    assert.equal(signature.contextHex, '');
    check(signature.messageHex, signature.signatureHex, value.publicKeyHex);
  }
}
assert.equal(signatures, 46);
assert.equal(client.duplicateRequests.length, 4);
assert.ok(client.duplicateRequests.every(value => value.sameSignature));
console.log(JSON.stringify({ passed: true, loadSignatures: 38, setupSignatures: 8,
  alteredMessagesRejected, recoveredCanonicalKeys: 4, duplicateResultsPreserved: 4,
  node: process.version, openssl: process.versions.openssl }));
