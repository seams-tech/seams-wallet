import json
import subprocess
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-four-wallet-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
window = json.loads((base / 'cloud-driver/sustained/start.json').read_text())
runner = ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs']
while time.time() * 1000 < window['endAtMs'] + 1000:
    time.sleep(5)
for attempt in range(18):
    status = subprocess.run(runner + ['status', str(base), 'sustained'], cwd=root, capture_output=True, text=True)
    if status.returncode:
        raise SystemExit(status.stderr)
    progress = json.loads((base / 'cloud-driver/sustained/progress.json').read_text())
    if all(row['state'] in ['complete', 'failed'] for row in progress):
        break
    time.sleep(5)
else:
    raise SystemExit('Drivers did not reach a terminal state after the window')
receipts = []
commands = [
    ('collect', runner + ['collect', str(base), 'sustained']),
    ('final-stock', ['node', str(base / 'stock.mjs'), 'final']),
    ('traces', runner + ['traces', str(base), 'sustained']),
]
for label, command in commands:
    with (base / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    receipts.append({'stage': label, 'exit_code': result.returncode, 'completed_at_ms': round(time.time() * 1000)})
    (base / 'completion-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps(receipts[-1]), flush=True)
if any(row['exit_code'] for row in receipts):
    raise SystemExit('A completion check failed; retained all results and traces')
