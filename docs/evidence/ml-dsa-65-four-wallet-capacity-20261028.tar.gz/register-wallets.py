import json
import os
import re
import subprocess
from pathlib import Path

base = Path('/private/tmp/ml-dsa-four-wallet-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
scope = json.loads((base / 'hosted-scope.json').read_text())
receipts = json.loads((base / 'release/receipts.json').read_text())
assert len(receipts) == 8 and all(row['exit_code'] == 0 for row in receipts)
front_log = (base / 'release/front.log').read_text()
url = re.search(r'https://' + re.escape(scope['prefix']) + r'-front\.[a-z0-9-]+\.workers\.dev', front_log)
assert url is not None
scope['router_url'] = url.group(0)
(base / 'scope.json').write_text(json.dumps(scope, indent=2) + '\n')
(base / 'cloud-driver').mkdir(exist_ok=True)
(base / 'cloud-driver/versions.json').write_text(json.dumps(receipts, indent=2) + '\n')
for index in range(1, 5):
    artifact = base / f'registration-{index}.json'
    assert not artifact.exists()
    environment = os.environ.copy()
    environment.update({
        'ML_DSA_REGISTRATION_ROUTER_URL': scope['router_url'],
        'ML_DSA_GATEWAY_TOKEN_FILE': str(base / 'gateway-token'),
        'ML_DSA_TEST_BUILD_ROOT': str(base / 'baseline-build'),
        'ML_DSA_TEST_PREPARATION_JOBS': '2',
        'ML_DSA_TEST_COOLDOWN_MS': '60000',
        'ML_DSA_TEST_WALLET_ID': 'four-wallet-1028-' + str(index),
    })
    with (base / f'registration-{index}.log').open('w') as output:
        result = subprocess.run([
            'node', 'tests/e2e/ml-dsa-registration-worker.e2e.mjs',
            str(base / f'wallet-{index}'), str(artifact),
        ], cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f'Registration {index} failed; preserve its artifact and log')
    registration = json.loads(artifact.read_text())
    assert registration['registrationChecksPassed'] and registration['recoveryPreservesCanonicalKey']
    print(json.dumps({'wallet': index, 'creation_and_recovery_passed': True,
                     'cases': [{'epoch': row['epoch'], 'registration_ms': row['registrationWithClientVerificationMs'],
                                'generic_preparation_ms': row['preparationMs']} for row in registration['cases']]}), flush=True)
