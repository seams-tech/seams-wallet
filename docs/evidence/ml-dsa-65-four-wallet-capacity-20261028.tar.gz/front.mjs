import {routeLoadRequest,archiveTail,LoadWallet,LoadTraceArchive} from '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/tests/e2e/ml-dsa-cloud-load-worker.mjs';
export {LoadWallet,LoadTraceArchive};
async function fetch(request,env){if(new URL(request.url).pathname.startsWith('/__benchmark/'))return routeLoadRequest(request,env);return env.ROUTER.fetch(request);}
export default {fetch,tail:archiveTail};
