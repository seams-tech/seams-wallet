import json
import sys
import math
import statistics
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

BASE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent


def load(relative):
    return json.loads((BASE / relative).read_text())


def hexadecimal(value):
    return bytes(value).hex()


def distribution(values):
    ordered = sorted(values)
    if not ordered:
        return {'count': 0}
    return {
        'count': len(ordered),
        'minimum': ordered[0],
        'median': statistics.median(ordered),
        'p95_nearest_rank': ordered[math.ceil(0.95 * len(ordered)) - 1],
        'maximum': ordered[-1],
    }


def inside(at, start, end):
    return start <= at <= end


client = load('cloud-driver/sustained/client.json')
initial = load('initial-stock.json')
final = load('final-stock.json')
rows = load('cloud-driver/sustained/traces.json')['records']
window = load('cloud-driver/sustained/start.json')
start_at = window['startAtMs']
end_at = window['endAtMs']
driver_done_at = round(datetime.fromisoformat(client['completedAt'].replace('Z', '+00:00')).timestamp() * 1000)
external_observation_end = max(end_at, driver_done_at, final['endedAtMs'])
assert initial['complete'] and final['complete']
assert initial['endedAtMs'] < start_at
assert final['startedAtMs'] >= driver_done_at, 'Observe final stock after the drivers finish'
assert len(client['wallets']) == 4
assert not any(row['status'] == 'existing' and row.get('state') not in ['succeeded', 'failed', 'declined'] for row in client['requests']), 'Nonterminal operations require another restoration boundary'
restoration_observations = []
for wallet in client['wallets']:
    index = wallet['index']
    key = wallet['key']
    terminal = max(row['completedAtMs'] for row in client['requests'] if row['wallet'] == index and row.get('state') in ['succeeded', 'failed', 'declined'])
    final_stock = final['final'][index]
    assert final_stock['key'] == key
    expected = set(final_stock['paired'])
    matches = []
    for row in rows:
        for inventory in row['inventories']:
            if inventory['key'] != hexadecimal(key['public_key_digest']) or inventory['epoch'] != key['epoch']:
                continue
            if inventory['log_timestamp_ms'] < terminal:
                continue
            if set(inventory['ready_a']) == expected and set(inventory['ready_b']) == expected and not inventory['reserved_a'] and not inventory['reserved_b']:
                matches.append(inventory)
    assert matches, 'No paired full-stock event after the final terminal operation'
    observation = min(matches, key=lambda value: value['log_timestamp_ms'])
    restoration_observations.append({'wallet': index, 'last_terminal_at_ms': terminal, 'inventory': observation})
cycle_end = max(end_at, driver_done_at, *(value['inventory']['log_timestamp_ms'] for value in restoration_observations))
assert cycle_end <= external_observation_end
expected_versions = {row['role']: row['version'] for row in load('release/receipts.json')}
phase = [row for row in rows if inside(row['event_timestamp_ms'], start_at, cycle_end)]
assert phase
for row in phase:
    assert row['version'] == expected_versions[row['role']], row['role']
    assert row['logs_truncated'] is False
    assert isinstance(row['cpu_ms'], (int, float))
overlap = [row for row in rows if row['event_timestamp_ms'] < start_at
           and row['event_timestamp_ms'] + (row['wall_ms'] or 0) > start_at]

successes = [row for row in client['requests'] if row.get('verified') is True]
success_operations = {hexadecimal(row['operation']) for row in successes}
operation_durations = []
nonterminal_success_operations = []
for success in successes:
    operation = hexadecimal(success['operation'])
    observed = [row for row in client['requests'] if hexadecimal(row['operation']) == operation]
    first = min(row['startAtMs'] for row in observed)
    operation_durations.append(success['completedAtMs'] - first)
    if any(row.get('state') in ['awaiting_stock', 'preparing', 'running'] for row in observed):
        nonterminal_success_operations.append(operation)
all_operations = {hexadecimal(row['operation']) for row in client['requests']}
assert len(success_operations) == len(successes)
taken = {'a': defaultdict(set), 'b': defaultdict(set)}
signing = {}
for row in phase:
    for event in row['material_stages']:
        if event['value']['stage'] == 'taken' and event['operation'] in all_operations:
            taken[event['role']][event['operation']].add(event['value']['material_id'])
    for event in row['signing']:
        if event['operation'] in all_operations:
            if event['operation'] in signing:
                assert signing[event['operation']] == event['outcome']
            signing[event['operation']] = event['outcome']
all_taken_operations = set(taken['a']) | set(taken['b'])
asymmetric_takes = []
material_owners = defaultdict(set)
for operation in all_taken_operations:
    a = taken['a'][operation]
    b = taken['b'][operation]
    if a != b:
        asymmetric_takes.append({'operation': operation, 'a_only': sorted(a - b), 'b_only': sorted(b - a)})
    materials = a | b
    for material in materials:
        material_owners[material].add(operation)
assert all(len(operations) == 1 for operations in material_owners.values()), 'Material reused across operations'
for operation in success_operations:
    assert taken['a'][operation] == taken['b'][operation]
    assert signing[operation]['status'] == 'signed'
    assert signing[operation]['consumed_batches'] == len(taken['a'][operation])

jobs = {}
for row in rows:
    for event in row['producer_jobs']:
        job = jobs.setdefault(event['batch'], {'key': event['key'], 'epoch': event['epoch'], 'batches': event['batches'], 'stages': [], 'cpu': {}, 'wall': {}, 'attempts': {}})
        assert job['key'] == event['key'] and job['epoch'] == event['epoch']
    metadata = row['refill_job']
    if metadata:
        jobs.setdefault(metadata['batch'], {'key': metadata['key'], 'epoch': metadata['epoch'], 'batches': metadata['batches'], 'stages': [], 'cpu': {}, 'wall': {}, 'attempts': {}})
for row in rows:
    for event in row['preparation_stages']:
        if event['job'] in jobs:
            jobs[event['job']]['stages'].append(event)
    measured_jobs = {event['job'] for event in row['preparation_transport']}
    assert len(measured_jobs) <= 1, 'Multiple jobs share one invocation; per-job CPU is ambiguous'
    for identity in measured_jobs:
        if identity in jobs:
            job = jobs[identity]
            role = row['role']
            job['cpu'][role] = job['cpu'].get(role, 0) + row['cpu_ms']
            job['wall'][role] = job['wall'].get(role, 0) + row['wall_ms']
            job['attempts'][role] = job['attempts'].get(role, 0) + 1

publications = {'a': set(), 'b': set()}
complete_jobs = []
for identity, job in jobs.items():
    selected = [event['at_ms'] for event in job['stages'] if event['stage'] == 'controller_selected']
    if not selected or not inside(min(selected), start_at, cycle_end):
        continue
    published = {'a': {}, 'b': {}}
    for event in job['stages']:
        if event['stage'] == 'published':
            published[event['role']][event['batch']] = event['at_ms']
    expected = set(job['batches'])
    if set(published['a']) == expected and set(published['b']) == expected:
        completed_at = max(*published['a'].values(), *published['b'].values())
        if completed_at <= cycle_end:
            publications['a'].update(expected)
            publications['b'].update(expected)
            complete_jobs.append({'job': identity, 'key': job['key'], 'epoch': job['epoch'],
                                  'batches': job['batches'], 'candidates': 2 * len(job['batches']), 'started_at_ms': min(selected),
                                  'published_at_ms': completed_at, 'wall_ms': completed_at - min(selected),
                                  'crypto_invocation_cpu_ms': job['cpu'], 'crypto_invocation_wall_ms': job['wall'],
                                  'crypto_invocations_by_role': job['attempts']})

initial_ids = set()
final_ids = set()
for snapshot, destination in [(initial, initial_ids), (final, final_ids)]:
    for stock in snapshot['final']:
        assert len(stock['paired']) == 16
        assert not stock['a']['reserved'] and not stock['b']['reserved']
        assert destination.isdisjoint(stock['paired'])
        destination.update(stock['paired'])
assert len(initial_ids) == 64 and len(final_ids) == 64
consumed_ids = set(material_owners)
assert not (final_ids & consumed_ids)
assert not (initial_ids & publications['a'])
known = initial_ids | publications['a']
missing_consumed = consumed_ids - known
unaccounted_lost = known - consumed_ids - final_ids
unexpected_final = final_ids - known
cpu_by_role = Counter()
for row in phase:
    cpu_by_role[row['role']] += row['cpu_ms']
request_reasons = Counter(row.get('reason') for row in client['requests'] if row.get('status') == 'unavailable')
verified_in_window = [row for row in successes if row['completedAtMs'] <= end_at]
whole_cycle_minutes = (cycle_end - start_at) / 60000
window_minutes = (end_at - start_at) / 60000
job_cpu = defaultdict(list)
for job in complete_jobs:
    for role, value in job['crypto_invocation_cpu_ms'].items():
        job_cpu[role].append(value)
report = {
    'scope': client['scope'], 'functional_passed': client['functionalPassed'],
    'policy': client['policy'], 'start_at_ms': start_at, 'window_end_at_ms': end_at,
    'cycle_end_at_ms': cycle_end, 'reserve_detection_after_window_ms': cycle_end - end_at,
    'restoration_boundary': 'Each wallet has an exact final-ID inventory with sixteen ready pairs at A/B and no reserved pairs after its last terminal operation. End after all these observations and driver drain. Cross-host clocks limit precision.',
    'restoration_observations': restoration_observations,
    'late_external_confirmation_at_ms': final['endedAtMs'],
    'external_observer_delay_after_window_ms': final['startedAtMs'] - end_at,
    'driver_completed_at_ms': driver_done_at,
    'successes': len(successes), 'successes_in_window': len(verified_in_window),
    'window_signatures_per_minute': len(verified_in_window) / window_minutes,
    'whole_cycle_signatures_per_minute': len(successes) / whole_cycle_minutes,
    'successes_per_wallet': client['successesPerWallet'],
    'successful_call_ms': distribution([row['elapsedMs'] for row in successes]),
    'successful_operation_ms': distribution(operation_durations),
    'operation_timing_boundary': 'First request for the same operation ID through receipt of its verified signature, including unavailable responses.',
    'successes_with_earlier_nonterminal_responses': nonterminal_success_operations,
    'successful_demand_ms': distribution([row['elapsedMs'] for row in client['demands'] if row['state'] == 'succeeded']),
    'unfinished_demands': [row for row in client['demands'] if row['state'] != 'succeeded'],
    'successful_calls_under_five_seconds': sum(row['elapsedMs'] < 5000 for row in successes),
    'unavailable_responses': dict(request_reasons),
    'failed_or_declined_operations': len({hexadecimal(row['operation']) for row in client['requests'] if row.get('state') in ['failed', 'declined']}),
    'errors': client['errors'],
    'asymmetric_take_operations': asymmetric_takes,
    'candidates_consumed': 2 * len(consumed_ids),
    'candidates_consumed_per_success': 2 * len(consumed_ids) / len(successes) if successes else None,
    'pairs_per_success': distribution([len(taken['a'][operation]) for operation in success_operations]),
    'cpu_by_role_ms': dict(cpu_by_role), 'all_captured_cpu_ms': sum(cpu_by_role.values()),
    'captured_cpu_ms_per_success': sum(cpu_by_role.values()) / len(successes) if successes else None,
    'invocation_outcomes': dict(Counter(row['outcome'] for row in phase)),
    'preparation_jobs': complete_jobs,
    'complete_preparation_job_wall_ms': distribution([row['wall_ms'] for row in complete_jobs]),
    'job_counts_by_candidate_count': dict(Counter(row['candidates'] for row in complete_jobs)),
    'four_candidate_preparation_job_wall_ms': distribution([row['wall_ms'] for row in complete_jobs if row['candidates'] == 4]),
    'preparation_crypto_cpu_ms_by_role': {role: distribution(values) for role, values in job_cpu.items()},
    'initial_pairs': len(initial_ids), 'final_pairs': len(final_ids),
    'fresh_published_pairs': len(publications['a']), 'consumed_pairs': len(consumed_ids),
    'missing_consumed_ids': sorted(missing_consumed), 'unaccounted_lost_ids': sorted(unaccounted_lost),
    'unexpected_final_ids': sorted(unexpected_final),
    'ledger_balanced': not missing_consumed and not unaccounted_lost and not unexpected_final,
    'outside_start_overlapping_invocations': len(overlap),
    'initial_stock_alone_cannot_explain_consumption': len(consumed_ids) > len(initial_ids),
    'verified_operations_using_fresh_material': sum(bool(taken['a'][operation] - initial_ids) for operation in success_operations),
    'fresh_pairs_consumed_by_verified_operations': len(set().union(*(taken['a'][operation] for operation in success_operations)) - initial_ids),
}
(BASE / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key not in ['preparation_jobs', 'scope', 'policy']}))
