# Four-wallet capacity upload scope

Qualify sustainable signing for four synthetic wallets using the selected software runtime. Include verified standard signatures, empty-pool waits, failures, and restoration of the original reserve. Use the production sixty-second cooldown and two experimental producer slots. No production wallets or resources.

Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.
A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.
Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.
All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-cap-1028-17ed8f-router | ca5a01ec8c3c07b484f4582dd664b30b0f3742ea7b0b8412813a1973a9b0536f |
| ml-dsa-cap-1028-17ed8f-a | d9b673237a5d10ae0f7e97dd65ec2df68bdafac53869410977cc2421b81752b9 |
| ml-dsa-cap-1028-17ed8f-b | 6f524ea6c2106d07e1916315ca834210b3f773218a16a85f93509c403f810038 |
| ml-dsa-cap-1028-17ed8f-preparer-a | d9b673237a5d10ae0f7e97dd65ec2df68bdafac53869410977cc2421b81752b9 |
| ml-dsa-cap-1028-17ed8f-preparer-b | 6f524ea6c2106d07e1916315ca834210b3f773218a16a85f93509c403f810038 |
| ml-dsa-cap-1028-17ed8f-preparer-a-secondary | d9b673237a5d10ae0f7e97dd65ec2df68bdafac53869410977cc2421b81752b9 |
| ml-dsa-cap-1028-17ed8f-preparer-b-secondary | 6f524ea6c2106d07e1916315ca834210b3f773218a16a85f93509c403f810038 |
| ml-dsa-cap-1028-17ed8f-front | ca5a01ec8c3c07b484f4582dd664b30b0f3742ea7b0b8412813a1973a9b0536f |

The checked-in compatibility date is 2026-06-12. Registration, recovery, and standard-signature checks use disposable deterministic wallet fixtures. The initial benchmark measures four wallets over at least ten minutes, then waits for full reserve restoration. No production admission default changes.

[Exact current build hashes](build-artifacts.json) identify the frozen Router and participant artifacts. The native fixture role files and generated credentials remain local until the approved test setup needs them.
