import json
import subprocess
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-four-wallet-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
scope = json.loads((base / 'hosted-scope.json').read_text())
assert scope['prefix'] == 'ml-dsa-cap-1028-17ed8f'
assert len(scope['workers']) == 8
folder = base / 'cleanup'
folder.mkdir(exist_ok=False)
receipts = []
workers = sorted(scope['workers'], key=lambda row: row['role'] == 'front')
for worker in workers:
    role = worker['role']
    assert worker['name'] == scope['prefix'] + '-' + role
    result = subprocess.run([
        str(root / 'node_modules/.bin/wrangler'), 'delete', '--force',
        '--config', str(base / (role + '.json')),
    ], cwd=root, capture_output=True, text=True)
    (folder / (role + '-delete.log')).write_text(result.stdout + result.stderr)
    receipts.append({'role': role, 'name': worker['name'], 'exit_code': result.returncode, 'at_ms': int(time.time() * 1000)})
    (folder / 'deletions.json').write_text(json.dumps(receipts, indent=2) + '\n')
    if result.returncode:
        raise SystemExit('Deletion failed for ' + role)
absence = []
for worker in workers:
    role = worker['role']
    result = subprocess.run([
        str(root / 'node_modules/.bin/wrangler'), 'deployments', 'list', '--json',
        '--config', str(base / (role + '.json')),
    ], cwd=root, capture_output=True, text=True)
    text = result.stdout + result.stderr
    (folder / (role + '-absence.log')).write_text(text)
    absence.append({'role': role, 'exit_code': result.returncode, 'confirmed_absent': result.returncode != 0 and '10007' in text})
    (folder / 'absence.json').write_text(json.dumps(absence, indent=2) + '\n')
assert all(row['confirmed_absent'] for row in absence)
print(json.dumps({'removed_workers': len(receipts), 'independent_absence_checks_passed': len(absence)}))
