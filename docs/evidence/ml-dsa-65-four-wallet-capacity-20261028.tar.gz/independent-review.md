# Independent review

The reviewer independently verifies all thirty-eight signatures and altered-message rejection.
The complete ledger balances: sixty-four initial pairs plus 121 fresh pairs, less 121 consumed pairs, leaves sixty-four final pairs.
Successful operations consume 111 pairs. The failed operation consumes ten pairs.
All initial pairs and fifty-seven fresh pairs are consumed. All seventy selected preparation jobs complete.

The reviewer reproduces the first exact-final-ID inventory after the last terminal operation for each wallet:

- Wallet 0: normalized record 2482, timestamp 1793164461703.
- Wallet 1: record 2449, timestamp 1793164434494.
- Wallet 2: record 2417, timestamp 1793164421228.
- Wallet 3: record 2440, timestamp 1793164424818.

Each inventory contains sixteen ready pairs at both participants and zero reservations.
No later conflicting inventory or take appears before late external confirmation.
This supports an approximate observation bound about 3.5 seconds after the window, and approximately 3.78 signatures/minute including restoration.
Cross-actor clocks remain uncalibrated. The witnessing A invocation finishes about twenty-two milliseconds after its inventory log.

Corrections applied:

- Failed or unknown operations use the union of participant takes for consumed-material accounting.
- Verified signatures still require exact A/B take agreement.
- Same-operation duration includes unavailable requests sharing that operation ID.
- Successful-demand statistics retain the unfinished demand's 13.697-second lower bound separately.
- Cross-actor checkpoint spans are not presented as exact dispatch latency.
- Same-A-producer correlation spans preserve matching module identities and are described as wall spans containing work and waits.
- The idle result supports only that signing load alone does not explain the slow preparation.

No production source was edited by the reviewer.
