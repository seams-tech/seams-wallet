import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
const base = '/private/tmp/ml-dsa-four-wallet-20261028';
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const capture = { atMs: Date.now(), wallets: [] };
for (let index = 0; index < 4; index++) {
  const response = await fetch(scope.router_url + '/__benchmark/wallet/sustained-' + index, {
    headers: { 'x-router-ab-internal-service-auth': token },
    signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  capture.wallets.push(await response.json());
}
await mkdir(base + '/live', { recursive: true });
await writeFile(base + '/live/' + capture.atMs + '.json', JSON.stringify(capture, null, 2) + '\n');
for (const wallet of capture.wallets) {
  console.log(JSON.stringify({ wallet: wallet.state.config.index, state: wallet.state.state,
    successes: wallet.state.successes, requests: wallet.requests.length,
    lastReason: wallet.requests.at(-1)?.reason ?? null, error: wallet.state.error ?? null }));
}
