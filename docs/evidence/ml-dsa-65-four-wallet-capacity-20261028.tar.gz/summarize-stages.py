import json
import statistics
import sys
from pathlib import Path

base = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
analysis = json.loads((base / 'analysis.json').read_text())
records = json.loads((base / 'cloud-driver/sustained/traces.json').read_text())['records']
jobs = {job['job']: job for job in analysis['preparation_jobs'] if job['candidates'] == 4}
stages = {}
for record in records:
    for event in record['preparation_stages']:
        if event['job'] in jobs and event['role'] == 'a' and event['stage'] in ['crypto_started', 'correlations_completed', 'crypto_completed']:
            stages.setdefault(event['job'], {})[event['stage']] = event
values = []
for identity, job in jobs.items():
    events = stages[identity]
    assert len(events) == 3
    assert len({event['module_instance'] for event in events.values()}) == 1
    started = events['crypto_started']['at_ms']
    correlated = events['correlations_completed']['at_ms']
    complete = events['crypto_completed']['at_ms']
    assert started <= correlated <= complete
    values.append({'job': identity, 'same_module': True,
                   'correlation_wall_ms': correlated - started,
                   'remaining_crypto_wall_ms': complete - correlated,
                   'cross_actor_controller_to_crypto_ms': started - job['started_at_ms']})
report = {
    'scope': 'Same-A-producer wall spans include work and waits. Cross-actor differences are not qualified dispatch latency.',
    'jobs': values,
    'correlation_wall_median_ms': statistics.median(row['correlation_wall_ms'] for row in values),
    'remaining_crypto_wall_median_ms': statistics.median(row['remaining_crypto_wall_ms'] for row in values),
    'negative_cross_actor_differences': sum(row['cross_actor_controller_to_crypto_ms'] < 0 for row in values),
    'minimum_cross_actor_difference_ms': min(row['cross_actor_controller_to_crypto_ms'] for row in values),
}
(base / 'preparation-stages.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'jobs'}))
