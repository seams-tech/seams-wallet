# Offline replay

Run `python3 replay.py` from this extracted directory.
It checks every archived member hash, reproduces the capacity and idle analyses,
and verifies all 46 standard signatures plus altered-message rejection.
It makes no network requests. Node with ML-DSA support is required.

The full idle raw capture includes setup, the sustained window, late confirmation,
and the subsequent idle controls. The earlier normalized sustained capture is
also retained so the reviewed record indexes remain stable.

The external closing observer starts late. The primary result instead uses
exact paired inventory observations after each wallet's last terminal result.
Cross-actor timestamps support approximate bounds.
No authentication token, private participant key, or encrypted role fixture is included.
