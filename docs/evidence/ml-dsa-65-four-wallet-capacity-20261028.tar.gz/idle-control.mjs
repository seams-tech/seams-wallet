import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-four-wallet-20261028';
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const secrets = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8'));
const keys = [];
for (let index = 1; index <= 4; index++) {
  const value = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  keys.push(value.cases.at(-1).key);
}
const report = { scope: 'Idle preparation control on the same Workers and policy. Retire two unused pairs per selected synthetic wallet, then replace them. This is deliberate benchmark waste, separate from sustained signing.', cases: [] };

function hex(value) {
  return Buffer.from(value).toString('hex');
}

async function call(role, body) {
  const response = await fetch('https://' + scope.prefix + '-' + role + '.n6378056.workers.dev/router-ab/ml-dsa/role', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': secrets.INTERNAL_AUTH },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200, role + ' ' + body.command);
  return response.json();
}

async function inventory(key) {
  const command = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 };
  const a = await call('a', command);
  const b = await call('b', command);
  assert.equal(a.reserved.length, 0);
  assert.equal(b.reserved.length, 0);
  const bIds = new Set(b.ready.map(hex));
  const paired = [];
  for (const value of a.ready) if (bIds.has(hex(value))) paired.push(value);
  return { key, paired };
}

async function replace(name, indexes) {
  const value = { name, indexes, startedAtMs: Date.now(), initial: [], snapshots: [], passed: false };
  report.cases.push(value);
  for (const index of indexes) {
    const stock = await inventory(keys[index]);
    assert.equal(stock.paired.length, 16);
    value.initial.push(stock);
  }
  value.retirementStartedAtMs = Date.now();
  for (const stock of value.initial) {
    const command = { command: 'retire_unpaired', key: stock.key, batches: stock.paired.slice(0, 2) };
    await Promise.all([call('a', command), call('b', command)]);
  }
  for (const index of indexes) await call('a', { command: 'wake_refill', key: keys[index] });
  const deadline = Date.now() + 180000;
  while (Date.now() < deadline) {
    const stocks = [];
    for (const index of indexes) stocks.push(await inventory(keys[index]));
    value.snapshots.push({ atMs: Date.now(), stocks });
    if (stocks.every(full)) {
      value.passed = true;
      value.final = stocks;
      break;
    }
    await delay(2000);
  }
  value.endedAtMs = Date.now();
  await writeFile(base + '/idle-control.json', JSON.stringify(report, null, 2) + '\n');
  assert.equal(value.passed, true, 'Idle replacement timed out');
  console.log(JSON.stringify({ name, passed: true, elapsedMs: value.endedAtMs - value.retirementStartedAtMs }));
}

function full(stock) {
  return stock.paired.length === 16;
}

await replace('isolated-first-wallet', [0]);
await delay(3000);
await replace('isolated-second-wallet', [1]);
await delay(3000);
await replace('concurrent-two-wallets', [0, 1]);
