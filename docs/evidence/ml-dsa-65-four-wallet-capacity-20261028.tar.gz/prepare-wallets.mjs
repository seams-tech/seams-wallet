import assert from 'node:assert/strict';
import { createPrivateKey, createPublicKey } from 'node:crypto';
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';

const base = '/private/tmp/ml-dsa-four-wallet-20261028';
const fixtures = '/private/tmp/ml-dsa-aes-profile-20261028/capacity-fixtures';
const publicKeys = [];
for (const role of ['a', 'b']) {
  const encoded = (await readFile(fixtures + '/' + role + '-kek', 'utf8')).trim();
  const parts = encoded.split(':');
  assert.equal(parts.length, 2);
  assert.match(parts[1], /^[0-9a-f]{64}$/);
  const key = createPrivateKey({
    key: Buffer.concat([Buffer.from('302e020100300506032b656e04220420', 'hex'), Buffer.from(parts[1], 'hex')]),
    format: 'der',
    type: 'pkcs8',
  });
  const publicKey = createPublicKey(key).export({ type: 'spki', format: 'der' });
  publicKeys.push(Array.from(publicKey.subarray(-32)));
}
for (let index = 1; index <= 4; index++) {
  const destination = base + '/wallet-' + index;
  await mkdir(destination, { mode: 0o700 });
  for (const role of ['a', 'b']) await copyFile(fixtures + '/' + role + '-kek', destination + '/' + role + '-kek');
  await writeFile(destination + '/publics.json', JSON.stringify(publicKeys) + '\n', { mode: 0o600 });
}
console.log('Prepared four disposable client directories with the approved participant keys.');
