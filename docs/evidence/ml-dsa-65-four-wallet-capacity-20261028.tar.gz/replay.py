import hashlib
import json
import subprocess
import sys
from pathlib import Path

base = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
manifest = json.loads((base / 'manifest.json').read_text())
for relative, expected in manifest.items():
    assert hashlib.sha256((base / relative).read_bytes()).hexdigest() == expected, relative
for script, artifact in [('analyze.py', 'analysis.json'), ('analyze-idle.py', 'idle-analysis.json'), ('summarize-stages.py', 'preparation-stages.json')]:
    expected = json.loads((base / artifact).read_text())
    subprocess.run(['python3', str(base / script), str(base)], check=True, capture_output=True, text=True)
    assert json.loads((base / artifact).read_text()) == expected, artifact
result = subprocess.run(['node', str(base / 'verify-signatures.mjs'), str(base)], check=True, capture_output=True, text=True)
print(json.dumps({'member_hashes_verified': len(manifest), 'analysis_reproduced': True,
                  'signatures': json.loads(result.stdout)}))
