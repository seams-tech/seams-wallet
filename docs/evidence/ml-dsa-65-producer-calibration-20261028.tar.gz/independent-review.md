# Independent review

The reviewer reproduces the four complete windows:

| Window | Jobs | Fresh pairs | Paired CPU ms | Client restoration ms |
| --- | ---: | ---: | ---: | ---: |
| Initial | 16 | 32 | 142282 | 93979 |
| Matched baseline | 16 | 32 | 149294 | 99318 |
| Candidate | 16 | 32 | 148516 | 96999 |
| Return | 16 | 32 | 144013 | 98189 |

Rejecting the candidate is supported. Its CPU improvement over the matched control does not repeat against the return control.
Primary/secondary allocation differs: 9/7, 9/7, 8/8, and 10/6 jobs. Keep that confound.

All 128 fresh pair IDs across the windows are distinct. Both participants confirm every publication.
No retired pair returns. Actual protocol versions match the deployment receipts.
Both candidate signatures verify independently and reject altered messages.
The exact A/B takes consume three and two pairs from candidate-window stock, with matching key digests.

The 771 zero/basis comparisons prove the masked swap for the three actual shift/mask pairs.
The proof covers byte and 64-bit boundaries. All caller indices are public, distinct, and in range.
By-value casts add no aliasing or alignment-dependent accesses.
Named erasure remains unchanged. Register and compiler-temporary erasure retain the earlier limitation.
No protocol, domain, seed derivation, or recovery change is apparent.
The isolated SIMD timing is effectively flat. It establishes no speedup.

Calibration eligibility reproduces as 48/96, 74/96, 72/96, and 72/96 samples.
Initial direct B calibration has zero matching samples out of forty-eight.
Matching improves through A's binding. Instance IDs identify software rather than physical hardware.
The small auxiliary working set and changed first-touch/warmup conditions limit attribution.

Provider eventTimestamp plus wallTime does not always include the invocation's logs.
The conservative envelope of provider metadata and retained log timestamps still finds zero eligible heavy-calibration overlaps.
The event-timestamp outcome cohort does not include every causally related invocation.
Paired CPU uses exact job identity and includes the out-of-cohort B invocations.
Four earlier Router exceptions remain in the complete capture. Do not call the entire campaign failure-free.

No source files or credentials were read or changed beyond the requested public/code evidence review.
