import assert from 'node:assert/strict';
import { createCipheriv, createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const root = '/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa';
const base = '/private/tmp/ml-dsa-producer-calibration-20261028';
const require = createRequire(root + '/package.json');
const { Miniflare } = require('miniflare');
const bytes = await readFile(base + '/calibration.wasm');
const module = await WebAssembly.compile(bytes);
const imports = {};
for (const item of WebAssembly.Module.imports(module)) {
  assert.equal(item.kind, 'function');
  imports[item.module] ??= {};
  imports[item.module][item.name] = unexpectedImport;
}
function unexpectedImport() { throw new Error('Unexpected public calibration import'); }
const probe = new WebAssembly.Instance(module, imports).exports;

function expectedAes(seed) {
  const bytes = new Uint8Array(144);
  const view = new DataView(bytes.buffer);
  let state = seed;
  for (let offset = 0; offset < bytes.length; offset += 4) {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    view.setUint32(offset, state >>> 0, true);
  }
  const blocks = bytes.subarray(16);
  const cipher = createCipheriv('aes-128-ecb', bytes.subarray(0, 16), new Uint8Array(0));
  cipher.setAutoPadding(false);
  for (let round = 0; round < 1048576; round++) blocks.set(cipher.update(blocks));
  assert.equal(cipher.final().length, 0);
  cipher.destroy();
  let checksum = 0;
  for (const byte of blocks) checksum = (Math.imul(checksum, 31) + byte) >>> 0;
  return { checksum, fullOutputSha256: createHash('sha256').update(blocks).digest('hex') };
}

const reference = [];
for (const seed of [1, 17, 65537]) {
  const aes = expectedAes(seed);
  assert.equal(probe.aes_wide(seed) >>> 0, aes.checksum);
  assert.equal(probe.aes_scalar(seed) >>> 0, aes.checksum);
  reference.push({ seed, aes, encoder: probe.encoder(seed) >>> 0 });
}
const workers = [];
for (const role of ['a', 'b']) {
  const worker = {
    name: 'preparer-' + role,
    modules: true,
    modulesRoot: base,
    scriptPath: base + '/preparer-' + role + '-entry.mjs',
    modulesRules: [
      { type: 'ESModule', include: ['**/*.js', '**/*.mjs'] },
      { type: 'CompiledWasm', include: ['**/*.wasm'] },
    ],
    compatibilityDate: '2026-06-12',
    bindings: {
      INTERNAL_AUTH: 'public-local-control',
      ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING: 'INTERNAL_AUTH',
      DERIVER_ROLE_PRIVATE_D1_ROLE: 'deriver_' + role,
      DERIVER_ROLE_PRIVATE_D1_KEK_BINDING: 'ROLE_KEK',
      DERIVER_ROLE_PRIVATE_D1_KEK_VERSION: 'role-private-e2e',
      ROLE_KEK: (await readFile(base + '/fixtures/' + role + '-kek', 'utf8')).trim(),
    },
  };
  if (role === 'a') worker.serviceBindings = { DERIVER_B: 'preparer-b' };
  if (role === 'a') worker.durableObjects = { PROBE: { className: 'RouterAbMlDsaProducerDurableObject', useSQLite: true } };
  workers.push(worker);
}
const emptySecret = structuredClone(workers[0]);
emptySecret.name = 'preparer-a-empty-secret';
emptySecret.bindings.INTERNAL_AUTH = '';
workers.push(emptySecret);
const emptyBinding = structuredClone(workers[0]);
emptyBinding.name = 'preparer-a-empty-binding';
emptyBinding.bindings.ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING = '';
workers.push(emptyBinding);
workers.push({
  name: 'front', modules: true, compatibilityDate: '2026-06-12',
  durableObjects: {
    PROBE: { className: 'RouterAbMlDsaProducerDurableObject', scriptName: 'preparer-a' },
    EMPTY_SECRET: { className: 'RouterAbMlDsaProducerDurableObject', scriptName: 'preparer-a-empty-secret' },
    EMPTY_BINDING: { className: 'RouterAbMlDsaProducerDurableObject', scriptName: 'preparer-a-empty-binding' },
  },
  serviceBindings: { B: 'preparer-b' },
  script: `async function fetch(request, env) {
    const routed = new Request('https://probe/__benchmark/calibration', request);
    const path = new URL(request.url).pathname;
    if (path === '/a-empty-secret') return env.EMPTY_SECRET.get(env.EMPTY_SECRET.idFromName('ml-dsa-producer-v1')).fetch(routed);
    if (path === '/a-empty-binding') return env.EMPTY_BINDING.get(env.EMPTY_BINDING.idFromName('ml-dsa-producer-v1')).fetch(routed);
    if (path === '/a') return env.PROBE.get(env.PROBE.idFromName('ml-dsa-producer-v1')).fetch(routed);
    const peer = new Request('https://probe/__benchmark/calibration-peer', request);
    return env.PROBE.get(env.PROBE.idFromName('ml-dsa-producer-v1')).fetch(peer);
  }
  export default {fetch};`,
});
const runtime = new Miniflare({ workers });
const observations = { passed: false, reference, responses: [] };
try {
  await runtime.ready;
  const front = await runtime.getWorker('front');
  for (const name of ['a-empty-secret', 'a-empty-binding']) {
    const refused = await front.fetch('https://probe/' + name, {
      method: 'POST', headers: { 'x-router-ab-internal-service-auth': 'public-local-control' },
      body: JSON.stringify({kind: 'noop', seed: 1}),
    });
    assert.equal(refused.status, 503);
  }
  for (const role of ['a', 'b']) {
    const denied = await front.fetch('https://probe/' + role, { method: 'POST', body: '{}' });
    assert.equal(denied.status, 403);
    for (const value of reference) {
      for (const kind of ['noop', 'aes_wide', 'aes_scalar', 'encoder']) {
        const response = await front.fetch('https://probe/' + role, {
          method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': 'public-local-control' },
          body: JSON.stringify({ kind, seed: value.seed }),
        });
        assert.equal(response.status, 200);
        const result = await response.json();
        const expected = kind === 'noop' ? value.seed : kind === 'encoder' ? value.encoder : value.aes.checksum;
        assert.equal(result.checksum, expected);
        assert.match(result.js_module_instance, /^[0-9a-f]{32}$/);
        assert.ok(Number.isSafeInteger(result.core_instance));
        assert.ok(result.memory_bytes <= 4 * 1024 * 1024);
        observations.responses.push({ role, ...result });
      }
    }
  }
  observations.passed = true;
} finally {
  await runtime.dispose();
  await writeFile(base + '/local-calibration.json', JSON.stringify(observations, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: true, referenceCases: reference.length, workerResponses: observations.responses.length }));
