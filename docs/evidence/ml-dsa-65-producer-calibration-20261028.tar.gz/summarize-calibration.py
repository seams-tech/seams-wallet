import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

base = Path('/private/tmp/ml-dsa-producer-calibration-20261028')
label = sys.argv[1]
capture_label = sys.argv[2] if len(sys.argv) > 2 else label
measurement = json.loads((base / 'calibrations' / label / 'results.json').read_text())
roles = ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']
traces = {}
for role in roles:
    for line in (base / 'cloud-driver' / capture_label / (role + '-raw.jsonl')).read_text().splitlines():
        if not line:
            continue
        row = json.loads(line)
        identity = row.get('event', {}).get('request', {}).get('headers', {}).get('x-ml-dsa-request-id')
        if identity:
            key = (role, identity)
            assert key not in traces, 'Duplicate exact request trace'
            traces[key] = row
samples = []
missing = []
for sample in measurement['samples']:
    role = 'preparer-' + sample['participant']
    if sample['slot'] == 'secondary':
        role += '-secondary'
    trace = traces.get((role, sample['requestId']))
    if trace is None:
        missing.append({'role': role, 'request': sample['requestId']})
        continue
    assert trace['outcome'] == 'ok' and not trace['exceptions'] and trace['truncated'] is False
    assert isinstance(trace['cpuTime'], (int, float))
    found = []
    for log in trace['logs']:
        for text in log['message']:
            event = json.loads(text)
            if event.get('event') == 'ml_dsa_calibration_result_v1':
                found.append(event)
    assert found == [sample['result']]
    samples.append({'role': role, 'kind': sample['kind'], 'seed': sample['seed'],
                    'request': sample['requestId'], 'cpu_ms': trace['cpuTime'], 'wall_ms': trace['wallTime'],
                    'version': trace['scriptVersion']['id'], 'event_timestamp_ms': trace['eventTimestamp'],
                    'js_module_instance': sample['result']['js_module_instance'],
                    'core_instance': sample['result']['core_instance'], 'actor': sample['result']['actor']})
groups = defaultdict(list)
for sample in samples:
    groups[(sample['role'], sample['kind'])].append(sample['cpu_ms'])
medians = [{'role': role, 'kind': kind, 'samples': len(values), 'cpu_median_ms': statistics.median(values)} for (role, kind), values in groups.items()]
result = {'label': label, 'trace_capture': capture_label, 'expected': len(measurement['samples']), 'captured': len(samples), 'missing': missing,
          'samples': samples, 'medians': medians,
          'identity_limit': 'JavaScript module UUID and core instance epoch identify software instances, not physical hardware.'}
(base / 'calibrations' / label / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'samples'}))
if missing:
    raise SystemExit(1)
