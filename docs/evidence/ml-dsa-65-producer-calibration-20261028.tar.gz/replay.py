import hashlib
import json
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
manifest = json.loads((base / 'manifest.json').read_text())
for relative, expected in manifest.items():
    assert hashlib.sha256((base / relative).read_bytes()).hexdigest() == expected, relative
expected = json.loads((base / 'comparison.json').read_text())
script = base / 'source/tools/ml-dsa-investigation/research/summarize_producer_variation.py'
windows = ['baseline-window', 'matched-baseline-window', 'candidate-window', 'return-window']
arguments = [sys.executable, str(script), str(base / 'cloud-driver/final/traces.json'), str(base / 'comparison.json')]
for window in windows:
    arguments.append(str(base / window / 'result.json'))
subprocess.run(arguments, check=True, capture_output=True, text=True)
reproduced = json.loads((base / 'comparison.json').read_text())
for window in windows:
    assert reproduced['phases'][window] == expected['phases'][window]
expected = json.loads((base / 'analysis.json').read_text())
subprocess.run([sys.executable, str(base / 'analyze-campaign.py')], check=True, capture_output=True, text=True)
assert json.loads((base / 'analysis.json').read_text()) == expected
subprocess.run([sys.executable, str(base / 'prove-transpose.py')], check=True, capture_output=True, text=True)
result = subprocess.run(['node', str(base / 'verify-signatures.mjs'), str(base)], check=True, capture_output=True, text=True)
print(json.dumps({'member_hashes_verified': len(manifest), 'comparison_windows': 4,
                  'complete_preparation_jobs': 64, 'analysis_reproduced': True,
                  'signature_checks': json.loads(result.stdout)}))
