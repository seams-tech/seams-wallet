import copy,hashlib,json,os,secrets,shutil,subprocess
from pathlib import Path
os.umask(0o077)
base=Path(__file__).resolve().parent
root=Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
assert not (base/'hosted-scope.json').exists()
prefix='ml-dsa-cpu-1028-'+secrets.token_hex(3)
roles=['router','a','b','preparer-a','preparer-b','preparer-a-secondary','preparer-b-secondary','front']
internal=secrets.token_hex(32)
gateway=secrets.token_hex(32)
policy={'wallet_cooldown':{'mode':'enabled','interval_ms':60000},'max_active_operations':1,'operation_timeout_ms':30000,'candidate_group_size':2,'preparation_group_size':4,'minimum_ready_batches':8,'refill_target_batches':16,'max_active_preparations':2}
front=base/'front.mjs'
front.write_text("import {routeLoadRequest,archiveTail,LoadWallet,LoadTraceArchive} from '"+str(root/'tests/e2e/ml-dsa-cloud-load-worker.mjs')+"';\nexport {LoadWallet,LoadTraceArchive};\nasync function fetch(request,env){if(new URL(request.url).pathname.startsWith('/__benchmark/'))return routeLoadRequest(request,env);return env.ROUTER.fetch(request);}\nexport default {fetch,tail:archiveTail};\n")
workers=[]
for role in roles:
 cfg={'name':prefix+'-'+role,'main':str(front) if role=='front' else str(base/'baseline-build'/('router' if role=='router' else 'deriver-a' if role=='a' or role.startswith('preparer-a') else 'deriver-b')/'worker/shim.mjs'),'compatibility_date':'2026-06-12','compatibility_flags':['nodejs_compat'],'workers_dev':True,'preview_urls':False,'limits':{'cpu_ms':300000},'vars':{'ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING':'INTERNAL_AUTH','ML_DSA_ADMISSION_POLICY':json.dumps(policy,separators=(',',':'))},'observability':{'enabled':True},'durable_objects':{'bindings':[]},'services':[]}
 own=[]
 def object_binding(name,cls,owner):
  binding={'name':name,'class_name':cls}
  if owner==role:own.append(cls)
  else:binding['script_name']=prefix+'-'+owner
  cfg['durable_objects']['bindings'].append(binding)
 def service(name,target):cfg['services'].append({'binding':name,'service':prefix+'-'+target})
 payload={'INTERNAL_AUTH':internal}
 if role=='front':
  object_binding('TEST_WALLET','LoadWallet','front');object_binding('TEST_TRACES','LoadTraceArchive','front')
  service('TEST_FRONT','front');service('ROUTER','router')
  cfg['vars']['TEST_WORKER_PREFIX']=prefix
  payload['ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET']=gateway
 elif role=='router':
  object_binding('ML_DSA_ADMISSION_DO','RouterAbMlDsaAdmissionDurableObject','router')
  service('DERIVER_A','a');service('DERIVER_B','b')
  payload['ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET']=gateway
 else:
  participant='a' if role=='a' or role.startswith('preparer-a') else 'b'
  preparer=role.startswith('preparer-')
  cfg['vars'].update(DERIVER_ROLE_PRIVATE_D1_ROLE='deriver_'+participant,DERIVER_ROLE_PRIVATE_D1_KEK_BINDING='ROLE_KEK',DERIVER_ROLE_PRIVATE_D1_KEK_VERSION='role-private-e2e')
  payload['ROLE_KEK']=(base/'fixtures'/f'{participant}-kek').read_text()
  object_binding('ML_DSA_POOL_DO','RouterAbMlDsaPoolDurableObject',participant)
  object_binding('ML_DSA_ADMISSION_DO','RouterAbMlDsaAdmissionDurableObject','router')
  if not preparer:object_binding('ML_DSA_REGISTRATION_DO','RouterAbMlDsaRegistrationDurableObject',participant)
  if participant=='a':
   producer=role if preparer else 'preparer-a'
   object_binding('ML_DSA_PRODUCER_DO','RouterAbMlDsaProducerDurableObject',producer)
   object_binding('ML_DSA_SECONDARY_PRODUCER_DO','RouterAbMlDsaProducerDurableObject','preparer-a-secondary')
   service('DERIVER_B',role.replace('preparer-a','preparer-b') if preparer else 'b')
 if own:cfg['migrations']=[{'tag':'experiment-v1','new_sqlite_classes':list(dict.fromkeys(own))}]
 if role!='front':cfg['tail_consumers']=[{'service':prefix+'-front'}]
 path=base/f'{role}.json';path.write_text(json.dumps(cfg,indent=2)+'\n')
 bootstrap=copy.deepcopy(cfg);bootstrap.pop('services');bootstrap.pop('tail_consumers',None)
 bootstrap['durable_objects']['bindings']=[b for b in bootstrap['durable_objects']['bindings'] if 'script_name' not in b]
 (base/f'{role}-bootstrap.json').write_text(json.dumps(bootstrap,indent=2)+'\n')
 encoded=(json.dumps(payload,indent=2)+'\n').encode();(base/f'{role}-secrets.json').write_bytes(encoded)
 workers.append({'role':role,'name':cfg['name'],'payload_sha256':hashlib.sha256(encoded).hexdigest(),'config_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
scope={'prefix':prefix,'workers':workers,'policy':policy,'purpose':'Profile producer CPU variation with fixed public-input AES and encoder workloads inside the producer actor or peer Worker. Compare complete fresh preparation jobs and one measured optimization on the same eight temporary Workers. Use two synthetic wallets and the selected policy. No production wallets or resources.','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(base/'hosted-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
lines=['# Producer CPU calibration upload scope','',scope['purpose'],'','Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.','A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.','Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.','All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.','','| Worker | Credential payload SHA-256 |','| --- | --- |']
lines.extend(f"| {w['name']} | {w['payload_sha256']} |" for w in workers)
(base/'hosted-upload-scope.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'scope':str(base/'hosted-upload-scope.md'),'prefix':prefix,'workers':len(workers)}))
