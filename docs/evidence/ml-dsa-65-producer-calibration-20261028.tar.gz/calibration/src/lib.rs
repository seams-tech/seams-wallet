#![deny(unsafe_op_in_unsafe_fn)]
use cryprot_core::Block;
use two_party_primitives::gate_aes::{FourBlockAes128, FourBlocks};
use zeroize::Zeroizing;
#[path = "/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa/crates/ml-dsa-threshold/src/runtime/boolean_mpc/silent/correlation_aes.rs"]
mod software;

const AES_ROUNDS: usize = 1_048_576;
const ENCODER_SIZE: usize = 16_384;
const ENCODER_ROUNDS: usize = 128;

fn fill(bytes: &mut [u8], seed: &mut u32) {
    for word in bytes.chunks_mut(4) {
        *seed ^= *seed << 13;
        *seed ^= *seed >> 17;
        *seed ^= *seed << 5;
        word.copy_from_slice(&seed.to_le_bytes());
    }
}

fn checksum(blocks: &[[u8; 16]]) -> u32 {
    let mut value = 0u32;
    for block in blocks {
        for byte in block {
            value = value.wrapping_mul(31).wrapping_add(u32::from(*byte));
        }
    }
    core::hint::black_box(value)
}

#[no_mangle]
pub extern "C" fn aes_wide(mut seed: u32) -> u32 {
    let mut key = Zeroizing::new([0u8; 16]);
    fill(&mut *key, &mut seed);
    let cipher = software::CorrelationAes::new(&key);
    let mut blocks = Zeroizing::new([[0u8; 16]; 8]);
    for block in blocks.iter_mut() {
        fill(block, &mut seed);
    }
    for _ in 0..AES_ROUNDS {
        cipher.encrypt(&mut blocks[..]);
    }
    checksum(&blocks[..])
}

#[no_mangle]
pub extern "C" fn aes_scalar(mut seed: u32) -> u32 {
    let mut key = Zeroizing::new([0u8; 16]);
    fill(&mut *key, &mut seed);
    let cipher = FourBlockAes128::new(&key);
    let mut blocks = Zeroizing::new([[0u8; 16]; 8]);
    for block in blocks.iter_mut() {
        fill(block, &mut seed);
    }
    for _ in 0..AES_ROUNDS {
        for chunk in blocks.chunks_mut(4) {
            let mut batch = Zeroizing::new(FourBlocks::default());
            batch.0.copy_from_slice(chunk);
            cipher.encrypt_four(&mut batch);
            chunk.copy_from_slice(&batch.0);
        }
    }
    checksum(&blocks[..])
}

#[no_mangle]
pub extern "C" fn encoder(seed: u32) -> u32 {
    let mut values = Zeroizing::new(Vec::with_capacity(2 * ENCODER_SIZE));
    for index in 0..2 * ENCODER_SIZE {
        values.push(Block::from([
            (index as u64).wrapping_mul(0x9e3779b97f4a7c15) ^ u64::from(seed),
            (!(index as u64)).wrapping_mul(0x517cc1b727220a95),
        ]));
    }
    let encoder = cryprot_codes::ExConvCode::new(ENCODER_SIZE);
    for _ in 0..ENCODER_ROUNDS {
        encoder.dual_encode(&mut values[..]);
    }
    let mut checksum = 0u32;
    for block in values.iter() {
        for byte in block.as_bytes() {
            checksum = checksum.wrapping_mul(31).wrapping_add(u32::from(*byte));
        }
    }
    core::hint::black_box(checksum)
}

#[no_mangle]
pub extern "C" fn noop(seed: u32) -> u32 {
    core::hint::black_box(seed)
}
