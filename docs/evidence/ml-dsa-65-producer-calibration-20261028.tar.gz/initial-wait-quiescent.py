import json
import subprocess
import sys
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-producer-calibration-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
label = sys.argv[1]
for attempt in range(20):
    capture = subprocess.run(['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(base), label], cwd=root, capture_output=True, text=True)
    assert capture.returncode == 0, capture.stderr
    rows = json.loads((base / 'cloud-driver' / label / 'traces.json').read_text())['records']
    a = set()
    b = set()
    for row in rows:
        if row['role'].startswith('preparer-a'):
            for receipt in row['refill']:
                if receipt['published'] is True:
                    a.add(receipt['batch'])
        if row['role'].startswith('preparer-b') and row['refill_job']:
            b.add(row['refill_job']['batch'])
    missing = sorted(a - b)
    proof = {'successful_a_invocations': len(a), 'completed_b_invocations': len(b), 'missing_b_tails': missing,
             'observed_at_ms': round(time.time() * 1000), 'attempts': attempt + 1}
    (base / (label + '-quiescent.json')).write_text(json.dumps(proof, indent=2) + '\n')
    if a and not missing:
        print(json.dumps(proof))
        break
    time.sleep(2)
else:
    raise SystemExit('Provider completion records are incomplete; refuse heavy post-job calibration')
