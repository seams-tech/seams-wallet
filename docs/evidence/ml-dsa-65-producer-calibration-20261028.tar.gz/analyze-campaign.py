import json
from pathlib import Path

base = Path(__file__).resolve().parent
profile = json.loads((base / 'comparison.json').read_text())
scope = json.loads((base / 'scope.json').read_text())
roles = ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']
raw = {}
for role in roles:
    values = []
    for line in (base / 'cloud-driver/final' / (role + '-raw.jsonl')).read_text().splitlines():
        if line:
            values.append(json.loads(line))
    raw[role] = values


def events(record):
    values = []
    for log in record['logs']:
        for message in log['message']:
            values.append(json.loads(message))
    return values


def protocol_record(role, identity):
    found = []
    for record in raw[role]:
        if any(value.get('event') == 'ml_dsa_preparation_stage_v1' and value.get('job') == identity and value.get('stage') == 'crypto_started' for value in events(record)):
            found.append(record)
    assert len(found) == 1, (role, identity, len(found))
    return found[0]


def envelope(record):
    timestamps = [log['timestamp'] for log in record['logs']]
    start = min(record['eventTimestamp'], *timestamps)
    end = max(record['eventTimestamp'] + record['wallTime'], *timestamps)
    return start, end


def tags(record):
    values = [value for value in events(record) if value.get('event') == 'ml_dsa_calibration_module_v1']
    identities = {(value['js_module_instance'], value['core_instance'], value['actor']) for value in values}
    assert len(identities) == 1
    return next(iter(identities))


configurations = {
    'baseline-window': ('release', ['warm-before', 'warm-after']),
    'matched-baseline-window': ('matched-route', ['matched-before', 'matched-after']),
    'candidate-window': ('candidate-1', ['candidate-before', 'candidate-after']),
    'return-window': ('return-1', ['return-before', 'return-after']),
}
results = {}
all_fresh = set()
for phase, (receipt_name, labels) in configurations.items():
    window = profile['phases'][phase]
    receipts = json.loads((base / receipt_name / 'receipts.json').read_text())
    expected_versions = {row['role']: row['version'] for row in receipts}
    jobs = window['jobs']
    assert len(jobs) == 16
    fresh = {bytes(value).hex() for values in window['window']['finalReady'] for value in values}
    assert len(fresh) == 32 and all_fresh.isdisjoint(fresh)
    all_fresh.update(fresh)
    instances = {role: set() for role in roles}
    protocol = {role: [] for role in roles}
    for job in jobs:
        a = job['slot']
        b = a.replace('preparer-a', 'preparer-b')
        assert job['version_a'] == expected_versions[a]
        assert job['version_b'] == expected_versions[b]
        for role in [a, b]:
            record = protocol_record(role, job['job'])
            assert record['outcome'] == 'ok' and not record['exceptions'] and record['truncated'] is False
            instances[role].add(tags(record))
            protocol[role].append(record)
    calibration = []
    overlaps = []
    for label in labels:
        measured = json.loads((base / 'calibrations' / label / 'results.json').read_text())
        for sample in measured['samples']:
            role = 'preparer-' + sample['participant']
            if sample['slot'] == 'secondary':
                role += '-secondary'
            identity = (sample['result']['js_module_instance'], sample['result']['core_instance'], sample['result']['actor'])
            eligible = identity in instances[role]
            matching = [row for row in raw[role] if row.get('event', {}).get('request', {}).get('headers', {}).get('x-ml-dsa-request-id') == sample['requestId']]
            assert len(matching) == 1
            record = matching[0]
            assert record['scriptVersion']['id'] == expected_versions[role]
            assert record['outcome'] == 'ok' and not record['exceptions']
            start, end = envelope(record)
            if eligible and sample['kind'] != 'noop':
                for job_record in protocol[role]:
                    if tags(job_record) == identity:
                        job_start, job_end = envelope(job_record)
                        if max(start, job_start) < min(end, job_end):
                            overlaps.append({'calibration': sample['requestId'], 'role': role})
            calibration.append({'label': label, 'role': role, 'kind': sample['kind'],
                                'cpu_ms': record['cpuTime'], 'eligible_instance_match': eligible,
                                'identity': list(identity), 'request': sample['requestId']})
    results[phase] = {
        'jobs': len(jobs),
        'paired_invocation_cpu_ms': sum(job['cpu_a_ms'] + job['cpu_b_ms'] for job in jobs),
        'client_restoration_ms': window['window']['endAtMs'] - window['window']['startAtMs'],
        'material_accounting': window['material_accounting'],
        'provider_start_cohort_outcomes': window['all_outcomes'],
        'slots': window['slots'],
        'calibrations': calibration,
        'overlaps': overlaps,
        'instance_counts': {role: len(values) for role, values in instances.items()},
    }
    assert not overlaps, (phase, overlaps)

signature = json.loads((base / 'candidate-signatures.json').read_text())
assert signature['passed']
normalized = json.loads((base / 'cloud-driver/final/traces.json').read_text())['records']
ready = json.loads((base / 'candidate-window/result.json').read_text())['finalReady']
for case in signature['cases']:
    operation = bytes(case['operation']).hex()
    expected = {bytes(value).hex() for value in ready[case['wallet'] - 1]}
    taken = {'a': set(), 'b': set()}
    for row in normalized:
        for event in row['material_stages']:
            if event['operation'] == operation and event['value']['stage'] == 'taken':
                taken[event['role']].add(event['value']['material_id'])
    assert taken['a'] == taken['b'] and taken['a'] and taken['a'] <= expected
    case['candidate_material_pairs'] = sorted(taken['a'])
report = {'phases': results, 'candidate_signatures': signature,
          'limits': ['Calibration uses a separately compiled small working set.',
                     'Software instance IDs do not identify hardware.',
                     'Calibration first touches A producers before ordinary wallet setup; placement or warmup can be affected.',
                     'Per-invocation CPU includes complete role work, not individual stage CPU.',
                     'Provider eventTimestamp plus wallTime can exclude later logs. Overlap checks use the envelope of metadata and all retained log timestamps.',
                     'Provider-start outcome cohorts are not complete causal-window outcome sets.'],
          'decision': 'Reject the masked-word transpose. Paired CPU and restoration do not show a consistent useful gain.'}
(base / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({phase: {'jobs': data['jobs'], 'paired_cpu_ms': data['paired_invocation_cpu_ms'],
                          'restoration_ms': data['client_restoration_ms'],
                          'eligible_calibration_samples': sum(row['eligible_instance_match'] for row in data['calibrations']),
                          'overlap_count': len(data['overlaps'])} for phase, data in results.items()}))
