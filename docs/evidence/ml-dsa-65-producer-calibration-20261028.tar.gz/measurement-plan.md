# Producer calibration and preparation comparison

1. Deploy the eight Workers and exact credential payloads in the reviewed scope.
2. Complete canonical creation and recovery for two synthetic wallets. Observe full unchanged reserves before profiling.
3. Run fixed AES SIMD, scalar AES, bounded encoder, and no-op requests on each producer participant separately.
4. Compare exact-request provider CPU records. Use per-role no-op controls because A and B authenticate through different paths.
5. Run fresh four-candidate replacement jobs without heavy calibration in their execution intervals.
6. Await both participants' publication and complete provider invocation records before post-job B calibration. A's runtime guard refuses calibration during an active alarm.
7. Match the JavaScript module ID and core Wasm instance epoch. Require actual Rust job events and successful paired publication. A module ID does not identify physical hardware.
8. Compare isolated and concurrent jobs. Record cache state, both participants, protocol bytes, versions, memory observations, and failures.
9. Select one optimization only after the workload and calibration results identify the largest cost. Preserve cryptographic outputs and secret-independent execution.
10. Run full-output and complete-protocol checks, then compare baseline, candidate, and return-baseline windows on the same fleet.
11. Verify signatures and canonical recovery. Reconcile every consumed, retired, and newly published pair before reporting useful throughput.
12. Retain sanitized evidence and delete all eight Workers.

Calibration is a control. Its small encoder working set, separate module, code layout, and runtime tiering differ from production.
It cannot directly establish production stage cost or predict a speedup.
Heavy calibration must not overlap protocol work. HTTP return from B's WebSocket upgrade is not completion of B's asynchronous work.
The auxiliary module declares a four-MiB maximum memory. Observed local allocation is 1,703,936 bytes.
Combined Worker memory remains a separate observation.

Preparation remains on Workers. Wallet-seed recovery, canonical FIPS export, two-at-once consumption, and per-wallet capacity remain required.
The policy keeps four-candidate preparation, bounded partial replacements, sixteen-candidate admission minimum, and thirty-two-candidate capacity.
The production cooldown and preparation-slot defaults are not changed by this campaign.
