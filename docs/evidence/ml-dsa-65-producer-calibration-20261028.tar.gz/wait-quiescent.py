import json
import subprocess
import sys
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-producer-calibration-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
label = sys.argv[1]
window = json.loads((base / sys.argv[2] / 'result.json').read_text())
expected = {bytes(value).hex() for batches in window['finalReady'] for value in batches}
for attempt in range(20):
    capture = subprocess.run(['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(base), label], cwd=root, capture_output=True, text=True)
    assert capture.returncode == 0, capture.stderr
    rows = json.loads((base / 'cloud-driver' / label / 'traces.json').read_text())['records']
    a = set()
    b = set()
    for row in rows:
        for event in row['preparation_stages']:
            if event['stage'] == 'published' and event['batch'] in expected:
                if event['role'] == 'a':
                    a.add(event['batch'])
                else:
                    b.add(event['batch'])
    missing_a = sorted(expected - a)
    missing_b = sorted(expected - b)
    proof = {'expected_pairs': len(expected), 'observed_a_pairs': len(a), 'observed_b_pairs': len(b),
             'missing_a': missing_a, 'missing_b': missing_b, 'attempts': attempt + 1}
    (base / (label + '-quiescent.json')).write_text(json.dumps(proof, indent=2) + '\n')
    if not missing_a and not missing_b:
        print(json.dumps(proof))
        break
    time.sleep(2)
else:
    raise SystemExit('Incomplete participant publication tails; refuse heavy post-job calibration')

