import {routeLoadRequest, archiveTail, LoadWallet, LoadTraceArchive} from './load-worker.mjs';
export {LoadWallet, LoadTraceArchive};

async function fetch(request, env) {
  const path = new URL(request.url).pathname;
  if (path.startsWith('/__benchmark/calibrate/')) {
    if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) {
      return new Response('Unauthorized', { status: 401 });
    }
    const parts = path.split('/');
    if (request.method !== 'POST' || parts.length !== 5 ||
        !['primary', 'secondary'].includes(parts[3]) || !['a', 'b'].includes(parts[4])) {
      return new Response('Invalid calibration route', { status: 400 });
    }
    const text = await request.text();
    if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
    const calibrationPath = parts[4] === 'a' ? '/__benchmark/calibration' : '/__benchmark/calibration-peer';
    const target = new Request('https://calibration' + calibrationPath, {
      method: 'POST', headers: { 'content-type': 'application/json',
        'x-router-ab-internal-service-auth': env.INTERNAL_AUTH,
        'x-ml-dsa-request-id': request.headers.get('x-ml-dsa-request-id') ?? '' }, body: text,
    });
    const namespace = parts[3] === 'primary' ? env.CALIBRATION_A : env.CALIBRATION_A_SECONDARY;
    return namespace.get(namespace.idFromName('ml-dsa-producer-v1')).fetch(target);
  }
  if (path.startsWith('/__benchmark/')) return routeLoadRequest(request, env);
  return env.ROUTER.fetch(request);
}
export default {fetch, tail: archiveTail};
