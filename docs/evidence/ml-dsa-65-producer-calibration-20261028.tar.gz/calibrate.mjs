import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-producer-calibration-20261028';
const label = process.argv[2];
assert.match(label, /^[a-z0-9-]{1,60}$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const local = JSON.parse(await readFile(base + '/local-calibration.json', 'utf8'));
const folder = base + '/calibrations/' + label;
await mkdir(folder, { recursive: true });
const report = { label, startedAtMs: Date.now(), passed: false, requests: [], samples: [] };

function expected(kind, seed) {
  const row = local.reference.find(value => value.seed === seed);
  assert.ok(row);
  if (kind === 'noop') return seed;
  if (kind === 'encoder') return row.encoder;
  return row.aes.checksum;
}

async function call(slot, participant, kind, seed, repetition) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const row = { slot, participant, kind, seed, repetition, attempt,
      requestId: randomBytes(16).toString('hex'), startedAtMs: Date.now() };
    report.requests.push(row);
    const started = performance.now();
    const response = await fetch(scope.router_url + '/__benchmark/calibrate/' + slot + '/' + participant, {
      method: 'POST', headers: { 'content-type': 'application/json',
        'x-router-ab-internal-service-auth': token, 'x-ml-dsa-request-id': row.requestId },
      body: JSON.stringify({ kind, seed }), signal: AbortSignal.timeout(30000),
    });
    row.httpStatus = response.status;
    row.elapsedMs = performance.now() - started;
    row.endedAtMs = Date.now();
    if (response.status === 409) {
      await delay(1000);
      continue;
    }
    assert.equal(response.status, 200, participant + ' calibration refused');
    const result = await response.json();
    assert.equal(result.checksum, expected(kind, seed));
    assert.equal(result.kind, kind);
    assert.equal(result.seed, seed);
    assert.match(result.js_module_instance, /^[0-9a-f]{32}$/);
    assert.ok(Number.isSafeInteger(result.core_instance));
    assert.ok(result.memory_bytes <= 4 * 1024 * 1024);
    report.samples.push({ ...row, result });
    return;
  }
  throw new Error('Producer did not become idle for calibration');
}

try {
  let repetition = 0;
  for (const seed of [1, 17, 65537]) {
    const slots = repetition % 2 === 0 ? ['primary', 'secondary'] : ['secondary', 'primary'];
    const kinds = repetition % 2 === 0 ? ['noop', 'aes_wide', 'aes_scalar', 'encoder'] : ['encoder', 'aes_scalar', 'aes_wide', 'noop'];
    for (const slot of slots) {
      for (const participant of ['a', 'b']) {
        for (const kind of kinds) await call(slot, participant, kind, seed, repetition);
      }
    }
    repetition++;
    await writeFile(folder + '/results.json', JSON.stringify(report, null, 2) + '\n');
  }
  report.passed = true;
} finally {
  report.endedAtMs = Date.now();
  await writeFile(folder + '/results.json', JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ label, passed: report.passed, samples: report.samples.length }));
