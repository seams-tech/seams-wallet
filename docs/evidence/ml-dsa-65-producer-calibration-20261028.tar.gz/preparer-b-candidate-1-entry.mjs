import * as core from './candidate-build/deriver-b/worker/shim.mjs';
import {calibrate, tagProtocol} from './calibration.mjs';
export * from './candidate-build/deriver-b/worker/shim.mjs';

export default class CalibratedWorker extends core.default {
  async fetch(request) {
    if (new URL(request.url).pathname !== '/__benchmark/calibration') {
      tagProtocol('fetch', 'fetch_entered');
      const response = await super.fetch(request);
      tagProtocol('fetch', 'fetch_returned');
      return response;
    }
    const headers = { 'content-type': 'application/json',
      'x-router-ab-internal-service-auth': request.headers.get('x-router-ab-internal-service-auth') };
    const authorized = await super.fetch(new Request('https://calibration/router-ab/ml-dsa/registration/recipient-key', {
      method: 'POST', headers, body: '{}',
    }));
    if (authorized.status !== 200) return authorized;
    await authorized.arrayBuffer();
    const text = await request.text();
    return calibrate(text, 'fetch');
  }
}
