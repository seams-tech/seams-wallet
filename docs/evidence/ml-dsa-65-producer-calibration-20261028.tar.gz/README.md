# Offline replay

Run `python3 replay.py` in this extracted directory.
It verifies member hashes, regenerates all four comparison windows, reproduces
instance eligibility and overlap checks, checks the 771 basis cases, and verifies
six standard signatures plus altered-message rejection. It makes no network requests.

Production crypto source is the restored baseline. The rejected candidate source
and patch remain separate. Original measurement scope text stays unchanged in
measured artifacts; the current helper corrects its generic wording.

The complete final raw capture contains the setup exceptions. The earlier
incomplete and complete normalized snapshots preserve the telemetry-gap evidence.
No credential payload, private participant storage key, or encrypted role fixture is included.
