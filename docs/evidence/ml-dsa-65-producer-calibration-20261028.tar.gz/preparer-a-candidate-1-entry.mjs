import * as core from './candidate-build/deriver-a/worker/shim.mjs';
import {calibrate, tagProtocol} from './calibration.mjs';
export * from './candidate-build/deriver-a/worker/shim.mjs';

const identities = new WeakMap();
export class RouterAbMlDsaProducerDurableObject extends core.RouterAbMlDsaProducerDurableObject {
  constructor(state, env) {
    super(state, env);
    identities.set(this, { actor: state.id.toString(), env, alarmRunning: false });
  }
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (!['/__benchmark/calibration', '/__benchmark/calibration-peer'].includes(path)) return super.fetch(request);
    const entry = identities.get(this);
    if (!entry || entry.env.ROUTER_AB_INTERNAL_SERVICE_AUTH_SECRET_BINDING !== 'INTERNAL_AUTH' ||
        typeof entry.env.INTERNAL_AUTH !== 'string' || entry.env.INTERNAL_AUTH.trim().length === 0) {
      return new Response('Calibration auth is not configured', { status: 503 });
    }
    if (request.headers.get('x-router-ab-internal-service-auth') !== entry.env.INTERNAL_AUTH) {
      return new Response('Unauthorized', { status: 403 });
    }
    if (entry.alarmRunning) return new Response('Producer is active', { status: 409 });
    const authorized = await super.fetch(request.clone());
    if (authorized.status !== 400) return authorized;
    await authorized.arrayBuffer();
    const text = await request.text();
    if (entry.alarmRunning) return new Response('Producer is active', { status: 409 });
    if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
    if (path === '/__benchmark/calibration-peer') {
      return entry.env.DERIVER_B.fetch(new Request('https://calibration/__benchmark/calibration', {
        method: 'POST', headers: { 'content-type': 'application/json',
          'x-router-ab-internal-service-auth': entry.env.INTERNAL_AUTH,
          'x-ml-dsa-request-id': request.headers.get('x-ml-dsa-request-id') ?? '' }, body: text,
      }));
    }
    return calibrate(text, entry.actor);
  }
  async alarm() {
    const entry = identities.get(this);
    if (!entry) throw new Error('Missing producer actor identity');
    entry.alarmRunning = true;
    tagProtocol(entry.actor, 'alarm_entered');
    try {
      return await super.alarm();
    } finally {
      tagProtocol(entry.actor, 'alarm_returned');
      entry.alarmRunning = false;
    }
  }
}
export default core.default;
