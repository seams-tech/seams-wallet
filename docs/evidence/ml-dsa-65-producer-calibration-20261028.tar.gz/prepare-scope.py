import hashlib
import json
import shutil
import subprocess
from pathlib import Path

base = Path('/private/tmp/ml-dsa-producer-calibration-20261028')
previous = Path('/private/tmp/ml-dsa-four-wallet-20261028')
source = (previous / 'prepare-hosted.py').read_text()
source = source.replace("prefix='ml-dsa-cap-1028-'", "prefix='ml-dsa-cpu-1028-'")
source = source.replace("Path('/private/tmp/ml-dsa-aes-profile-20261028/capacity-fixtures')", "base/'fixtures'")
source = source.replace('Qualify sustainable signing for four synthetic wallets using the selected software runtime. Include verified standard signatures, empty-pool waits, failures, and restoration of the original reserve. Use the production sixty-second cooldown and two experimental producer slots. No production wallets or resources.', 'Profile producer CPU variation with fixed public-input AES and encoder workloads inside the producer actor or peer Worker. Compare complete fresh preparation jobs and one measured optimization on the same eight temporary Workers. Use two synthetic wallets and the selected policy. No production wallets or resources.')
source = source.replace('# Four-wallet capacity upload scope', '# Producer CPU calibration upload scope')
(base / 'prepare-hosted.py').write_text(source)
subprocess.run(['python3', str(base / 'prepare-hosted.py')], check=True)
shutil.copyfile(base / 'front-template.mjs', base / 'front.mjs')
scope = json.loads((base / 'hosted-scope.json').read_text())
for worker in scope['workers']:
    role = worker['role']
    path = base / (role + '.json')
    config = json.loads(path.read_text())
    if role.startswith('preparer-'):
        config['main'] = str(base / (role + '-entry.mjs'))
    if role == 'front':
        config['durable_objects']['bindings'].extend([
            {'name': 'CALIBRATION_A', 'class_name': 'RouterAbMlDsaProducerDurableObject', 'script_name': scope['prefix'] + '-preparer-a'},
            {'name': 'CALIBRATION_A_SECONDARY', 'class_name': 'RouterAbMlDsaProducerDurableObject', 'script_name': scope['prefix'] + '-preparer-a-secondary'},
        ])
        config['services'].extend([
            {'binding': 'CALIBRATION_B', 'service': scope['prefix'] + '-preparer-b'},
            {'binding': 'CALIBRATION_B_SECONDARY', 'service': scope['prefix'] + '-preparer-b-secondary'},
        ])
    path.write_text(json.dumps(config, indent=2) + '\n')
    worker['config_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    bootstrap = json.loads((base / (role + '-bootstrap.json')).read_text())
    bootstrap['main'] = config['main']
    (base / (role + '-bootstrap.json')).write_text(json.dumps(bootstrap, indent=2) + '\n')
(base / 'hosted-scope.json').write_text(json.dumps(scope, indent=2) + '\n')
shutil.copyfile(base / 'hosted-scope.json', base / 'scope.json')
fleet = (previous / 'fleet.py').read_text().replace("ml-dsa-cap-1028-", "ml-dsa-cpu-1028-")
(base / 'fleet.py').write_text(fleet)
with (base / 'hosted-upload-scope.md').open('a') as output:
    output.write('\nThe calibration module uses only fixed public inputs. It measures AES SIMD, scalar AES, a bounded public encoder workload, and an empty control. It runs inside the same producer actor or peer Worker. The core production Wasm stays unchanged in the baseline.\n')
    output.write('\nCompatibility date is 2026-06-12. Pool capacity stays thirty-two candidates per wallet. A candidate implementation is deployed only to the same four preparer Workers, with existing credentials and the same policy. All eight Workers are deleted after measurement.\n')
print(json.dumps({'scope':str(base/'hosted-upload-scope.md'),'workers':len(scope['workers'])}))
