# Producer CPU calibration upload scope

Profile producer CPU variation with fixed public-input AES and encoder workloads inside the producer actor or peer Worker. Compare complete fresh preparation jobs and one measured optimization on the same eight temporary Workers. Use two synthetic wallets and the selected policy. No production wallets or resources.

Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.
A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.
Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.
All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-cpu-1028-58152f-router | a85fd65f56aeb494416b3392f02a298e620dc3d5b609302028e78140ad506665 |
| ml-dsa-cpu-1028-58152f-a | de084e5bd713820840bd2accb85dce984c040f18a7dcb0f7d919c35fe6324185 |
| ml-dsa-cpu-1028-58152f-b | f9c7ebf0a3ac67d394a1118a42c01366895b1fffa1bd5088ec8210cdd9513db4 |
| ml-dsa-cpu-1028-58152f-preparer-a | de084e5bd713820840bd2accb85dce984c040f18a7dcb0f7d919c35fe6324185 |
| ml-dsa-cpu-1028-58152f-preparer-b | f9c7ebf0a3ac67d394a1118a42c01366895b1fffa1bd5088ec8210cdd9513db4 |
| ml-dsa-cpu-1028-58152f-preparer-a-secondary | de084e5bd713820840bd2accb85dce984c040f18a7dcb0f7d919c35fe6324185 |
| ml-dsa-cpu-1028-58152f-preparer-b-secondary | f9c7ebf0a3ac67d394a1118a42c01366895b1fffa1bd5088ec8210cdd9513db4 |
| ml-dsa-cpu-1028-58152f-front | a85fd65f56aeb494416b3392f02a298e620dc3d5b609302028e78140ad506665 |

The calibration module uses only fixed public inputs. It measures AES SIMD, scalar AES, a bounded public encoder workload, and an empty control. It runs inside the same producer actor or peer Worker. The core production Wasm stays unchanged in the baseline.

Compatibility date is 2026-06-12. Pool capacity stays thirty-two candidates per wallet. A candidate implementation is deployed only to the same four preparer Workers, with existing credentials and the same policy. All eight Workers are deleted after measurement.

Local Worker validation passes 24 calibration responses across A and B, plus missing-credential refusals. AES outputs match an independent native AES reference at three fixed public seeds. Auxiliary Wasm memory is 1,703,936 bytes. [Frozen source and build hashes](build-artifacts.json).

The final wrapper refuses empty authentication configuration and active A-side alarms. The auxiliary Wasm declares a hard four-MiB memory maximum. Module UUIDs describe software instances, not physical hosts. [Measurement procedure](measurement-plan.md). Credential payloads and Worker destinations are unchanged.
