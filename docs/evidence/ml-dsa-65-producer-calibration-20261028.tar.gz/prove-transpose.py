import json
from pathlib import Path

base = Path(__file__).resolve().parent

def byte_step(lower, upper, shift, mask):
    left = lower.to_bytes(16, 'little')
    right = upper.to_bytes(16, 'little')
    out_left = bytearray(16)
    out_right = bytearray(16)
    for index in range(16):
        swapped = (right[index] ^ (left[index] >> shift)) & mask
        out_right[index] = right[index] ^ swapped
        out_left[index] = left[index] ^ ((swapped << shift) & 255)
    return int.from_bytes(out_left, 'little'), int.from_bytes(out_right, 'little')


def word_step(lower, upper, shift, mask):
    word_mask = (1 << 64) - 1
    repeated_mask = int.from_bytes(bytes([mask]) * 8, 'little')
    out_left = 0
    out_right = 0
    for lane in range(2):
        left = (lower >> (64 * lane)) & word_mask
        right = (upper >> (64 * lane)) & word_mask
        swapped = (right ^ (left >> shift)) & repeated_mask
        out_left |= (left ^ ((swapped << shift) & word_mask)) << (64 * lane)
        out_right |= (right ^ swapped) << (64 * lane)
    return out_left, out_right

cases = 0
for shift, mask in [(1, 0x55), (2, 0x33), (4, 0x0f)]:
    assert byte_step(0, 0, shift, mask) == word_step(0, 0, shift, mask)
    cases += 1
    for bit in range(128):
        for lower, upper in [(1 << bit, 0), (0, 1 << bit)]:
            assert byte_step(lower, upper, shift, mask) == word_step(lower, upper, shift, mask)
            cases += 1
result = {'passed': True, 'basis_and_zero_cases': cases,
          'scope': 'Both transforms use only XOR, constant AND masks, and fixed logical shifts. They are linear over GF(2). Equality on the complete 256-bit input basis proves equality on every input pair for each of the three masks. This does not prove a speedup.',
          'linear_input_bits': 256, 'parameter_sets': 3}
(base / 'transpose-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
