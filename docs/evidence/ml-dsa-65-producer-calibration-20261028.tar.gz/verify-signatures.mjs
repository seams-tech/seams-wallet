import assert from 'node:assert/strict';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const base = resolve(process.argv[2] ?? import.meta.dirname);
let count = 0;

function check(messageHex, signatureHex, publicKeyHex) {
  const message = Buffer.from(messageHex, 'hex');
  const signature = Buffer.from(signatureHex, 'hex');
  const bytes = Buffer.from(publicKeyHex, 'hex');
  const key = createPublicKey({ key: Buffer.concat([
    Buffer.from('308207b2300b0609608648016503040312038207a100', 'hex'), bytes,
  ]), format: 'der', type: 'spki' });
  assert.equal(bytes.length, 1952);
  assert.equal(signature.length, 3309);
  assert.ok(message.length);
  assert.equal(verify(null, message, key, signature), true);
  const altered = Buffer.from(message);
  altered[0] ^= 0x80;
  assert.equal(verify(null, altered, key, signature), false);
  count++;
  return createHash('sha256').update(bytes).digest('hex');
}

for (let index = 1; index <= 2; index++) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.registrationChecksPassed, true);
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  assert.equal(registration.cases.length, 2);
  assert.equal(registration.cases[0].publicKeyHex, registration.cases[1].publicKeyHex);
  for (const value of registration.cases) {
    assert.equal(value.canonicalKeyVerified, true);
    assert.equal(value.initialStockSign.verified, true);
    check(value.initialStockSign.messageHex, value.initialStockSign.signatureHex, value.publicKeyHex);
  }
}
const candidate = JSON.parse(await readFile(base + '/candidate-signatures.json', 'utf8'));
assert.equal(candidate.passed, true);
for (const value of candidate.cases) {
  const digest = check(value.messageHex, value.signatureHex, value.publicKeyHex);
  assert.equal(digest, Buffer.from(value.key.public_key_digest).toString('hex'));
}
assert.equal(count, 6);
console.log(JSON.stringify({ passed: true, setupSignatures: 4, candidateSignatures: 2,
  alteredMessagesRejected: count, recoveredCanonicalKeys: 2, node: process.version, openssl: process.versions.openssl }));
