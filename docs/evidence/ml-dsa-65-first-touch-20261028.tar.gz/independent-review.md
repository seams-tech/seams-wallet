# Independent review

The reviewer inspected frozen raw captures, normalized records, the analyzer, and report.
It did not modify files or inspect credential payloads.

Verified: forty selected jobs and eighty distinct paired outputs; exact versions,
routing and A/B publication metadata; complete successful participant records;
sufficient stock lifetime; forty selected-job ledgers; and all cleanup absence logs.

CPU reproduces as 510.992 s selected + 17.243 s surplus + 18.836 s rejected return
= 547.071 s combined producer invocation CPU. Conditioning remains separate.
Light first-protocol software identities match four of eight target requests.
Compute conditioning matches eight of eight. All six signatures verify, and all
six altered messages fail verification.

Review corrections applied: first-protocol matching uses the earliest actual
role job; per-job and per-wallet IDs are checked; all attempts and extra work
are counted; elapsed conditioning includes its intervening gap; idle uses
conservative metadata/log envelopes; and role ready sets are checked individually.

The stale-inventory race was independently reconstructed from the fourteen/sixteen
snapshot, preceding publication and lease release, new acquired claim, and exact
surplus IDs. Its two pairs existed before the first wrapper idle interval.
The wrapper continuation remains unqualified after normalization because its
warmup history differs. Light first-block allocation is unbalanced. Actual gaps
and module changes govern reuse interpretation.

Final wording corrections preserve persistent compilation/runtime state as an
open cause and distinguish recorded stage/log times from exact cross-actor grant
timestamps. The evidence supports association, without a causal speedup claim.
