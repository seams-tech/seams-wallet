import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const base = '/private/tmp/ml-dsa-first-touch-20261028';
const armName = process.argv[2];
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const proof = JSON.parse(await readFile(base + '/routing-proof.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
let arm;
for (const value of proof.arms) if (value.name === armName) arm = value;
assert.ok(arm);
const result = {};
for (const slot of ['primary', 'secondary']) {
  const response = await fetch(scope.router_url + '/__benchmark/producer-id?slot=' + slot + '&object=' + arm.object_name, {
    headers: { 'x-router-ab-internal-service-auth': token },
    signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  const value = await response.json();
  assert.equal(value.object, arm.object_name);
  assert.equal(value.slot, slot);
  result[slot] = value.id;
}
console.log(JSON.stringify(result));
