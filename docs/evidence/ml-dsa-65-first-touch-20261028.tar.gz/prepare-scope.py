import hashlib
import json
import shutil
import subprocess
from pathlib import Path

base = Path('/private/tmp/ml-dsa-first-touch-20261028')
previous = Path('/private/tmp/ml-dsa-producer-calibration-20261028')
script = (previous / 'prepare-hosted.py').read_text()
script = script.replace("prefix='ml-dsa-cpu-1028-'", "prefix='ml-dsa-ft-1028-'")
script = script.replace('Profile producer CPU variation with fixed public-input AES and encoder workloads inside the producer actor or peer Worker. Compare complete fresh preparation jobs and one measured optimization on the same eight temporary Workers. Use two synthetic wallets and the selected policy. No production wallets or resources.', 'Separate ordinary producer execution, wrapper overhead, light first-touch, and compute conditioning on the same eight temporary Workers. Use fresh routing-only producer object names, repeated fresh preparation, and idle controls. Preserve the selected policy and two synthetic wallets. No production wallets or resources.')
script = script.replace('# Producer CPU calibration upload scope', '# Producer first-touch upload scope')
(base / 'prepare-hosted.py').write_text(script)
subprocess.run(['python3', str(base / 'prepare-hosted.py')], check=True)
scope = json.loads((base / 'hosted-scope.json').read_text())
config = json.loads((base / 'front.json').read_text())
config['durable_objects']['bindings'].extend([
    {'name': 'CALIBRATION_A', 'class_name': 'RouterAbMlDsaProducerDurableObject', 'script_name': scope['prefix'] + '-preparer-a'},
    {'name': 'CALIBRATION_A_SECONDARY', 'class_name': 'RouterAbMlDsaProducerDurableObject', 'script_name': scope['prefix'] + '-preparer-a-secondary'},
])
(base / 'front.json').write_text(json.dumps(config, indent=2) + '\n')
for worker in scope['workers']:
    worker['config_sha256'] = hashlib.sha256((base / (worker['role'] + '.json')).read_bytes()).hexdigest()
(base / 'hosted-scope.json').write_text(json.dumps(scope, indent=2) + '\n')
(base / 'scope.json').write_text(json.dumps(scope, indent=2) + '\n')
text = (previous / 'load-worker.mjs').read_text()
(base / 'load-worker.mjs').write_text(text)
text = (previous / 'front.mjs').read_text()
text = text.replace("const calibrationPath = parts[4] === 'a' ?", "const objectName = new URL(request.url).searchParams.get('object');\n    if (!['ml-dsa-producer-v4', 'ml-dsa-producer-v5'].includes(objectName)) return new Response('Conditioning arm required', {status: 400});\n    const calibrationPath = parts[4] === 'a' ?")
text = text.replace("namespace.idFromName('ml-dsa-producer-v1')", 'namespace.idFromName(objectName)')
needle = "  if (path.startsWith('/__benchmark/')) return routeLoadRequest(request, env);"
insert = '''  if (path === '/__benchmark/producer-id') {
    if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) return new Response('Unauthorized', {status: 401});
    const url = new URL(request.url);
    const name = url.searchParams.get('object');
    const slot = url.searchParams.get('slot');
    if (!['ml-dsa-producer-v2', 'ml-dsa-producer-v3', 'ml-dsa-producer-v4', 'ml-dsa-producer-v5', 'ml-dsa-producer-v6'].includes(name) || !['primary', 'secondary'].includes(slot)) return new Response('Invalid producer identity', {status: 400});
    const namespace = slot === 'primary' ? env.CALIBRATION_A : env.CALIBRATION_A_SECONDARY;
    return Response.json({object: name, slot, id: namespace.idFromName(name).toString()});
  }
'''
assert needle in text
text = text.replace(needle, insert + needle)
(base / 'front.mjs').write_text(text)
fleet = (previous / 'fleet.py').read_text().replace("ml-dsa-cpu-1028-", "ml-dsa-ft-1028-")
(base / 'fleet.py').write_text(fleet)
with (base / 'hosted-upload-scope.md').open('a') as output:
    output.write('\nFive arms run on these same eight Workers: plain first, wrapper-only, light first-touch, compute conditioning, and plain return. Fresh producer object names prevent reuse of earlier object state. Only the controller routing-name data changes; every executable Wasm code section and producer crypto binary stays identical. [Routing proof](routing-proof.json).\n')
    output.write('\nEach arm uses fresh independently consumed material and includes immediate and sixty-second idle repeats. Per-wallet capacity remains thirty-two candidates. Conditioning CPU and wall time remain included in total treatment cost. No candidate crypto optimization or GPU work is introduced.\n')
print(json.dumps({'scope': str(base / 'hosted-upload-scope.md'), 'workers': len(scope['workers'])}))
