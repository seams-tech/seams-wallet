import json
import subprocess
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
stock = json.loads((base / 'initial-stock.json').read_text())
assert stock['complete']
for value in stock['final']:
    assert len(value['paired']) == 16
for attempt in range(30):
    result = subprocess.run(['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(base), 'setup-complete'],
                            cwd=root, capture_output=True, text=True)
    (base / 'setup-complete-collection.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0
    records = json.loads((base / 'cloud-driver/setup-complete/traces.json').read_text())['records']
    queued = {}
    running = {}
    for record in records:
        for job in record['producer_jobs']:
            if job['stage'] == 'queued':
                queued[job['batch']] = set(job['batches'])
            if job['stage'] == 'running':
                running[job['batch']] = set(job['batches'])
    assert running
    complete = queued == running
    for job, expected in running.items():
        for role in ['a', 'b']:
            matched = [record for record in records if
                       any(stage['job'] == job and stage['role'] == role and stage['stage'] == 'crypto_started'
                           for stage in record['preparation_stages'])]
            if len(matched) != 1:
                complete = False
                continue
            record = matched[0]
            assert record['outcome'] == 'ok' and not record['exception_names'] and not record['logs_truncated']
            published = {stage['batch'] for stage in record['preparation_stages']
                         if stage['job'] == job and stage['stage'] == 'published'}
            complete = complete and published == expected
    if complete:
        (base / 'setup-complete-tails.json').write_text(json.dumps({
            'attempts': attempt + 1, 'producer_jobs': sorted(running),
            'full_ready_pairs': 32, 'registration_installed_stock_checked_by_lifecycle_e2e': True,
            'complete_paired_publication_tails': True, 'at_ms': round(time.time() * 1000),
        }, indent=2) + '\n')
        print(json.dumps({'complete_setup_producer_jobs': len(running), 'full_ready_pairs': 32}))
        break
    time.sleep(2)
else:
    raise SystemExit('Initial paired publication tails did not arrive')
