import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
const base = '/private/tmp/ml-dsa-first-touch-20261028';
const armName = process.argv[2];
const proof = JSON.parse(await readFile(base + '/routing-proof.json', 'utf8'));
let arm = null;
for (const value of proof.arms) if (value.name === armName) arm = value;
assert.ok(arm);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = (await readFile(base + '/gateway-token', 'utf8')).trim();
const directory = base + '/measurements/' + armName;
await mkdir(directory, { recursive: true });
const local = JSON.parse(await readFile(base + '/local-calibration.json', 'utf8'));
const fixedMemory = local.responses[0].memory_bytes;
for (const response of local.responses) assert.equal(response.memory_bytes, fixedMemory);
const identities = JSON.parse(await readFile(directory + '/expected-producer-ids.json', 'utf8'));
const record = { arm: armName, mode: arm.conditioning, startedAtMs: Date.now(), requests: [], passed: false };
try {
  if (arm.conditioning !== 'none') {
    const kinds = arm.conditioning === 'noop' ? ['noop', 'noop'] : ['aes_wide', 'encoder'];
    for (const slot of ['primary', 'secondary']) {
      for (const participant of ['a', 'b']) {
        for (let index = 0; index < kinds.length; index++) {
          const requestId = randomBytes(16).toString('hex');
          const row = { slot, participant, kind: kinds[index], seed: index === 0 ? 1 : 17,
            requestId, startedAtMs: Date.now() };
          record.requests.push(row);
          const response = await fetch(scope.router_url + '/__benchmark/calibrate/' + slot + '/' + participant + '?object=' + arm.object_name, {
            method: 'POST', headers: { 'content-type': 'application/json',
              'x-router-ab-internal-service-auth': token, 'x-ml-dsa-request-id': requestId },
            body: JSON.stringify({kind: row.kind, seed: row.seed}), signal: AbortSignal.timeout(30000),
          });
          row.httpStatus = response.status;
          assert.equal(response.status, 200);
          assert.equal(response.headers.get('x-benchmark-producer-id'), identities[slot]);
          row.result = await response.json();
          row.endedAtMs = Date.now();
          if (participant === 'a') assert.equal(row.result.actor, identities[slot]);
          let reference = null;
          for (const value of local.reference) if (value.seed === row.seed) reference = value;
          assert.ok(reference);
          const expected = row.kind === 'noop' ? row.seed : row.kind === 'encoder' ? reference.encoder : reference.aes.checksum;
          assert.equal(row.result.checksum, expected);
          assert.equal(row.result.kind, row.kind);
          assert.equal(row.result.seed, row.seed);
          assert.equal(row.result.memory_bytes, fixedMemory);
        }
      }
    }
  }
  record.passed = true;
} finally {
  record.endedAtMs = Date.now();
  await writeFile(directory + '/conditioning.json', JSON.stringify(record, null, 2) + '\n');
}
console.log(JSON.stringify({arm: armName, requests: record.requests.length, passed: record.passed}));
