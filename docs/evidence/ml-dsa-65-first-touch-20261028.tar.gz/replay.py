import hashlib
import json
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
manifest = json.loads((base / 'manifest.json').read_text())
for relative, expected in manifest.items():
    assert hashlib.sha256((base / relative).read_bytes()).hexdigest() == expected, relative
expected = json.loads((base / 'analysis.json').read_text())
subprocess.run([sys.executable, str(base / 'analyze.py')], check=True, capture_output=True, text=True)
assert json.loads((base / 'analysis.json').read_text()) == expected
signatures = subprocess.run(['node', str(base / 'verify-signatures.mjs'), str(base)],
                            check=True, capture_output=True, text=True)
print(json.dumps({'member_hashes_verified': len(manifest), 'arms': len(expected['arms']),
                  'complete_preparation_jobs': expected['distinct_jobs'],
                  'fresh_pairs': expected['distinct_pairs'], 'analysis_reproduced': True,
                  'signature_checks': json.loads(signatures.stdout)}))
