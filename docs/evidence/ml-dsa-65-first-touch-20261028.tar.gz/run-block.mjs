import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-first-touch-20261028';
const [arm, block] = process.argv.slice(2);
assert.match(arm, /^[a-z-]{1,40}$/);
assert.match(block, /^[a-z0-9-]{1,40}$/);
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const secrets = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8'));
const keys = [];
for (let index = 1; index <= 2; index++) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  keys.push(registration.cases.at(-1).key);
}
const directory = base + '/measurements/' + arm + '/' + block;
await mkdir(directory, { recursive: true });
const result = { arm, block, startedAtMs: Date.now(), initial: [], retired: [], snapshots: [], passed: false };

function hex(value) {
  return Buffer.from(value).toString('hex');
}

async function call(role, body) {
  const response = await fetch('https://' + scope.prefix + '-' + role + '.n6378056.workers.dev/router-ab/ml-dsa/role', {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': secrets.INTERNAL_AUTH },
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200, role + ' ' + body.command);
  return response.json();
}

async function inventory(key) {
  const request = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 };
  const a = await call('a', request);
  const b = await call('b', request);
  assert.equal(a.reserved.length, 0);
  assert.equal(b.reserved.length, 0);
  const peers = new Set(b.ready.map(hex));
  const paired = [];
  for (const id of a.ready) if (peers.has(hex(id))) paired.push(id);
  return { key, a, b, paired };
}

function pairedCount(value) {
  return value.paired.length;
}

function full(value) {
  return value.paired.length === 16 && value.a.ready.length === 16 && value.b.ready.length === 16;
}

try {
  for (const key of keys) {
    const stock = await inventory(key);
    result.initial.push(stock);
    assert.ok(full(stock), 'Require full unchanged reserves before a block');
  }
  result.retirementStartedAtMs = Date.now();
  for (const stock of result.initial) {
    const batches = stock.paired.slice(0, 2);
    await Promise.all([call('a', { command: 'retire_unpaired', key: stock.key, batches }),
      call('b', { command: 'retire_unpaired', key: stock.key, batches })]);
    result.retired.push({ key: stock.key, batches });
  }
  for (const key of keys) await call('a', { command: 'wake_refill', key });
  const deadline = Date.now() + 180000;
  while (Date.now() < deadline) {
    const stocks = [];
    for (const key of keys) stocks.push(await inventory(key));
    result.snapshots.push({ atMs: Date.now(), paired: stocks.map(pairedCount) });
    if (stocks.every(full)) {
      result.final = stocks;
      result.passed = true;
      break;
    }
    await delay(2000);
  }
  assert.equal(result.passed, true, 'Block reserve restoration timed out');
} finally {
  result.endedAtMs = Date.now();
  await writeFile(directory + '/result.json', JSON.stringify(result, null, 2) + '\n');
}
console.log(JSON.stringify({ arm, block, passed: result.passed,
  restorationMs: result.endedAtMs - result.retirementStartedAtMs }));
