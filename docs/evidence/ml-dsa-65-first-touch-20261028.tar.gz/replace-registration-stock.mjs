import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';

const base = '/private/tmp/ml-dsa-first-touch-20261028';
const scope = JSON.parse(await readFile(base + '/scope.json', 'utf8'));
const token = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8')).INTERNAL_AUTH;
const setup = JSON.parse(await readFile(base + '/cloud-driver/setup-complete/traces.json', 'utf8'));
const normal = new Set();
for (const record of setup.records) {
  for (const job of record.producer_jobs) {
    if (job.stage === 'running') for (const batch of job.batches) normal.add(batch);
  }
}
const report = { startedAtMs: Date.now(), retirements: [], passed: false };

function hex(value) {
  return Buffer.from(value).toString('hex');
}

async function call(role, body) {
  const response = await fetch('https://' + scope.prefix + '-' + role + '.n6378056.workers.dev/router-ab/ml-dsa/role', {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': token },
    body: JSON.stringify(body), signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200);
  return response.json();
}

const original = JSON.parse(await readFile(base + '/initial-stock.json', 'utf8'));
for (const stock of original.final) {
  const registration = new Set(stock.paired.filter(isRegistration));
  for (const role of ['a', 'b']) {
    const inventory = await call(role, { command: 'inventory', key: stock.key, target: 16, ready_until_ms: Date.now() + 30000 });
    assert.equal(inventory.reserved.length, 0);
    const batches = [];
    for (const value of inventory.ready) if (registration.has(hex(value))) batches.push(value);
    let result = null;
    if (batches.length) result = await call(role, { command: 'retire_unpaired', key: stock.key, batches });
    report.retirements.push({ key: stock.key, role, batches, result });
  }
  await call('a', { command: 'wake_refill', key: stock.key });
}
report.passed = true;
report.endedAtMs = Date.now();
await writeFile(base + '/registration-stock-retirement.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, roleRetirements: report.retirements.map(count) }));

function isRegistration(value) {
  return !normal.has(value);
}

function count(value) {
  return value.batches.length;
}
