import hashlib
import json
import shutil
from pathlib import Path

base = Path('/private/tmp/ml-dsa-first-touch-20261028')
previous = Path('/private/tmp/ml-dsa-producer-calibration-20261028')


def unsigned(data, position):
    value = 0
    shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7


def sections(data):
    result = []
    position = 8
    while position < len(data):
        kind = data[position]
        position += 1
        size, start = unsigned(data, position)
        end = start + size
        result.append((kind, start, end))
        position = end
    return result


for role in ['router', 'deriver-a', 'deriver-b']:
    shutil.copytree(previous / 'baseline-build' / role, base / 'baseline-build' / role)
original = (base / 'baseline-build/deriver-a/index_bg.wasm').read_bytes()
needle = b'ml-dsa-producer-v1'
assert original.count(needle) == 1
location = original.index(needle)
parts = sections(original)
assert any(kind == 11 and start <= location < end for kind, start, end in parts)
code = next(original[start:end] for kind, start, end in parts if kind == 10)
arms = [
    ('plain-first', 'ml-dsa-producer-v2', False, 'none'),
    ('wrapper-only', 'ml-dsa-producer-v3', True, 'none'),
    ('light-touch', 'ml-dsa-producer-v4', True, 'noop'),
    ('compute-conditioning', 'ml-dsa-producer-v5', True, 'compute'),
    ('plain-return', 'ml-dsa-producer-v6', False, 'none'),
]
proof = {'baseline_wasm_sha256': hashlib.sha256(original).hexdigest(),
         'code_section_sha256': hashlib.sha256(code).hexdigest(), 'arms': []}
for label, name, wrapped, conditioning in arms:
    directory = base / 'arms' / label / 'deriver-a'
    shutil.copytree(base / 'baseline-build/deriver-a', directory)
    replacement = name.encode()
    assert len(replacement) == len(needle)
    patched = original[:location] + replacement + original[location + len(needle):]
    for kind, start, end in parts:
        if kind != 11:
            assert patched[start:end] == original[start:end]
    assert next(patched[start:end] for kind, start, end in parts if kind == 10) == code
    (directory / 'index_bg.wasm').write_bytes(patched)
    proof['arms'].append({'name': label, 'object_name': name, 'wrapped': wrapped,
                          'conditioning': conditioning, 'wasm_sha256': hashlib.sha256(patched).hexdigest(),
                          'only_routing_name_data_changed': True})
(base / 'routing-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'arms': len(arms), 'code_section_identical': True, 'producer_core_wasm_unchanged': True}))
