import json
import subprocess
import sys
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-first-touch-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
name = sys.argv[1]
proof = json.loads((base / 'routing-proof.json').read_text())
arm = next(value for value in proof['arms'] if value['name'] == name)
directory = base / 'measurements' / name
directory.mkdir(parents=True, exist_ok=True)


def run(stage, arguments):
    with (directory / (stage + '.log')).open('w') as output:
        result = subprocess.run(arguments, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit('Arm step failed: ' + stage)


def expected_ids():
    result = subprocess.run(['node', str(base / 'producer-ids.mjs'), name], cwd=root,
                            capture_output=True, text=True)
    (directory / 'producer-ids.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0, 'Producer identity lookup failed'
    return json.loads(result.stdout)


def publication_barrier(block):
    measurement = json.loads((directory / block / 'result.json').read_text())
    expected = set()
    for before, retired, after in zip(measurement['initial'], measurement['retired'], measurement['final']):
        old = {bytes(value).hex() for value in before['paired']}
        final = {bytes(value).hex() for value in after['paired']}
        removed = {bytes(value).hex() for value in retired['batches']}
        new = final - old
        assert len(new) == 2
        assert len(removed) == 2 and removed <= old
        assert final == old - removed | new, 'Unexpected retained or retired material'
        expected.update(new)
    label = name + '-' + block
    for attempt in range(30):
        run('capture-' + block, ['node', 'tests/e2e/ml-dsa-cloud-load.e2e.mjs', 'traces', str(base), label])
        records = json.loads((base / 'cloud-driver' / label / 'traces.json').read_text())['records']
        observed = {'a': set(), 'b': set()}
        jobs = set()
        for record in records:
            for stage in record['preparation_stages']:
                if stage['stage'] == 'published' and stage['batch'] in expected:
                    observed[stage['role']].add(stage['batch'])
                    jobs.add(stage['job'])
        if observed['a'] == expected and observed['b'] == expected:
            assert len(jobs) == 2
            expected_producers = set(identities.values())
            observed_producers = set()
            routed_jobs = set()
            controllers = set()
            for record in records:
                for job in record['producer_jobs']:
                    if job['batch'] in jobs:
                        assert job['producer'] in expected_producers, 'Stale producer routing detected'
                        observed_producers.add(job['producer'])
                        routed_jobs.add(job['batch'])
                if record['role'] == 'a':
                    for stage in record['preparation_stages']:
                        if stage['job'] in jobs and stage['stage'] == 'controller_selected':
                            assert record['version'] == controller_version, 'Stale pool/controller version detected'
                            controllers.add(stage['job'])
            assert routed_jobs == jobs and controllers == jobs
            receipt = {'new_pairs': sorted(expected), 'jobs': sorted(jobs), 'attempts': attempt + 1,
                       'observed_at_ms': round(time.time() * 1000), 'routing_checked': True,
                       'observed_producers': sorted(observed_producers),
                       'both_slots_used': observed_producers == expected_producers}
            (directory / block / 'complete-tails.json').write_text(json.dumps(receipt, indent=2) + '\n')
            return
        time.sleep(2)
    raise SystemExit('Complete paired publication records did not arrive')


def audit_attempts(block):
    records = json.loads((base / 'cloud-driver' / (name + '-' + block) / 'traces.json').read_text())['records']
    planned = set()
    for path in directory.glob('*/complete-tails.json'):
        planned.update(json.loads(path.read_text())['jobs'])
    queued = set()
    running = set()
    for record in records:
        for job in record['producer_jobs']:
            if job['producer'] not in identities.values():
                continue
            if job['stage'] == 'queued':
                queued.add(job['batch'])
            if job['stage'] == 'running':
                running.add(job['batch'])
    result = {'planned': sorted(planned), 'queued': sorted(queued), 'running': sorted(running),
              'qualified': queued == running == planned}
    (directory / block / 'attempt-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    assert result['qualified'], 'Unplanned producer work invalidates this arm'


receipts = json.loads((base / 'deployments' / name / 'receipts.json').read_text())
controller_version = next(row['version'] for row in receipts if row['role'] == 'a')
assert controller_version
identities = expected_ids()
(directory / 'expected-producer-ids.json').write_text(json.dumps(identities, indent=2) + '\n')
run('conditioning', ['node', str(base / 'condition.mjs'), name])
for block in ['first', 'immediate-1', 'immediate-2', 'after-idle']:
    if block == 'after-idle':
        idle = {'started_at_ms': round(time.time() * 1000)}
        for tick in range(6):
            time.sleep(10)
        idle['ended_at_ms'] = round(time.time() * 1000)
        (directory / 'idle.json').write_text(json.dumps(idle, indent=2) + '\n')
    run(block, ['node', str(base / 'run-block.mjs'), name, block])
    publication_barrier(block)
    audit_attempts(block)
    print(json.dumps({'arm': name, 'block': block, 'complete': True}), flush=True)
