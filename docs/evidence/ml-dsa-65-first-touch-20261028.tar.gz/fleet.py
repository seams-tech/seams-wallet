import argparse
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
scope = json.loads((base / 'hosted-scope.json').read_text())
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['bootstrap', 'credentials', 'release', 'baseline', 'candidate'])
parser.add_argument('label')
args = parser.parse_args()
assert scope['prefix'].startswith('ml-dsa-ft-1028-')
assert len(scope['workers']) == 8
folder = base / args.label
folder.mkdir(exist_ok=False)
receipts = []
workers = scope['workers']
if args.mode == 'bootstrap':
    workers = sorted(workers, key=lambda row: row['role'] != 'front')
elif args.mode in ['baseline', 'candidate']:
    workers = [row for row in workers if row['role'].startswith('preparer-')]
for worker in workers:
    role = worker['role']
    assert worker['name'] == scope['prefix'] + '-' + role
    original = base / (role + ('-bootstrap.json' if args.mode == 'bootstrap' else '.json'))
    config = json.loads(original.read_text())
    assert config['name'] == worker['name']
    if args.mode in ['baseline', 'candidate']:
        entry = base / (role + '-' + args.label + '-entry.mjs')
        text = (base / (role + '-entry.mjs')).read_text()
        text = text.replace('./baseline-build/', './' + args.mode + '-build/')
        entry.write_text(text)
        config['main'] = str(entry)
    destination = folder / (role + '.json')
    destination.write_text(json.dumps(config, indent=2) + '\n')
    if args.mode == 'credentials':
        payload = base / (role + '-secrets.json')
        assert hashlib.sha256(payload.read_bytes()).hexdigest() == worker['payload_sha256']
        command = ['secret', 'bulk', str(payload)]
    else:
        command = ['deploy']
    started = int(time.time() * 1000)
    result = subprocess.run([str(root / 'node_modules/.bin/wrangler'), *command, '--config', str(destination)], cwd=root, capture_output=True, text=True)
    (folder / (role + '.log')).write_text(result.stdout + result.stderr)
    matched = re.search(r'Current Version ID: ([0-9a-f-]{36})', result.stdout)
    receipt = {'role': role, 'worker': worker['name'], 'exit_code': result.returncode, 'started_at_ms': started, 'ended_at_ms': int(time.time() * 1000), 'version': matched.group(1) if matched else None}
    receipts.append(receipt)
    (folder / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    if result.returncode:
        raise SystemExit('Cloudflare ' + args.mode + ' failed for ' + role + '; see its retained log')
print(json.dumps({'mode': args.mode, 'label': args.label, 'workers': len(receipts), 'passed': True}))
