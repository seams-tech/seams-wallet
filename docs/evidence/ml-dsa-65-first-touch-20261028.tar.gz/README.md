# Offline replay

Run `python3 replay.py` after extraction. Node with OpenSSL ML-DSA support is required.
The replay checks member hashes, rebuilds the identity-based job ledger and timing
tables from complete provider captures, and verifies six standard ML-DSA signatures.
It also checks altered-message rejection and canonical-key continuity during recovery.
It makes no network requests.

This fixed-order first pass is exploratory. Hardware placement and platform
compilation history are unobserved. The report does not claim a causal warmup gain.
Routing proof receipts retain exact binary hashes. Full deployed Wasm binaries are
excluded, so binary code-section equality is a measured receipt, not rebuilt offline.
No credential payloads, private role fixtures or wallet custody seeds are included.
