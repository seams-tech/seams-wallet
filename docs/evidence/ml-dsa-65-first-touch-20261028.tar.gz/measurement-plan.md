# First-touch and warmup controls

Use one approved eight-Worker fleet, two synthetic wallets, and unchanged pool policy.
Keep the producer Wasm identical in every arm. Change only the controller's equal-length object-name data.
Verify that every executable Wasm code section remains byte-identical.

Run these arms in order:

1. Plain first: original producer entrypoints, with no diagnostic module or early requests.
2. Wrapper-only: diagnostic wrappers and fixed auxiliary memory, with no early requests.
3. Light first-touch: the same wrappers, with empty-control calls through the front and A-to-B binding.
4. Compute conditioning: the same wrappers and request count, with fixed public AES/encoder work.
5. Plain return: original entrypoints on another fresh object name.

Shared wallet setup uses the original producer object name.
Registration-installed initial stock has a shorter lifetime. Replace it through ordinary refill before measuring.
Require every starting pair to map to normal producer metadata with expiry beyond the whole arm.
The precondition-failed v2 pilot stays separate. Registration expiry overlapped; its exact failure count was not retained. The restarted plain control uses fresh v7. Each measured arm uses a fresh name.
This resets object state, rather than proving fresh physical hardware or an empty platform compilation cache.
Redeploying producer entrypoints provides fresh observed software instances where the platform creates them.
Record actual module identities, construction counters, cache state, versions, and routing IDs.
Reject an arm if work reaches a prior producer object or another intended service version.

Activate the arm with `activate.py`, then run `run-arm.py`. Node fetch performs read-only ID lookup because Cloudflare refuses Python urllib with error 1010.
Each arm runs four replacement blocks. A block retires two unused pairs per wallet and replaces them with fresh material.
The first block records first production work on the new producer objects.
The second and third blocks follow immediately after complete participant tails.
The fourth follows sixty seconds without inventory polling or calibration against producers.
Record the actual idle gap and whether software instances survive it.

Keep both reserves full before every block. Capacity stays thirty-two candidates per wallet.
Consumption stays two-at-once. Preparation stays four-at-once, with existing bounded partial replacement behavior.
Measure both participants, client restoration, complete publication identities, and all failed work.
Report conditioning CPU and wall time separately and include them in total treatment cost.
Never count early compute as free preparation acceleration.

The public auxiliary module has the same initial memory in all wrapper arms and a four-MiB maximum.
It conditions the diagnostic environment; it is not a direct call to the production cipher implementation.
Its effects can include code, memory, runtime state, and allocation. Do not claim a particular mechanism without evidence.
Use the plain and wrapper-only arms to expose diagnostic interference.

Tail barriers require all new pair IDs at A and B. A WebSocket response is not completion of deferred B work.
Use job identity for CPU pairing. Provider event timestamps alone do not give a complete execution timeline.
Preserve raw metadata and compare conservative log envelopes before any overlap claim.

Verify canonical creation and wallet-seed recovery during setup, then standard signatures from final ready stock.
Retain an offline replay of routing proofs, ledgers, versions, identities, and signatures.
Delete all eight Workers and private benchmark credentials after the campaign.
The production defaults, recovery semantics, FIPS export, and GPU deferral remain unchanged.

Interpretation limits: object-name allocation, service redeployment, order, and platform compilation history remain confounds.
Require repeated direction across both participants and include conditioning cost before considering a production change.
If a useful first-touch effect appears, repeat plain and light-touch controls in reversed order on fresh object names before claiming a treatment effect.
