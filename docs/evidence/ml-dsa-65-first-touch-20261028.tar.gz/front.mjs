import {routeLoadRequest, archiveTail, LoadWallet, LoadTraceArchive} from './load-worker.mjs';
export {LoadWallet, LoadTraceArchive};

async function fetch(request, env) {
  const path = new URL(request.url).pathname;
  if (path.startsWith('/__benchmark/calibrate/')) {
    if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) {
      return new Response('Unauthorized', { status: 401 });
    }
    const parts = path.split('/');
    if (request.method !== 'POST' || parts.length !== 5 ||
        !['primary', 'secondary'].includes(parts[3]) || !['a', 'b'].includes(parts[4])) {
      return new Response('Invalid calibration route', { status: 400 });
    }
    const text = await request.text();
    if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
    const objectName = new URL(request.url).searchParams.get('object');
    if (!['ml-dsa-producer-v4', 'ml-dsa-producer-v5'].includes(objectName)) return new Response('Conditioning arm required', {status: 400});
    const calibrationPath = parts[4] === 'a' ? '/__benchmark/calibration' : '/__benchmark/calibration-peer';
    const target = new Request('https://calibration' + calibrationPath, {
      method: 'POST', headers: { 'content-type': 'application/json',
        'x-router-ab-internal-service-auth': env.INTERNAL_AUTH,
        'x-ml-dsa-request-id': request.headers.get('x-ml-dsa-request-id') ?? '' }, body: text,
    });
    const namespace = parts[3] === 'primary' ? env.CALIBRATION_A : env.CALIBRATION_A_SECONDARY;
    const id = namespace.idFromName(objectName);
    const response = await namespace.get(id).fetch(target);
    const headers = new Headers(response.headers);
    headers.set('x-benchmark-producer-id', id.toString());
    return new Response(response.body, {status: response.status, headers});
  }
  if (path === '/__benchmark/producer-id') {
    if (request.headers.get('x-router-ab-internal-service-auth') !== env.ROUTER_AB_GATEWAY_TO_ROUTER_AUTH_SECRET) return new Response('Unauthorized', {status: 401});
    const url = new URL(request.url);
    const name = url.searchParams.get('object');
    const slot = url.searchParams.get('slot');
    if (!['ml-dsa-producer-v7', 'ml-dsa-producer-v3', 'ml-dsa-producer-v4', 'ml-dsa-producer-v5', 'ml-dsa-producer-v6'].includes(name) || !['primary', 'secondary'].includes(slot)) return new Response('Invalid producer identity', {status: 400});
    const namespace = slot === 'primary' ? env.CALIBRATION_A : env.CALIBRATION_A_SECONDARY;
    return Response.json({object: name, slot, id: namespace.idFromName(name).toString()});
  }
  if (path.startsWith('/__benchmark/')) return routeLoadRequest(request, env);
  return env.ROUTER.fetch(request);
}
export default {fetch, tail: archiveTail};
