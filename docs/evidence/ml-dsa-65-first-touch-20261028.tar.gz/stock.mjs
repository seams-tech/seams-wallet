import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const base = '/private/tmp/ml-dsa-first-touch-20261028';
const phase = process.argv[2];
assert.ok(['initial', 'final'].includes(phase));
const scope = JSON.parse(await readFile(base + '/hosted-scope.json', 'utf8'));
const secrets = JSON.parse(await readFile(base + '/router-secrets.json', 'utf8'));
const keys = [];
for (let index = 1; index <= 2; index++) {
  const registration = JSON.parse(await readFile(base + '/registration-' + index + '.json', 'utf8'));
  assert.equal(registration.registrationChecksPassed, true);
  assert.equal(registration.recoveryPreservesCanonicalKey, true);
  keys.push(registration.cases.at(-1).key);
}
const report = { phase, startedAtMs: Date.now(), policy: scope.policy, snapshots: [], complete: false };

async function call(role, body) {
  const response = await fetch('https://' + scope.prefix + '-' + role + '.n6378056.workers.dev/router-ab/ml-dsa/role', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-router-ab-internal-service-auth': secrets.INTERNAL_AUTH },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30000),
  });
  assert.equal(response.status, 200, 'Stock call failed: ' + role + ' ' + body.command);
  return response.json();
}

async function inventory(key) {
  const command = { command: 'inventory', key, target: 16, ready_until_ms: Date.now() + 30000 };
  const a = await call('a', command);
  const b = await call('b', command);
  const peer = new Set(b.ready.map(hex));
  const paired = a.ready.map(hex).filter(contains.bind(null, peer));
  assert.equal(new Set(paired).size, paired.length);
  return { key, a, b, paired };
}

function contains(set, value) {
  return set.has(value);
}

function hex(value) {
  return Buffer.from(value).toString('hex');
}

function full(stock) {
  return stock.paired.length === 16 && stock.a.reserved.length === 0 && stock.b.reserved.length === 0;
}

for (const key of keys) await call('a', { command: 'wake_refill', key });
try {
  const deadline = Date.now() + 900000;
  while (Date.now() < deadline) {
    const stocks = [];
    for (const key of keys) stocks.push(await inventory(key));
    report.snapshots.push({ atMs: Date.now(), stocks });
    await writeFile(base + '/' + phase + '-stock.json', JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ phase, pairedReady: stocks.map(stock => stock.paired.length) }));
    if (stocks.every(full)) {
      report.complete = true;
      report.final = stocks;
      break;
    }
    await delay(5000);
  }
  assert.equal(report.complete, true, 'Full paired reserve restoration timed out');
} finally {
  report.endedAtMs = Date.now();
  await writeFile(base + '/' + phase + '-stock.json', JSON.stringify(report, null, 2) + '\n');
}
