import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
staging = base / 'public-evidence'
staging.mkdir(exist_ok=False)
files = [
    'scope.json', 'hosted-scope.json', 'hosted-upload-scope.md', 'measurement-plan.md',
    'routing-proof.json', 'build-artifacts.json', 'deployment-history.json',
    'analysis.json', 'analyze.py', 'replay.py', 'archive.py', 'report.md', 'independent-review.md',
    'calibration.mjs', 'calibration.wasm', 'calibration/src/lib.rs',
    'calibration/Cargo.toml', 'calibration/Cargo.lock',
    'local-calibration.mjs', 'local-calibration.json', 'local-calibration-fixed-allocation.log',
    'front.mjs', 'load-worker.mjs', 'fleet.py', 'activate.py', 'condition.mjs',
    'run-arm.py', 'run-block.mjs', 'stock.mjs', 'initial-barrier.py', 'producer-ids.mjs',
    'register-wallets.py', 'prepare-wallets.mjs', 'prepare-artifacts.py',
    'prepare-hosted.py', 'prepare-scope.py', 'capture-history.py', 'cleanup.py',
    'registration-1.json', 'registration-2.json', 'initial-stock.json',
    'final-stock.json', 'setup-complete-tails.json', 'final-signatures.json',
    'sign-final.mjs', 'verify-signatures.mjs', 'offline-signatures.json',
    'bloat-check.log', 'cleanup/deletions.json', 'cleanup/absence.json',
    'setup-auth-failure/registration-1.json', 'setup-auth-failure/registration-1.log',
    'setup-auth-failure/classification.json',
    'setup-barrier-failure.json',
    'setup-http-client-failure.json',
    'replace-registration-stock.mjs', 'registration-stock-retirement.json', 'idle-stock-audit.json',
    'front-routing-refresh.log',
]
for folder in ['bootstrap', 'credentials', 'release']:
    files.extend(str(path.relative_to(base)) for path in sorted((base / folder).glob('*.json')))
for folder in ['deployments', 'measurements']:
    files.extend(str(path.relative_to(base)) for path in sorted((base / folder).rglob('*.json')))
    files.extend(str(path.relative_to(base)) for path in sorted((base / folder).rglob('*.log')))
for path in sorted((base / 'pilot').rglob('*')):
    if path.is_file():
        files.append(str(path.relative_to(base)))
for path in sorted((base / 'rejected-return').rglob('*')):
    if path.is_file():
        files.append(str(path.relative_to(base)))
files.extend(path.name for path in sorted(base.glob('*-entry.mjs')))
scope = json.loads((base / 'scope.json').read_text())
for worker in scope['workers']:
    role = worker['role']
    files.extend([role + '.json', 'cleanup/' + role + '-delete.log', 'cleanup/' + role + '-absence.log'])
    if role != 'front':
        files.append('cloud-driver/final/' + role + '-raw.jsonl')
files.extend(['cloud-driver/final/traces.json', 'cloud-driver/final/collection.log',
              'cloud-driver/validation-final/traces.json', 'cloud-driver/validation-final/collection.log',
              'cloud-driver/wrapper-idle-failure/traces.json',
              'cloud-driver/rejected-return-first/traces.json',
              'cloud-driver/pilot-idle-confound/traces.json'])
for relative in sorted(set(files)):
    source = base / relative
    assert source.is_file(), relative
    destination = staging / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
for relative in ['tools/ml-dsa-investigation/research/collect_worker_traces.py',
                 'tests/e2e/ml-dsa-cloud-load.e2e.mjs',
                 'tests/e2e/ml-dsa-cloud-load-worker.mjs',
                 'tests/e2e/ml-dsa-registration-worker.e2e.mjs']:
    destination = staging / 'source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / relative, destination)
(staging / 'README.md').write_text('''# Offline replay

Run `python3 replay.py` after extraction. Node with OpenSSL ML-DSA support is required.
The replay checks member hashes, rebuilds the identity-based job ledger and timing
tables from complete provider captures, and verifies six standard ML-DSA signatures.
It also checks altered-message rejection and canonical-key continuity during recovery.
It makes no network requests.

This fixed-order first pass is exploratory. Hardware placement and platform
compilation history are unobserved. The report does not claim a causal warmup gain.
Routing proof receipts retain exact binary hashes. Full deployed Wasm binaries are
excluded, so binary code-section equality is a measured receipt, not rebuilt offline.
No credential payloads, private role fixtures or wallet custody seeds are included.
''')
patterns = set()
for source in base.glob('*-secrets.json'):
    for value in json.loads(source.read_text()).values():
        data = value.strip().encode()
        patterns.add(data)
        if b':' in data:
            patterns.add(data.rsplit(b':', 1)[1])
patterns.add((base / 'gateway-token').read_bytes().strip())
for source in staging.rglob('*'):
    if source.is_file():
        content = source.read_bytes()
        for pattern in patterns:
            assert not pattern or pattern not in content, str(source)
hashes = {str(source.relative_to(staging)): hashlib.sha256(source.read_bytes()).hexdigest()
          for source in sorted(staging.rglob('*')) if source.is_file()}
(staging / 'manifest.json').write_text(json.dumps(hashes, indent=2) + '\n')
archive = base / 'ml-dsa-65-first-touch-20261028.tar.gz'
with tarfile.open(archive, 'w:gz') as compressed:
    for source in sorted(staging.rglob('*')):
        if source.is_file():
            compressed.add(source, arcname=str(source.relative_to(staging)), recursive=False)
analysis = json.loads((base / 'analysis.json').read_text())
summary = {}
for name, result in analysis['arms'].items():
    summary[name] = {'blocks': {}, 'conditioning_cpu_ms': result['conditioning_cpu_ms'],
                     'conditioning_client_ms': result['conditioning_client_ms'],
                     'net_first_stock_client_ms': result['net_first_stock_client_ms'],
                     'control_qualification': result['control_qualification'],
                     'extra_paired_cpu_ms': result['extra_paired_cpu_ms'],
                     'first_protocol_identity_matches': sum(value['first_protocol_instance_match'] is True for value in result['conditioning_invocations'])}
    for block, value in result['blocks'].items():
        summary[name]['blocks'][block] = {
            'paired_cpu_ms': value['paired_cpu_ms'],
            'client_restoration_ms': value['client_restoration_ms'],
            'jobs': len(value['jobs']),
        }
index = {
    'schema': 'seams.ml-dsa-first-touch.v1', 'observed_date': '2026-10-28',
    'source_revision': scope['source_revision'],
    'policy': scope['policy'], 'comparison': summary,
    'distinct_jobs': analysis['distinct_jobs'], 'distinct_pairs': analysis['distinct_pairs'],
    'extra_jobs': analysis['extra_jobs'], 'extra_pairs': analysis['extra_pairs'],
    'rejected_return': analysis['rejected_return'],
    'signature_material': analysis['signature_material'],
    'accounted_comparison_protocol_cpu_ms': analysis['accounted_comparison_protocol_cpu_ms'],
    'signature_verification': json.loads((base / 'offline-signatures.json').read_text()),
    'limits': analysis['limits'], 'production_crypto_changed': False,
    'all_eight_workers_absent': all(value['confirmed_absent'] for value in
                                  json.loads((base / 'cleanup/absence.json').read_text())),
    'credential_scan': {'passed': True, 'exact_patterns_checked': len(patterns)},
    'bloat_check': {'passed': False, 'reason': 'Inherited Rust duplication excess',
                    'baseline': 13754, 'observed': 13992},
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                'members': len(hashes) + 1, 'file_sha256': hashes},
}
(base / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(hashes) + 1,
                  'credential_scan_passed': True}))
