import json
import re
import subprocess
import sys
import time
from pathlib import Path

base = Path('/private/tmp/ml-dsa-first-touch-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
arm_name = sys.argv[1]
proof = json.loads((base / 'routing-proof.json').read_text())
arm = next(value for value in proof['arms'] if value['name'] == arm_name)
folder = base / 'deployments' / arm_name
folder.mkdir(parents=True, exist_ok=False)
receipts = []
for role in ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary', 'a']:
    config = json.loads((base / (role + '.json')).read_text())
    if role == 'a':
        config['main'] = str(base / 'arms' / arm_name / 'deriver-a/worker/shim.mjs')
    else:
        part = 'deriver-a' if role.startswith('preparer-a') else 'deriver-b'
        entry = base / (role + '-' + arm_name + '-entry.mjs')
        if arm['wrapped']:
            text = (base / (role + '-entry.mjs')).read_text()
        else:
            reference = './baseline-build/' + part + '/worker/shim.mjs'
            text = "export * from '" + reference + "';\nexport {default} from '" + reference + "';\n"
        entry.write_text(text)
        config['main'] = str(entry)
    destination = folder / (role + '.json')
    destination.write_text(json.dumps(config, indent=2) + '\n')
    started = round(time.time() * 1000)
    result = subprocess.run([str(root / 'node_modules/.bin/wrangler'), 'deploy', '--config', str(destination)], cwd=root, capture_output=True, text=True)
    (folder / (role + '.log')).write_text(result.stdout + result.stderr)
    matched = re.search(r'Current Version ID: ([0-9a-f-]{36})', result.stdout)
    receipts.append({'role': role, 'worker': config['name'], 'started_at_ms': started,
                     'completed_at_ms': round(time.time() * 1000), 'exit_code': result.returncode,
                     'version': matched.group(1) if matched else None})
    (folder / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    if result.returncode or matched is None:
        raise SystemExit('Arm deployment failed at ' + role)
print(json.dumps({'arm': arm_name, 'deployments': len(receipts), 'passed': True}))
