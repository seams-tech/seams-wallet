# Producer first-touch upload scope

Separate ordinary producer execution, wrapper overhead, light first-touch, and compute conditioning on the same eight temporary Workers. Use fresh routing-only producer object names, repeated fresh preparation, and idle controls. Preserve the selected policy and two synthetic wallets. No production wallets or resources.

Create these eight temporary Workers and upload the exact fresh synthetic benchmark credentials below.
A role keys go only to A Workers. B role keys go only to B Workers. Front and Router receive no role storage key.
Pool capacity is thirty-two candidates per wallet. Consumption stays two-at-once. Preparation stays four-at-once.
All eight Workers will be deleted after the campaign. No D1 databases, buckets, production wallet credentials, or production routes are involved.

| Worker | Credential payload SHA-256 |
| --- | --- |
| ml-dsa-ft-1028-d8f208-router | 7e8b712dfab387eb92eefcf4326c9294674caecd58e90aa9b85858d25eef54e1 |
| ml-dsa-ft-1028-d8f208-a | d41a2ecd2967d10a76ae1eafc72c6ae9147f38b1c5d4a19db345846f4c7f0d6b |
| ml-dsa-ft-1028-d8f208-b | 716baf2584665cd922e6dedbdedf2c411d58d21fa52be96a304b245e388eec6d |
| ml-dsa-ft-1028-d8f208-preparer-a | d41a2ecd2967d10a76ae1eafc72c6ae9147f38b1c5d4a19db345846f4c7f0d6b |
| ml-dsa-ft-1028-d8f208-preparer-b | 716baf2584665cd922e6dedbdedf2c411d58d21fa52be96a304b245e388eec6d |
| ml-dsa-ft-1028-d8f208-preparer-a-secondary | d41a2ecd2967d10a76ae1eafc72c6ae9147f38b1c5d4a19db345846f4c7f0d6b |
| ml-dsa-ft-1028-d8f208-preparer-b-secondary | 716baf2584665cd922e6dedbdedf2c411d58d21fa52be96a304b245e388eec6d |
| ml-dsa-ft-1028-d8f208-front | 7e8b712dfab387eb92eefcf4326c9294674caecd58e90aa9b85858d25eef54e1 |

Five arms run on these same eight Workers: plain first, wrapper-only, light first-touch, compute conditioning, and plain return. Fresh producer object names prevent reuse of earlier object state. Only the controller routing-name data changes; every executable Wasm code section and producer crypto binary stays identical. [Routing proof](routing-proof.json).

Each arm uses fresh independently consumed material and includes immediate and sixty-second idle repeats. Per-wallet capacity remains thirty-two candidates. Conditioning CPU and wall time remain included in total treatment cost. No candidate crypto optimization or GPU work is introduced.

Local Worker validation passes twenty-four responses, independent AES reference checks, missing-credential refusals, and empty-auth-configuration refusals. All wrapper modes retain exactly 2,228,224 bytes of auxiliary memory, with a four-MiB declared maximum. [Exact artifact hashes](build-artifacts.json), [measurement plan](measurement-plan.md).

The final orchestration checks object IDs, controller/producer versions, both first-block slots, complete participant tails, and a sixty-second interval without client producer touches. The first pass is exploratory; a promising treatment needs balanced replication before a causal claim. Updated source hashes are in build-artifacts.json. Credential payloads and destinations are unchanged.
