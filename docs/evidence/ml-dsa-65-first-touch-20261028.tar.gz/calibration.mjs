import compiled from './calibration.wasm';
const imports = {};
for (const item of WebAssembly.Module.imports(compiled)) {
  if (item.kind !== 'function') throw new Error('Unexpected calibration import');
  imports[item.module] ??= {};
  imports[item.module][item.name] = unexpectedImport;
}
const probe = new WebAssembly.Instance(compiled, imports).exports;
probe.reserve_working_set();
let moduleInstance = null;

function identity() {
  if (moduleInstance === null) moduleInstance = crypto.randomUUID().replaceAll('-', '');
  return moduleInstance;
}

function coreInstance() {
  const state = globalThis.__worker_init_state;
  if (!state || !Number.isSafeInteger(state.instanceId) || state.instanceId < 0) {
    throw new Error('Missing core Wasm instance identity');
  }
  return state.instanceId;
}

function unexpectedImport() {
  throw new Error('The public calibration called a host import');
}

export function tagProtocol(actor, stage) {
  console.log(JSON.stringify({ event: 'ml_dsa_calibration_module_v1', js_module_instance: identity(), core_instance: coreInstance(), actor, kind: 'protocol', stage }));
}

export function calibrate(text, actor) {
  if (text.length > 256) return new Response('Oversized calibration', { status: 400 });
  const input = JSON.parse(text);
  if (!input || typeof input !== 'object' || Array.isArray(input) ||
      !['noop', 'aes_wide', 'aes_scalar', 'encoder'].includes(input.kind) ||
      ![1, 17, 65537].includes(input.seed)) {
    return new Response('Invalid public calibration', { status: 400 });
  }
  const checksum = probe[input.kind](input.seed) >>> 0;
  const result = { event: 'ml_dsa_calibration_result_v1', js_module_instance: identity(), core_instance: coreInstance(), actor,
    kind: input.kind, seed: input.seed, checksum, memory_bytes: probe.memory.buffer.byteLength };
  console.log(JSON.stringify(result));
  return Response.json(result);
}
