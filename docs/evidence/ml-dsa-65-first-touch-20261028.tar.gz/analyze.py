import json
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
proof = json.loads((base / 'routing-proof.json').read_text())
records = json.loads((base / 'cloud-driver/final/traces.json').read_text())['records']
material_expiries = {}
for record in records:
    metadata = record['refill_job']
    if metadata:
        for batch in metadata['batches']:
            expiry = metadata['material_expires_at_ms']
            assert batch not in material_expiries or material_expiries[batch] == expiry
            material_expiries[batch] = expiry
roles = ['preparer-a', 'preparer-b', 'preparer-a-secondary', 'preparer-b-secondary']
raw = {}
for role in roles:
    raw[role] = [json.loads(line) for line in
                 (base / 'cloud-driver/final' / (role + '-raw.jsonl')).read_text().splitlines() if line]


def load(relative):
    return json.loads((base / relative).read_text())


def events(record):
    result = []
    for log in record['logs']:
        for message in log['message']:
            try:
                value = json.loads(message)
            except (ValueError, TypeError):
                continue
            if isinstance(value, dict):
                result.append(value)
    return result


def protocol_record(job, role):
    found = [record for record in records if record['role'] == role and
             any(stage['job'] == job and stage['stage'] == 'crypto_started'
                 for stage in record['preparation_stages'])]
    assert len(found) == 1, (job, role, len(found))
    return found[0]


def raw_protocol(job, role):
    found = [record for record in raw[role] if
             any(value.get('event') == 'ml_dsa_preparation_stage_v1' and
                 value.get('job') == job and value.get('stage') == 'crypto_started'
                 for value in events(record))]
    assert len(found) == 1, (job, role, len(found))
    return found[0]


def tag(record):
    identities = {(value['js_module_instance'], value['core_instance'], value['actor'])
                  for value in events(record)
                  if value.get('event') == 'ml_dsa_calibration_module_v1'}
    assert len(identities) <= 1
    return list(next(iter(identities))) if identities else None


def envelope(record):
    timestamps = [value['timestamp'] for value in record['logs']]
    return (min([record['eventTimestamp'], *timestamps]),
            max([record['eventTimestamp'] + record['wallTime'], *timestamps]))


def stage_time(stages, name):
    values = [stage['at_ms'] for stage in stages if stage['stage'] == name]
    assert len(values) == 1, (name, len(values))
    return values[0]


def elapsed(stages, start, end):
    duration = stage_time(stages, end) - stage_time(stages, start)
    assert duration >= 0, (start, end, duration)
    return duration


def production_time(value):
    return value['crypto_started_at_ms']


all_pairs = set()
all_jobs = set()
extra_pairs = set()
extra_jobs = set()
report = {'arms': {}, 'limits': [
    'The fixed-order first pass is exploratory. Deployment, time, object placement and compilation history remain confounded.',
    'Fresh object IDs do not prove fresh physical hardware or an empty platform compilation cache.',
    'Module IDs and construction counters identify software instances, rather than physical hosts.',
    'Conditioning uses a separate public-input Wasm module, rather than production private AES.',
    'Equal logical auxiliary allocation does not equalize page residency, allocator state or compilation.',
    'CPU includes complete participant invocations. Stage durations are wall time, with clock precision limits.',
    'Conditioning cost includes A forwarding and B work. Front CPU is unmeasured; client conditioning elapsed includes its latency.',
    'Client restoration includes inventory polling and request round trips.',
    'The idle interval excludes client touches. Recovery alarms and platform eviction remain possible.',
    'Phase names describe planned order. Actual gaps and instance identities govern warm/reuse interpretation.',
    'These bounded replacement screens do not measure sustained signatures per minute or public SDK latency.',
]}
for arm in proof['arms']:
    name = arm['name']
    directory = 'measurements/' + name + '/'
    expected_ids = load(directory + 'expected-producer-ids.json')
    versions = {row['role']: row['version'] for row in load('deployments/' + name + '/receipts.json')}
    conditioned = load(directory + 'conditioning.json')
    assert conditioned['passed']
    result = {'conditioning': conditioned, 'blocks': {}, 'conditioning_invocations': []}
    instances = {role: [] for role in roles}
    previous_block_end = None
    for block in ['first', 'immediate-1', 'immediate-2', 'after-idle']:
        measured = load(directory + block + '/result.json')
        barrier = load(directory + block + '/complete-tails.json')
        assert measured['passed'] and barrier['routing_checked']
        for before, retired, after in zip(measured['initial'], measured['retired'], measured['final']):
            old = {bytes(value).hex() for value in before['paired']}
            final = {bytes(value).hex() for value in after['paired']}
            removed = {bytes(value).hex() for value in retired['batches']}
            fresh = final - old
            assert len(old) == len(final) == 16
            assert len(removed) == len(fresh) == 2 and removed <= old
            assert final == old - removed | fresh
        pairs = set(barrier['new_pairs'])
        jobs = set(barrier['jobs'])
        assert len(pairs) == 4 and len(jobs) == 2
        assert all_pairs.isdisjoint(pairs) and all_jobs.isdisjoint(jobs)
        all_pairs.update(pairs)
        all_jobs.update(jobs)
        data = {'client_restoration_ms': measured['endedAtMs'] - measured['retirementStartedAtMs'],
                'jobs': [], 'new_pairs': sorted(pairs),
                'client_started_at_ms': measured['startedAtMs'], 'client_ended_at_ms': measured['endedAtMs'],
                'gap_after_previous_block_ms': None if previous_block_end is None else measured['startedAtMs'] - previous_block_end}
        previous_block_end = measured['endedAtMs']
        data['exact_target_stock_snapshots'] = all(
            {bytes(value).hex() for value in stock['a']['ready']} ==
            {bytes(value).hex() for value in stock['b']['ready']} ==
            {bytes(value).hex() for value in stock['paired']}
            for stock in [*measured['initial'], *measured['final']])
        published = {'a': set(), 'b': set()}
        observed_slots = set()
        for job in sorted(jobs):
            candidates = [record for record in records if record['role'].startswith('preparer-a') and
                          any(stage['job'] == job and stage['stage'] == 'crypto_started'
                              for stage in record['preparation_stages'])]
            assert len(candidates) == 1
            role_a = candidates[0]['role']
            slot = 'secondary' if role_a.endswith('-secondary') else 'primary'
            observed_slots.add(slot)
            job_result = {'id': job, 'slot': slot, 'roles': {}}
            produced_by_role = {}
            for role in [role_a, role_a.replace('preparer-a', 'preparer-b')]:
                record = protocol_record(job, role)
                original = raw_protocol(job, role)
                assert record['version'] == versions[role]
                assert record['outcome'] == 'ok' and not record['logs_truncated']
                assert not record['exception_names']
                assert original['cpuTime'] == record['cpu_ms']
                stages = [stage for stage in record['preparation_stages'] if stage['job'] == job]
                role_letter = 'a' if role.startswith('preparer-a') else 'b'
                fresh = {stage['batch'] for stage in stages if stage['stage'] == 'published'}
                assert len(fresh) == 2 and fresh <= pairs
                if role_letter == 'a':
                    running = [value for value in record['producer_jobs']
                               if value['batch'] == job and value['stage'] == 'running']
                    assert len(running) == 1
                    assert set(running[0]['batches']) == fresh
                else:
                    assert record['refill_job']['batch'] == job
                    assert set(record['refill_job']['batches']) == fresh
                produced_by_role[role_letter] = fresh
                published[role_letter].update(fresh)
                startup = record['producer_startup']
                if role_letter == 'a':
                    assert len(startup) == 1
                    assert startup[0]['producer'] == expected_ids[slot]
                cache = [value for value in record['preparation_cache'] if value['job'] == job]
                assert {value['stage'] for value in cache} == {'started', 'prepared'}
                module = next(stage['module_instance'] for stage in stages if stage['stage'] == 'crypto_started')
                assert all(stage['module_instance'] == module for stage in stages)
                wrapped_identity = tag(original)
                assert bool(wrapped_identity) == arm['wrapped']
                instances[role].append({'block': block, 'job': job, 'module': module,
                                        'crypto_started_at_ms': stage_time(stages, 'crypto_started'),
                                        'wrapper_identity': wrapped_identity})
                job_result['roles'][role_letter] = {
                    'cpu_ms': record['cpu_ms'], 'provider_wall_ms': record['wall_ms'],
                    'module_instance': module, 'wrapper_identity': wrapped_identity,
                    'correlations_wall_ms': elapsed(stages, 'crypto_started', 'correlations_completed'),
                    'commitments_wall_ms': elapsed(stages, 'correlations_completed', 'crypto_completed'),
                    'publication_wall_ms': max(stage['at_ms'] for stage in stages if stage['stage'] == 'published')
                                           - stage_time(stages, 'crypto_completed'),
                    'crypto_start_at_ms': stage_time(stages, 'crypto_started'),
                    'publication_at_ms': max(stage['at_ms'] for stage in stages if stage['stage'] == 'published'),
                    'linear_memory_max_bytes': max(stage['wasm_linear_memory_bytes'] for stage in stages),
                    'startup': startup, 'cache': cache,
                    'transport': [value for value in record['preparation_transport'] if value['job'] == job],
                }
                if role_letter == 'a':
                    job_result['roles']['a']['activation_wall_ms'] = elapsed(stages, 'producer_running', 'crypto_started')
            assert produced_by_role['a'] == produced_by_role['b']
            job_result['paired_cpu_ms'] = sum(value['cpu_ms'] for value in job_result['roles'].values())
            data['jobs'].append(job_result)
        assert published['a'] == pairs == published['b']
        data['observed_slots'] = sorted(observed_slots)
        data['both_slots_used'] = observed_slots == {'primary', 'secondary'}
        data['paired_cpu_ms'] = sum(job['paired_cpu_ms'] for job in data['jobs'])
        result['blocks'][block] = data
    result['instances'] = instances
    for sample in conditioned['requests']:
        participant = sample['participant']
        suffix = '-secondary' if sample['slot'] == 'secondary' else ''
        sample_roles = ['preparer-a' + suffix]
        if participant == 'b':
            sample_roles.append('preparer-b' + suffix)
        for role in sample_roles:
            found = [record for record in raw[role] if record.get('event', {}).get('request', {})
                     .get('headers', {}).get('x-ml-dsa-request-id') == sample['requestId']]
            assert len(found) == 1, (name, role, sample['requestId'], len(found))
            record = found[0]
            assert record['scriptVersion']['id'] == versions[role]
            assert record['outcome'] == 'ok' and not record['exceptions'] and not record['truncated']
            first_match = None
            matched_blocks = []
            if role.startswith('preparer-' + participant):
                identity = [sample['result']['js_module_instance'], sample['result']['core_instance'], sample['result']['actor']]
                matched_blocks = [value['block'] for value in instances[role] if value['wrapper_identity'] == identity]
                earliest = min(instances[role], key=production_time) if instances[role] else None
                first_match = earliest is not None and earliest['wrapper_identity'] == identity
            result['conditioning_invocations'].append({'role': role, 'request': sample['requestId'],
                'kind': sample['kind'], 'cpu_ms': record['cpuTime'],
                'first_protocol_instance_match': first_match, 'matching_protocol_blocks': matched_blocks})
    result['conditioning_cpu_ms'] = sum(value['cpu_ms'] for value in result['conditioning_invocations'])
    result['conditioning_client_ms'] = conditioned['endedAtMs'] - conditioned['startedAtMs']
    first_measurement = load(directory + 'first/result.json')
    result['first_stock_component_sum_client_ms'] = result['conditioning_client_ms'] + result['blocks']['first']['client_restoration_ms']
    result['conditioning_to_retirement_gap_ms'] = first_measurement['retirementStartedAtMs'] - conditioned['endedAtMs']
    result['net_first_stock_client_ms'] = first_measurement['endedAtMs'] - conditioned['startedAtMs']
    result['net_first_stock_paired_cpu_ms'] = result['conditioning_cpu_ms'] + result['blocks']['first']['paired_cpu_ms']
    result['idle'] = load(directory + 'idle.json')
    assert result['idle']['ended_at_ms'] - result['idle']['started_at_ms'] >= 60000
    initial_pairs = {bytes(value).hex() for stock in first_measurement['initial'] for value in stock['paired']}
    assert len(initial_pairs) == 32 and initial_pairs <= material_expiries.keys()
    minimum_expiry = min(material_expiries[value] for value in initial_pairs)
    final_measurement = load(directory + 'after-idle/result.json')
    assert minimum_expiry > final_measurement['endedAtMs'] + 30000
    result['initial_stock_lifetime'] = {
        'all_pairs_from_normal_producer': True, 'pair_count': len(initial_pairs),
        'minimum_expiry_ms': minimum_expiry,
        'minimum_remaining_at_arm_end_ms': minimum_expiry - final_measurement['endedAtMs'],
    }
    result['idle_producer_alarms'] = []
    for role in roles:
        for record in raw[role]:
            if 'scheduledTime' not in record.get('event', {}):
                continue
            start, end = envelope(record)
            if max(start, result['idle']['started_at_ms']) < min(end, result['idle']['ended_at_ms']):
                actor_ids = sorted({value['producer'] for value in events(record) if 'producer' in value})
                result['idle_producer_alarms'].append({'role': role, 'envelope_start_ms': start,
                    'envelope_end_ms': end, 'cpu_ms': record['cpuTime'], 'outcome': record['outcome'],
                    'actor_ids': actor_ids, 'expected_actor_observed': bool(set(actor_ids) & set(expected_ids.values()))})
    expected_jobs = {job['id'] for block in result['blocks'].values() for job in block['jobs']}
    attempts = {'queued': set(), 'running': set()}
    actors = set(expected_ids.values())
    result['post_arm_actor_jobs_from_other_versions'] = []
    for record in records:
        for job in record['producer_jobs']:
            if job['producer'] in actors and job['stage'] in attempts:
                if record['version'] != versions.get(record['role']):
                    assert job['log_timestamp_ms'] > final_measurement['endedAtMs']
                    result['post_arm_actor_jobs_from_other_versions'].append({
                        'job': job['batch'], 'role': record['role'], 'version': record['version'],
                        'stage': job['stage'], 'at_ms': job['log_timestamp_ms']})
                    continue
                attempts[job['stage']].add(job['batch'])
    assert attempts['queued'] == attempts['running'] and expected_jobs <= attempts['running']
    result['extra_jobs'] = []
    for job in sorted(attempts['running'] - expected_jobs):
        candidates = [record for record in records if record['role'].startswith('preparer-a') and
                      any(stage['job'] == job and stage['stage'] == 'crypto_started'
                          for stage in record['preparation_stages'])]
        assert len(candidates) == 1
        role_a = candidates[0]['role']
        costs = {}
        outputs = {}
        for role in [role_a, role_a.replace('preparer-a', 'preparer-b')]:
            record = protocol_record(job, role)
            assert record['version'] == versions[role]
            assert record['outcome'] == 'ok' and not record['logs_truncated'] and not record['exception_names']
            costs[role] = record['cpu_ms']
            outputs[role] = {stage['batch'] for stage in record['preparation_stages']
                             if stage['job'] == job and stage['stage'] == 'published'}
        assert outputs[role_a] == outputs[role_a.replace('preparer-a', 'preparer-b')]
        assert all_pairs.isdisjoint(outputs[role_a]) and extra_pairs.isdisjoint(outputs[role_a])
        extra_pairs.update(outputs[role_a])
        extra_jobs.add(job)
        result['extra_jobs'].append({'job': job, 'cpu_ms_by_role': costs,
                                    'paired_cpu_ms': sum(costs.values()), 'pairs': sorted(outputs[role_a])})
    settlements = [value for record in records for value in record['refill']
                   if value['batch'] in attempts['running']]
    assert {value['batch'] for value in settlements} == attempts['running']
    assert all(value['published'] is True for value in settlements)
    result['attempt_accounting'] = {'queued': sorted(attempts['queued']),
                                    'running': sorted(attempts['running']),
                                    'settled_published': sorted(value['batch'] for value in settlements),
                                    'planned_jobs': sorted(expected_jobs),
                                    'all_attempts_accounted': True}
    result['control_qualification'] = {
        'balanced_first_block': result['blocks']['first']['both_slots_used'],
        'exact_target_stock_snapshots': all(value['exact_target_stock_snapshots'] for value in result['blocks'].values()),
        'equal_planned_job_history': not result['extra_jobs'],
        'after_idle_comparison_qualified': not result['extra_jobs'],
        'reason': 'Unplanned preparation changes warmup history.' if result['extra_jobs'] else 'No extra attempts observed.',
    }
    result['total_protocol_paired_cpu_ms'] = sum(value['paired_cpu_ms'] for value in result['blocks'].values())
    result['extra_paired_cpu_ms'] = sum(value['paired_cpu_ms'] for value in result['extra_jobs'])
    result['total_protocol_paired_cpu_ms'] += result['extra_paired_cpu_ms']
    report['arms'][name] = result

report['distinct_jobs'] = len(all_jobs)
report['distinct_pairs'] = len(all_pairs)
assert all_pairs.isdisjoint(extra_pairs) and all_jobs.isdisjoint(extra_jobs)
report['extra_jobs'] = len(extra_jobs)
report['extra_pairs'] = len(extra_pairs)
rejected = load('rejected-return/first/result.json')
rejected_pairs = set()
for before, after in zip(rejected['initial'], rejected['final']):
    rejected_pairs.update({bytes(value).hex() for value in after['paired']} -
                          {bytes(value).hex() for value in before['paired']})
rejected_jobs = {stage['job'] for record in records for stage in record['preparation_stages']
                 if stage['stage'] == 'published' and stage['batch'] in rejected_pairs}
assert len(rejected_pairs) == 4 and len(rejected_jobs) == 2
assert all_pairs.isdisjoint(rejected_pairs) and extra_pairs.isdisjoint(rejected_pairs)
rejected_costs = []
for job in sorted(rejected_jobs):
    costs = {}
    for role in roles:
        matched = [record for record in records if record['role'] == role and
                   any(stage['job'] == job and stage['stage'] == 'crypto_started'
                       for stage in record['preparation_stages'])]
        assert len(matched) <= 1
        if matched:
            record = matched[0]
            assert record['outcome'] == 'ok' and not record['logs_truncated'] and not record['exception_names']
            costs[role] = record['cpu_ms']
    assert len(costs) == 2
    rejected_costs.append({'job': job, 'cpu_ms_by_role': costs, 'paired_cpu_ms': sum(costs.values())})
report['rejected_return'] = {'jobs': rejected_costs, 'fresh_pairs': sorted(rejected_pairs),
                            'paired_cpu_ms': sum(value['paired_cpu_ms'] for value in rejected_costs)}
report['accounted_comparison_protocol_cpu_ms'] = sum(value['total_protocol_paired_cpu_ms'] for value in report['arms'].values()) + report['rejected_return']['paired_cpu_ms']
validation = load('cloud-driver/validation-final/traces.json')['records']
signatures = load('final-signatures.json')
assert signatures['passed']
report['signature_material'] = []
for case in signatures['cases']:
    operation = bytes(case['operation']).hex()
    taken = {'a': set(), 'b': set()}
    for record in validation:
        for value in record['material_stages']:
            if value['operation'] == operation and value['value']['stage'] == 'taken':
                taken[value['role']].add(value['value']['material_id'])
    assert taken['a'] and taken['a'] == taken['b']
    report['signature_material'].append({'wallet': case['wallet'], 'operation': operation,
                                         'paired_take_ids': sorted(taken['a'])})
report['comparison_capture_provider_outcomes'] = dict(Counter(record['outcome'] for record in records))
report['provider_exceptions'] = [{'role': record['role'], 'at_ms': record['event_timestamp_ms'],
    'outcome': record['outcome'], 'names': record['exception_names']}
    for record in records if record['outcome'] != 'ok' or record['exception_names']]
(base / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({name: {'blocks': {block: {'paired_cpu_ms': value['paired_cpu_ms'],
                    'client_restoration_ms': value['client_restoration_ms']} for block, value in arm['blocks'].items()},
               'conditioning_cpu_ms': arm['conditioning_cpu_ms'], 'conditioning_client_ms': arm['conditioning_client_ms']}
                  for name, arm in report['arms'].items()}, indent=2))
