import json
import subprocess
from pathlib import Path

base = Path('/private/tmp/ml-dsa-first-touch-20261028')
root = Path('/Users/pta/Dev/rust/seams-wallet/.worktrees/ml-dsa')
scope = json.loads((base / 'scope.json').read_text())
expected = {row['role']: row['version'] for row in json.loads((base / 'release/receipts.json').read_text())}
expected.update({row['role']: row['version'] for row in json.loads((base / 'deployments/plain-return/receipts.json').read_text())})

history = {}
for worker in scope['workers']:
    role = worker['role']
    result = subprocess.run([
        str(root / 'node_modules/.bin/wrangler'), 'deployments', 'list', '--json',
        '--config', str(base / (role + '.json')),
    ], cwd=root, capture_output=True, text=True)
    if result.returncode:
        raise SystemExit('Deployment history failed for ' + role)
    entries = json.loads(result.stdout)
    if isinstance(entries, dict):
        entries = entries['deployments']
    history[role] = []
    for entry in entries:
        versions = [{'version_id': version['version_id'], 'percentage': version['percentage']} for version in entry['versions']]
        history[role].append({'id': entry['id'], 'created_on': entry['created_on'], 'versions': versions})
    assert any(version['version_id'] == expected[role] for entry in history[role] for version in entry['versions'])
(base / 'deployment-history.json').write_text(json.dumps(history, indent=2) + '\n')
print(json.dumps({'matched_worker_versions': len(history)}))
